import Script from 'next/script';
const adsDefineSlot = (props) => {
        const {categoryNameURL} = props;
       
    return(
        <>

            <Script type="text/javascript" src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" async></Script>
            <Script dangerouslySetInnerHTML={{__html: `

                        var widthWindow = window.innerWidth;

                        var googletag = googletag || {};
                        googletag.cmd = googletag.cmd || [];
                        
                        googletag.cmd.push(function() {
                    
                            if(widthWindow >= 1024){
                                googletag.defineSlot('/13276288/Eng_Jagran/Desktop/Markets/listing/pagepush_980x50', [[980, 50], [728, 90], [980, 60], [980, 270]], 'al_pagepush_980x50').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/Eng_Jagran/Desktop/Markets/listing/top_300x250', [[300, 250], [300, 200], [250, 250]], 'al_top_300x250').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/Eng_Jagran/Desktop/Markets/listing/medium_300x250', [[300, 250], [300, 200], [250, 250]], 'al_medium_300x250').addService(googletag.pubads()); 
                            }
                            else{
                                googletag.defineSlot('/13276288/Eng_Jagran/Mobile/Markets/listing/top_320x50', [320, 50], 'al_top_320x50_m').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/Eng_Jagran/Mobile/Markets/listing/top_300x250', [[300, 250], [336, 280], [300, 200], [250, 250]], 'al_top_300x250_m').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/Eng_Jagran/Mobile/Markets/listing/medium_300x250', [[300, 250], [336, 280], [300, 200], [250, 250]], 'al_medium_300x250_m').addService(googletag.pubads());
                                googletag.defineSlot('13276288/Eng_Jagran/Mobile/Markets/listing/bottom_300x250', [[300, 250], [336, 280], [300, 200], [250, 250]], 'al_bottom_300x250_m').addService(googletag.pubads());
                            }
                            googletag.pubads().set("page_url", window.location.href);
                            googletag.pubads().collapseEmptyDivs();
                            googletag.pubads().setTargeting('Category', []);
                            googletag.enableServices();
                            
                            if(widthWindow >= 1024){
                                googletag.display('al_pagepush_980x50');
                                googletag.display('al_top_300x250');
                                //googletag.display('target-1');
                                //googletag.display('al_interstitial_1x1');
                            }else{ 
                                googletag.display('al_top_300x250_m');
                                //googletag.display('al_medium_300x250_m');
                                //googletag.display('al_bottom_300x250_m');
                                //googletag.display('al_interstitial_1x1_m');
                            }
                        
                        });

            ` }}  />

            <div className="eweb" id="hjdg"><div className="ads pagepush-980x50"><div id='al_pagepush_980x50'></div></div></div>
        </>
    )
}
export default adsDefineSlot;