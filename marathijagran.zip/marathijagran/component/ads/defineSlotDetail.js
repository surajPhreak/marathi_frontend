import Script from 'next/script';
const adsDefineSlot = (props) => {
       const {categoryNameURL, metaKeywords, tagData} = props;
       const metaKeywords1 = metaKeywords.replace(/'/g, '\&#39;')
       const tagsList = [];
       tagData.map(
            (data, index) => {   return tagsList.push(data.name)  }
       )
    return(
        <>

{/* <Script type="text/javascript" src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" async></Script> */}

            <Script dangerouslySetInnerHTML={{__html: `

                        var widthWindow = window.innerWidth;

                        var googletag = googletag || {};
                        googletag.cmd = googletag.cmd || [];

                        // function jsUcfirst(string){ return string.charAt(0).toUpperCase() + string.slice(1); }
                        // function categoryName(){
                        //     var pathname = window.location.pathname;
                        //     var res = pathname.split("/");
                        //     var catName = res[1];
                        //     return jsUcfirst(catName);
                        // }
                        // var categoryNameURL = categoryName();

                        // function getMetaKeywordsContent() { var metas = document.getElementsByTagName('meta');for (var i=0; i < metas.length; i++) {if (metas[i].getAttribute("name") == "keywords") {var value = metas[i].getAttribute("content").split(",").map(Function.prototype.call, String.prototype.trim);return value;}}return ''; }

                        googletag.cmd.push(function(){

                            if(widthWindow >= 1024){

                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/pagepush_980x50', [[980, 60], [728, 90], [980, 50], [980, 270]], 'al_pagepush_980x50').addService(googletag.pubads());
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/top_300x250', [[300, 250], [336, 280]], 'al_top_300x250').addService(googletag.pubads());
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/medium_300x250',[[300, 250], [336, 280]], 'al_medium_300x250').addService(googletag.pubads());
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/bottom_300x250', [[300, 250], [336, 280]], 'al_bottom_300x250').addService(googletag.pubads());
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/midarticle_480x320', [[300, 250], [336, 280], [320, 480], [480, 320]], 'midarticle_480x320').addService(googletag.pubads());
                                    // googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/lhs_160x600', [[160, 600], [120, 600]], 'al_lhs_160x600').addService(googletag.pubads());
                                    // googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/rhs_160x600', [[160, 600], [120, 600]], 'al_rhs_160x600').addService(googletag.pubads());
                                    googletag.defineSlot("${'/13276288/marathi_jagran/desktop/ros/detail/video_interstitial_1x1'}", [1, 1], 'al_video_interstitial_1x1').addService(googletag.pubads());
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/interstitial_1x1', [1, 1], 'al_interstitial_1x1').addService(googletag.pubads());
                                    
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/Innovation_1x1', [1, 1], 'innovation_1x1').addService(googletag.pubads());
                                    googletag.defineSlot('/13276288/marathi_jagran/desktop/ros/detail/InImage_1x1', [1, 1], 'inimage_1x1').addService(googletag.pubads());                            
                            }
                            else{

                                googletag.defineSlot('/13276288/marathi_jagran/mobile/ros/detail/top_300x250', [[300, 250], [336, 280]], 'al_top_300x250_m').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/marathi_jagran/mobile/ros/detail/medium_300x250',[[300, 250], [336, 280]], 'al_medium_300x250_m').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/marathi_jagran/mobile/ros/detail/bottom_300x250', [[300, 250], [336, 280]], 'al_bottom_300x250_m').addService(googletag.pubads());
                                googletag.defineSlot("${'/13276288/marathi_jagran/mobile/ros/detail/video_interstitial_1x1'}", [1, 1], 'al_video_interstitial_1x1').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/marathi_jagran/mobile/ros/detail/video_interstitial_1x1', [1, 1], 'al_interstitial_1x1_m').addService(googletag.pubads());
                                googletag.defineSlot('/13276288/marathi_jagran/mobile/ros/detail/sticky_320x50', [320, 50], 'al_sticky_320x50_m').addService(googletag.pubads());
                           
                                googletag.defineSlot('/13276288/marathi_jagran/mobile/ros/detail/medium_320x50',[[300, 50], [320, 75]], 'al_medium_300x50_m').addService(googletag.pubads());

                                googletag.defineSlot("${'/13276288/marathi_jagran/mobile/ros/detail/Innovation_1x1'}", [1, 1], 'innovation_mobile1x1').addService(googletag.pubads());
                                googletag.defineSlot("${'/13276288/marathi_jagran/mobile/ros/detail/InImage_1x1'}", [1, 1], 'inimage_mobile1x1').addService(googletag.pubads());

                            }
                            googletag.pubads().set("page_url", window.location.href);
                            googletag.pubads().collapseEmptyDivs();
                            googletag.pubads().setTargeting('Category', ['Detail Page', '${categoryNameURL}', '${metaKeywords1}', '${tagsList}']);
                            googletag.enableServices();
                           
                                if(widthWindow >= 1024){
                                    googletag.display('al_pagepush_980x50');
                                    googletag.display('al_top_300x250');
                                    // googletag.display('al_medium_300x250');
                                    // googletag.display('midarticle_480x320');
                                    // googletag.display('al_interstitial_1x1');
                                    // googletag.display('al_video_interstitial_1x1');
                                    // googletag.display('al_bottom_300x250');
                                    //  googletag.display('al_lhs_160x600');
                                    //  googletag.display('al_rhs_160x600');
                                    // googletag.display('al_medium_300x50');
                                }else{
                                    // googletag.display('al_top_300x250_m');
                                //     googletag.display('al_medium_300x250_m');
                                //     googletag.display('al_medium_300x50');
                                //    googletag.display('al_bottom_300x250_m');
                                //     googletag.display('al_interstitial_1x1_m');
                                //     googletag.display('al_interstitial_1x1');
                                //     googletag.display('al_video_interstitial_1x1');
                                }
                           

                        });
                        // if(widthWindow < 1024){	
                        //     window.googletag = window.googletag || { cmd: [] };
                        //     googletag.cmd.push(function() {
                        //     var slot = googletag.defineOutOfPageSlot("${'/13276288/marathi_jagran/mobile/ros/detail/Interstitial_Vignette'}", googletag.enums.OutOfPageFormat.INTERSTITIAL, );
                        //     if (slot) slot.addService(googletag.pubads());
                        //     googletag.enableServices();
                        //     googletag.display(slot);
                        //     });
                        // }

            ` }}  />

            <div className="eweb" id="hjdg"><div className="ads pagepush-980x50"><div id='al_pagepush_980x50'></div></div></div>
        </>
    )
}
export default adsDefineSlot;