export default function Interstitial() {
    return( 
        <>
            <div className="eweb"><div className="ads interstitial-1x1"><div id="al_interstitial_1x1"></div></div></div>
            <div className="emobile"><div className="ads interstitial-1x1"><div id="al_interstitial_1x1_m"></div></div></div> 
        </>
         )
}