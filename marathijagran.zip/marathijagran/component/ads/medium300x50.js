export default function Medium300x50(){
    return( <div className="eweb"><div className="ads medium-300x25"><div id="target-1"></div></div></div> )
}