export default function Medium300x250M(){
    return( <div className="emobile"><div className="ads medium-300x250"><div id="al_medium_300x250_m"></div></div></div> )
}