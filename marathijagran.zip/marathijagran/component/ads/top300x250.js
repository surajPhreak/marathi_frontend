export default function Top300x250(){
    return( <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div></div></div> )
}