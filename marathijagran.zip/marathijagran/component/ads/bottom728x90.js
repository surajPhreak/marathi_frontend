export default function Bottom728x90() {
    return( <div className="ads bottom-728x90 ewebf"><div id='al_bottom_728x90'></div></div> )
}