import React from 'react';

function Gutter(props) {
  return (
    <>
      <div id="HomePageGutterLHS" className="GutterAdsLHS webAds">
        <div id="al_lhs_160x600" className="adsView"></div>
      </div>

      <div id="HomePageGutterRHS" className="GutterAdsRHS webAds">
        <div id="al_rhs_160x600" className="adsView"></div>
      </div>
    </>
  );
}

export default Gutter;