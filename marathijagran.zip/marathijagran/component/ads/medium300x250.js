export default function Medium300x250(){
    return( <div className="eweb"><div className="ads medium-300x250"><div id="target-1"></div></div></div> )
}