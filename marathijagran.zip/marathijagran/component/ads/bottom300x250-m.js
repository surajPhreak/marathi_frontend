export default function Bottom300x250M(){ 
        return( <div className="emobile"><div className="ads bottom-300x250"><div id="target-6"></div></div></div> )
}