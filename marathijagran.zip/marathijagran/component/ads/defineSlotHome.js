import Script from 'next/script';
const adsDefineSlot = (props) => {
    const {metaKeywords} = props;

    return (
      <>
        {/* <Script type="text/javascript" src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" async></Script> */}
        <Script
          dangerouslySetInnerHTML={{
            __html: `
                var widthWindow = window.innerWidth;
                
                var googletag = googletag || {};
                googletag.cmd = googletag.cmd || [];
                
                function getMetaKeywordsContent(){
                var metas = document.getElementsByTagName('meta');for (var i=0; i < metas.length; i++) {if (metas[i].getAttribute("name") == "keywords") {var value = metas[i].getAttribute("content").split(",").map(Function.prototype.call, String.prototype.trim);return value;}}return '';}

                googletag.cmd.push(function(){

                    if(widthWindow >= 1024){
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/pagepush_980x50', [[980, 60], [980, 50], [728, 90], [980, 270]], 'al_pagepush_980x50').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/medium_728x90', [[980,60], [980, 50], [728, 90]], 'al_medium_728x90').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/bottom_728x90', [[980, 60], [980, 50], [728, 90]], 'al_bottom_728x90').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/top_300x250', [[300, 250], [336, 280]], 'al_top_300x250').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/medium_300x250', [[300, 250], [336, 280]], 'al_medium_300x250').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/bottom_300x250', [[300, 250], [336, 280]], 'al_bottom_300x250').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/interstitial_1x1', [1, 1], 'al_interstitial_1x1').addService(googletag.pubads());
                        // googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/lhs_160x600', [[169, 600], [120, 600]], 'al_lhs_160x600').addService(googletag.pubads());
                        // googletag.defineSlot('/13276288/marathi_jagran/desktop/home/homepage/rhs_160x600', [[169, 600], [120, 600]], 'al_rhs_160x600').addService(googletag.pubads());
                    }
                    else{
                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/top_300x250', [[300, 250], [336, 280]], 'al_top_300x250_m').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/top_300x100', [[320, 50], [320, 75],[320,100]], 'al_top_300x100_m').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/top_300x250_1', [[300, 250], [336, 228]], 'al_top_300x250_1_m').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/medium_300x250', [[300, 250], [336, 280]], 'al_medium_300x250_m').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/bottom_300x250', [[300, 250], [336, 280]], 'al_bottom_300x250_m').addService(googletag.pubads());
                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/sticky_320x50', [320,50], 'al_sticky_320x50_m').addService(googletag.pubads());

                        googletag.defineSlot('/13276288/marathi_jagran/mobile/home/homepage/interstitial_1x1', [1, 1], 'al_interstitial_1x1_m').addService(googletag.pubads());	
                    }

                    googletag.pubads().set("page_url", window.location.href);
                    googletag.pubads().collapseEmptyDivs();
                    googletag.pubads().setTargeting('Category', ['Home Page', 'home' ,'${metaKeywords}']);
                    googletag.enableServices();

                    if(widthWindow >= 1024){
                        googletag.display('al_pagepush_980x50');
                        googletag.display('al_top_300x250');
                        // googletag.display('al_lhs_160x600');
                        // googletag.display('al_rhs_160x600');
                        // googletag.display('al_medium_728x90');
                        // googletag.display('al_bottom_728x90');
                        // googletag.display('al_medium_300x250');
                        // googletag.display('al_bottom_300x250');
                        // googletag.display('al_interstitial_1x1');
                    }else{ 
                        // googletag.display('al_top_300x250_m');
                        // googletag.display('top_300x100_m');
                        // googletag.display('top_300x250_1_m');
                        // googletag.display('al_medium_300x250_m'); 
                        // googletag.display('al_bottom_300x250_m'); 
                        // googletag.display('al_interstitial_1x1_m'); 
                    }

                });
                
                // if(widthWindow < 1024){
                //     window.googletag = window.googletag || { cmd: [] };
                //     googletag.cmd.push(function() {
                //     var slot = googletag.defineOutOfPageSlot('/13276288/marathi_jagran/mobile/home/homepage/Interstitial_Vignettee', googletag.enums.OutOfPageFormat.INTERSTITIAL, );
                //     if (slot) slot.addService(googletag.pubads());
                //     googletag.enableServices();
                //     googletag.display(slot);
                //     });
                // }
                
            `,
          }}
        />
        <div className="eweb" id="hjdg">
          <div className="ads pagepush-980x50">
            <div id="al_pagepush_980x50"></div>
          </div>
        </div>
      </>
    );
}
export default adsDefineSlot;