export default function Bottom300x250(){ 
    return( <div className="eweb"><div className="ads bottom-300x250"><div id="al_bottom_300x250"></div></div></div> )
}