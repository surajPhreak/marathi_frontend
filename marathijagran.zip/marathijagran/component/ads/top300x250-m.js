export default function Top300x250M(){
    return( <div className="emobile"><div className="ads top-300x250"><div id="target-4"></div></div></div> )
}