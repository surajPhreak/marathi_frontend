import Script from 'next/script';
const TaboolaAdsHome = () => {

    return(
        <>           
            {/* Taboola */}
            <div id="taboola-below-home-thumbnails"></div>
            <Script type="text/javascript" dangerouslySetInnerHTML={{__html: `
          window._taboola = window._taboola || [];
              _taboola.push({homepage:'auto'});
              !function (e, f, u, i) {
                if (!document.getElementById(i)){
                  e.async = 1;
                  e.src = u;
                  e.id = i;
                  f.parentNode.insertBefore(e, f);
                }
              }(document.createElement('script'),
              document.getElementsByTagName('script')[0],
              '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
              'tb_loader_script');
              if(window.performance && typeof window.performance.mark == 'function')
              { window.performance.mark('tbl_ic'); }
              window._taboola = window._taboola || [];
              _taboola.push({
                mode: 'thumbnails-a',
                container: 'taboola-below-home-thumbnails',
                placement: 'Below Home Thumbnails',
                target_type: 'mix'
              });
              window._taboola = window._taboola || [];
              _taboola.push({flush: true});
            ` }}  />
            {/* Taboola */}
        </>
    )
}
export default TaboolaAdsHome;