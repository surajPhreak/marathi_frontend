import React from "react"
import { DomainPrefixes } from "../utils/ejConfig";
export const config = { amp: true };
export default function articleBody(props){
  const {articledetaildata} = props;
  const authorUrl =  (articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? " " : articledetaildata.authorUrl;
  const bigImage = articledetaildata.imagePath.split(',');
  var injectAds = " ";
  var paragrafArray = articledetaildata.ampBody.split('\n');

  paragrafArray.forEach((element , key) => {
    var pos = 0;
    var pos2 = 0;
    var pos3 = 0;
    var pos4 = 0;
    var pos5 = 0;
    var pos11 = 0;
  pos = element.search("https://amzn.to/");
  if(pos != 0 && pos != -1){
    var result = element.replace(`rel="nofollow"`, `rel="nofollow sponsored"`);
    paragrafArray[key]= result;
  }
  pos11 = element.search("https://www.amazon.in/");
  if(pos11 != 0 && pos11 != -1){
    let result = element.replace(`rel="nofollow"`, `rel="nofollow sponsored"`);
    paragrafArray[key]= result;
  }
  pos2 = element.search("<amp-img");
  pos3 = element.search("Buy Now");
  pos4 = element.search("Click Here");
  pos5 = element.search("Check Here");
  if(pos2 != 0 && pos2 != -1){
    var result = element.replace(`width="360" height="216"`, `width="650" height="540"`);
    paragrafArray[key]= result;
  }

  if(pos3 != 0 && pos3 != -1){
    
    element = element.replace(`rel="nofollow"`, `rel="nofollow sponsored"`);
    var result = element.replace(`Buy Now`, `<div class="center_click">Buy Now</div>`);
    paragrafArray[key]= result;
  }

  if(pos4 != 0 && pos4 != -1){
    element = element.replace(`rel="nofollow"`, `rel="nofollow sponsored"`);
    var result = element.replace(`Click Here`, `<div class="center_click">Click Here</div>`);
    paragrafArray[key]= result;
  }

  if(pos5 != 0 && pos5 != -1){
    element = element.replace(`rel="nofollow"`, `rel="nofollow sponsored"`);
    var result = element.replace(`Check Here`, `<div class="center_click">Check Here</div>`);
    paragrafArray[key]= result;
  }
  });
  
  injectAds = paragrafArray.join(" ");
  return (
    <>
      <div id="topHeading" className="topHeading">
          <h1>{articledetaildata.headline}</h1>
          <p>{articledetaildata.summary}</p>
      </div>
      <article className="detailBox">
      <div className="articleHd">
              <div className="dateInfo">
                <strong> Author: 
                  {(articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? ` ${articledetaildata.authorEng}` : <a href={DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl} title="English Jagran">{" " + articledetaildata.authorEng}</a>}
                </strong><br />
                <span className="fl">Updated Date: {(articledetaildata.modDate == undefined) || (articledetaildata.modDate == null) ? ' ' : articledetaildata.modDate }</span>
              </div>
            </div>
            <figure className="bodySummery">
                <amp-img src={(DomainPrefixes.ImagePath+bigImage[0] == undefined) || (DomainPrefixes.ImagePath+bigImage[0] == null) ? 'https://imgeng.jagran.com/images/2022/aug/jagran-new-media1659421108433.jpg' : DomainPrefixes.ImagePath+bigImage[0]} alt={articledetaildata.headline} height='675' width='1200' layout='responsive'></amp-img>
            </figure>
            <div className="articleBody" dangerouslySetInnerHTML={{ __html: injectAds }} />
            {/* <div className="authorname">Posted By: <strong><a href={DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl} title="English Jagran">{articledetaildata.authorEng}</a></strong></div> */}
      </article>
    </>
  )
}