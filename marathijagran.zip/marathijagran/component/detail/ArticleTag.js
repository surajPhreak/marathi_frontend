import React from 'react';
import { DomainPrefixes } from "../utils/ejConfig";

function ArticleTag(props) {
    const {articledata, routerUrl} = props;
   
    return (
        <>
        <div className="clearfix"></div>
        {
                    // <div className="tagList">
                    //     <span className='h3'>You May Like</span>
                    //     <ul>
                    //         {articledata.map((taglist,index) => {
                    //             return(
                    //             <li key={index}>
                    //                 <a href={"/tag/"+taglist.slug}>#{taglist.name}</a>
                    //             </li>
                    //             )
                    //         })
                            
                    //         }
                    //     </ul>
                    // </div>
                       
        }
        
         {/* { routerUrl.match('/sports') ?
            <div><div className="bannerBox">
    <a href="https://www.marathijagran.com/web-stories?utm_source=articledetail&utm_medium=banner&utm_campaign=webstorypush" title="Marathi Banner"> <img src={`${DomainPrefixes.ImagePath}2023/05/banner_marathi_web.jpg`} alt="Marathi Banner" /></a>
     </div>  
     <div className="mbannerBox">
        <a href="https://www.marathijagran.com/web-stories?utm_source=articledetail&utm_medium=banner&utm_campaign=webstorypush" title="Marathi Banner"> <img src={`${DomainPrefixes.ImagePath}2023/05/banner_marathi_mobile.jpg`} alt="Marathi Banner" /></a>
    </div> </div> : ''
    } */}
        </>
    );
}

export default ArticleTag;