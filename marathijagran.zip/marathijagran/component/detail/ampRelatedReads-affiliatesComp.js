import { DomainPrefixes } from "../utils/ejConfig";
export default function RelatedReads(props){
    const {relatedreadsdata} = props;
    return(
        <>
        <div className="relatedReads">
            <div className="h4">Related Reads</div>
            <ul>
              {relatedreadsdata.map( (value, index) => { if(index < 3){return  <li key={index}><a href={'/lite/top-deals/'+ value.categoryUrl+ '/'+ value.subCategoryUrl+ '/' +value.webTitleUrl + '-' + value.id} title={value.headline}>{value.headline}</a></li>}  })}
            </ul>
          </div>
          {/* <div className="adBox tabolabad"><amp-embed width='100' height='100' type='taboola' layout='responsive' data-publisher='jagrannewmedia-jagranenglish' data-mode='thumbs-feed-01' data-placement='Below Article Thumbnails AMP' data-target_type='mix' data-article='auto' data-feed-container-num='1' data-url=''></amp-embed></div>
          <div className="adBox tabolabad"><amp-embed width='100' height='100' type='taboola' layout='responsive' data-publisher='jagrannewmedia-jagranenglish' data-mode='thumbs-feed-01' data-placement='Below Article Thumbnails AMP' data-target_type='mix' data-article='auto' data-feed-container-num='2' data-url=''></amp-embed></div>
          <amp-sticky-ad layout='nodisplay'><amp-ad width='320' height='100'  type='doubleclick'  data-slot={'/13276288/Eng_Jagran/AMP/'+ relatedreadsdata[1].category.toLowerCase() +'/detail/sticky_320x50'} data-multi-size='320x75, 320x50' rtc-config='{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }}'></amp-ad></amp-sticky-ad> */}
        </>
    )
}