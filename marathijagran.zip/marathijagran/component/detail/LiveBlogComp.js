// import Bottom300x250M from "../ads/bottom300x250-m";
import { DomainPrefixes, formatDate, getFullTime } from "../../component/utils/ejConfig";
const LiveBlog = ({ liveblog, articledetaildata, tagsList,isAmp}) => {
  return (
    <>
{/* {isAmp!=false&&  <div class="adsBox300h"> 
  <amp-fx-flying-carpet height="300px"> 
   <amp-ad data-lazy-fetch="true" data-loading-strategy="2" width="300" height="300" type="doubleclick" data-slot="/13276288/Guj_Jagran/AMP/ros/detail/FlyingCarpet_300x600" data-multi-size="300x250"  rtc-config={`{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.category ? articledetaildata.category.replace(/'/g, "") :''}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }`} ></amp-ad> 
  </amp-fx-flying-carpet></div>} */}
      <div className="timeline">
        {/* <div class="date">20 March 2023</div> */}
        {liveblog &&
          liveblog.map((el,index) => {
            let time = el.liveblog_time.split(" ")[1];
            let date = el.liveblog_time.split(" ")[0];
            return (
              <>
              <div key={index} className="timeline-block">
               <span className="timeLineTime" style={{color:'#da251d'}}>{formatDate( el.liveblog_time)}, {getFullTime(el.liveblog_time)}</span> 

                <span className="h3">{el.live_blog_title}</span>
                <div className="blogcontent"><p dangerouslySetInnerHTML={{__html:el.live_blog_content}}></p></div>
                </div>
              {/* {index==2&& isAmp!=false&& <div class="ads">
                              <amp-ad data-lazy-fetch="true" data-loading-strategy='3' width="336" height="280"  type="doubleclick"  data-slot={'13276288/Guj_Jagran/AMP/ros/detail/medium_300x250'} data-multi-size="300x250" rtc-config={`{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.category?articledetaildata.category.replace(/'/g, ""): ''}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }`}></amp-ad>

                </div >} */}
              
                </>
            );
          })}
      </div>
      {/* {isAmp==false&&<Bottom300x250M />}
      
     {isAmp!=false&&   <div className="ads">
                <amp-ad data-lazy-fetch="true" data-loading-strategy='2' width="336" height="280"  type="doubleclick"  data-slot={'/13276288/Guj_Jagran/AMP/ros/detail/bottom_300x250'} data-multi-size="300x250" rtc-config={`{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.category?articledetaildata.category.replace(/'/g, ""): ''}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }`}></amp-ad>
            </div>} */}

    </>
  );
};

export default LiveBlog;
