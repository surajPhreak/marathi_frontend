//import React from "react"
import { DomainPrefixes } from "../utils/ejConfig";
import LiveBlogComp from './LiveBlogComp'
export const config = { amp: true };
export default function articleBody(props){
const {articledetaildata, urlRoughter, articleasloread,jsonObj} = props;
//const authorUrl = articledetaildata.authorEng.toLowerCase().split(' ').join('-');
const authorUrl =  (articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? " " : articledetaildata.authorUrl;
//const bigImage = articledetaildata.imagePath.split(',');
var injectAds = " ";
var paragrafArray = articledetaildata.ampBody.split('\n');

const tagsList = [];
articledetaildata.tags.map(
            (data, index) => {   return tagsList.push(data.name)  }
       );


//   if (paragrafArray[8]) {
//   paragrafArray.splice(7, 0, `<div class="ads"><amp-ad data-lazy-fetch="true" data-loading-strategy="3" width="336" height="280" type="doubleclick" data-slot="/13276288/marathi_jagran/amp/ros/detail/medium_300x250" data-multi-size="300x250" json='${jsonObj}' rtc-config='{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.categoryUrl.replace(/'/g, "")}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }'></amp-ad></div>`)
// }
//   if (paragrafArray[5] || paragrafArray[5]=='') {

//   paragrafArray.splice(4, 0, `<div class="ads"><amp-ad data-lazy-fetch="true" data-loading-strategy="3" width="336" height="280" type="doubleclick" data-slot="/13276288/marathi_jagran/amp/ros/detail/medium_300x250_1" data-multi-size="300x250" json='${jsonObj}' rtc-config='{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.categoryUrl.replace(/'/g, "")}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }'></amp-ad></div>`)
//   }
 
//   if (paragrafArray[12] || paragrafArray[12] == '') {
    
//   paragrafArray.splice(11, 0, `<div class="ads"><amp-ad data-lazy-fetch="true" data-loading-strategy="3" width="336" height="280" type="doubleclick" data-slot="/13276288/marathi_jagran/amp/ros/detail/bottom_300x250" json='${jsonObj}' rtc-config='{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.categoryUrl.replace(/'/g, "")}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }'></amp-ad></div>`)
//   } 


// if(paragrafArray[3]){
//   paragrafArray.splice(2, 0, `<div class="adsBox300h"> 
//   <amp-fx-flying-carpet height="300px"> 
//    <amp-ad data-lazy-fetch="true" data-loading-strategy="2" width="300" height="300" type="doubleclick" data-slot="/13276288/marathi_jagran/amp/ros/detail/FlyingCarpet_300x600" data-multi-size="300x600" json='${jsonObj}' rtc-config='{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }, "targeting":{"Category": ["AMP Article Detail","${articledetaildata.categoryUrl.replace(/'/g, "")}","${articledetaildata.keywords.replace(/'/g, "")}", "${tagsList}"]} }'></amp-ad> 
//   </amp-fx-flying-carpet></div>`)
// }



  injectAds = paragrafArray.join(" ");
  return (
    <>
    { articledetaildata.liveBlog &&  articledetaildata.liveBlog.length>0&&<div className="liveBlog"><b className="liveBlink"></b>Live Blog</div>}
      <div id="topHeading" className="topHeading">
          <h1>{articledetaildata.webTitle.replace(/(<([^>]+)>)/ig, '')}</h1>
          <p>{articledetaildata.summary}</p>
      </div>
      <article className="detailBox">
      <div className="articleHd">
              <div className="dateInfo">
                <strong> Author: 
                  {(articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? ` ${articledetaildata.authorEng}` : <a href={'/authors/'+ authorUrl} title="Marathi Jagran">{" " + articledetaildata.authorEng}</a>}
                </strong><br />
                  {/* <a href={DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl} title="English Jagran">{articledetaildata.authorEng}</a></strong><br /> */}
                <span className="fl">{(articledetaildata.pubDate==articledetaildata.modDate) ? articledetaildata.pubDate : ('Updated: '+articledetaildata.modDate)} </span>
              </div>
            </div>
            <figure className="bodySummery">
                <amp-img src={(DomainPrefixes.ImagePath+articledetaildata.imagePath == undefined) || (DomainPrefixes.ImagePath+articledetaildata.imagePath == null) ? 'https://imgeng.jagran.com/images/2022/aug/jagran-new-media1659421108433.jpg' : DomainPrefixes.ImagePath+articledetaildata.imagePath} alt={articledetaildata.headline} height='675' width='1200' data-hero layout='responsive'></amp-img>
            </figure>
            <div className="ads">
                <amp-ad data-lazy-fetch="true" data-loading-strategy='2' width="336" height="280"  type="doubleclick"  data-slot={'/13276288/marathi_jagran/amp/ros/detail/top_300x250'} data-multi-size="300x250" json={jsonObj} rtc-config='{"vendors": { "aps": {"PUB_ID": "600", "PUB_UUID": "ce6d367a-edd7-43d0-924f-91dc6130bd6b", "PARAMS":{"amp":"1"}} }}'></amp-ad>
            </div>
            <div className="articleBody" dangerouslySetInnerHTML={{ __html: injectAds }} />
            { articledetaildata?.liveBlog?.length>0&& <LiveBlogComp liveblog={ articledetaildata.liveBlog} />}
            <div className="clearfix"></div>
            {/* <div className="tagList">
                <h3>Tags</h3>
                <ul>
                    {articledetaildata.tags.map((taglist, index) => {
                        return(
                        <li key={index}>
                            <a href={"/tag/"+taglist.slug}>#{taglist.name}</a>
                        </li>
                        )
                    })
                    
                    }
                </ul>
            </div> */}
            {/* { urlRoughter.match('/sports') ?<div><div className="bannerBox">
            <a href="https://www.marathijagran.com/web-stories?utm_source=articledetail&utm_medium=banner&utm_campaign=webstorypush" title="Marathi Banner"> <img src={`${DomainPrefixes.ImagePath}2023/05/banner_Marathi_web.jpg`} alt="Marathi Banner" /></a>
     </div>  
     <div className="mbannerBox">
     <a href="https://www.marathijagran.com/web-stories?utm_source=articledetail&utm_medium=banner&utm_campaign=webstorypush" title="Marathi Banner"> <img src={`${DomainPrefixes.ImagePath}2023/05/banner_Marathi_mobile.jpg`} alt="Marathi Banner" /></a>
    </div> 
    </div>: '' } */}
            <div className="clearfix"></div>
            {/* <amp-sticky-ad layout="nodisplay" className="h-50"><amp-ad width="320" height="50"  type="doubleclick" data-slot={`/13276288/marathi_jagran/amp/ros/detail/sticky_320x50`} json={jsonObj} data-multi-size="320x50"></amp-ad></amp-sticky-ad> */}
            <div className="clearfix"></div>
            {/* <amp-sticky-ad layout="nodisplay"><amp-ad  width="320" height="100"  type="doubleclick" data-slot={`/13276288/Guj_Jagran/amp/ros/Detail/sticky_320x50`} data-multi-size="320x75,320x50"></amp-ad></amp-sticky-ad> */}
             {/* <div className="authorname">Posted By: <strong><a href={DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl} title="English Jagran">{articledetaildata.authorEng}</a></strong></div> */}
      </article>
    </>
  )
}