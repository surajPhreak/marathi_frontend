//import React, { useCallback, useRef } from 'react';
//import { Swiper, SwiperSlide } from 'swiper/react';
//import { Autoplay } from "swiper";
//import 'swiper/swiper.min.css';
import { DomainPrefixes } from "../utils/ejConfig";

 function ArticleRecommendation(props) {
 const {recommendation, articledata} = props
//     const sliderRef = useRef(null);
//   const handlePrev = useCallback(() => {
//     if (!sliderRef.current) return;
//     sliderRef.current.swiper.slidePrev();
//   }, []);

//   const handleNext = useCallback(() => {
//     if (!sliderRef.current) return;
//     sliderRef.current.swiper.slideNext();
//   }, []);

    return (
        <div>
 {!articledata.liveBlog ||
            (articledata?.liveBlog?.length == 0 && (
<div className="recommendationSwipe">
<div className='swiper-slide'>
           <ul>
{recommendation && recommendation.posts ?
                        recommendation.posts.map( (data,index) => {                           
                           const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';    
                            return(
                                articledata.id!=data.id?
                                    <li key={index}>
                                    <a href={'/'+data.categoryUrl+'/'+subcatt+data.webTitleUrl+'-'+data.id} 
                                  title={data.headline}>
                                  <figure>
                  <img src={`${DomainPrefixes.ImagePath}${data.imagePath}`} alt={data.headline} />
                    </figure>
                                     <div className="descauthor">
                                     <h5> {data.headline}</h5>
                                     {/* {<small>{data.summary}</small>} */}
                                  </div>
                                  </a>
                                  </li>
                                  :''
                            )
                           
                        }):""
                    }
 </ul>
   </div>
</div>

))}
{/* <div className="recommendationSwipe">
       
     
        <Swiper  breakpoints= {{
                        300: {
                          slidesPerView: 2,
                          spaceBetween: 20,
                        },
                        425: {
                          slidesPerView: 3,
                          spaceBetween: 40,
                        },
                        768: {
                            slidesPerView: 3,
                            spaceBetween: 40,
                          },
                       
                        }}
                        ref={sliderRef}
                    spaceBetween={10}
                    slidesPerView={3}
                    autoplay={{
                        delay: 4000,
                        pauseOnMouseEnter: true,
                        disableOnInteraction: false,
                      }}

                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                    modules={[Autoplay]} 
                    
                    >
                {recommendation && recommendation.posts ?
                        recommendation.posts.map( (data,index) => {                           
                           const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';    
                            return(
                                articledata.id!=data.id?
                                <SwiperSlide>
                                <div classNameName='swiper-slide' key={index}>
                                    <a href={'/'+data.categoryUrl+'/'+subcatt+data.webTitleUrl} 
                                  title={data.headline}>
                                  <figure>
                  <img src={`https://img.marathijagran.com/${data.imagePath}`} alt={data.headline} />
                    </figure>
                    </a>
                                  <a href={'/'+data.categoryUrl+'/'+subcatt+data.webTitleUrl} 
                                  title={data.headline}>
                                     <div classNameName="descauthor">
                                     <h5> {data.headline}</h5>
                                     {<small>{data.summary}</small>}
                                  </div>
                                  </a>
                                </div></SwiperSlide>:''
                            )
                           
                        }):""
                    }
               
               <div className="swiper-button-next" onClick={handleNext}></div>
                <div className="swiper-button-prev" onClick={handlePrev}></div>  
            </Swiper>


              <SwiperSlide>
                <div className='swiper-slide'>
              
                    <figure>
                  <img src="https://img.marathijagran.com/2023/06/Baba-Bageshwar-reaction-on-Sakshi-murder-case-1024x576.jpg" alt="" />
                    </figure>
                    <div className="descauthor">
                        <h5>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર</h5>
                    <small>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર, કહ્યું- આ જોઈને જેનું લોહી ઉકળે નહીં… </small>
                    </div>
                   
                </div>
                </SwiperSlide>
                <SwiperSlide>
                <div className='swiper-slide'>
              
                    <figure>
                  <img src="https://img.marathijagran.com/2023/06/Baba-Bageshwar-reaction-on-Sakshi-murder-case-1024x576.jpg" alt="" />
                    </figure>
                    <div className="descauthor">
                        <h5>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર</h5>
                    <small>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર, કહ્યું- આ જોઈને જેનું લોહી ઉકળે નહીં… </small>
                    </div>
                   
                </div>
                </SwiperSlide> 
                <SwiperSlide>
                <div className='swiper-slide'>
              
                    <figure>
                  <img src="https://img.marathijagran.com/2023/06/Baba-Bageshwar-reaction-on-Sakshi-murder-case-1024x576.jpg" alt="" />
                    </figure>
                    <div className="descauthor">
                        <h5>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર</h5>
                    <small>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર, કહ્યું- આ જોઈને જેનું લોહી ઉકળે નહીં… </small>
                    </div>
                   
                </div>
                </SwiperSlide>  
                <SwiperSlide>
                <div className='swiper-slide'>
              
                    <figure>
                  <img src="https://img.marathijagran.com/2023/06/Baba-Bageshwar-reaction-on-Sakshi-murder-case-1024x576.jpg" alt="" />
                    </figure>
                    <div className="descauthor">
                        <h5>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર</h5>
                    <small>સાક્ષીની હત્યા પર ગુસ્સે થયા બાબા બાગેશ્વર, કહ્યું- આ જોઈને જેનું લોહી ઉકળે નહીં… </small>
                    </div>
                   
                </div>
                </SwiperSlide>
               
          <style>`.recommendationSwipe{ padding-bottom:20px;}
.swiper-slide {width: 100%; clear:both; position: relative;} 
.swiper-slide{display: flex;justify-content:space-between; flex-wrap: wrap; width:100%; padding:4px; box-shadow:0 1px 6px 0 rgba(0,0,0,.16);background-color: #fff;border-radius: 4px;}
.swiper-slide .figure-img{clear: both;}
.swiper-slide figure{margin-right:10px;text-align: center; margin:0 auto;}
.swiper-slide figure img{width:100%; height:100px;object-fit: cover;}
.swiper-slide h5{font-weight:600;font-size:16px;margin:8px auto 0px;height: 70px;overflow: hidden;}
.swiper-slide small{color:var(--grey);}
.swiper-button-next,
.swiper-button-prev {position: absolute;top: 50%;transform: translateY(-50%);width:30px;height:30px;background-color: #fff;color: white;font-size: 20px; display: flex;align-items: center;justify-content: center;
border-radius:4px 0 0 4px;cursor: pointer; box-shadow:-1px 0 4px 0 rgba(0,0,0,.5);}
.swiper-button-next::after, .swiper-button-prev::after {
content: ''; display: inline-block; width: 10px; height: 10px;border-top: 2px solid #948e8e; border-right: 2px solid #948e8e;transform: rotate(45deg);}
.swiper-button-prev::after{transform: rotate(229deg);  }
.swiper-button-next {right:0px; z-index:99;}
.swiper-button-prev {left:0px;z-index:99; border-radius:0px 4px 4px 0px;}`</style>
    
    </div> */}
        </div>



       
    );
}

export default ArticleRecommendation;