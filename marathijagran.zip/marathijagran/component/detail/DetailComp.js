import { DomainPrefixes } from "../../component/utils/ejConfig";
import Script from "next/script";
import dynamic from "next/dynamic";
import Top300x250M from "../ads/top300x250-m";
// import Image from 'next/legacy/image'

//import Medium300x250M from "../ads/medium300x250-m";
import Bottom300x250M from "../ads/bottom300x250-m";
const LiveBlogComp = dynamic(() => import("./LiveBlogComp"));
function deatailPage(props){    
    const{articledata, relatedData} = props;

      
    //const imagePath = articledata.imagePath.split(',');
    var paragrafArray = articledata.body_new.split('\n');
   
    
    if (paragrafArray.length>=8){ paragrafArray.splice(8, 0, `<div id="videoplayer"></div><div id="recomdedArticle"></div>`) }
    // if (paragrafArray.length>=3) { paragrafArray.splice(3, 0, `<div id="recomdedArticle"></div>`) }
    if (paragrafArray.length>=5 ) {  paragrafArray.splice(5, 0, `<div class="ads ewebf" style="margin-bottom:20px"><div id="target-3"></div></div>`) }
    if (paragrafArray.length>=5) { paragrafArray.splice(5, 0, `<div class="ads emobilef"><div id="target-5"></div></div>`) }    
    if (paragrafArray.length>=10) { paragrafArray.splice(10, 0, `<div class="ads emobilef"><div id="target-11"></div></div>`) }
    if (paragrafArray.length>=12) { paragrafArray.splice(12, 0, `<div class="ads emobilef"><div id="target-12"></div></div>`) }
    if (paragrafArray.length>=14) { paragrafArray.splice(14, 0, `<div class="ads emobilef"><div id="target-13"></div></div>`) }
    if (paragrafArray.length>30) { paragrafArray.splice(30, 0, `<div class="ads emobilef"><div id="target-17"></div></div>`) }
   
    
    let rel1 = paragrafArray.findIndex(elemnt => elemnt.match('<p id="rel1"></p>'));
    let rel2 = paragrafArray.findIndex(elemnt => elemnt.match('<p id="rel2"></p>'));
    //var rel1ImagePath = articleasloread[0].imagePath.split(',');
    //var rel2ImagePath = articleasloread[1].imagePath.split(',');



    var articleBody = paragrafArray.join(' ');
    
    return(
        <>
<div className="topLabel">
        {articledata.liveBlog && articledata.liveBlog.length > 0 && (
          <div className="liveBlog">
            <div style={{ animationDelay: -3 + "s" }} className="circle"></div>
            <div style={{ animationDelay: -2 + "s" }} className="circle"></div>
            <div style={{ animationDelay: -1 + "s" }} className="circle"></div>
            <div style={{ animationDelay: 0 + "s" }} className="circle"></div>
            LIVE BLOG
          </div>
        )}
      </div>
      {articledata?.label && (
        <div className="post_label">{articledata.label}</div>
      )}
        <div className="article-head">
            <h1>{articledata.webTitle!=null||articledata.webTitle!=undefined?articledata.webTitle.replace(/(<([^>]+)>)/ig, ''):''}</h1>
            <p className="short">{articledata.summary}</p>
        </div>
        <article id="article" className="limited">
            <div className="article-top-content">
                <div className="autor">
                    <span>By: {(articledata.authorName === "Author") ? (<a href={'/authors/'+articledata.authorUrl} tittle={articledata.authorEng}>{articledata.editedBy}</a>) : (articledata.authorName)}</span> 
                    {!articledata.liveBlog ||
                   (articledata?.liveBlog?.length == 0 && ( 
                    <span>Edited By: <a href={'/authors/' + articledata.authorUrl} title={articledata.authorEng}>{articledata.editedBy}</a> 
                    </span>
                  ))}
                        
                        
                      

                    {/* <span>Edited By: {articledata.authorName != null ? articledata.editedBy != null ? <a href={'http://localhost:3001/' + 'authors/' +articledata.authorUrl}>{articledata.editedBy} </a> : articledata.editedBy : ''}</span> */}

                   {/* <span>Edited By: 
                    {articledata.authorName != null 
                        ? articledata.editedBy != null 
                        ? <a href={'http://localhost:3001/' + 'authors/' + articledata.authorUrl}>{articledata.editedBy}</a> 
                        : articledata.editedBy 
                        : ''}
                    </span> */}

                   {articledata.liveBlog && articledata.liveBlog.length > 0 && (
                    
                   <span>Publish Date: {(articledata.pubDate)}</span>
                    )}
                    <span>Updated Date: {(articledata.pubDate == articledata.modDate)? articledata.pubDate : (articledata.modDate) }</span>

                   
                    {/* <div className="readingtime"><span id="time"></span> Minute Read</div> */}
                    </div>
                    {!articledata.liveBlog ||
            (articledata?.liveBlog?.length == 0 && (
                    <div className="googleNews"
                            // onClick={() => datalayerClickEvent('detail_social_links', 'google_news', 'article')}
                        ><a href="https://news.google.com/publications/CAAqBwgKMPOSqgwwhZO3BA?hl=en-IN&gl=IN&ceid=IN:en" target="_blank" rel="noreferrer" title="Google News"><span><svg><use href="/sprite.svg#googleNews"></use></svg></span><small>Google News</small></a></div>
                    ))}
            </div>
            {/* <figure className="main-img"><Image id="jagran_image_id" width={1200} height={675} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+articledata.largeImage} alt={articledata.webTitleUrl} data-imgurl={DomainPrefixes.ImagePath+articledata.largeImage} /></figure> */}
            <figure className="main-img"><img id="jagran_image_id" width={1200} height={675} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+articledata.largeImage} alt={articledata.webTitleUrl} data-imgurl={DomainPrefixes.ImagePath+articledata.largeImage} /></figure>
            
            
            {/* <div className="ads emobilef">
                <div id="target-9"></div>
            </div> */}
            <Top300x250M />
            {/* <Medium300x250M /> */}
            <div className="articleBody" dangerouslySetInnerHTML={{__html: articleBody}} />
           
            
     
            <div className="clearfix"></div>
            {/* <div className="ads emobilef"><div id="target-13"></div></div>  */}
            {/* <h3>About The Author</h3> */}
             {/* <div className="autor-profile authorProfile">
                    <div className="profile">
                        <div className="left-col">
                             <figure><img src={AuthorProfile1.user_image} alt={AuthorProfile1.authorName} /></figure>
                             <a href={'/authors/'+articledata.authorUrl}  title={articledata.authorName}><figure><img src={`https://img.marathijagran.com/${articledata.authorImage}`} alt={articledata.authorName} /></figure></a>
                        </div>
                        <div className="right-col">
                            <h2><a href={'/authors/'+articledata.authorUrl} title={articledata.authorName}>{articledata.authorName}</a></h2>
                             <div className="editorLft">
                                 <ul className="autor-social">
                                     <li className="fb-btn"><a target="_blank" rel="noreferrer" href={articledata.authorFBUrl} title={articledata.authorName}><svg className="icon"><use href="#3225194-facebook"></use></svg></a></li>
                                     <li className="tw-btn"><a target="_blank" rel="noreferrer" href={articledata.authorTwitterUrl} title={articledata.authorName}><svg className="icon"><use href="#3225183-twitter"></use></svg></a></li>
                                     <li className="lin-btn"><a target="_blank" rel="noreferrer" href={articledata.authorLnkedinUrl} title={articledata.authorName}><svg className="icon"><use href="#3225190-linkedin"></use></svg></a></li>
                                 </ul>
                           </div>
                       </div>
                   </div>
                    <div className="authoeDesc"><p>{articledata.authorAbout}</p></div>
                </div> */}
                      
            <div className="clearfix"></div>  
          
            <div className="clearfix"></div>
            <Bottom300x250M />
            <div className="ads eweb"><div id="target-10"></div></div>
             {articledata.liveBlog && articledata.liveBlog.length > 0 && (
            <LiveBlogComp
                liveblog={articledata.liveBlog}
                articledetaildata={articledata}
                isAmp={false}
            />
            )}

        </article>

        <div id="social-break" className="tagList1"></div>
        <div className="pianobox eweb" id="paywall"></div>


        <div className="social social-div" id="socialIconM">
            <ul className="social-ul">
                <li className="fb">
                    <a title="Facebook" rel="nofollow noopener" target="_blank" href="https://www.facebook.com/sharer.php?u=https://www.marathijagran.com/india/himachal-election-results-2022-cm-jai-ram-thakur-concedes-defeat-as-congress-crosses-majority-mark-10056778">
                        <svg><use href="#facebook"></use></svg>
                    </a>
                </li>
                <li className="tw">
                    <a title="Twitter" rel="nofollow noopener" target="_blank" href="https://twitter.com/share?url=https://www.marathijagran.com/india/himachal-election-results-2022-cm-jai-ram-thakur-concedes-defeat-as-congress-crosses-majority-mark-10056778">
                        <svg><use href="#twitter"></use></svg>
                    </a>
                </li>
                <li className="whatsapp">
                    <a title="Whatsapp" target="_self" href="https://api.whatsapp.com/send?text=https://www.marathijagran.com/india/himachal-election-results-2022-cm-jai-ram-thakur-concedes-defeat-as-congress-crosses-majority-mark-10056778"> <svg><use href="#whattsApp"></use></svg></a>
                </li>
                <li className="play-icon">
                    <a title="play open app" href="https://play.google.com/store/apps/details?id=com.marathijagran.twa" target="_blank"><svg className="icon"><use href="#openappIcon"></use></svg></a>
                </li>
                <li className="shbtn">
                    <a title="Share Handle" href="#" className="share-btn">
                        <svg><use href="#share-post"></use></svg>
                    </a>
                </li>
            </ul>
        </div>
        <Script dangerouslySetInnerHTML={{__html: `
            document.addEventListener("copy", function (event) {
                var select = document.getSelection();
                var secle = window.location.href;
                event.clipboardData.setData('text/plain', "" + secle);
                event.preventDefault();
            });
            // function readingTime() {
            //     const text = document.getElementById("article").innerText;
            //     const wpm = 225;
            //     const words = text.trim().split(/\s+/).length;
            //     const time = Math.ceil(words / wpm);
            //     document.getElementById("time").innerText = time;
            // }
            // readingTime();
        ` }}  />
        </>
    )
}
export default deatailPage;