import React, { useEffect, useState } from "react";

function RelatedTag(props) {
  const { relatedData, articledata } = props;
  const [listing, setListing] = useState(
    relatedData && relatedData.posts ? relatedData.posts : []
  );
  const handleResize = () => {
    var widthWindow = window.innerWidth;
      if (widthWindow < 1024) {
          let list = listing.filter((l)=>l.id!=articledata.id).map((el, index) => {
              if (index > 3  ) {

          return { ...el, isHide: true };
        }
        return el;
      });
      setListing(list);
    } else {
      let list = listing.map((el, index) => {
        return { ...el, isHide: false };
      });
      setListing(list);
    }
  };
  useEffect(() => {
    window.addEventListener("resize", handleResize, false);
    handleResize()
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return (
    <div>
      <div className="LazyLoad is-visible">
        <div className="relatedReads">
          <div className="h4">Related Reads</div>
          <ul>
            {listing
              ? listing.map((data, index) => {
                  if (data.isHide == true) {
                    return;
                  }
                  const subcatt = data.subcategoryUrl
                    ? data.subcategoryUrl.split(" ").join("-") + "/"
                    : "";
                  return articledata.id != data.id ? (
                    <li key={index}>
                      <a
                        href={
                          "/" +
                          data.categoryUrl +
                          "/" +
                          subcatt +
                          data.webTitleUrl+
                          "-" +
                          data.id
                        }
                        title={data.headline}
                      >
                        {data.headline}
                      </a>
                    </li>
                  ) : (
                    ""
                  );
                })
              : ""}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default RelatedTag;
