import Script from "next/script";
function Actfeeedbackcomp(props){   
    return(
        <>
                <div className="feedbackPage">
                        <div className="column_left">
                       
                            <div className="redmarkerright"></div>
                            <div className="clear"></div>
                        </div>
                        <div className="right_column">
                            <div className="subpages">
                                <div className="submenuhead" id="ctl00_ctlSubMenu1_lblSubmenuHead"><h1>Actionable Feedback</h1></div>
                            </div>
                            <div className="staticContent">                           
                            <h3>Mission Statement</h3>



<p>To Produce Factual and Credible Content to Empower New India Through Knowledge, Information and Voice towards Better Health, Better Education, and Better Growth leading to an Inclusive and Progressive Society.</p>



<h3><strong>Message from the Editor</strong></h3>



<p>Jagran New Media (JNM) is the digital wing of Jagran Prakashan Ltd (JPL), India’s leading media and communications conglomerate, with its interests spanning across Print, OOH, Activations, Radio and Digital. JPL is a listed firm and publishes the world’s largest read daily, Dainik Jagran, along with India’s Largest FM Radio Network – Radio City.</p>



<p>At JNM, journalists create and publish online news and informational content with the stated aim of informing, educating and helping the users to take better life decisions. Our portfolio includes 9 digital platforms which provide content across genres like news, education, lifestyle, entertainment, health and youth.</p>



<p>Our editorial mission is driven by the commitment to provide factual and credible content which can enable the ‘New Bharat’ or the share of ‘next billion’ in India. To this end, we tirelessly work to produce original and authentic content that meets the expected standards of Expertise, Authority and Trustworthiness.</p>



<p>Our team is trained under Google News Initiative on fact-checking and news verification and incorporates these learnings in their daily news creation. It is also certified by the Poynter Institute for Fact Checking and launched India’s First Fact Check Website in Hindi – Vishvas News.</p>



<h3>Our Business</h3>



<p>JNM publishes multimedia content which includes, over 7000 plus stories and 50 videos in a day, which majorly covers categories like National – International News, Hyperlocal activities, Business, Auto, Technology, Sports, Entertainment – Movies reviews, School, College, Career, Govt Jobs, GK, Exam Prep Info, Health, Ayurveda, Food , Style, Wellness, Travel, Women Issues &amp; Astrology etc.</p>



<p>Jagran New Media focuses on creating and sharing helpful, relevant and factual content that inspires, educates, helps to solve problems and entertains the readers. Jagran New Media provides meaningful content to the consumers through DATA DRIVEN JOURNALISM. Jagran New Media journalists follow an ethics and process manual, led by pre-defined processes and news formats for news gathering and publishing.</p>



<p>Currently, Jagran New Media has a reach of over 72+ Million users (Comscore MMX Multi- Platform; August 2019) and 55.5 Million Video Views.</p>



<h3>How our Journalists work</h3>



<h3>Ethics Policy</h3>



<p><strong>A. Responsible journalism</strong>Ensuring high editorial standards is central to everything Jagran New Media journalists do at Jagran New Media. Jagran New Media believes that a combined and coordinated effort from reporters, editors and producers is needed to achieve good quality journalism. It is their responsibility to present an error-free and top quality report to the audience. A successful editor tells the reporters about every aspect of the report, so that the reporters can present a holistic picture in their coverage.</p>



<p>At Jagran New Media, reporters, sub-editors, content writers and desk shift in-charges in all centers carefully check all editorial material before publication, and only then is it made live on websites. In cases where it is needed, the shift in-charge publishes the copy only after consulting the editor and getting his/her approval.</p>



<p><strong>B. Non-partisanship</strong></p>



<h3>Corrections Policy</h3>



<p>JNM welcomes suggestions and rectifications which we receive from our readers in the form of comments, mails and phone calls. In case JNM receives any complaint regarding accuracy of our content, the JNM desks immediately put it on hold and determine the facts. Once the facts have been cross-examined, JNM takes a considered decision and appropriately respond to the feedback.</p>



<p>Depending on the authenticity and magnitude of the mistake/error, JNM removes/edits the published information or duly inform the reader in case the original news does not qualify as a mistake and how JNM News Desk arrived at such a decision.</p>



<p>As per the correction policy, JNM has strengthened its fight against misinformation and created a team to do fact checking regularly and monitor the content flow on our websites. Jagran New Media’s fact-checking Unit – Vishvas News – actively does fact checking work. Vishvas News is certified by the International Fact Checking Network (IFCN). In case of any appeal or feedback, Jagran New Media takes note of the details provided, does the correction/corrections following our SOP and editorial guidelines and also puts on record the stories done by the team members which needed corrections.</p>



<h3>Coverage Priorities</h3>



<p>Jagran New Media aims to reshape the online Hindi news segment in the Hindi Heartland with a compelling customer experience and user engagement. For the Thinking Man segment, the primary focus is on politics, states, common man issues, international, business, finance and sports. For the students and the youth, our primary focus is on providing authentic Education and Career related news and information along with specialized features on overall personality development and life skills. For the Women segment, our main focus is on Career, Food and Recipes, Fashion, Health, Fitness, Travel, Tourism, Bollywood and TV. For the benefits of the tabloid surfers, Jagran New Media focuses on the content production in states and cities segment.</p>



<p>Jagran websites produce real-time news coverage, analysis, feature-based stories, knowledge-based stories to enable the youth of the country, expert-based How-to content in a contemporary and easy to use format to widen the thinking of the readers.</p>



<h3>Diverse Voices Statement</h3>



<p>Jagran New Media is committed to pursuing accurate, fair and balanced coverage and believe that diversity and inclusion in sourcing and in hiring are critical for us to deliver a balanced news file. From an editorial standpoint, JNM believes that including diverse voices from the community in its coverage serves our readers and improves the balance in its journalism. Our Editorial motto is ‘Empowering the New Bharat’.</p>



<h3>Diverse Staffing and Policy</h3>



<p>JNM is committed to upholding its content quality and profitability and efficiency of the group websites by attracting and on-boarding the most suitable candidates for the role irrespective of their caste, creed, ethnic origin, religion, gender, age, sexual orientation, marital status or disability.</p>



<p>JNM hires based on merits including relevant experience, previous performance, aptitude and ability. JNM does not make hiring decisions based on gender, sexual orientation, age, religion, disability, race, gender reassignment, marital status, pregnancy or other characteristics purely of a personal nature.</p>



<p>JNM is an equal opportunity employer and takes pride in being certified as a Great Place to Work which provides equal opportunity to all employees. The workplace has a healthy representation of women not only in the editorial team but across all verticals. Many women occupy responsible positions at entry, mid, senior as well as executive leadership levels with significant responsibilities including strategy formulation and P&amp;L portfolios.</p>



<p><strong>– Users are our employers</strong></p>



<h3>Anonymous Sources Policy</h3>



<p>Under Jagran New Media’s policies and guidelines, content from anonymous sources may be used only if:</p>



<ul><li>The content is information, and not opinion or speculation, and is vital to the news report.</li><li>The information is not available except under the conditions of anonymity imposed by the source.</li><li>The source is reliable, and in a position to have accurate information.</li><li>Jagran New Media strictly believes in identifying sources whenever feasible. The public is entitled to as much information as possible on sources’ reliability.</li><li>JNM reporters/news writers/Editors cannot take information from anonymous sources without the approval of their reporting managers.</li><li>JNM believes in using information from anonymous sources to tell important stories that would otherwise go unreported.</li></ul>



<h3>Actionable Feedback</h3>



<p>Jagran New Media encourages meaningful conversations between News writers/Reporters/Editors, Reviewers, readers and senior JNM management groups. JNM is committed to engaging with its readers and taking action based on their suggestions, complaints, and other feedback.</p>



<p>Readers may help us develop an individual story or line of coverage, answer questions that a story may raise, identify related or under-covered issues, and teach us about new and diverse sources, experts, and perspectives. We believe that news organisations have a responsibility to engage with the public on the values, issues, and ideas of the times and those news organizations have much to gain in return.</p>



<ul><li>About Us : A page dedicated to discussing a news source coverage and/or agenda, also providing access to third-party social media websites (Facebook), where readers can have a more direct and informal relationship with the Jagran New Media News team.</li><li>Complaints: A dedicated link-form for complaints, which is easily available in every article page of our websites. This page provides our users with a direct response system to request any errors, suggestions, or corrections to the article.</li><li>Comments in the story page_ Readers have an option to comment on each article on JNM websites. All the comments are moderated by the news desk. JNM has the right to edit or cancel comments, messages and content submitted by readers.</li><li>A defined channel dedicated to discussing a news source coverage and/or agenda, also providing access to third-party social media websites (Facebook), where readers can have a more direct and informal relationship with the Blasting News team.</li><li>User feedback stories: In particular, the direct feedback system, easily accessible from every Blasting News article page, is a key element of our editorial standing. Blasting News provides its users with a direct feedback system, easily accessible from every Blasting News’ article page, to report any error, suggestion or request for adjustment for each article.</li><li>Article updates: Updates to articles based on audience comments/feedback.</li></ul>
 
                        </div>
                    </div>
                    <div className="clear"></div>
                </div>
                <script src="https://code.jquery.com/jquery-3.6.2.min.js"></script>
                <script id="my-script" dangerouslySetInnerHTML={{__html: `

                var referer = document.referrer;
                var r_uri = location.pathname + location.search;
                if (referer.indexOf("google") > 0 || referer.indexOf("bing") > 0) {
                    history.pushState(null, null, r_uri);
                    window.addEventListener('popstate', function (event) {
                        window.location.assign("https://english.jagran.com/?itm_source=backbutton");
                    });
                }
                $(document).ready(function () {
                    $('.tdata').hide();
                    $('.latestnewsTabs ul li').removeClass('current');
                    $('.latestnewsTabs ul li').eq(0).addClass('current');
                    $('.latestnewsTabs ul li a').click(function (e) {
                        e.preventDefault();
                        $('.latestnewsTabs ul li').removeClass('current');
                        $('.tdata').hide();
                        $(this).parent().addClass('current');
                        var showcontent = $(this).attr('rel');
                        $('#' + showcontent).show();
                    });
                    $('.latestnewsTabs ul li:first-child a').trigger('click');
                });

                ` }}  ></script>
        </>
    )
}
export default Actfeeedbackcomp;