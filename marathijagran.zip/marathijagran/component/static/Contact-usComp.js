import Script from "next/script";
function Contactuscomp(props){   
    return(
        <>
                <div className="contactUsPage">                        
                        <div className="right_column">
                            <div className="subpages">
                                <div className="submenuhead" id="ctl00_ctlSubMenu1_lblSubmenuHead"><h1>Contact Us</h1></div>
                            </div>
                            <div className="staticContent contus"> 
                            <div className="stBox">  
                            <h3>Editorial Team</h3>
                            <p>Marathi Jagran<br />Plot No, C-1, 2001, 20th floor
,<br />Tower B, WTT, Sector 16,
<br />Noida, Uttar Pradesh 201301
</p>
                            <p>E-mail:&nbsp;<a href="mailto:editor@jagrannewmedia.com"></a>
                            <a href="mailto:marathijagran@jagrannewmedia.com">Marathijagran@jagrannewmedia.com</a>
                            </p>
                            </div>
                            <div className="stBox">  
                            <h3>Corporate office</h3>
                            <p><strong>Jagran Prakashan Limited</strong><br />Jagran Building, 2, Sarvodaya Nagar<br />Kanpur – 208005</p>
                            <p><strong>Phone:</strong><br />0512 2216161<br />0512 2216162<br />0512 2216163</p>   
                            <p>E-mail:&nbsp;<a href="mailto:jagrancorp@jagran.com">jagrancorp@jagran.com</a></p>
                            </div>
                            <div className="stBox">
                            <h3>Secretary &amp; Registered office</h3>
                            <p><strong>Mr Amit Jaiswal</strong><br />Company Secretary<br />Jagran Prakashan Limited<br />Jagran Building, 2, Sarvodaya Nagar<br />Kanpur – 208005</p>
                            <p><strong>Phone:</strong><br />0512 2216161<br />0512 2216162<br />0512 2216163</p>
                             </div>   
                        </div>
                    </div>
                    <div className="clear"></div>
                </div>
                <script src="https://code.jquery.com/jquery-3.6.2.min.js"></script>
                <script id="my-script" dangerouslySetInnerHTML={{__html: `

                var referer = document.referrer;
                var r_uri = location.pathname + location.search;
                if (referer.indexOf("google") > 0 || referer.indexOf("bing") > 0) {
                    history.pushState(null, null, r_uri);
                    window.addEventListener('popstate', function (event) {
                        window.location.assign("https://english.jagran.com/?itm_source=backbutton");
                    });
                }
                $(document).ready(function () {
                    $('.tdata').hide();
                    $('.latestnewsTabs ul li').removeClass('current');
                    $('.latestnewsTabs ul li').eq(0).addClass('current');
                    $('.latestnewsTabs ul li a').click(function (e) {
                        e.preventDefault();
                        $('.latestnewsTabs ul li').removeClass('current');
                        $('.tdata').hide();
                        $(this).parent().addClass('current');
                        var showcontent = $(this).attr('rel');
                        $('#' + showcontent).show();
                    });
                    $('.latestnewsTabs ul li:first-child a').trigger('click');
                });

                ` }}  ></script>
        </>
    )
}
export default Contactuscomp;