import Script from "next/script";
function Aboutuscomp(props){   
    return(
        <>
                <div className="aboutUsPage">
                        
                        <div className="right_column">
                            <div className="subpages">
                            <div className="submenuhead" id="ctl00_ctlSubMenu1_lblSubmenuHead"><h1>About Us</h1></div>
                            </div>
                            <div className="staticContent">
                           
                            <p><a target="_blank" href="https://jnm.digital/" rel="noreferrer noopener"><strong>Jagran New Media</strong></a>&nbsp;is the digital wing of the&nbsp;<strong>Jagran Prakashan Limited</strong>&nbsp; India's leading media and communications group with its interests spanning across Print, OOH, Activations, Radio and Digital. Jagran.com is the flagship brand of the Jagran New Media and is the No.1 Hindi News and Information site in India (Source: comScore MoMX Multi- Platform; Aug 2018).</p>



<p>Jagran.com is the online version of the world's largest read daily newspaper - Dainik Jagran, with 29.6 Million users (comScore MMX Multi- Platform; Aug 2018). The site aims to reshape the online Hindi news segment in Hindi Heartland with a compelling customer experience and user engagement.</p>


<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_24.jpg" alt="Daink Jagran"/></figure>
<p>Dainik Jagran is the flagship brand of the company. In today's dynamic media world , where consumers have an unprecedented array of choices, Dainik Jagran stands out as a brand that is the choice of millions of Indians as they start their day. With a readership of 5.59 cr, it has been the largest read daily of India for the last consecutive 21 rounds of the Indian Readership Survey (IRS). With 37 editions, Dainik Jagran covers 11 states of India. It has also been declared by the World Association of Newspapers (WAN) as the Largest read daily in the world. Not just the largest read, Dainik Jagran has also been voted as the Most Credible Source of News in a BBC-Reuters survey.</p>


</div>




<p>The genesis for Dainik Jagran was in the year 1942. The year when the freedom struggle of India reached its crescendo and found expression in the “Quit India movement”. Dainik Jagran was launched during this time with the vision of our founder Shri Puran Chandra Gupta, to “Create a newspaper that would reflect the free voice of the people” . This vision was as much a reflection of the time when it was propounded as much as it is relevant to us today. Even as on today, when Dainik Jagran markets control the political destiny of the largest democracy in the world, the vision continues to guide us.</p>


<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_25.gif" alt="INext Live"/><figcaption><a target="_blank" href="http://www.inext.co.in/" rel="noreferrer noopener">http://www.inext.co.in</a></figcaption></figure>
<p>i-next, India's fastest growing compact daily in bilingual format, has caught on to the pulse of the Young at Heart. In a very short span of time, it has captured the imagination of people who look out for newer opportunities and seek deeper probes into the more relevant issues of changing India of today. It now covers 12 prominent cities in 4 states of India through its various editions and infrastructure. The readership of I Next is an impressive 22 Lakhs as per Latest IRS. It distinctly stands apart from its competitors due to its beautiful packaging of news, attractive layout design and the versatility of news and features. These accomplishments have made I next the pulse of today's Youthful India wherever it's present.</p>

</div>




<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_26.jpg" alt="City Plus"/><figcaption><a target="_blank" href="http://www.jagrancityplus.com/" rel="noreferrer noopener">http://www.jagrancityplus.com</a></figcaption></figure>
<p>City Plus is the Weekly English Tabloid from the group. It is an English News-Information-Entertainment paper with 31 editions from Delhi, NCR, Bangalore, Pune, Mumbai and Hyderabad ,targeting premium geographic localities. An aesthetically designed all colour newspaper editorially cover a variety of topics from Food, Fashion, Lifestyle, etc. Apart from this, it also has reader interactivity through Contests, Coupons, Puzzles, Quiz, Crossword, Games, Polls, Suggestions.</p>


</div>



<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_82.jpg" alt="Mid Day"/></figure>

<p>City Plus is the Weekly English Tabloid from the group. It is an English News-Information-Entertainment paper with 31 editions from Delhi, NCR, Bangalore, Pune, Mumbai and Hyderabad ,targeting premium geographic localities. An aesthetically designed all colour newspaper editorially cover a variety of topics from Food, Fashion, Lifestyle, etc. Apart from this, it also has reader interactivity through Contests, Coupons, Puzzles, Quiz, Crossword, Games, Polls, Suggestions.</p>

</div>



<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_83.jpg" alt="Mid Day"/></figure>
<p>MiD-DAY Marathi is the Marathi Tabloid from Jagran Prakashan Ltd. With its unique content and engaging activities, it caters to the affluent Marathi Community of Mumbai. It is positioned as a complete family newspaper with content for everyone. Apart from the other areas, the newspaper also has a dedicated business segment focusing on share market as majority of the community trade in these markets.</p>

</div>




<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_84.jpg" alt="Inquilab"/></figure>
<p>Inquilab is India's No.1 Urdu Newspaper with a readership of 7 L.<br />Inquilab has 12 editions covering Maharashtra, Delhi &amp; UP and is further expanding.<br />Inquilab made its appearance in 1938. An underground newspaper during the freedom struggle<br />Mr. Abdul Hamid Ansari, a freedom fighter, wanted to use the medium of Urdu to educate the Muslims and fight against British rule<br />In the post-independence scenario, Inquilab shifted focus, concentrating on social reforms, education and employment as well as addressing the problems faced by the Muslim community.<br />Renowned columnists like Kuldip Nayyar, Bharat Jhunjhunwala, Shamim Tarique &amp; Zafer Agha contributing to Inquilab. As the lodestone of a publishing house Inquilab stands tall in modern India. We continue to live in revolutionary times and Inquilab – ‘Revolution' continues to be in the vanguard.</p>
</div>




<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_86.jpg" alt="Mid Day"/></figure>
<p>Nai Dunia is a leading Hindi daily being published from Madhya Pradesh and Chhattisgarh. The newspaper was launched in 1947 and has, over the years, attained a pre-eminent status as a Hindi daily in the print media in Madhya Pradesh and Chhattisgarh. Naidunia has multiple editions published from Indore, Gwalior, Jabalpur and Bhopal in Madhya Pradesh and Raipur and Bilaspur in Chhattisgarh. Placed amongst the Top 10 Hindi newspapers in India, and has been one of the fastest growing newspapers in the market.</p>

</div>




<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_30.jpg" alt="Sakhi"/></figure>
<p>Sakhi is a premium women's magazine targeted at upwardly mobile &amp; outgoing women in the upper segment of the socio-economic class. The Sakhi reader retains her cultural values but is contemporary and modern in her outlook. The magazine also highlights the role of women in modern times &amp; helps them in coping with the outside world.</p>
</div>





<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_27.gif" alt="Jagran Engage"/></figure>
<p>Jagran Engage is the OOH division of JPL which specializes in Out of Home media solutions across India. Jagran Engage covers 900 + towns spread across 370 districts in 27 states. Engage offers comprehensive Out-Of-Home (OOH) solutions to prospects &amp; customers through its bouquet of offerings of Hoardings &amp;Billboards, Unique Street Furniture, Transit &amp; Mobile Media besides innovative &amp; ambient to suit specific client requirements.</p>
</div>





<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_28.gif" alt="Jagran Solution"/></figure>
<p>Jagran Solutions is the division that leads work in the Below the Line Marketing Solutions or Experiential Marketing area . Jagran Solutions has been at the forefront of transformation; transforming imagination into realities &amp; ideas into beliefs. Awarded with numerous awards at various national and international platform like PMAA &amp; AIPA, Jagran Solutions specializes in providing versatile, complete and measurable solutions in ensuring an immersive, interactive and experiential integrated marketing plan applicable to activations, corporate events, conventions, product launches, meetings, conferences, exhibitions and contests.</p>
</div>





<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_32.gif" alt="Jagran Pehel"/></figure>
<p>As a responsible corporate citizen, JPL supports a specifically dedicated organization, Pehel to discharge its social responsibilities and provide social services such as organizing workshops/seminars to voice different social issues, health camps/roadshows for creating awareness on the social concerns and helping underprivileged masses. Pehel is working with various national and international organizations such as World Bank on various projects to effectively discharge the responsibilities entrusted by the company. The company has also been assisting trusts and societies dedicated to the cause of promoting education, culture, healthcare, etc.</p>

</div>




<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_33.gif" alt="Jagran international"/></figure>
<p>Jagran International is the international division of JPL responsible for marketing JPL products outside of India. Amongst other things, develops country reports for India, and works with our international associates to develop India Reports in markets like Ireland, UK, South Africa, Australia and New Zealand.<br /><br /></p>
</div>





<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_29.jpg" alt="Jagran"/></figure>
<p>The group foray into the internet space has been through “jagran.com” which is the largest Hindi portal its category. We have entered into a strategic alliance with Yahoo India to launch a co-branded site. This we believe will reshape the online Hindi news and current affairs landscape — in terms of compelling customer experience and user engagement. Jagran.com is the largest language site in India with over 60 mn page views/month with 37 pages per visitor and a unique user base of 1.6 mn per month</p>

</div>




<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_34.gif" alt="Jagran foundation"/></figure>
<p>Under the banner of Jagran Foundation there are a series of initiatives that would help towards the larger cause of nation building. The first in the series of such initiatives is Jagran Forum – our first step towards “Thought Leadership”. The 1st Jagran Forum was on Democracy, Development and Social Inclusion. The 2nd Forum was on “Democracy and Conflict Resolution in Asia”. The 3rd Forum was on “Democracy : Challenges of Consensus Building”. All were attended by dignitaries from across India and the World including the Prime Minster and Vice President of India.</p>
</div>





<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_75.gif" alt="Jagran Research"/></figure>
<p>Jagran Research Centre (JRC) was established in May, 1996 as independent and premier multidisciplinary research &amp; consulting organization. JRC is also involved in publishing reference books and magazines. These books include Jagran Yearbooks, Country and Statewise statistical databank, Jagran Josh monthly magazine and others.</p>
</div>





<div className="wp-block-image">
<figure className="alignleft"><img decoding="async" src="https://www.jagran.com/Resources/jagran/images/GroupCompany_Logo_85.gif" alt="Jagran Punjabi" /></figure>
<p>Punjabi Jagran, the Punjabi language daily of Jagran.<br />The Punjabi language is very widely used in Punjab – and this runs across all the Pop Strata of Punjab. The language has great acceptance in the region, and it therefore makes an automatic choice for us to complete our bouquet for Punjab. With the launch of Punjabi Jagran, we hope to add newer readers, newer markets and strengthen the Jagran presence in complete Punjab.</p>
</div>






<p>JPL has grown consistently over the last 15 years though expansion and launch of newspaper brands across various states and languages and at the same time also made successful forays into other media like Magazines, Outdoor, Below the Line Marketing Solutions, Internet and Mobile Value Added Services. Apart from having the scale and size across every media platform, JPL has the objective of being the most professional communications solutions provider across every platform.</p>



<p>Jagran Prakashan Limited is a media conglomerate with interests spanning across printing and publication of newspapers &amp; magazines, FM Radio, Digital, Outdoor Advertising and Promotional marketing / Event management / on ground activation businesses.</p>



<p>For detailed information you may direct them to&nbsp;<strong>jplcorp.in</strong></p>
                           

 
                        </div>
                    </div>
                    <div className="clear"></div>
                </div>
                <script src="https://code.jquery.com/jquery-3.6.2.min.js"></script>
                <script id="my-script" dangerouslySetInnerHTML={{__html: `

                var referer = document.referrer;
                var r_uri = location.pathname + location.search;
                if (referer.indexOf("google") > 0 || referer.indexOf("bing") > 0) {
                    history.pushState(null, null, r_uri);
                    window.addEventListener('popstate', function (event) {
                        window.location.assign("https://english.jagran.com/?itm_source=backbutton");
                    });
                }
                $(document).ready(function () {
                    $('.tdata').hide();
                    $('.latestnewsTabs ul li').removeClass('current');
                    $('.latestnewsTabs ul li').eq(0).addClass('current');
                    $('.latestnewsTabs ul li a').click(function (e) {
                        e.preventDefault();
                        $('.latestnewsTabs ul li').removeClass('current');
                        $('.tdata').hide();
                        $(this).parent().addClass('current');
                        var showcontent = $(this).attr('rel');
                        $('#' + showcontent).show();
                    });
                    $('.latestnewsTabs ul li:first-child a').trigger('click');
                });

                ` }}  ></script>
        </>
    )
}
export default Aboutuscomp;