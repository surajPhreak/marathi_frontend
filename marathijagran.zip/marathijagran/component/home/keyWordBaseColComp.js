import { DomainPrefixes } from "../../component/utils/ejConfig";
//import Image from "next/image";
const keyBasedNews = (props) => {
    const {categoryData} = props;
    //console.log(categoryData);
    return(
        <div className="master-div">
            <div className="allhead"><h2><a href={'/'+categoryData[0].category.toLowerCase()} title={categoryData[0].category.toLowerCase()}>{categoryData[0].category}</a></h2></div>
            <ul className="list">
                {
                    categoryData.map( (data, index) => { 
                        const ImpPath = data.imagePath.split(',');
                        return(              
                        <li className="article" key={index}>                            
                            <figure><a href={'/'+categoryData[index].category.toLowerCase()+'/'+data.webTitleUrl+'-'+data.id} title={data.headline}>
                                <img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                            <div className="summary">
                                {/* <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.categoryName}</span></span></div> */}
                                <p><a href={'/'+categoryData[index].category.toLowerCase()+'/'+data.webTitleUrl+'-'+data.id} title={data.headline}>{data.headline}{(data.webTitleUrl.match('-lb-'))?(<b className="liveBlink"></b>):""}</a></p>
                            </div>
                        </li>)                
                     })
                }
            </ul>
        </div>
    )
}
export default keyBasedNews;