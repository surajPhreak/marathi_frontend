import { DomainPrefixes } from "../../component/utils/ejConfig";

function poneNews(props){
    const{homePoneData} = props;
    // console.log('homePoneData',homePoneData)
    function removeLastId(str) {
      const reLast = /-\d+$/;
    
      //console.log(str.replace(reLast, ""));
      //console.log(str.replace(reLast, ""));
      return str.replace(reLast, "");
    }
    return(
        <>
                          {
                    homePoneData.map( 
                      (data, index) => { 
                        const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';
                        if(index < 1){ return(

                          <div className=" article" key={index}>
                            <figure><a title={data.headline} href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+data.imagePath} alt={data.headline} /></a></figure>
                            <div className="hero-story summary ">
                                <h2>
                                  <a title={data.headline} href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}
                                  {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}</a>
                                </h2>
                                <div className="timestemp text-uppercase">
                                    <span className="label"><span className="red"><a className="red" href={'/'+data.categoryUrl||''}>{data.category} </a></span></span>
                                </div>
                            </div>
                          </div>

                        ) }
                      } 
                      )
                  }
                  
              
              <div className="main-story">
                  <div className="article secart emobile"><div className="ads top-300x250"><div id="target-6"></div></div></div>
                  {
                    
                    homePoneData.map( 
                      (data, index) => { 
                        const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';
                        if(index > 0){ return(

                          <div className="article secart" key={index}>

                            <div className="h3">
                                <h2>
                                  <a title={data.headline} href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}
                                  {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}</a>
                                  <div className="timestemp text-uppercase">
                                    <span className="label"><span className="red"><a className="red" href={'/'+data.categoryUrl||''}>{data.category}</a> </span></span>
                                  </div>
                                </h2>
                                <figure><a title={data.headline} href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+data.imagePath} alt={data.headline} /></a></figure>
                            </div>
                            
                          </div>

                        ) }
                      } 
                      )
                  }
              </div>
        </>
    )
}
export default poneNews;