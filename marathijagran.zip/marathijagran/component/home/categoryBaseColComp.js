import { DomainPrefixes } from "../../component/utils/ejConfig";
import Image from 'next/legacy/image'
const categoryBaseColComp = (props) => {
    const {categoryData, compHeadTxt} = props;
    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    return(
            <div className="list-article">
                <div className="master-div">
                <div className="allhead"><h2><a href={`/${categoryData[0].categoryUrl}${categoryData[0].subcategoryUrl!=''?'/'+categoryData[0].subcategoryUrl:''}`} title={categoryData[0].category}>
                {(compHeadTxt!=null && compHeadTxt!=undefined) ? compHeadTxt : categoryData[0].category}
                </a></h2></div>

                <ul className="list">
                    {
                        categoryData.map( (data, index) => { 
                            //const ImpPath = data.imagePath.split(',');
                            
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';
                            return(              
                            <li className="article" key={index}>                            
                                <figure><a href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id} title={data.headline}>
                                    <Image width={100} height={100} unoptimized src={DomainPrefixes.ImagePath+data.imagePath} alt={data.headline} /></a></figure>
                                <div className="summary">
                                    {/* <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.subcategory?data.subcategory:data.category}</span>{data.pubDate}</span></div> */}
                                    <p><a href={'/'+data.categoryUrl+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id} title={data.headline}>{data.headline}
                                    {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}</a></p>
                                </div>
                            </li>)                
                        })
                    }
                </ul>
                </div>
            </div>
    )
}
export default categoryBaseColComp;