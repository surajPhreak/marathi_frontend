import { DomainPrefixes } from "../../component/utils/ejConfig";
//import Image from "next/legacy/image";
import Image from "next/image";
import LoadMore from "../loadMore";
const categoryBasedNews = (props) => {
  const { categoryData, compHeadTxt,type,categoryUrl } = props;

  function removeLastId(str) {
    const reLast = /-\d+$/;

    //console.log(str.replace(reLast, ""));
    //console.log(str.replace(reLast, ""));
    return str.replace(reLast, "");
  }
  return (
    <div className="master-div">
      <div className="head-load-more">
        {categoryData && categoryData[0] && (
          <div className="allhead">
                      <h2>
            {type=='tag'?   <a
                href={`/tag/${categoryUrl}`}
                title={compHeadTxt != null && compHeadTxt != undefined
                    ? compHeadTxt
                    : categoryData[0].category}
              >
                {compHeadTxt != null && compHeadTxt != undefined
                  ? compHeadTxt
                  : categoryData[0].category}
              </a>:   <a
                href={`/${categoryData[0].categoryUrl}${
                  categoryData[0].categoryUrl != "maharashtra" &&
                  categoryData[0].categoryUrl != "sports" &&
                  categoryData[0].categoryUrl != "omg" &&
                  categoryData[0].categoryUrl != "religion"
                    ? categoryData[0].subcategoryUrl != ""
                      ? "/" + categoryData[0].subcategoryUrl
                      : ""
                    : ""
                }`}
                title={categoryData[0].category}
              >
                {compHeadTxt != null && compHeadTxt != undefined
                  ? compHeadTxt
                  : categoryData[0].category}
              </a>}
            
            </h2>
          </div>
        )}
        <LoadMore />
      </div>

      <ul className="list">
        {categoryData &&
          categoryData.map((data, index) => {
            const subcatt = data.subcategoryUrl
              ? data.subcategoryUrl.split(" ").join("-") + "/"
              : "";
            return (
              <li className="article" key={index}>
                <figure>
                  <a
                    href={
                      "/" +
                      data.categoryUrl +
                      "/" +
                      subcatt +
                      removeLastId(data.webTitleUrl) +
                      "-" +
                      data.id
                    }
                    title={data.headline}
                  >
                    <Image
                      width={100}
                      unoptimized
                      height={100}
                      src={DomainPrefixes.ImagePath + data.imagePath}
                      alt={data.headline}
                    />
                  </a>
                </figure>
                <div className="summary">
                  <div className="timestemp text-uppercase">
                    <span className="label">
                      <a
                        href={`/${data.categoryUrl}/${data.subcategoryUrl}`}
                        className="red"
                      >
                        {data.subcategory ? data.subcategory : data.category}
                      </a>
                      {/* {data.pubDate} */}
                    </span>
                  </div>
                  <p>
                    <a
                      href={
                        "/" +
                        data.categoryUrl +
                        "/" +
                        subcatt +
                        removeLastId(data.webTitleUrl) +
                        "-" +
                        data.id
                      }
                      title={data.headline}
                    >
                      {data.headline}
                      {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                      {/* {data.webTitleUrl.match("-lb-") ? (
                        <b className="liveBlink"></b>
                      ) : (
                        ""
                      )} */}
                    </a>
                  </p>
                </div>
              </li>
            );
          })}
      </ul>
    </div>
  );
};
export default categoryBasedNews;
