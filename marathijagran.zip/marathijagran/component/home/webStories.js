//import Image from "next/image";
function webStories(props){
    const { webStoriesData } = props;
    return(   
        <div className="master-div">
            <div className="allhead"><h2><span><a title="Web Stories News" href="https://www.marathijagran.com/web-stories?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints">वेब स्टोरीज</a></span>
                <a title="Web Stories See More" className="btn btn-primary" href="https://www.marathijagran.com/web-stories?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints">Load More</a>
            </h2></div>
            <div id="webStory" className="swiper webStory">
                <ul className="web-story swiper-wrapper">
                    {webStoriesData&& 
                        webStoriesData.records[0].data_list.map( (data, index) => {
                            if (index < 6) {
                            return(
                                <li className="swiper-slide" key={index}>
                                    <figure><a href={data.link} title={data.title}><img width={183} height={326} src={data.img} alt={data.title} /></a></figure>
                                    <div className="caption">
                                        <span>{data.category}</span>
                                        <p><a href={'https://www.marathijagran.com/web-stories/'+data.url+".html"} title={data.title}>{data.title}</a></p>
                                    </div>
                                </li>
                            )
                            }
                        } )
                    }
                </ul>
            </div>
        </div>
    )
}
export default webStories;