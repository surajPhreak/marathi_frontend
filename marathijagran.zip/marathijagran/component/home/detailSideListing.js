import { DomainPrefixes } from "../../component/utils/ejConfig";
//import Image from "next/legacy/image";
import Image from "next/image";
import LoadMore from "../loadMore";
import { useEffect, useState } from "react";
const DetailSideListing = (props) => {
  const { categoryData, compHeadTxt } = props;
  const [catList, setListing] = useState(categoryData);
  function removeLastId(str) {
    const reLast = /-\d+$/;
    return str.replace(reLast, "");
  }
  const handleResize = () => {
    var widthWindow = window.innerWidth;
    if (widthWindow < 1024) {
        let list = catList.map((el, index) => {
        if (index > 2) {
          return { ...el, isHide: true };
        }
        return el;
      });
      setListing(list);
    } else {
      let list = catList.map((el, index) => {
        return { ...el, isHide: false };
      });
      setListing(list);
    }
  };
  useEffect(() => {
    if (compHeadTxt == "महाराष्ट्र") {
        window.addEventListener("resize", handleResize, false);
        handleResize()
    }
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return (
    <div className="master-div">
      <div className="head-load-more">
        {categoryData && categoryData[0] && (
          <div className="allhead">
            <h2>
              <a
                href={`/${categoryData[0].categoryUrl}${
                  categoryData[0].categoryUrl != "maharashtra" &&
                  categoryData[0].categoryUrl != "sports" &&
                  categoryData[0].categoryUrl != "omg" &&
                  categoryData[0].categoryUrl != "religion"
                    ? categoryData[0].subcategoryUrl != ""
                      ? "/" + categoryData[0].subcategoryUrl
                      : ""
                    : ""
                }`}
                title={categoryData[0].category}
              >
                {compHeadTxt != null && compHeadTxt != undefined
                  ? compHeadTxt
                  : categoryData[0].category}
              </a>
            </h2>
          </div>
        )}
        <LoadMore />
      </div>

      <ul className="list">
        {catList &&
          catList.map((data, index) => {
            const subcatt = data.subcategoryUrl
              ? data.subcategoryUrl.split(" ").join("-") + "/"
              : "";
            if (data.isHide == true) {
                return
            }
            return (
              <li className="article" key={index}>
                <figure>
                  <a
                    href={
                      "/" +
                      data.categoryUrl +
                      "/" +
                      subcatt +
                      removeLastId(data.webTitleUrl) +
                      "-" +
                      data.id
                    }
                    title={data.headline}
                  >
                    <Image
                      width={100}
                      unoptimized
                      height={100}
                      src={DomainPrefixes.ImagePath + data.imagePath}
                      alt={data.headline}
                    />
                  </a>
                </figure>
                <div className="summary">
                  <div className="timestemp text-uppercase">
                    <span className="label">
                      <a
                        href={`/${data.categoryUrl}/${data.subcategoryUrl}`}
                        className="red"
                      >
                        {data.subcategory ? data.subcategory : data.category}
                      </a>
                      {/* {data.pubDate} */}
                    </span>
                  </div>
                  <p>
                    <a
                      href={
                        "/" +
                        data.categoryUrl +
                        "/" +
                        subcatt +
                        removeLastId(data.webTitleUrl) +
                        "-" +
                        data.id
                      }
                      title={data.headline}
                    >
                      {data.headline}
                      {data.webTitleUrl.match("-lb-") ? (
                        <b className="liveBlink"></b>
                      ) : (
                        ""
                      )}
                    </a>
                  </p>
                </div>
              </li>
            );
          })}
      </ul>
    </div>
  );
};
export default DetailSideListing;
