function topNews(props) {
    const {topNewsAdata, compHeadTxt} = props;
    function removeLastId(str) {
      const reLast = /-\d+$/;
    
      //console.log(str.replace(reLast, ""));
      //console.log(str.replace(reLast, ""));
      return str.replace(reLast, "");
    }
    return(
        <div className="master-div">
            <div className="allhead"><h2>{(compHeadTxt!=null && compHeadTxt!=undefined)?compHeadTxt:""}</h2></div>
                <ul className="list onlytxt">
                    {
                      topNewsAdata.map( (data, index) => { 
                        const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';
                        return (              
                        <li className="article" key={index}>
                          <div className="summary">
                            <a href={'/'+data.categoryUrl+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id} title={data.headline}>{data.headline}{(data.webTitleUrl.match('-lb-'))?(<b className="liveBlink"></b>):""}</a>                            
                          </div>
                          <div className="timestemp text-uppercase">
                            <span className="label"><span className="red">{data.categoryName}</span></span>  
                          </div>
                        </li>    
                      )                
                    })
                    }
                </ul>
        </div>
    )
}
export default topNews;