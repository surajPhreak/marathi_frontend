import Head from "next/head";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from "../global/Header.js";
import Footer from "../global/Footer.js";
import Gutter from "../ads/GutterAds.js";

function Layout({children, Title, Keywords, Description, articleImgPath, fixUrlCanonical, headerdata, footerdata, navtrending,sidebar}){

   const routerUrl = useRouter().asPath;
   var newfull = routerUrl.replace(/\?.*$/g,"");
   //const newUrl=fixUrlCanonical;

   //const[headerData, setHeaderData] = useState([]);
  // const[footerData, setFooterData] = useState([]);

   // useEffect(async () => {
      
   //  //  fetch('http://34.93.183.178:3001/header').then(res => res.json()).then(data => { setHeaderData(data); }).catch((e) => {console.log(e)});
   //    fetch('http://10.10.229.21:3001/footer').then(res => res.json()).then(data => { setFooterData(data);  }).catch((e) => {console.log(e)});
   //    /*fetch('https://eng-api.jagran.com/api/jagranenglish/latestarticles/0/8', payload).then(res => res.json()).then(data => { setNotificationData(data);  }).catch((e) => {console.log(e)}); */
   //    },[]);

   return (
   <>
      <Head>
          <title>{Title}</title>
          <meta name="description" content={Description} />
          <meta name="keywords" content={Keywords} />

          {(fixUrlCanonical)?
          <link rel="canonical" href={"https://www.marathijagran.com/"+fixUrlCanonical} />:
          <link rel="canonical" href={"https://www.marathijagran.com"+newfull} />}

          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />

          <meta property="og:title" content={Title} />
          <meta property="og:description" content={Description} />

          {(fixUrlCanonical)?
          <meta property="og:url" content={'https://www.marathijagran.com/'+fixUrlCanonical} />:
          <meta property="og:url" content={'https://www.marathijagran.com'+newfull} />}

          {(articleImgPath)?
          <meta property="og:image" content={'https://img.marathijagran.com/'+articleImgPath} />
          :<meta property="og:image" content='https://img.marathijagran.com/2023/02/marathi-jagran-home-page-image.jpg' />}

          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="Marathi Jagran" />
            <meta property="og:type" content="Article" />
            <link rel="preconnect" href="https://www.google-analytics.com" />
            <link rel="dns-prefetch" href="https://www.googletagmanager.com" />
          {/* <link rel="manifest" href="manifest.json" />  */}

          {/* <script type="module" dangerouslySetInnerHTML={{__html: `
   import 'https://cdn.jsdelivr.net/npm/@pwabuilder/pwaupdate';
   const el = document.createElement('pwa-update');
   document.body.appendChild(el);
`}} /> */}
          <meta name="theme-color" content="#dc0228" />

         </Head>
         {/* <Gutter/> */}
      <Header headerDataMenu={headerdata} navtrendingg={navtrending} sidebar={sidebar} fixUrlCanonical={fixUrlCanonical} newfull={newfull}  />
      <div className="container">{children}</div>
      <Footer FooterDataMenu={footerdata} />
   </>
   )
}
export default Layout;