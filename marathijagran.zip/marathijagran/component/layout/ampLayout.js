import Header from "../global/ampHeader.js"
import Footer from "../global/ampFooter.js"
export const config = { amp:true };
function Layout({children, navtrendingg}){
return (
<>
   <Header navtrendingg={navtrendingg} />
    <div className="container">{children}</div>
   <Footer />
   <style jsx global>{`
      *{margin:0; padding:0; outline:none;}
      body{font-family:Noto Sans, sans-serif; color:#000000; font-size:16px; line-height:22px; -webkit-text-size-adjust:none; letter-spacing:1px;}
      a{color:#000; text-decoration:none;}
      ul,li{list-style:none;}
      h1{font-size:1.5rem; line-height:36px; font-weight:600; margin-bottom:16px;}
      h2{float:left; font-size:21px; line-height:35px;}
      .h3{font-size:14px; line-height:21px;}
      .container{width:100%; padding:0 20px; clear:both; overflow:hidden; box-sizing:border-box;}
      ::-webkit-scrollbar {width:5px; height:1px;} ::-webkit-scrollbar-track{background: #f9f9f9;}
      ::-webkit-scrollbar-thumb {background:#ccc;} ::-webkit-scrollbar-thumb:hover{background:#ab1111;}
      .amp-container{clear:both; display:block; width:100%; margin:0 auto;}
      .amp-container:after{content:''; overflow:hidden; clear:both; display:block;}
      header{position:sticky; position:-webkit-sticky; clear:both; overflow:hidden; top:0; left:0; z-index:9;  background-color:#ffffff; box-shadow:0 8px 32px #f1f1f1; margin-bottom:20px;}
      header .logo{position:relative; background:#fff; margin-top:4px;}
      header .logo a{background:url('https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg') center no-repeat; width:128px; height:41px; background-size:100%; float:left; position:relative;}
      .topRight a{color:#fff; font-size:16px; line-height:44px; float:right; font-weight:600;}
      .nav{margin:0; padding:0; width:256px; background:#fff; clear:both; position:relative;}
      .topClose{overflow:hidden; clear:both; display:block;}
      .HDtopright{margin-top:15px; position:relative;} 
      .HDtopright .choose-state{font-weight:700;}
      .HDtopright .election{float:left; margin:3px 10px 0px 5px; line-height:18px;}
      .HDtopright .election span{color:#b50505;}
      .currentTopic{font-size:14px; color:#810909;}
      .topNav{display:block; margin: 0 -15px;}
      .scroll{width:100%; float:left; background:#fff; white-space:nowrap; overflow-x:auto; overflow-y:hidden; height:auto}
      .scroll ul li:last-child a{margin-right:27px;}
      .scroll ul{width:97%; float:left;}
      .scroll li{padding:0; display:inline-block;}
      .scroll li a{padding:6px 9px 4px; font-size:14px; line-height:28px; display:block;}
      .scroll li.mobileVishvasLogo a{color:#165f17;}
      .scroll li.photolink a{color:#b30f18;}
      .scroll li .burger{display:inline-block; margin:-9px 0; height:30px}
      // .scroll ul li:first-child{position:relative; width:24px; height:20px; margin-left:5px;}
      // .scroll ul li:first-child a{padding:0; position:absolute; top:4px; left:7px;}
      // .scroll ul li:first-child i{background:url(https://imgeng.jagran.com/images/micon-home.png?v1) no-repeat; width:19px; height:20px; display:inline-block; background-size:100%; background-position:center;}
      // [class*=h-50]
      // .h-50.i-amphtml-sticky-ad-layout .i-amphtml-element{display:inline-grid;}
      .footer{color:#555; text-align:center; margin-bottom:48px; padding-top:13px; clear:both; overflow:hidden;}
      .copyRight{padding:10px 0; display:block; font-size:12px;}
      .copyRight span{display:block;}
      .android-ios-box{line-height:0; display:inline-block; vertical-align:top; padding:5px;}
      .android-ios-box a{display:inline-block; background-image:url(https://imgeng.jagran.com/images/newimg/articleimage/footerappicon-englishjagran-15062020.jpg); background-repeat:no-repeat; height:37px; width:112px; background-size:212%;}
      .android-ios-box a.android-dwn{background-position:0 0;}
      .android-ios-box a.ios-dwn{background-position:right 0; margin-left:9px;}
      .comlink{clear:both; overflow:hidden; padding-bottom:5px; text-align:center;}
      .comlink a{display:inline-block; font-size:12px; color:#555;}

      .flexbox{display:flex; justify-content:space-between;}
      .ads{text-align:center; padding:7px 0; margin-bottom:20px; background:#f8f8f8; clear:both; overflow:hidden; line-height:0;}
      .adBox{padding:10px 0; margin:auto;}

      .breadcrum{margin-bottom:15px; clear: both; overflow: hidden;}
      .breadcrum ul li{float:left; color:#000; font-size:12px;}
      .breadcrum ul li a{color:#000; padding:2px 6px;text-transform: capitalize;}.breadcrum ul li:first-child a{padding-left:0;}
      .breadcrum ul li:after{content:'/'; margin:0 4px 0 5px; color:#707070;}
      .breadcrum ul li:last-child:after{display:none;}
      .breadcrum ul li:last-child a, .breadcrum li:last-child{color:#ab1a4f;}
      .breadcrum ul li:last-child{padding:0 6px;}
      .breadcrum ul li:nth-child(2){padding:0;}
 
      .liveBlink{background-color:#dd4b39; height:9px; width:9px; border-radius:50%; display:inline-block; line-height:0px; position:absolute; left:0; top:6px;}
      .liveBlink:before{position:absolute; content:""; height:9px; width:9px; left:0; top:0; background-color:transparent; border-radius:50%; box-shadow:0px 0px 2px 2px #dd4b39; -webkit-animation:active 2s infinite linear; animation:active 2s infinite linear;}
      .list li.article .summary{position:relative;}
      .liveBlog{display:block; font-size:19px; color:#000; padding:0 0 0 19px; position:relative; font-weight:700; text-transform:uppercase; margin:15px 0 10px;}
      .liveBlink i{color:#dd4b39; margin-left:15px; font-style:inherit;}
      @-webkit-keyframes active{   0%{-webkit-transform:scale(.1);  opacity:1;} 70%{-webkit-transform:scale(2.5); opacity:0;}  100%{opacity:0;}  }
      @keyframes active{  0%{transform:scale(.1); opacity:1;} 70%{transform:scale(2.5);  opacity:0;}  100%{opacity:0;}  }
      .timeline { margin-left: auto; width: calc(100% - 80px); box-shadow: -2px 2px 20px 0 rgba(239,239,239,1); border: 1px solid #f5f3f3; font-size: 12px; width: 100%;}
      .timeline .date { padding: 4px 10px; font-size: 12px; display: inline-block; color: #fff; background-color: #000; }
      .timeline .timeline-block { padding:20px 20px; position: relative; border-left: 1px solid #ccc; }
      .timeline .timeline-block:last-child { border-bottom: 0; }
      .timeline .timeline-block:before { position: absolute; left: -5px; top: 23px; width: 10px; height: 10px; content: ''; border-radius: 50%; background-color: #da251d; outline: 5px solid rgba(236,29,37,.1); }
      .timeline .timeline-block p { margin-bottom: 20px; }
      .timeline .timeline-block p:last-child { margin-bottom: 0; }
      .timeline .timeline-block ul { padding: 0; margin-left: 0; list-style: none; }
      .timeline .timeline-block ul > li { padding: 0 0 0 15px; margin: 0; position: relative; border: 0; }
      .timeline .timeline-block ul > li:before { position: absolute; top: 8px; left: 0; width: 6px; height: 6px; content: ''; background-color: #000; border-radius: 50%; }
      .timeline .timeline-block ul > li > a { color: #000; }
      .timeline .timeline-block ul:last-child { margin-bottom: 0; }
      .timeline .time { padding-right: 15px; width: 80px; text-align: right;}
      .timeLineTime{background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAQAAAAngNWGAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA/0lEQVQoU33SPW7CQBCG4YcCt75HBFVyCmgikKzcIRwEUoJzBLhAmpwiPUgkZRpT+QCTAuM/rLzT7ErvajTfDg2JzMFJqXRykEkMsHQWvTpbdqWRNyEUtmYmJma2LkLYGDXiRgi5FDx7BKlcCOumaQiv9bNfH/V5JYQFJL6FXEPhs3XLhbMxmVBUTYfEVCFkHIStNl2RnbDnJMz+FefCkVKY9MQvz1VNMRXKIfGnFfmlEe9bP3ip60nd+n6YPtUw9/F0SV2u8STOvcC71IHfvnA1qLW+kP5S3Ei96ywFo0ot7MxNTc3tqjVbt9cMFoOLuzDAWGbvqFQ62suuI1z5A7kwiyDAOLZsAAAAAElFTkSuQmCC'); background-repeat:no-repeat; background-position:7px center; background-size:12px 12px; padding-left:22px; font-size:15px; line-height:19px; color:#ec1d25; display:block; margin-bottom:10px;}

      /*social floating icon*/
      .tabs-sec{display:flex; justify-content:right; align-items:center; width:100%; position:fixed; right:20px; bottom:150px; z-index:9; height:1px;} 
      .tabs-sec .tab-cell{display: flex;align-items:center;  background:#fff; box-shadow:0 0 20px rgb(0 0 0 / 20%);border-radius: 40px;}
      .tabs-sec amp-social-share{display:flex; align-items: center; color: var(--colr-dark); white-space: nowrap;padding:4px;} 
      .tabs-sec .amp-social-share-system{background-color:#000; padding:5px; background-size: 20px; border-radius:50%;}

      /*bottom User notification, gdpr*/
      amp-user-notification > div{padding:0.5rem; align-items:center; justify-content:center;  background:#ededed;color:#1c1c1c;font-size:13px; }
      amp-user-notification > div a{ text-decoration:none; font-weight:bold; color:#000;}  
      amp-user-notification > div > button{background:#484647;padding:5px 15px;color:#fff;border:0px;margin:0 auto;display:block;}
      #topHeading{width:100%; float:left;}
      .newTop{margin:0 20px; padding-top:15px;}
      .dateInfo{border-top:1px solid #eee; padding:15px 0; clear:both; overflow:hidden;}
      .dateInfo span, .dateInfo strong{font-size:11px; color:#484848;}
      .detailBox figure{margin:0 -20px 20px; clear:both;}
      .articleBody{padding:0 0 10px 0px; text-align:justify; font-size:15px; line-height:25px;}
      .detailBox p, .authorname{margin-bottom:20px; color:#000; font-size:16px; line-height:29PX;}
      .detailBox p a, .authorname a{border-bottom:1px solid #ed1c24; font-weight:bold;}
      .articleBody ul{list-style:disc; margin-left:0px; line-height:25px; font-size:15px; padding-left:18px;}
      .articleBody ul li{margin-bottom:20px; list-style:disc;}
      .mgidbox{clear:both; overflow:hidden; display:block; margin-bottom:25px;}
      .tagList{display:-webkit-box; -webkit-box-orient:vertical; clear:both;}
      .tagList:after{content:''; display:block; clear:both; overflow:hidden;}

      .bodySummery img{width:100%; height:auto;}
      .realatedSreachtag{clear:both; overflow:hidden; border-top:1px solid #f0efef; padding:15px 0 10px; box-sizing:border-box; position:relative; margin-bottom:20px;}
      .realatedSreachtag h2{font-weight:600; font-size:15px; line-height:20px; box-sizing:border-box; margin-right:6px;}
      .realatedSreachtag .tagList{display:inline-block; line-height:inherit; white-space:nowrap; overflow-x:auto; overflow-y:hidden; padding:1px 0 9px;}
      .realatedSreachtag .tagList li{list-style:none; margin:0 8px 0 0; color:#707070; display:inline-block;}
      .realatedSreachtag .tagList li a{color:#3c3b3b; font-size:12px; border:1px solid #f1eded; padding:5px 11px; border-radius:20px;}
      .realatedSreachtag .content{overflow:hidden; clear:both; display:flex; justify-content:space-between;}
      .realatedSreachtag .label-container #read-more-label{float:right; font-size:12px; color:#af0202; font-weight:bold;}
      .realatedSreachtag .label-container #read-more-label:before{content:'+View All';}
      .realatedSreachtag #read-more-trigger{display:none;}
      .realatedSreachtag #read-more-trigger:checked ~ .label-container #read-more-label:before{ content:'-View Less';}
      .realatedSreachtag #read-more-trigger:checked ~ .content{max-height:100em;}

      .topHeading p{font-size:16px; line-height:28px; color:#000; margin-bottom:15px;}
      .commonList, .protxt{margin:0 4%; width:92%; float:left;}
      .commonList li{padding:8px 0; float:left; border-bottom:2px solid #f3f3f3; background:#fff;}
      .commonList.size1 li{padding:15px 0px; float:left; border-bottom:1px solid #f3f3f3; background:#fff; width:100%;}
      .commonList.size1 li figure, .commonList.size1 li figure img{height:85px;}
      .commonList li figure{width:100px; float:right; margin-left:15px;}
      .newsBox ul li span{color:#af0202; font-size:11px; text-transform:uppercase; line-height:13px; font-weight:bold; display:block; margin-bottom:5px;}
      .newsBox small{margin-left:5px; padding-left:5px; color:#585757; border-left:1px solid #c9c3c3; font-weight:400; display:inline-block; text-transform:capitalize;}
      .commonList li:last-child{border-bottom:0px;}

      .elec-head{width:100%; position:relative; padding:0px 0 20px; float:left;}
      .listingRhsNav{display:block; background-image:url(https://imgeng.jagran.com/images/mobile-election-nav2.jpg); background-size:cover; float:left; width:100%;}
      .listingRhsNav h2{padding:9px 8px 10px 9px; font-size:26px; line-height:29px; color:#fffc00; float:left; margin:0px; text-align:center; border:0; width:100%; box-sizing:border-box;}
      .listingRhsNav h2 a{color:#fffc00;}
      .listingRhsNav h2 small{color:#fff; vertical-align:top;}
      .toptabs{padding:5px 0px 8px 0; box-shadow:none; margin:0; white-space:inherit; float:left; background:none; text-align:center; width:inherit; border-bottom:1px solid #f3f3f3;}
      .toptabs li{display:inline-block; line-height:30px; background:#b30f18; border-radius:60px; padding:0px 7px 2px;}
      .toptabs li a{font-size:14px; font-weight:500; color:#fff;}

      .budget-banner{width:320px; text-align:center; clear:both; margin:0 auto;}
      .entryBudget{float:right; padding:13px 0 0;}
      .entryBudget a{color:#b30f18; font-weight:600;}

      .relatedReads{margin-bottom:0px; padding:20px 20px 15px; clear:both; overflow:hidden; background:#fff5f5;}
      .relatedReads .h4{color:#000; font-size:14px; margin-bottom:10px; font-weight:700; text-transform: uppercase;}
      .relatedReads ul li{clear:both; list-style:disc; margin-left:20px; color:#565454; margin-bottom:12px;}
      .relatedReads ul li a{font-size:14px;}

      .detailBox table{width:100%;}
      .detailBox table tr td{width:-webkit-fill-available; height:auto; padding:10px 5px; vertical-align:top; text-align:left; font-size:14px; border-bottom:1px solid #ccc; border-right:1px solid #ccc;}
      .detailBox table tr:first-child td{border-top:1px solid #ccc;}
      .detailBox table tr td:first-child{border-left:1px solid #ccc;}

      .jitengaBharatBanner{display:block; clear:both; overflow:hidden; margin-bottom:10px; text-align:center;}
      .relativeNews{padding:8px 0 15px; margin:20px auto; clear:both; border-top:1px solid #ccc; border-bottom:1px solid #ccc; min-height:85px;}
     
      
      .relativeNews figure{margin:5px 10px 0 0; width:87px; min-height:81px; float:left; overflow:hidden; font-size:2px; line-height:5px; background:0 0;}
      .relativeNews figure img{width:100%;height:81px;}
      
      .bodySummery .relativeNews .h3 a,.bodySummery .relativeNews figure a{border:none;font-size:13px;line-height:15px;font-weight:400;color:#000;}
      .relativeNews .nextRead{color:#b30f18;font-size:12px;font-weight:700;line-height:11px;border-radius:0 10px 0 10px;border-bottom:0;}
      
      .tagList{border-top:1px solid var(--light-grey);padding:20px 0; margin-top:20px;overflow: hidden;}
      .tagList h3{margin-bottom:15px;}
      .tagList li {list-style: none; margin-right:1.5rem; margin-bottom:10px; float: left;color:var(--grey); }
      .tagList li a { color: #000; font-size: 13px;}
      .tagList li a:hover{color: #ed1c24; border-bottom: 1px solid#ed1c24;}
      .inTheNews{display:flex; gap:18px; align-items:center; border-bottom:2px solid var(--light-grey);padding:10px 0; /*white-space:nowrap; overflow-x:scroll;   overflow-y:hidden;*/}
    
      .inTheNews h2{font-size:0.9rem;color:var(--grey); font-weight:600; text-transform:uppercase;display: flex;position:relative;margin-left: 25px;}
      .inTheNews h2:before{position: absolute;top: 5px;left: -33px; content:''; 
      background-image:url(https://img.marathijagran.com/2023/07/trending_nav.png);height:25px; width:25px;background-repeat: no-repeat;
      background-position: center;
      background-size: 70%;}
      .inTheNews h2 svg{ width: 24px; height: 24px; margin-right:8px;}
      .inTheNews .sub-menu{width:100%;height:100%;}
      .inTheNews .sub-menu li{width:auto; font-size:0.85rem; display:inline-block;margin-right: 15px;}
      .inTheNews .sub-menu li a{color:#000; font-size:.9rem; padding:6px 10px 3px; display:block;background: #efefef; border-radius: 4px; font-weight: 500;}
      .inTheNews .sub-menu li:last-child{margin-right: 0;}
      .inTheNews .sub-menu li a:hover{background-size:100% 1px; color: #fff; background-color:#da251d;}
      .taboolaad{height:60px;}.taboola-mid{height:140px; margin-bottom:10px;}
      .bannerBox{text-align:center; clear:both;}
      .mbannerBox{display: none;}
      .adBox amp-ad{margin:0 auto;}
      @media screen and (max-width:580px){ table tr td{word-break:break-word;} }
      @media screen and (max-width:320px){ header .logo a{width:80px;} }
      @media only screen and (max-width: 850px){
         .bannerBox{display: none;}.mbannerBox{ display: block; text-align: center; margin-bottom: 20px;}
         .inTheNews{white-space:nowrap; overflow-x:scroll; overflow-y:hidden;padding:6px 5px;}
      ::-webkit-scrollbar {height:1px;}
  }
         }
   `}</style>
</>
)
}
export default Layout;