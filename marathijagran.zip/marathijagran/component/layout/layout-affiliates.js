import Head from "next/head";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
//import Header from "../global/Header.js";
import TopDealsHeader from "../global/TopDealsHeader";
import Footer from "../global/Footer.js";
import axios from "axios";

function Layout({children, Title, Keywords, Description, articleImgPath}){
   const routerUrl = useRouter().asPath;
   const router = useRouter();
   var newfull = routerUrl.replace(/\?.*$/g,"");

   //console.log(newfull);
   
  var token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqYWdyYW5uZXdtZWRpYSIsImlhdCI6MTY2MTIzNjg2Mn0.cngV-wseScZG2S7VQH7DPj7i1LPnA1sxpqGzH2kUAolSJ4hEYeAIlifH8dvoqoQ5P_x-5HhL3-wGTjJauhmwyg";
  //const payload = {  headers: { Authorization: `Bearer ${token}` }  };
  const payload = {  headers: { Authorization: `Bearer ${token}`, 'Access-Control-Allow-Origin': "*",'Access-Control-Allow-Credentials': 'true' }  };
  const payload2 = {  headers: { Authorization: `Bearer ${token}`, 'Access-Control-Allow-Origin': "*" }  };

   const[headerData, setHeaderData] = useState([]);
   const[footerData, setFooterData] = useState([]);
   //const[notificationData, setNotificationData] = useState([]);
   const[topSubHeaderData, setTopSubHeaderData] = useState([]);
   // if(router.query.category){
   //   var cat = router.query.category.split("-").join(" ").replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()})
   // }
   
   useEffect(async () => {

      // if( !(routerUrl.match('top-deals')) ){         
      //    fetch('https://header-footer-api.jnm.digital/api/mainnavigation-get-by-product-url/english.jagran.com').then(res => res.json()).then(data => { setHeaderData(data); }).catch((e) => {console.log(e)});
      // }else{
         
      //    fetch('https://eng-api.jagran.com/api/jagranenglish/getAllAffiliateCategory',payload2).then(res => res.json()).then(data => { setHeaderData(data); }).catch((e) => {console.log(e)});
      //    if(router.query.category){
      //     await getSubheader(router.query.category);
      //    }
      // }

      fetch('https://eng-api.jagran.com/api/jagranenglish/getAllAffiliateCategory',payload2).then(res => res.json()).then(data => { setHeaderData(data); }).catch((e) => {console.log(e)});
         if(router.query.category){
          await getSubheader(router.query.category);
         }      
      fetch('https://header-footer-api.jnm.digital/api/footer-get-by-product-url/english.jagran.com').then(res => res.json()).then(data => { setFooterData(data);  }).catch((e) => {console.log(e)});
      
      /*fetch('https://eng-api.jagran.com/api/jagranenglish/latestarticles/0/8', payload).then(res => res.json()).then(data => { setNotificationData(data);  }).catch((e) => {console.log(e)}); */

      },[]);

 async function getSubheader(data){
   const Datax = await axios.get(`https://eng-api.jagran.com/api/jagranenglish/getAllAffiliateCategory`,payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
   Datax.map((val)=>{

      if(val.categoryUrl == data){
         fetch(`https://eng-api.jagran.com/api/jagranenglish/subcategoryByCategory/${val.categoryName}`,payload).then(res => res.json()).then(data => { setTopSubHeaderData(data); }).catch((e) => {console.log(e)});
      }

   }, []);
}
   // var newfull = routerUrl.replace(/\/.*$/g,"");
   // console.log(newfull[0]+newfull[1]+newfull[2]+newfull[3]+newfull[4]+newfull[5]+newfull[6]+newfull[7]+newfull[8]+newfull[9]);
   const schemaAarray_1=[];
   schemaAarray_1.push( 
      "(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g; m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga'); ga('create', 'UA-60996559-1', 'auto',{'useAmpClientId':true}); ga('require', 'GTM-TFC6TDN');" 
   );
   const schemaAarray_2=[];
   schemaAarray_2.push(`
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5CTQK3');
   `);
 

   const schemaAarray_8=[];
   schemaAarray_8.push(`
      <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5CTQK3" height="0" width="0" style="display:none;visibility:hidden"></iframe
   `);

   const schemaAarray_9=[];
   schemaAarray_9.push(`
      var referer = document.referrer; var r_uri = location.pathname + location.search; if (referer.indexOf('google') > 0 || referer.indexOf('bing') > 0) { history.pushState(null, null, r_uri); window.addEventListener('popstate', function (event) {  window.location.assign('https://english.jagran.com/?itm_source=backbutton');});}
   `);

   const schemaAarray_10=[];
   schemaAarray_10.push(`
      var dataLayer = window.dataLayer || [];dataLayer.push({'event':'english_pageview','tvc_page_type':'Homepage','tvc_homepage_type':'Homepage','language':'English'});
   `);

   const schemaAarray_11=[];
   schemaAarray_11.push(`
      var _comscore = _comscore || [];_comscore.push({ c1: "2", c2: "13184768", cs_ucfr: "1" }); (function() {var s = document.createElement("script"), el = document.getElementsByTagName("script")[0];s.async = true;s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b")+ ".scorecardresearch.com/beacon.js"; el.parentNode.insertBefore(s, el); })();
   `);

   const schemaAarray_12=[];
   schemaAarray_12.push(`
      window._tfa = window._tfa || [];  window._tfa.push({notify: 'event', name: 'page_view', id: 1464031});  !function (t, f, a, x) { if (!document.getElementById(x)) { t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f); } }(document.createElement('script'),  document.getElementsByTagName('script')[0], '//cdn.taboola.com/libtrc/unip/1464031/tfa.js', 'tb_tfa_script');
   `);

   const schemaAarray_15=[];
   schemaAarray_15.push(`
      window._izq = window._izq || []; window._izq.push(["init"]);
   `);

   return (
   <>
      <Head>          
          <title>{Title}</title>
          <meta name="keywords" content={Keywords} />
          <meta name="description" content={Description} />
          <meta property="og:title" content={Title} />
          <meta property="og:description" content={Description} />
          <meta property="og:url" content={'https://english.jagran.com'+newfull} />
          {(articleImgPath)?
          <meta property="og:image" content={'https://imgeng.jagran.com/images/'+articleImgPath} />
          :<meta property="og:image" content='https://imgeng.jagran.com/images/2021/jul/jagran_english.jpg' />}
         
          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="English Jagran" />
          <meta property="og:type" content="Article" />
          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />
          <meta name="theme-color" content="#dc0228" />
          <link rel="canonical" href={"https://english.jagran.com"+newfull} />
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_1}} ></script>         
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_2}} ></script>
        
          <noscript dangerouslySetInnerHTML={{__html: schemaAarray_8}} ></noscript>
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_9}} ></script>
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_10}} ></script> 
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_11}} ></script>
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_12}} ></script>
          <script dangerouslySetInnerHTML={{__html: schemaAarray_15}} ></script>
          <script type='text/javascript' src='https://cdn.izooto.com/scripts/f3c265e32e010b5080fb2e88ef527d5df2d5353e.js'></script>
          {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_13}} ></script> */}
      </Head>
      <TopDealsHeader headerDataMenu={headerData} subHeader={topSubHeaderData} />
      
      {/* {
         !(routerUrl.match('top-deals')) ? 
         <Header headerDataMenu={headerData} /> : 
         <TopDealsHeader headerDataMenu={headerData} subHeader={topSubHeaderData} />
      } */}

     

      <div className="container">{children}</div>
      <Footer FooterDataMenu={footerData} />
   </>
   )
}
export default Layout;