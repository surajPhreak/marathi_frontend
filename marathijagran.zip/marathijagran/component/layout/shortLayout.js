import Head from "next/head";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from "../global/Header.js";
import TopDealsHeader from "../global/TopDealsHeader";
import Footer from "../global/Footer.js";
import axios from "axios";

function Layout({children}){
   
  

   return (
   <>
    
      
      {children}
      <style jsx global>{`
    *,html,body{margin: 0; padding: 0;box-sizing: border-box;font-family: 'Poppins', sans-serif;}
    html,body, #__next{height: 100%;background-color: black;}
    header{position:fixed;z-index:1;top:0;width:100%;height:90px;background:linear-gradient(to bottom, rgb(0 0 0) 0%,rgb(0 0 0) 26%,rgb(0 0 0 / 70%), rgb(0 0 0 / 0%) 100%);padding:0 20px;display:flex;align-items:start;}
    header .header{display:flex;justify-content:space-between;width:100%; border: 0px;}
    header .logo{display:flex;align-items:center;}
    header .logo a{display:block;margin-top: 15px;}
    header .logo svg{width:110px;height:26px}
    header .header .social-share{align-items:center}
    header .header .social-share a{width:36px;height:36px;border-radius:36px;background-color:#333;display:flex;align-items:center;justify-content:center;margin:0 5px}
    header .header .social-share a.mob{display:flex}
    header .header .social-share a.web{display:none}
    header .header .social-share a svg{width:14px;height:14px;fill:#fff}
    section{width:100%;height:calc(100% - 0px);background-color:#000}
    section .player{height:100%;overflow:hidden;}
    .youtube-container{position:relative;height:100%;width:-webkit-fill-available;overflow:hidden;z-index:0;scale:1.1;}
    .youtube-container iframe,.youtube-container object,.youtube-container embed{position:relative;top:0;left:0;width:100%;height:100%;}
    .caption-control{position:absolute;bottom:0;width:100%;padding-top:50px;background:linear-gradient(to bottom, rgb(0 0 0 / 0%) 0%,rgb(0 0 0 / 50%) 26%,rgb(0 0 0), rgb(0 0 0) 100%)}
    .caption-control .caption{color:#fff;margin-right:70px;padding-left:20px;margin-bottom:30px;position:relative;padding-right: 20px}
    .caption-control .caption h1{font-size:12px;font-weight:700;margin-bottom:10px;}
    .caption-control .caption p{font-size:10px;}
    .caption-control .caption span{background-color:#ff00c6;display:inline-block;padding:5px 15px;font-size:12px;border-radius:30px;margin-bottom:10px}
    .caption-control .caption .share{position:absolute;width:40px;height:40px;border-radius:40px;right:20px;background-color:#333;display:flex;justify-content:center;align-items:center;top:-10px}
    .caption-control .caption .share svg{width:14px;height:14px;fill:#fff}
    .caption-control .control{display:flex;justify-content:space-between;border-top:1px solid rgb(255 255 255 / 30%);overflow:hidden}
    .caption-control .control>a{display:flex;width:50%;height:50px;justify-content:center;align-items:center;position:relative;border-right:1px solid rgb(255 255 255 / 30%);text-decoration:none;color:#fff;text-transform:uppercase;font-size:12px;font-weight:700;}
    .caption-control .control>a:hover{background-color:rgb(255 255 255 / 10%);color:#fff;}
    .caption-control .control>.disable{cursor:not-allowed;color:#777}
    .caption-control .control>a:last-child{border-right:0}
    .caption-control .control>a svg{width:18px;height:18px;fill:#fff}
    .caption-control .control>.disable svg{fill:#777}
    .sideshare{position: fixed;bottom:70px;right:0;padding:0 20px;border-left: 1px solid rgb(255 255 255 / 30%);z-index:9;text-align:center;min-width: 90px;}
    .sideshare li{list-style: none;margin-bottom:20px;border-bottom: 1px solid rgb(255 255 255 / 30%);padding-bottom:20px;}
    .sideshare li:last-child{margin-bottom:0;border-bottom:none;padding-bottom:0;}
    .sideshare li a,.sideshare li button{color: white;font-size:9px;text-align: center;text-decoration:none;border:none;background:none;display:block;margin:0 auto;}
    .sideshare li button.clipboard.active{color:#ff00c6;}
    .sideshare li a span,.sideshare li button span{display: block;font-weight:700;}
    .sideshare li a svg,.sideshare li button svg{width:22px;height:22px;fill: white;margin:0 auto 10px;display: block;}
    .sideshare li button.clipboard.active svg{fill:#ff00c6;}
    @media (min-width: 767px){
        header{height:70px}
        header .header .social-share a.mob{display:none}
        header .header .social-share a.web{display:flex}
        header .header{width:500px;margin:0 auto}
        section .player{width:500px;margin:0 auto}
        .caption-control{padding-bottom:20px}
        .caption-control .caption{width:500px;margin:0 auto}
        .caption-control .control{width:450px;margin:0 auto;border:1px solid rgb(255 255 255 / 30%);border-radius:40px}
    }
   `}</style>
      </>
   )
}
export default Layout;