//import React from 'react';
import moment from 'moment';
function GoogleAnalyticsDetails(props) {
    const {articledetaildata} = props;
	//console.log(articledetaildata.pubDate);
    // const ampBodyWithoutHtml=articledetaildata.body.replace(/(<([^>]+)>)/ig, '');
    // const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
	//var wordCount = ampBodyWithoutHtml1.split(" ").length;
	//const subcatt = articledata.subcategory ? (articledata.subcategory.toLowerCase() + '/') : '';

	const metaKeywords=articledetaildata && articledetaildata.tags ? articledetaildata.tags.map(taglist => {
		return(taglist.name)
	}):''
	
	
	const keyWordLimit = articledetaildata.metaKeywords.toLowerCase();

	function padTo2Digits(num) {
        return num.toString().padStart(2, '0');
      }
	  
	const pubDateYear= new Date(articledetaildata.pubDate?articledetaildata.pubDate:'');
	const pubDateYearUpdate=`${padTo2Digits(pubDateYear.getFullYear())}-${padTo2Digits(pubDateYear.getMonth()+1)}-${padTo2Digits(pubDateYear.getDate())}`

	const modDateYear= new Date(articledetaildata.modDate?articledetaildata.modDate:'');
	const modDateYearUpdate=`${padTo2Digits(modDateYear.getFullYear())}-${padTo2Digits(modDateYear.getMonth()+1)}-${padTo2Digits(modDateYear.getDate())}`


	function timeAgo(d){
		const diff = (new Date() - d)/1000;
		if(diff<60){
		  const v = Math.round(diff)
		  return v + ' second' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60){
		  const v = Math.round(diff/60)
		  return v + ' minute' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60*24){
		  const v = Math.round(diff/(60*60))
		  return v + ' hour' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60*24*30.436875){
		  const v = Math.round(diff/(60*60*24))
		  return v + ' day' + (v===1?'':'s') + ' ago';
		}
		else if(diff<60*60*24*30.436875*12){
		  const v = Math.round(diff/(60*60*24*30.436875))
		  return v + ' month' + (v===1?'':'s') + ' ago';
		}
		const v = Math.round(diff/(60*60*24*30.436875*12)) 
		return v + ' year' + (v===1?'':'s') + ' ago';
	  }

	//console.log(wordCount);
	// const schemaAarray = [];
	// schemaAarray.push({
	// 		"vars": { "account": `UA-60996559-1` },
	// 		"extraUrlParams":{
	// 				  "cd3": `${articledetaildata.pubDate}`,
	// 				  "cd4": `${articledetaildata.modDate}`,
	// 				  "cd5": `${articledetaildata.keywords}`,
	// 				  "cd6": `${ampBodyWithoutHtml1.length}`,
	// 				  "cd7": `${articledetaildata.category.toLowerCase()}`,
	// 				  "cd8": `true`,
	// 				  "cd9": `${articledetaildata.authorEng}`,
	// 				  //"cd13": "<%=ampArticle.getStoryDuration()%>",
	// 				  "cd14": `En`,
	// 				  "cd15": `${articledetaildata.genre}`,
	// 				  "cd17": `AmpArticleDetail`,
	// 				  "cd19": `${articledetaildata.id}`,
	// 				  // <%if(itmMedium!=null){%>
	// 				  // "cd58": "iar",
	// 				  // "cd59": "<%=itmMedium%>",
	// 				  // "cd60": "InArticle",
	// 				  // <%}%>
	// 				  "cd72": `none`,
	// 				  "cd18": `Online`
	// 				   },
	// 		"triggers": {
	// 			  "defaultPageview": {
	// 				"on": "visible",
	// 				"request": "pageview",
	// 				"vars": { "title": `${articledetaildata.headline}`}
	// 		  }
	// 	}
	//   });
    return (
        <>
           {/* <script async type="text/javascript" dangerouslySetInnerHTML={{__html: `var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'Detail Page','tvc_publish_date':'${pubDateYearUpdate}','tvc_update_date':'${modDateYearUpdate}','tvc_artical_tags':'${keyWordLimit!=null||keyWordLimit!=undefined?keyWordLimit:''}','tvc_page_cat':'${articledetaildata.categoryUrl.toLowerCase()}','article_subcategory':'${articledetaildata.subcategory?articledetaildata.subcategoryUrl.toLowerCase():''}','link_present_home page':'true','tvc_author':'${(articledetaildata.authorName)?articledetaildata.authorName:''}','article_age':'${timeAgo(new Date(pubDateYearUpdate))}','language':'marathi','author_ID':'${(articledetaildata.authorID)?articledetaildata.authorID:''}','tvc_detail_page':'Article Detail','storyID':'${articledetaildata.id}','tvc_video_embed':'No','online_offline':'Online'});`}}  /> */}

		   <script async type="text/javascript" dangerouslySetInnerHTML={{__html: `var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'${articledetaildata.liveBlog &&  articledetaildata.liveBlog.length>0?'live blog detail':'article detail'}','tvc_publish_date':'${pubDateYearUpdate}','tvc_update_date':'${modDateYearUpdate}','tvc_artical_tags':'${keyWordLimit!=null||keyWordLimit!=undefined?keyWordLimit:''}','tvc_page_cat':'${articledetaildata.categoryUrl.toLowerCase()}','article_subcategory':'${articledetaildata.subcategory?articledetaildata.subcategoryUrl.toLowerCase():''}','link_present_home page':'true','tvc_author':'${(articledetaildata.authorName)?articledetaildata.authorName.toLowerCase():''}','article_age':'${timeAgo(new Date(pubDateYearUpdate))}','language':'marathi','author_ID':'${(articledetaildata.authorID)?articledetaildata.authorID:''}','tvc_detail_page':'article detail','storyID':'${articledetaildata.id}','tvc_video_embed':'no','online_offline':'online'});`}}  />
        </>
    );
}

export default GoogleAnalyticsDetails;