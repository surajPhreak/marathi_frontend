const headInjection = (props) => {
    const {urlRoughter} = props;

    // const schemaAarray_4=[];
    // schemaAarray_4.push(
    //   `document.cookie = "__adblocker=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";var setNptTechAdblockerCookie = function(adblocker) {var d = new Date();d.setTime(d.getTime() + 60 * 5 * 1000); document.cookie = "__adblocker=" + (adblocker ? "true" : "false") + "; expires=" + d.toUTCString() + "; path=/";};var script = document.createElement("script");script.setAttribute("async", true);script.setAttribute("src", "//www.npttech.com/advertising.js");script.setAttribute("onerror","setNptTechAdblockerCookie(true);");document.getElementsByTagName("head")[0].appendChild(script);`
    // );

    // const schemaAarray_5=[];
    // schemaAarray_5.push(
    //   `var cX = cX || {}; cX.callQueue = cX.callQueue || []; cX.callQueue.push(['setSiteId', '2479549409819650741']); cX.callQueue.push(['sendPageViewEvent']); `
    // );
    
    const schemaAarray_7=[];
    schemaAarray_7.push(
      `window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);}  gtag('js', new Date()); ` //gtag('config', 'UA-240551854-1');
    );
    
    return(
        <>
            
            {/* <script dangerouslySetInnerHTML={{__html: schemaAarray_4 }}  ></script> */}
            {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_5 }}  ></script> */}
            {/* <script async src="https://www.googletagmanager.com/gtag/js?id=UA-240551854-1"></script> */}

            <script dangerouslySetInnerHTML={{__html: schemaAarray_7 }}  ></script>
            
            <meta name="cXenseParse:pageclass" content="frontpage"/>
        </>
    )
}
export default headInjection;