import { DomainPrefixes } from "../utils/ejConfig";
import moment from "moment/moment";
const headInjection = (props) => {
    const {articledata} = props;

    const ampBodyWithoutHtml=articledata.summary.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
    const subcatt = articledata.subcategory ? (articledata.subcategory.toLowerCase() + '/') : '';

    let seodata = [];
    (articledata.blogs)?
    Object.keys(articledata.blogs).map((index, key) => {
        let updatedTime = articledata.blogs[index].commentTime.split(':');
        var refine1 = articledata.blogs[index].comment;
        var refine2 = refine1.replace(/(<([^>]+)>)/gi, '');
        var refine3 = refine2.replace(/"/g, "");
        return(  
            
          seodata.push(

            `{
              "@type": "BlogPosting",
              "headline": "${articledata.blogs[index].commentTitle}",
              "url": "${'https://english.jagran.com/'+articledata.category.toLowerCase()+'/'+subcatt+articledata.url+'-'+articledata.id+'#'+articledata.blogs[index].commentId}",
              "datePublished": "${moment(articledata.pubDate).set({h: updatedTime[0], m: updatedTime[1]}).format()}",
              "dateModified": "${moment(articledata.pubDate).set({h: updatedTime[0], m: updatedTime[1]}).format()}",
              "mainEntityOfPage":"${'https://english.jagran.com/'+articledata.category.toLowerCase()+'/'+subcatt+articledata.url+'-'+articledata.id}",
              "author": {
                "@type": "Person",
                "name": "${articledata.authorEng}",
                "url": "${(articledata.authorUrl) ? ('https://english.jagran.com/authors/'+articledata.authorUrl) : 'https://english.jagran.com/authors/'}"
              },
              "articleBody": "${refine3}",
              "publisher": {
                "@type": "Organization",
                "name": "Jagran English",
                "logo": {
                    "@type": "ImageObject",
                    "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png",
                    "width": 600,
                    "height": 60
                }
              },
              "image": {
                "@type": "ImageObject",
                "url": "${DomainPrefixes.ImagePath+articledata.imagePath}",
                "width": 1200,
                "height": 675
              }
            }`

          )
            
          )
    }):'';

     /*seoCommonScript*/
    const schemaAarray_1=[];
    schemaAarray_1.push( 
      "(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g; m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga'); ga('create', 'UA-60996559-1', 'auto',{'useAmpClientId':true}); ga('require', 'GTM-TFC6TDN');" 
    );
    const schemaAarray_2=[];
    schemaAarray_2.push(`
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5CTQK3');
    `);
    const schemaAarray_3=[];
    schemaAarray_3.push(`
      var _comscore = _comscore || [];_comscore.push({ c1: "2", c2: "13184768", cs_ucfr: "1" }); (function() {var s = document.createElement("script"), el = document.getElementsByTagName("script")[0];s.async = true;s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b")+ ".scorecardresearch.com/beacon.js"; el.parentNode.insertBefore(s, el); })();
    `);
    const schemaAarray_4=[];
    schemaAarray_4.push(`
      <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5CTQK3" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    `);
    const schemaAarray_5=[];
    schemaAarray_5.push(`
      var referer = document.referrer; var r_uri = location.pathname + location.search; if (referer.indexOf('google') > 0 || referer.indexOf('bing') > 0) { history.pushState(null, null, r_uri); window.addEventListener('popstate', function (event) {  window.location.assign('https://english.jagran.com/?itm_source=backbutton');});}
    `);   
  
    const schemaAarray_7=[];
    schemaAarray_7.push(`
      window._izq = window._izq || []; window._izq.push(["init"]);
    `);
    /*seoCommonScript*/
    const schemaAarray_14=[];
    schemaAarray_14.push(
      `document.cookie = "__adblocker=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";var setNptTechAdblockerCookie = function(adblocker) {var d = new Date();d.setTime(d.getTime() + 60 * 5 * 1000); document.cookie = "__adblocker=" + (adblocker ? "true" : "false") + "; expires=" + d.toUTCString() + "; path=/";};var script = document.createElement("script");script.setAttribute("async", true);script.setAttribute("src", "//www.npttech.com/advertising.js");script.setAttribute("onerror","setNptTechAdblockerCookie(true);");document.getElementsByTagName("head")[0].appendChild(script);`
    );
    const schemaAarray_15=[];
    schemaAarray_15.push(
      `var cX = cX || {}; cX.callQueue = cX.callQueue || []; cX.callQueue.push(['setSiteId', '2479549409819650741']); cX.callQueue.push(['sendPageViewEvent']); `
    );
    // const schemaAarray_16=[];
    // schemaAarray_16.push(
    //   ``
    // );
    const schemaAarray_17=[];
    schemaAarray_17.push(
      `window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);}  gtag('js', new Date()); gtag('config', 'UA-234940022-1');`
    );
    const schemaAarray_18=[];
    schemaAarray_18.push(
      `var cX = cX || {}; cX.callQueue = cX.callQueue || []; cX.callQueue.push(['setSiteId', '2479549409819650741']); cX.callQueue.push(['sendPageViewEvent']);`
    );
    const schemaAarray_19=[];
    schemaAarray_19.push(
      `{"@context": "https://schema.org","@type": "BreadcrumbList","itemListElement": [{"@type": "ListItem","position": 1,"item": {"@id": "https://english.jagran.com","name": "News"}},{"@type": "ListItem","position": 2,"item": {"@id": "${"https://english.jagran.com/" + articledata.category.toLowerCase()}","name":"${articledata.category}"} }]}`
    );
    // const schemaAarray_10=[];
    // schemaAarray_10.push(
    //   `(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g; m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga'); ga('create', 'UA-60996559-1', 'auto',{'useAmpClientId':true}); ga('require', 'GTM-TFC6TDN');`
    // );
    // const schemaAarray_11=[];
    // schemaAarray_11.push(
    //   `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5CTQK3');`
    // );
    const schemaAarray_20=[];
    schemaAarray_20.push(
      `{
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "url":"${'https://english.jagran.com/'+articledata.category.toLowerCase()+'/'+subcatt+articledata.url+'-'+articledata.id}",
        "articleBody":"${ampBodyWithoutHtml1}",
        "articleSection": "${articledata.category}",
        "mainEntityOfPage":{
          "@type":"WebPage",
          "@id":"${'https://english.jagran.com/'+articledata.category.toLowerCase()+'/'+subcatt+articledata.url+'-'+articledata.id}"
        },
        "headline": "${articledata.headline}",
        "description": "${articledata.metaDesc.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '')}",
        "datePublished": "${moment(articledata.pubDate).format()}",
        "dateModified": "${moment(articledata.modDate).format()}",
        "publisher": {
          "@type": "Organization",
          "name": "Jagran English",
          "logo": {
            "@type": "ImageObject",
            "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png",
            "width": 600,
            "height": 60
                  }
        },
        "author": {
          "@type": "Person",
          "name": "${articledata.authorEng}",
          "url": "${(articledata.authorUrl) ? ('https://english.jagran.com/authors/'+articledata.authorUrl) : 'https://english.jagran.com/authors/'}"
        },
        "image": {
          "@type": "ImageObject",
          "url": "${DomainPrefixes.ImagePath+articledata.imagePath}",
          "width": 1200,
          "height": 675
              },
        "keywords": ["${articledata.keywords}"]
      }
    `
    );
    
    const schemaAarray_21=[];
    schemaAarray_21.push(`

        {
            "@context": "https://schema.org",
            "@type": "LiveBlogPosting",
            "url": "${'https://english.jagran.com/'+articledata.category.toLowerCase()+'/'+subcatt+articledata.url+'-'+articledata.id}",
            "datePublished": "${moment(articledata.pubDate).format()}",
            "dateModified":"${moment(articledata.modDate).format()}",
            "publisher": {
            "@type": "Organization",
            "name": "Jagran English",
            "logo": {
                "@type": "ImageObject",
                "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png",
                "width": 600,
                "height": 60
            }
            },
            "author": {
            "@type": "Person",
            "name": "${articledata.authorEng}",
            "url": "${(articledata.authorUrl) ? ('https://english.jagran.com/authors/'+articledata.authorUrl) : 'https://english.jagran.com/authors/'}"
            },
            "about":{
                    "@type":"Thing",
                    "name":"event"
                },
            "image": {
            "@type": "ImageObject",
            "url": "${DomainPrefixes.ImagePath+articledata.imagePath}",
            "width": 1200,
            "height": 675
            },
            "coverageStartTime":"${moment(articledata.pubDate).format()}",
            "coverageEndTime":"${moment(articledata.pubDate).add(3, 'days').format()}",
            "headline":"${articledata.headline}",
            "description":"${(articledata.metaDesc)?articledata.metaDesc:''}",
            "liveBlogUpdate": [ ${seodata} ]
        }

    `);

    return(
        <>
            {/*seoCommonScript*/}
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_1}} ></script>         
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_2}} ></script>
            {/*seoCommonScript*/}

            <link rel="amphtml" href={'https://english.jagran.com/lite/' + articledata.category.toLowerCase()+'/'+subcatt+articledata.url+'-'+articledata.id} />

            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_14 }} ></script>
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_15 }} ></script>
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-234940022-1"></script>
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_17 }} ></script>
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_18 }} ></script>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_19 }} ></script>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_20 }} ></script>
            <meta property="article:published_time" content={moment(articledata.pubDate).format()} />
            <script type="application/ld+json"  dangerouslySetInnerHTML={{__html: schemaAarray_21 }} ></script>

            {/*seoCommonScript*/}
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_3 }} ></script>
            <noscript dangerouslySetInnerHTML={{__html: schemaAarray_4}} ></noscript>
            <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_5}} ></script>
            {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_6}} ></script> */}
            <script dangerouslySetInnerHTML={{__html: schemaAarray_7}} ></script>
            {/* <script type='text/javascript' src='https://cdn.izooto.com/scripts/f3c265e32e010b5080fb2e88ef527d5df2d5353e.js'></script> */}
            {/*seoCommonScript*/}
            
        </>
    )
}
export default headInjection;