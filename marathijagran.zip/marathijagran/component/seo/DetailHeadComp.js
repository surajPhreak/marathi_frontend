import { DomainPrefixes, convertToISOFormat } from "../utils/ejConfig";
//import moment from "moment/moment";
const headInjection = (props) => {
    const {articledata} = props;
  //  const imagePath = articledata.imagePath.split(',');
    const ampBodyWithoutHtml=articledata.body.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
    const subcatt = articledata.subcategory!='NA'?articledata.subcategory.split(' ').join('-')+'/':'';

    
	function padTo2Digits(num) {
    return num.toString().padStart(2, '0');
  }
  
    const datePublished = convertToISOFormat(articledata.pubDate);
    const dateModified = convertToISOFormat(articledata.modDate);
    const metaDescription = articledata.summary.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '')

    const newPubDate = (new Date(articledata.pubDate));
    const consPubDate = newPubDate.getFullYear()+"-"+padTo2Digits(newPubDate.getMonth()+1)+"-"+newPubDate.getDate()+"T"+padTo2Digits(newPubDate.getHours())+":"+padTo2Digits(newPubDate.getMinutes())+":00+05:30";


  /*seoCommonScript*/
    
    // const schemaAarray_2=[];
    // schemaAarray_2.push(`
    //     (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5CTQK3');
    // `);
    const schemaAarray_3=[];
    schemaAarray_3.push(`
        var _comscore = _comscore || [];_comscore.push({ c1: "2", c2: "13184768", cs_ucfr: "1" ,options:{enableFirstPartyCookie: true}}); (function() {var s = document.createElement("script"), el = document.getElementsByTagName("script")[0];s.async = true;s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b")+ ".scorecardresearch.com/beacon.js"; el.parentNode.insertBefore(s, el); })();
    `);
    // const schemaAarray_4=[];
    // schemaAarray_4.push(`
    //     <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5CTQK3" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    // `);
     
    const schemaAarray_7=[];
    schemaAarray_7.push(`
        window._izq = window._izq || []; window._izq.push(["init"]);
    `);
    /*seoCommonScript*/
    const schemaAarray_14=[];
    schemaAarray_14.push(
      `document.cookie = "__adblocker=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";var setNptTechAdblockerCookie = function(adblocker) {var d = new Date();d.setTime(d.getTime() + 60 * 5 * 1000); document.cookie = "__adblocker=" + (adblocker ? "true" : "false") + "; expires=" + d.toUTCString() + "; path=/";};var script = document.createElement("script");script.setAttribute("async", true);script.setAttribute("src", "//www.npttech.com/advertising.js");script.setAttribute("onerror","setNptTechAdblockerCookie(true);");document.getElementsByTagName("head")[0].appendChild(script);`
    );
    const schemaAarray_15=[];
    schemaAarray_15.push(
      `var cX = cX || {}; cX.callQueue = cX.callQueue || []; cX.callQueue.push(['setSiteId', '2479549409819650741']); cX.callQueue.push(['sendPageViewEvent']); `
    );
    // const schemaAarray_16=[];
    // schemaAarray_16.push(
    //   ``
    // );
    const schemaAarray_17=[];
    schemaAarray_17.push(
      `window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);}  gtag('js', new Date());`//
    );
    // const schemaAarray_18=[];
    // schemaAarray_18.push(
    //   `var cX = cX || {}; cX.callQueue = cX.callQueue || []; cX.callQueue.push(['setSiteId', '2479549409819650741']); cX.callQueue.push(['sendPageViewEvent']);`
    // );
    
    return(
        <> 
          {/*seoCommonScript*/}
          {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_2}} ></script> */}
          {/*seoCommonScript*/}

          
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_14 }} ></script>
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_15 }} ></script>
          {/* <script async src="https://www.googletagmanager.com/gtag/js?id=UA-240551854-1"></script> */}
          <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_17 }} ></script>
          {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_18 }} ></script> */}
         
          <meta property="article:published_time" content={consPubDate} />
          {/*seoCommonScript*/}
          {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html: schemaAarray_3 }} ></script> */}
          {/* <noscript dangerouslySetInnerHTML={{__html: schemaAarray_4}} ></noscript> */}
         
       <script dangerouslySetInnerHTML={{__html: schemaAarray_7}} ></script>
          {/* <script type='text/javascript' src='https://cdn.izooto.com/scripts/f3c265e32e010b5080fb2e88ef527d5df2d5353e.js'></script> */}
          {/*seoCommonScript*/}         
        </>
    )
}
export default headInjection;