//import React from 'react';
function GoogleAnalytics(props) {
    const {articledetaildata} = props;
	//console.log(articledetaildata.pubDate);
    const ampBodyWithoutHtml=articledetaildata.summary.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
	var wordCount = ampBodyWithoutHtml1.split(" ").length;

	function timeAgo(d){
		const diff = (new Date() - d)/1000;
		if(diff<60){
		  const v = Math.round(diff)
		  return v + ' second' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60){
		  const v = Math.round(diff/60)
		  return v + ' minute' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60*24){
		  const v = Math.round(diff/(60*60))
		  return v + ' hour' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60*24*30.436875){
		  const v = Math.round(diff/(60*60*24))
		  return v + ' day' + (v===1?'':'s') + ' ago';
		}
		else if(diff<60*60*24*30.436875*12){
		  const v = Math.round(diff/(60*60*24*30.436875))
		  return v + ' month' + (v===1?'':'s') + ' ago';
		}
		const v = Math.round(diff/(60*60*24*30.436875*12)) 
		return v + ' year' + (v===1?'':'s') + ' ago';
	  }

	//console.log(wordCount);
	// const schemaAarray = [];
	// schemaAarray.push({
	// 		"vars": { "account": `UA-60996559-1` },
	// 		"extraUrlParams":{
	// 				  "cd3": `${articledetaildata.pubDate}`,
	// 				  "cd4": `${articledetaildata.modDate}`,
	// 				  "cd5": `${articledetaildata.keywords}`,
	// 				  "cd6": `${ampBodyWithoutHtml1.length}`,
	// 				  "cd7": `${articledetaildata.category.toLowerCase()}`,
	// 				  "cd8": `true`,
	// 				  "cd9": `${articledetaildata.authorEng}`,
	// 				  //"cd13": "<%=ampArticle.getStoryDuration()%>",
	// 				  "cd14": `En`,
	// 				  "cd15": `${articledetaildata.genre}`,
	// 				  "cd17": `AmpArticleDetail`,
	// 				  "cd19": `${articledetaildata.id}`,
	// 				  // <%if(itmMedium!=null){%>
	// 				  // "cd58": "iar",
	// 				  // "cd59": "<%=itmMedium%>",
	// 				  // "cd60": "InArticle",
	// 				  // <%}%>
	// 				  "cd72": `none`,
	// 				  "cd18": `Online`
	// 				   },
	// 		"triggers": {
	// 			  "defaultPageview": {
	// 				"on": "visible",
	// 				"request": "pageview",
	// 				"vars": { "title": `${articledetaildata.headline}`}
	// 		  }
	// 	}
	//   });
    return (
        <>
          
    <amp-analytics type="cxense"> <script type="application/json" dangerouslySetInnerHTML={{__html: `{ "vars": { "siteId": "2479549409819650741" } }`}}  /> </amp-analytics>
    <amp-analytics type="comscore">   <script type="application/json" dangerouslySetInnerHTML={{__html: ` { "vars": {		"c2": "13184768","comscorekw":"amp"	}	}	`}}  /> </amp-analytics>
	{/* <amp-analytics type="googleanalytics" id="analytics1"> <script type="application/json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray)}}  />	</amp-analytics> */}
	<amp-analytics type="googleanalytics" id="analytics1"> <script type="application/json" dangerouslySetInnerHTML={{__html: `


{
	"vars": {
	 "account": "UA-60996559-1"
	},
	"extraUrlParams":{  
  
			  "cd3": "${articledetaildata.pubDate}",
			  "cd4": "${articledetaildata.modDate}",
			  "cd5": "${articledetaildata.keywords}",
			  "cd6": "${wordCount}",
			  "cd7": "${articledetaildata.category.toLowerCase()}",
			  "cd8": "true",
			  "cd9": "${articledetaildata.authorEng}",
			  "cd13": "${timeAgo(new Date(articledetaildata.pubDate))}",
			  "cd14": "En",
			  "cd15": "${articledetaildata.category}",
			  "cd17": "AmpArticleDetail",
			  "cd19": "${articledetaildata.id}",
			  
			  "cd72": "none",
			  "cd18": "Online"
			   },
	"triggers": {
		  "defaultPageview": {
			"on": "visible",
			"request": "pageview",
			"vars": {
			  "title": "${articledetaildata.headline}"
			}
	  }
}
}




	`}}  />	</amp-analytics>

        </>
    );
}
export default GoogleAnalytics;