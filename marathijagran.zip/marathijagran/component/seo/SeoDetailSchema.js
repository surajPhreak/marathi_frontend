import React from 'react';
import { DomainPrefixes,UrlPrifix } from "../utils/ejConfig";
function SeoCommonSchema({articledata, categoryUrl}) {
  const category = articledata.category
  ? articledata.category.toLowerCase().split(" ").join("-")
  : "";
const subcatt = articledata.subcategory
  ? articledata.subcategoryUrl.toLowerCase().split(" ").join("-") + "/"
  : "";

    //const subcatt = articledata.subcategory ? articledata.subcategoryUrl + '/' :'';

    function removeLastId(str) {
      const reLast = /-\d+$/;
      return str.replace(reLast, "");
    }
    function padTo2Digits(num) {
      return num.toString().padStart(2, "0");
    }
    const formatDate = (date) => {
    const newPubDate = new Date(date);
    return (
      newPubDate.getFullYear() +
      "-" +
      padTo2Digits(newPubDate.getMonth() + 1) +
      "-" +
      padTo2Digits(newPubDate.getDate()) +
      "T" +
      padTo2Digits(newPubDate.getHours()) +
      ":" +
      padTo2Digits(newPubDate.getMinutes()) +
      ":" +
      padTo2Digits(newPubDate.getSeconds()) +
      "+05:30"
    );
  };


    function addHoursToDate(date, hourss){
      const formatedtimeString = new Date(date);
      
      formatedtimeString.setHours(formatedtimeString.getHours() + hourss);
      let datavalue = new Date(formatedtimeString)
      const updatedDate =datavalue.getFullYear() + "-" + padTo2Digits(datavalue.getMonth() + 1) + "-" + datavalue.getDate() + "T" + padTo2Digits(datavalue.getHours()) + ":" + padTo2Digits(datavalue.getMinutes()) +':'+ padTo2Digits(datavalue.getSeconds()) + "+05:30";
      return updatedDate;
      }
    const schemaAarray_8=[];
    schemaAarray_8.push(
      `{"@context": "https://schema.org","@type": "Organization","name": "Jagran Marathi","url": "https://www.marathijagran.com","sameAs":["https://www.facebook.com/marathijagran/"]}`
    );
    const schemaAarray_9=[];
    schemaAarray_9.push(
      `{"@context":"https://schema.org","@type":"WebSite","url":"https://www.marathijagran.com/","potentialAction":{"@type":"SearchAction","target":"https://www.marathijagran.com/search/{search_term_string}","query-input":"required name=search_term_string"}}`
    );
    const schemaAarray_10=[];
    schemaAarray_10.push(
      `{"@context":"https://schema.org","@type":"WebPage","name":"${articledata.metaTitle ? articledata.metaTitle.replace(/"/g, "") : ''}", "description":"${articledata.metaDescription ? articledata.metaDescription : ''}", "keywords" : "${articledata.metaKeywords ? articledata.metaKeywords : ' '}","url":"${'https://www.marathijagran.com/'+articledata.categoryUrl.toLowerCase().split(' ').join('-')+'/'+subcatt.toLowerCase()+removeLastId(articledata.webTitleUrl).toLowerCase()+'-'+articledata.id}","publisher":{"@type":"Organization","name":"Marathi Jagran","url":"https://www.marathijagran.com/", "logo":{"@type":"ImageObject","url":"https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg","width":600,"height":60 } } }`
  );

  let livePost = [];
  if (articledata && articledata.liveBlog)
    livePost = articledata.liveBlog.map((el,index) => {
      const ampBodyWithoutHtml=el.live_blog_content.replace(/(<([^>]+)>)/ig, '');
      return {
        "@type": "BlogPosting",
        "url":`${'https://www.marathijagran.com/'+articledata.categoryUrl+'/'+subcatt+removeLastId(articledata.webTitleUrl)+'-'+articledata.id}#${articledata.id}${index}`,
        "headline": el.live_blog_title,
        datePublished: formatDate(el.liveblog_time),
        dateModified : formatDate(el.liveblog_time),
        mainEntityOfPage :`${'https://www.marathijagran.com/'+articledata.categoryUrl+'/'+subcatt+removeLastId(articledata.webTitleUrl)+'-'+articledata.id}`,
        "articleBody": ampBodyWithoutHtml,
        "author": {
          "@type": "Person",
          name : articledata.authorName == "Author" ? articledata.editedBy : articledata.authorName,
          url : (
            articledata.authorID
              ? "https://www.marathijagran.com/authors/" + articledata.authorUrl
              : "https://www.marathijagran.com/"
            )
        },
        publisher: {
          "@type": "Organization",
          name: "Marathi Jagran",
          logo: {
            "@type": "ImageObject",
            url: "https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg",
            width: 600,
            height: 60,
          },
        },
        image: {
          "@type": "ImageObject",
          url: articledata.largeImage ? DomainPrefixes.ImagePath+articledata.largeImage  : '',
          width: 1200,
          height: 675,
        },
      };
    });

  let newDate = new Date();
  // newDate.setHours(newDate.getHours() + 72);
  const schemaAarray_11 = [];
  let coverageDate = new Date();
  let modDate =articledata.modDate;
  if (articledata.liveBlog&&articledata.liveBlog.length>0) {
    coverageDate = new Date(articledata.liveBlog[0].liveblog_time)
    newDate = new Date(articledata.liveBlog[0].liveblog_time);
    newDate.setHours(newDate.getHours() + 72);
    if (new Date(articledata.liveBlog[articledata.liveBlog.length - 1].liveblog_time)>new Date(articledata.modDate)) {
      modDate=articledata.liveBlog[articledata.liveBlog.length - 1].liveblog_time
    }
    modDate=articledata.liveBlog[articledata.liveBlog.length - 1].liveblog_time

  }
  
  schemaAarray_11.push(
    `{
      "@context":"https://schema.org",
      "@type":"LiveBlogPosting",
      
      "about":{
        "@type":"Event",

        "name":"${
          articledata.webTitle ? articledata.webTitle.replace(/"/g, "") : ""
        }",
        "description":"${articledata.summary}",
        "image":"${
          articledata.largeImage
            ? DomainPrefixes.ImagePath + articledata.largeImage
            : ""
        }",
        "startDate":"${formatDate(articledata.pubDate)}",
        "endDate":"${addHoursToDate(articledata.pubDate, 72)}",
        
        "eventAttendanceMode":"mixed",
        "location":"India",
        "eventStatus":"live"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Marathi Jagran",
        "logo": {
          "@type": "ImageObject",
          "url": "https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg",
          "width": 600,
          "height": 60
        }
      },
     

      "coverageStartTime":"${formatDate(articledata.pubDate)}",
      "coverageEndTime":"${addHoursToDate(articledata.pubDate,  72)}",
      "headline":"${
        articledata.webTitle ? articledata.webTitle.replace(/"/g, "") : ""
      }",
      "datePublished":"${formatDate(articledata.pubDate)}",
      "dateModified":"${formatDate(articledata.modDate)}",
      "url":"${'https://www.marathijagran.com/'+articledata.categoryUrl+'/'+subcatt+removeLastId(articledata.webTitleUrl)+'-'+articledata.id}",
      "description":"${articledata.summary}",
      "author": {
        "@type": "Person",
        "name": "${articledata.authorName == "Author" ? articledata.editedBy : articledata.authorName}",
        "url": "${
          articledata.authorID
            ? "https://www.marathijagran.com/authors/" + articledata.authorUrl
            : "https://www.marathijagran.com/"
        }"
      },
      "image": {
        "@type": "ImageObject",
        "url": "${
          articledata.largeImage
            ? DomainPrefixes.ImagePath + articledata.largeImage
            : ""
        }",
        "width": 1200,
        "height": 675
      },

      "liveBlogUpdate":${JSON.stringify(livePost)}
    }`
  );

  const schemaAarray_4 = [];
  schemaAarray_4.push(`
     <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5CTQK3" height="0" width="0" style="display:none;visibility:hidden"></iframe>
  `);

    
    return (
        <div>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_8 }}  ></script>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_9 }}  ></script>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_10 }}  ></script>
            {articledata.liveBlog && articledata.liveBlog.length > 0 && (
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>
            )}
            <noscript dangerouslySetInnerHTML={{ __html: schemaAarray_4 }} ></noscript>

        </div>
    );
}

export default SeoCommonSchema;