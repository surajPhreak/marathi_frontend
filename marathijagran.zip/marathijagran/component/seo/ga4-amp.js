import { timeAgo, convertToISOFormat } from '../../component/utils/ejConfig';
function Ga4AmpComp({articledetaildata, headerDataMenu, navtrendingg, recommendation}) {

   //const ggHH = recommendation.posts[0];

    //console.log(recommendation.posts[0])

    function padTo2Digits(num) {
        return num.toString().padStart(2, '0');
      }
	const pubDateYear= new Date(articledetaildata.pubDate?articledetaildata.pubDate:'');
	const pubDateYearUpdate=`${padTo2Digits(pubDateYear.getFullYear())}-${padTo2Digits(pubDateYear.getMonth()+1)}-${padTo2Digits(pubDateYear.getDate())}`

	const modDateYear= new Date(articledetaildata.modDate?articledetaildata.modDate:'');
	const modDateYearUpdate=`${padTo2Digits(modDateYear.getFullYear())}-${padTo2Digits(modDateYear.getMonth()+1)}-${padTo2Digits(modDateYear.getDate())}`
	//const keyWordLimit = articledetaildata.keywords.replace(/[&\/\\#+()$~%.'":*?<>{}]/g, '').substring(0,95)+'...';
	  
    return (
        <>
          <amp-analytics type="gtag" data-credentials="include"><script type="application/json" dangerouslySetInnerHTML={{__html: `
                  {
                  "vars" : {
                      "gtag_id": "G-LS6SLCKQKJ",
                      "config" : {
                      "G-LS6SLCKQKJ": {  
                        "client_id_event": "CLIENT_ID(_ga).",
                        "page_type" :  "amp article detail",
                        "publish_date" :  "${convertToISOFormat(articledetaildata.pubDate)}",
                        "update_date" :  "${convertToISOFormat(articledetaildata.modDate)}",
                        "word_count" :  "na",
                        "author" :  "${articledetaildata.authorEng ? articledetaildata.authorEng.toLowerCase() : 'na'}",
                        "category" :  "${articledetaildata.categoryUrl ? articledetaildata.categoryUrl.toLowerCase() : 'na'}",
                        "story_id" :  "${articledetaildata.id}",
                        "tags" :  "na",
                        "sub_category" :  "${articledetaildata.subcategoryUrl ? articledetaildata.subcategoryUrl.toLowerCase() : 'na'}",
                        "embed_type" :  "na",
                        "Language" :  "marathi"
                          }
                      }
                  }
                  }
                  
          `}}  />	</amp-analytics> 
        
       


      
      </>
  );
}

export default Ga4AmpComp;