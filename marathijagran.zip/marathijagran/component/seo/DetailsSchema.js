import React from 'react';
import moment from 'moment';
import { DomainPrefixes } from "../utils/ejConfig";

function DetailsSchema(props) {
    const {articledata}= props
    const subcatt = articledata.subcategory ? articledata.subcategoryUrl + '/' :'';
    const ampBodyWithoutHtml=articledata.body.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
   
    function removeLastId(str) {
      const reLast = /-\d+$/;
    
      //console.log(str.replace(reLast, ""));
      //console.log(str.replace(reLast, ""));
      return str.replace(reLast, "");
    }

    function padTo2Digits(num) {
      return num.toString().padStart(2, '0');
    }

    const schemaModDate = ((articledata.modDate == null) || (articledata.modDate == undefined)) ? new Date() : articledata.modDate;
    const newDate = (new Date(schemaModDate));
    // console.log(newDate);
    const modifiedDate = newDate.getFullYear()+"-"+padTo2Digits(newDate.getMonth()+1)+"-"+newDate.getDate()+"T"+padTo2Digits(newDate.getHours())+":"+padTo2Digits(newDate.getMinutes())+":00+05:30";
    const newPubDate = (new Date(articledata.pubDate));
    const consPubDate = newPubDate.getFullYear()+"-"+padTo2Digits(newPubDate.getMonth()+1)+"-"+newPubDate.getDate()+"T"+padTo2Digits(newPubDate.getHours())+":"+padTo2Digits(newPubDate.getMinutes())+":00+05:30";

    const metaDescription = articledata.summary.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '')


    const schemaAarray_18=[];
  schemaAarray_18.push(
    `{"@context": "https://schema.org","@type": "BreadcrumbList","itemListElement": [{"@type": "ListItem","position": 1,"item": {"@id": "https://www.marathijagran.com","name": "News"}},
      {"@type": "ListItem","position": 2,"item": {"@id": "${"https://www.marathijagran.com/" + articledata.categoryUrl.toLowerCase().split(' ').join('-')}","name":"${articledata.categoryUrl.toLowerCase()}"}}
      ${articledata.subcategoryUrl ? `,{"@type": "ListItem","position": 3,"item": {"@id": "${"https://www.marathijagran.com/" + articledata.subcategoryUrl}","name":"${articledata.subcategoryUrl}"}}`:''}    
    ]}`
    );
  
    const schemaAarray_19=[];
    schemaAarray_19.push(
      `{
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "url":"${'https://www.marathijagran.com/'+articledata.categoryUrl.toLowerCase().split(' ').join('-')+'/'+subcatt.toLowerCase()+removeLastId(articledata.webTitleUrl).toLowerCase()+'-'+articledata.id}",
        "articleBody":"${ampBodyWithoutHtml1}",
        "articleSection": "${articledata.category}",
        "mainEntityOfPage":{
          "@type":"WebPage",
          "@id":"${'https://www.marathijagran.com/'+articledata.categoryUrl.toLowerCase().split(' ').join('-')+'/'+subcatt.toLowerCase()+removeLastId(articledata.webTitleUrl).toLowerCase()+'-'+articledata.id}"
        },
        "headline": "${articledata.webTitle?articledata.webTitle.replace(/"/g, ""):''}",
        "description": "${articledata.metaDescription ? articledata.metaDescription : ''}",
        "keywords": "${articledata.metaKeywords ? articledata.metaKeywords : ''}",
        "datePublished": "${consPubDate}",
        "dateModified": "${modifiedDate}",
        "publisher": {
          "@type": "Organization",
          "name": "Marathi Jagran",
          "sameAs": "https://www.marathijagran.com/",
          "logo": {
            "@type": "ImageObject",
            "url": "https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg",
            "width": 600,
            "height": 60
                  }
        },
        "author": {
          "@type": "Person",
          "name": "${articledata.authorName!=undefined||articledata.authorName!=null?articledata.authorName:''}",
          "url": "${(articledata.authorUrl) ? ('https://www.marathijagran.com/authors/'+articledata.authorUrl) : 'https://www.marathijagran.com/authors/'}"
        },
        "image": {
          "@type": "ImageObject",
          "url": "${DomainPrefixes.ImagePath+articledata.largeImage!=undefined||DomainPrefixes.ImagePath+articledata.largeImage!=null?DomainPrefixes.ImagePath+articledata.largeImage:'https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg'}",
          "width": 1200,
          "height": 675
              }
      }`
    );
    return (
        <div>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_18 }} ></script>
          <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_19 }} ></script> 
        </div>
    );
}

export default DetailsSchema;