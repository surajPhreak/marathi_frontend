import { DomainPrefixes } from "../utils/ejConfig";
import moment from 'moment';
const PhotoAmpMeta = (props) => {
    const {articledetaildata, urlRoughter} = props;
    //const authorUrl = articledetaildata.authorEng.toLowerCase().split(' ').join('-');
    const subcatt = articledetaildata.subcategory?articledetaildata.subcategory.toLowerCase()+'/':'';
    const carvar = articledetaildata.category.toLowerCase().split(' ').join('-');
    const authorUrl = (articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? " " : articledetaildata.authorUrl;
    const bigImage = articledetaildata.imagePath.split(',');

    const ampBodyWithoutHtml=articledetaildata.summary.replace(/(<([^>]+)>)/ig, '');
    //const topDealUrl = 'https://english.jagran.com/top-deals/'+ articledetaildata.category.toLowerCase().split(' ').join('-') ;
    const catlUrl = ( (articledetaildata.subcategory==null) || (articledetaildata.subcategory==undefined) ) ? "" : ('https://english.jagran.com/'+ articledetaildata.category.toLowerCase().split(' ').join('-') + '/' + articledetaildata.subcategory.toLowerCase().split(' ').join('-')) ;
    const photogalleryschema=[]
    const photogalleryimages=[]
    const schemaAarray_1=[]
    articledetaildata.photoDetails.map((item, index) =>{          
    photogalleryimages.push([`https://imgeng.jagran.com/images/${item.imagePath}`
    ])
    })
    photogalleryschema.push({
        "@context": "https://schema.org",
		"@type": "ImageGallery",
		"mainEntityOfPage":{
			"@type":"WebPage",
			"@id":`${ DomainPrefixes.UrlPrifix +'/photos/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id }`,
			"headline": `${articledetaildata.headline}`,
			"description": `${articledetaildata.summary}`
		},  
		"url":`${ DomainPrefixes.UrlPrifix +'/photos/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id }`,   
        "image":{
            "@type":"ImageObject",
            "url":photogalleryimages,"width":1200,"height":800},
        "datePublished": `${moment(articledetaildata.pubDate).format()}`,
		"dateModified": `${moment(articledetaildata.modDate).format()}`,
		
		"author": {
			"@type": "Person",
			"name": "Jagran English"
		},
		"publisher": {
			"@type": "Organization",
			"name": "Jagran English",
			"url":"https://english.jagran.com/",
			"logo": {
				"@type": "ImageObject",
				"url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png",
				"width": 600,
				"height": 60   
			}        
		}
    })
        

    schemaAarray_1.push({
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "url": `${ DomainPrefixes.UrlPrifix +'/photos/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id }`,
        "mainEntityOfPage":{ '@type':"WebPage", "@id":`${ DomainPrefixes.UrlPrifix +'/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id }` },
        "headline": `${ articledetaildata.headline.slice(0, 108) }`,
        "datePublished": `${moment(articledetaildata.pubDate).format()}`,
        "dateModified": `${moment(articledetaildata.modDate).format()}`,
        "description": `${articledetaildata.summary}`,
        "articleBody": `${ampBodyWithoutHtml}`,
        "articleSection": `${articledetaildata.category}`,
        "author": { "@type": "Person", "name": `${articledetaildata.authorByline?articledetaildata.authorByline:'Jagran English'}`, "url":`${DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl}` },
        "publisher": { "@type": "Organization", "name": "Jagran English", "logo": { "@type": "ImageObject", "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png", "width": 600, "height": 60 } },
        "image": { "@type": "ImageObject", "url": `${DomainPrefixes.ImagePath+bigImage[0]}`, "height":675, "width":1200 }
});
const schemaAarray_2 = { 
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "item": {"@id": "https://english.jagran.com","name": "News"}
        },
        {
        "@type": "ListItem",
        "position": 2,
        "item": {"@id": `${  DomainPrefixes.UrlPrifix +'/photos/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id }`,
        "name":`${articledetaildata.category}`}
        }
    ]
};
(articledetaildata.subcategory==null)||(articledetaildata.subcategory==undefined) ? '' : schemaAarray_2.itemListElement.push({
      "@type": "ListItem",
          "position": 3,
          "item": {"@id": `${catlUrl}`,
         "name":`${articledetaildata.subcategory}`}
 }) ;
// const schemaAarray_3=[];
// schemaAarray_3.push({ 
//     "@context": "https://schema.org",
//     "@type": "BreadcrumbList",
//     "itemListElement": [{
//         "@type": "ListItem",
//         "position": 1,
//         "item": {"@id": "https://english.jagran.com","name": "News"}
//         },
//         {
//         "@type": "ListItem",
//         "position": 2,
//         "item": {"@id": "https://english.jagran.com/top-deals",
//         "name":"Top Deals"}
//         },
//         {
//             "@type": "ListItem",
//             "position": 3,
//             "item": {"@id": `${  topDealUrl  }`,
//             "name":`${articledetaildata.category}`}
//         },
//         {
//             "@type": "ListItem",
//             "position": 4,
//             "item": {"@id": `${  ( urlRoughter.match('top-deals') ) ? ( DomainPrefixes.UrlPrifix +'/top-deals/' + articledetaildata.category.toLowerCase().split(' ').join('-') + "/" + articledetaildata.subcategory.toLowerCase().split(' ').join('-') ) : '' }`,
//             "name":`${ (articledetaildata.subcategory==null)||(articledetaildata.subcategory==undefined) ? '' : articledetaildata.subcategory }`}
//         }
//     ]
// });
return(
    <>
    <title>{( (articledetaildata.metaTitle==undefined)||(articledetaildata.metaTitle==null) ) ? articledetaildata.headline : articledetaildata.metaTitle}</title>
    <meta name="keywords" content={( (articledetaildata.keywords==undefined)||(articledetaildata.keywords==null) )?' ':articledetaildata.keywords} />
    <meta name="description" content={( (articledetaildata.summary==undefined)||(articledetaildata.summary==null) )?' ':articledetaildata.summary} />
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_1)}}  />
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  />
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(photogalleryschema)  }} />
    <meta name="theme-color" content="#dc0228" />
    <meta property="og:title" content={articledetaildata.headline} />
    <meta property="og:description" content={articledetaildata.summary} />
    <meta property="og:url" content={DomainPrefixes.UrlPrifix +'/photos/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id} />
    <meta property="og:image" content={DomainPrefixes.ImagePath+bigImage[0]} />
    <meta property="og:site_name" content="English Jagran" />
    <meta property="og:type" content="Article" />    
    {/* {        
        ( urlRoughter.match('top-deals') ) ? 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_3)}}  />) : 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  />)
    } */}
    </>
)
}
export default PhotoAmpMeta;