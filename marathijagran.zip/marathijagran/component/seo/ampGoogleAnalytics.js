//import React from 'react';
import { DomainPrefixes } from "../utils/ejConfig";
function GoogleAnalytics(props) {
    const {articledetaildata} = props;
	function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    const ampBodyWithoutHtml=articledetaildata.ampBody.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
	var wordCount = ampBodyWithoutHtml1.split(" ").length;
	const subcatt = articledetaildata.subcategoryUrl?articledetaildata.subcategoryUrl+'/':'';
	const carvar = articledetaildata.categoryUrl.split(' ').join('-'); 
	const metaKeywords=articledetaildata.tags.map(taglist => {
		return(taglist.name)
	})
	
	
	const keyWordLimit = metaKeywords;

	function padTo2Digits(num) {
        return num.toString().padStart(2, '0');
      }
	const pubDateYear= new Date(articledetaildata.pubDate?articledetaildata.pubDate:'');
	const pubDateYearUpdate=`${padTo2Digits(pubDateYear.getFullYear())}-${padTo2Digits(pubDateYear.getMonth()+1)}-${padTo2Digits(pubDateYear.getDate())}`

	const modDateYear= new Date(articledetaildata.modDate?articledetaildata.modDate:'');
	const modDateYearUpdate=`${padTo2Digits(modDateYear.getFullYear())}-${padTo2Digits(modDateYear.getMonth()+1)}-${padTo2Digits(modDateYear.getDate())}`

	function timeAgo(d){
		const diff = (new Date() - d)/1000;
		if(diff<60){
		  const v = Math.round(diff)
		  return v + ' second' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60){
		  const v = Math.round(diff/60)
		  return v + ' minute' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60*24){
		  const v = Math.round(diff/(60*60))
		  return v + ' hour' + (v===1?'':'s') + ' ago';   
		}
		else if(diff<60*60*24*30.436875){
		  const v = Math.round(diff/(60*60*24))
		  return v + ' day' + (v===1?'':'s') + ' ago';
		}
		else if(diff<60*60*24*30.436875*12){
		  const v = Math.round(diff/(60*60*24*30.436875))
		  return v + ' month' + (v===1?'':'s') + ' ago';
		}
		const v = Math.round(diff/(60*60*24*30.436875*12)) 
		return v + ' year' + (v===1?'':'s') + ' ago';
	}
	const tagsList = [];
	articledetaildata && articledetaildata.tags.map(
				(data) => {
				const moddata = data.name.replace(/'/g, "\&#39;"); 
				return tagsList.push(moddata)  
				}
		);
		console.log(`https://www.googletagmanager.com/amp.json?id=GTM-P8KZQN3&gtm.url=${ DomainPrefixes.UrlPrifix +'/' + carvar.toLowerCase() + "/" + subcatt + removeLastId(articledetaildata.webTitleUrl).toLowerCase()+'-'+articledetaildata.id+'/amp'}`);

	
	// const schemaAarray = [];
	// schemaAarray.push({
	// 		"vars": { "account": `UA-60996559-1` },
	// 		"extraUrlParams":{
	// 				  "cd3": `${articledetaildata.pubDate}`,
	// 				  "cd4": `${articledetaildata.modDate}`,
	// 				  "cd5": `${articledetaildata.keywords}`,
	// 				  "cd6": `${ampBodyWithoutHtml1.length}`,
	// 				  "cd7": `${articledetaildata.category.toLowerCase()}`,
	// 				  "cd8": `true`,
	// 				  "cd9": `${articledetaildata.authorEng}`,
	// 				  //"cd13": "<%=ampArticle.getStoryDuration()%>",
	// 				  "cd14": `En`,
	// 				  "cd15": `${articledetaildata.genre}`,
	// 				  "cd17": `AmpArticleDetail`,
	// 				  "cd19": `${articledetaildata.id}`,
	// 				  // <%if(itmMedium!=null){%>
	// 				  // "cd58": "iar",
	// 				  // "cd59": "<%=itmMedium%>",
	// 				  // "cd60": "InArticle",
	// 				  // <%}%>
	// 				  "cd72": `none`,
	// 				  "cd18": `Online`
	// 				   },
	// 		"triggers": {
	// 			  "defaultPageview": {
	// 				"on": "visible",
	// 				"request": "pageview",
	// 				"vars": { "title": `${articledetaildata.headline}`}
	// 		  }
	// 	}
	//   });
    return (
        <>
    <amp-analytics config={`https://www.googletagmanager.com/amp.json?id=GTM-P8KZQN3&gtm.url=${ DomainPrefixes.UrlPrifix +'/' + carvar.toLowerCase() + "/" + subcatt + removeLastId(articledetaildata.webTitleUrl).toLowerCase()+'-'+articledetaildata.id+'/amp'}`} data-credentials="include">
	<script type="application/json" dangerouslySetInnerHTML={{__html: ` 
	{
		"vars": {
			"gaTrackingId": "UA-60996559-1",
			"tvc_author":"${articledetaildata.authorEng ? articledetaildata.authorEng.toLowerCase() : ''}",
			"storyID":"${articledetaildata.id}",
			"pagetype":"${articledetaildata.liveBlog &&  articledetaildata.liveBlog.length>0?'amp live blog detail':'amp article detail'}",
			"article_subcategory":"${subcatt?subcatt.toLowerCase():'na'}",
			"tvc_page_cat":"${articledetaildata.categoryUrl.toLowerCase()}",
			"tvc_word_count":"${wordCount}",
			"position": "0",
			"video_embed":"no",
			"language":"marathi",
			"tvc_article_tags": "${tagsList}",
			"tvc_publish_date":"${pubDateYearUpdate}",
			"tvc_update_date":"${modDateYearUpdate}"
		}
		}

	`
}}  /> 
	</amp-analytics>      
			{/* <amp-analytics type="gtag" data-credentials="include">
 <script type="application/json" dangerouslySetInnerHTML={{ __html: ` { "vars" : { "gtag_id": "UA-60996559-1", "config" : { "UA-60996559-1": { "groups": "default" } } } }` }} />

 </amp-analytics> */}
    <amp-analytics type="cxense"> <script type="application/json" dangerouslySetInnerHTML={{__html: `{ "vars": { "siteId": "2479549409819650741" } }`}}  /> </amp-analytics>
    <amp-analytics type="comscore">   <script type="application/json" dangerouslySetInnerHTML={{__html: ` { "vars": {		"c2": "13184768"	},"extraUrlParams":{"comscorekw":"amp"}	}	`}}  /> </amp-analytics>
	{/* <amp-analytics type="googleanalytics" id="analytics1"> <script type="application/json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray)}}  />	</amp-analytics> */}
	
	{/* <amp-analytics type="googleanalytics" id="analytics1"> <script type="application/json" dangerouslySetInnerHTML={{__html: `
{
	"vars": {
	 "account": "UA-60996559-1"
	},
	"extraUrlParams":{  
			"cd2": "${articledetaildata.subcategory.toLowerCase()}",	
			  "cd3": "${pubDateYearUpdate}",
			  "cd4": "${modDateYearUpdate}",
			  "cd5": "${keyWordLimit}",
			  "cd6": "${wordCount}",
			  "cd7": "${articledetaildata.category.toLowerCase()}",
			  "cd8": "true",
			  "cd9": "${articledetaildata.authorEng}",
			  "cd13": "${timeAgo(new Date(pubDateYearUpdate))}",
			  "cd14": "marathi",
			  "cd15": "${articledetaildata.genre}",
			  "cd17": "AmpArticleDetail",
			  "cd19": "${articledetaildata.id}",
			  
			  "cd72": "none",
			  "cd18": "Online"
			   },
	"triggers": {
		  "defaultPageview": {
			"on": "visible",
			"request": "pageview",
			"vars": {
			  "title": "${articledetaildata.metaTitle?articledetaildata.metaTitle:articledetaildata.webTitle}"
			}
	  }
}
}




	`}}  />	</amp-analytics> */}

        </>
    );
}
export default GoogleAnalytics;