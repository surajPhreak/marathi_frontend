import { DomainPrefixes } from "../utils/ejConfig";
import moment from 'moment';
export const config = { amp: true };
const Meta = (props) => {
    const {articledetaildata, urlRoughter} = props;
    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }

      function padTo2Digits(num) {
        return num.toString().padStart(2, '0');
      }
      const formatDate = (date) => {
        const newPubDate = new Date(date);
        return (
          newPubDate.getFullYear() +
          "-" +
          padTo2Digits(newPubDate.getMonth() + 1) +
          "-" +
          padTo2Digits(newPubDate.getDate()) +
          "T" +
          padTo2Digits(newPubDate.getHours()) +
          ":" +
          padTo2Digits(newPubDate.getMinutes()) +
          ":00+05:30"
        );
      };
    //const authorUrl = articledetaildata.authorEng.split(' ').join('-');
    const authorUrl = (articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? " " : articledetaildata.authorUrl;
    const bigImage = articledetaildata.imagePath.split(',');
    const subcatt = articledetaildata.subcategoryUrl?articledetaildata.subcategoryUrl+'/':'';
    const carvar = articledetaildata.categoryUrl.split(' ').join('-'); 

    const ampBodyWithoutHtml=articledetaildata.ampBody.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
    const topDealUrl = 'https://www.marathijagran.com/top-deals/'+ articledetaildata.category.split(' ').join('-') ;
    const catlUrl = ( (articledetaildata.subcategory==null) || (articledetaildata.subcategory==undefined) ) ? "" : ('https://www.marathijagran.com/'+ articledetaildata.categoryUrl.split(' ').join('-') + '/' + articledetaildata.subcategoryUrl.split(' ').join('-')) ;
    

    const schemaModDate = ((articledetaildata.modDate == null) || (articledetaildata.modDate == undefined)) ? new Date() : articledetaildata.modDate;
    const newDate = (new Date(schemaModDate));
    const modifiedDate = newDate.getFullYear()+"-"+padTo2Digits(newDate.getMonth()+1)+"-"+newDate.getDate()+"T"+padTo2Digits(newDate.getHours())+":"+padTo2Digits(newDate.getMinutes())+":00+05:30";
    const newPubDate = (new Date(articledetaildata.pubDate));
    const consPubDate = newPubDate.getFullYear()+"-"+padTo2Digits(newPubDate.getMonth()+1)+"-"+newPubDate.getDate()+"T"+padTo2Digits(newPubDate.getHours())+":"+padTo2Digits(newPubDate.getMinutes())+":00+05:30";

    const schemaAarray_1=[];
    schemaAarray_1.push({
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "url": `${ DomainPrefixes.UrlPrifix +'/' + carvar.toLowerCase() + "/" + subcatt + removeLastId(articledetaildata.webTitleUrl)+'-'+articledetaildata.id}`,
        "mainEntityOfPage":{ '@type':"WebPage", "@id":`${ DomainPrefixes.UrlPrifix +'/' + carvar.toLowerCase() + "/" + subcatt + removeLastId(articledetaildata.webTitleUrl).toLowerCase()+'-'+articledetaildata.id}` },
        "headline": `${ articledetaildata.webTitle.slice(0, 108) }`,
        "datePublished": `${consPubDate}`,
        "dateModified": `${modifiedDate}`,
        "description": `${articledetaildata.metaDescription}`,
        "articleBody": `${ampBodyWithoutHtml1}`,
        "articleSection": `${articledetaildata.category}`,
        "author": { "@type": "Person", "name": `${articledetaildata.authorEng}`, "url":`${DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl}` },
        "publisher": { "@type": "Organization", "name": "Marathi Jagran", "logo": { "@type": "ImageObject", "url": "https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg", "width": 600, "height": 60 } },
        "image": { "@type": "ImageObject", "url": `${DomainPrefixes.ImagePath+bigImage[0]}`, "height":675, "width":1200 }
});

const schemaAarray_2 = { 
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "item": {"@id": "https://www.marathijagran.com","name": "News"}
        },
        {
        "@type": "ListItem",
        "position": 2,
        "item": {"@id": `${  DomainPrefixes.UrlPrifix +'/'+ articledetaildata.categoryUrl }`,
        "name":`${articledetaildata.categoryUrl}`}
        }
    ]
};

articledetaildata.subcategoryUrl ? schemaAarray_2.itemListElement.push({
    "@type": "ListItem",
        "position": 3,
        "item": {"@id": `${catlUrl}`,
       "name":`${articledetaildata.subcategoryUrl}`}
}) : '' ;


// const schemaAarray_3=[];
// schemaAarray_3.push({ 
//     "@context": "https://schema.org",
//     "@type": "BreadcrumbList",
//     "itemListElement": [{
//         "@type": "ListItem",
//         "position": 1,
//         "item": {"@id": "https://www.marathijagran.com","name": "News"}
//         },
//         {
//         "@type": "ListItem",
//         "position": 2,
//         "item": {"@id": "https://www.marathijagran.com/top-deals",
//         "name":"Top Deals"}
//         },
//         {
//             "@type": "ListItem",
//             "position": 3,
//             "item": {"@id": `${  topDealUrl  }`,
//             "name":`${articledetaildata.category}`}
//         }
//     ]
// });

let livePost = [];
if (articledetaildata && articledetaildata.liveBlog)
  livePost = articledetaildata.liveBlog.map((el,index) => {
    const ampBodyWithoutHtml=el.live_blog_content.replace(/(<([^>]+)>)/ig, '');
    return {
      "@type": "BlogPosting",
      "url":`${'https://www.marathijagran.com/'+articledetaildata.categoryUrl+'/'+articledetaildata.subcategoryUrl+removeLastId(articledetaildata.webTitleUrl)+'-'+articledetaildata.id}#${articledetaildata.id}${index}`,
      headline: el.live_blog_title,
      datePublished: formatDate(el.liveblog_time),
      "articleBody": ampBodyWithoutHtml,
      publisher: {
        "@type": "Organization",
        name: "Marathi Jagran",
        logo: {
          "@type": "ImageObject",
          url: "https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg",
          width: 600,
          height: 60,
        },
      },
      image: {
        "@type": "ImageObject",
        url: articledetaildata.largeImage ? DomainPrefixes.ImagePath+articledetaildata.largeImage  : '',
        width: 1200,
        height: 675,
      },
    };
  });

let newDate1 = new Date();
// newDate.setHours(newDate.getHours() + 72);
const schemaAarray_11 = [];
let coverageDate = new Date();
let modDate =articledetaildata.modDate;
if (articledetaildata.liveBlog&&articledetaildata.liveBlog.length>0) {
  coverageDate = new Date(articledetaildata.liveBlog[0].liveblog_time)
  newDate1 = new Date(articledetaildata.liveBlog[0].liveblog_time);
  newDate1.setHours(newDate1.getHours() + 72);
  if (new Date(articledetaildata.liveBlog[articledetaildata.liveBlog.length - 1].liveblog_time)>new Date(articledetaildata.modDate)) {
    modDate=articledetaildata.liveBlog[articledetaildata.liveBlog.length - 1].liveblog_time
  }
  modDate=articledetaildata.liveBlog[articledetaildata.liveBlog.length - 1].liveblog_time

}

schemaAarray_11.push(
  `{
    "@context":"https://schema.org",
    "@type":"LiveBlogPosting",
    
    "about":{
      "@type":"Event",
      "startDate":"${formatDate(articledetaildata.pubDate)}",
      "name":"${
        articledetaildata.metaTitle ? articledetaildata.metaTitle.replace(/"/g, "") : ""
      }",
      "description":"${articledetaildata.metaDescription}",
      "endDate":"${formatDate(modDate)}",
      "image":"${
        articledetaildata.largeImage
          ? DomainPrefixes.ImagePath + articledetaildata.largeImage
          : ""
      }",
      "eventAttendanceMode":"mix",
      "location":"India",
      "eventStatus":"live"
    },
    "publisher": {
      "@type": "Organization",
      "name": "Marathi Jagran",
      "logo": {
        "@type": "ImageObject",
        "url": "https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg",
        "width": 600,
        "height": 60
      }
    },
    "image": {
      "@type": "ImageObject",
      "url": "${
        articledetaildata.largeImage
          ? DomainPrefixes.ImagePath + articledetaildata.largeImage
          : ""
      }",
      "width": 1200,
      "height": 675
    },

    "coverageStartTime":"${formatDate(coverageDate)}",
    "coverageEndTime":"${formatDate(newDate1)}",
    "datePublished":"${formatDate(articledetaildata.pubDate)}",
    "dateModified":"${formatDate(modDate)}",
    "description":"${articledetaildata.metaDescription}",
    "headline":"${
      articledetaildata.metaTitle ? articledetaildata.metaTitle.replace(/"/g, "") : ""
    }",
    "url":"${'https://www.marathijagran.com/'+articledetaildata.categoryUrl+'/'+articledetaildata.subcategoryUrl+removeLastId(articledetaildata.webTitleUrl)+'-'+articledetaildata.id}",
    "author": {
      "@type": "Person",
      "name": "${articledetaildata.authorName}",
      "url": "${
        articledetaildata.authorID
          ? "https://www.marathijagran.com/authors/" + articledetaildata.authorUrl
          : "https://www.marathijagran.com/"
      }"
    },
    "liveBlogUpdate":${JSON.stringify(livePost)}
  }`
);

return(
    <>
    <title>{( (articledetaildata.metaTitle==undefined)||(articledetaildata.metaTitle==null) ) ? articledetaildata.webTitle : articledetaildata.metaTitle}</title>
    <meta name="description" content={( (articledetaildata.metaDescription==undefined)||(articledetaildata.metaDescription==null) )?' ':articledetaildata.metaDescription} />
    <meta name="keywords" content={( (articledetaildata.keywords==undefined)||(articledetaildata.keywords==null) )?' ':articledetaildata.keywords} />   
    
    <meta name="theme-color" content="#dc0228" />
    <meta property="og:title" content={articledetaildata.webTitle} />
    <meta property="og:description" content={articledetaildata.metaDescription} />
    <meta property="og:url" content={DomainPrefixes.UrlPrifix +'/' + carvar + "/" + subcatt+ removeLastId(articledetaildata.webTitleUrl).toLowerCase()+'-'+articledetaildata.id} />
    <meta property="og:image" content={DomainPrefixes.ImagePath+bigImage[0]} />
    <meta property="og:site_name" content="Marathi Jagran" />
    <meta property="og:type" content="Article" />
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_1)}}  />
    {/* <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  /> */}
    {        
        ( urlRoughter.match('top-deals') ) ? 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_3)}}  />) : 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  />)
    }
     {articledetaildata.liveBlog && articledetaildata.liveBlog.length > 0 && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: schemaAarray_11 }}
        ></script>
      )}
    </>
)
}
export default Meta;