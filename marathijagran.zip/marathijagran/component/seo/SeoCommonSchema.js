import React from 'react';

function SeoCommonSchema(props) {
    const schemaAarray_8=[];
    schemaAarray_8.push(
      `{"@context": "https://schema.org","@type": "Organization","name": "Jagran Marathi","url": "https://www.marathijagran.com","sameAs":["https://www.facebook.com/marathijagran/"]}`
    );
    const schemaAarray_9=[];
    schemaAarray_9.push(
      `{"@context":"https://schema.org","@type":"WebSite","url":"https://www.marathijagran.com/","potentialAction":{"@type":"SearchAction","target":"https://www.marathijagran.com/search/{search_term_string}","query-input":"required name=search_term_string"}}`
    );
    const schemaAarray_10=[];
    schemaAarray_10.push(
      `{"@context":"https://schema.org","@type":"WebPage","name":"Marathi News, Breaking News in Marathi,  Latest News in Marathi,  Marathi Jagran","description":"Marathi Jagran Marathi News: , Breaking News in Marathi, Top News Headlines , Marathi Latest News, Today Top News , Marathi News Today on Marathi Jagran.","url":"https://www.marathijagran.com/","publisher":{"@type":"Organization","name":"Marathi Jagran","logo":{"@type":"ImageObject","url":"https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg","width":600,"height":60 } } }`
    );

    return (
        <div>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_8 }}  ></script>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_9 }}  ></script>
            <script type="application/ld+json" dangerouslySetInnerHTML={{__html: schemaAarray_10 }}  ></script>
            
        </div>
    );
}

export default SeoCommonSchema;