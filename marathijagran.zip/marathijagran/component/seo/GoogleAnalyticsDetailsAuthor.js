//import React from 'react';
function GoogleAnalyticsDetailsAuthor(props) {
    const {authorName,type} = props;

    return (
        <>
           <script type="text/javascript" dangerouslySetInnerHTML={{__html: `var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'${type}' ${authorName? `, 'tvc_author_name': '${authorName}'`:''} });`}}  />
        </>
    );
}

export default GoogleAnalyticsDetailsAuthor;