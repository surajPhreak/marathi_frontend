import { DomainPrefixes } from "../utils/ejConfig";
import moment from 'moment';
export const config = { amp: true };
const Meta = (props) => {
    const {articledetaildata, urlRoughter} = props;
    // console.log(DomainPrefixes.ImagePath + articledetaildata.imagePath);
    //const authorUrl = articledetaildata.authorEng.toLowerCase().split(' ').join('-');
    const authorUrl = (articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? " " : articledetaildata.authorUrl;
    // const bigImage = articledetaildata.imagePath.split(',');
    const subcatt = articledetaildata.subcategory?articledetaildata.subcategory.toLowerCase()+'/':'';
    const carvar = articledetaildata.category.toLowerCase().split(' ').join('-'); 

    const ampBodyWithoutHtml=articledetaildata.body.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
    const topDealUrl = 'https://english.jagran.com/top-deals/'+ articledetaildata.category.toLowerCase().split(' ').join('-') ;
    const catlUrl = ( (articledetaildata.subcategory==null) || (articledetaildata.subcategory==undefined) ) ? "" : ('https://english.jagran.com/'+ articledetaildata.category.toLowerCase().split(' ').join('-') + '/' + articledetaildata.subcategory.toLowerCase().split(' ').join('-')) ;
    
    const schemaAarray_1=[];
    schemaAarray_1.push({
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "url": `${ DomainPrefixes.UrlPrifix +'/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id}`,
        "mainEntityOfPage":{ '@type':"WebPage", "@id":`${ DomainPrefixes.UrlPrifix +'/' + carvar + "/" + subcatt + articledetaildata.webTitleUrl+'-'+articledetaildata.id}` },
        "headline": `${ articledetaildata.headline.slice(0, 108) }`,
        "datePublished": `${moment(articledetaildata.pubDate).format()}`,
        "dateModified": `${moment(articledetaildata.modDate).format()}`,
        "description": `${articledetaildata.summary}`,
        "articleBody": `${ampBodyWithoutHtml1}`,
        "articleSection": `${articledetaildata.category}`,
        "author": { "@type": "Person", "name": `${articledetaildata.authorEng}`, "url":`${DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl}` },
        "publisher": { "@type": "Organization", "name": "Jagran English", "logo": { "@type": "ImageObject", "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png", "width": 600, "height": 60 } },
        "image": { "@type": "ImageObject", "url": `${DomainPrefixes.ImagePath + articledetaildata.imagePath}`, "height":675, "width":1200 }
});
const schemaAarray_2 = { 
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "item": {"@id": "https://english.jagran.com","name": "News"}
        },
        {
        "@type": "ListItem",
        "position": 2,
        "item": {"@id": `${  DomainPrefixes.UrlPrifix +'/'+ articledetaildata.category.toLowerCase() }`,
        "name":`${articledetaildata.category}`}
        }
    ]
};
(articledetaildata.subcategory==null)||(articledetaildata.subcategory==undefined) ? '' : schemaAarray_2.itemListElement.push({
      "@type": "ListItem",
          "position": 3,
          "item": {"@id": `${catlUrl}`,
         "name":`${articledetaildata.subcategory}`}
 }) ;
const schemaAarray_3=[];
schemaAarray_3.push({ 
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "item": {"@id": "https://english.jagran.com","name": "News"}
        },
        {
        "@type": "ListItem",
        "position": 2,
        "item": {"@id": "https://english.jagran.com/top-deals",
        "name":"Top Deals"}
        },
        {
            "@type": "ListItem",
            "position": 3,
            "item": {"@id": `${  topDealUrl  }`,
            "name":`${articledetaildata.category}`}
        },
        {
            "@type": "ListItem",
            "position": 4,
            "item": {"@id": `${DomainPrefixes.UrlPrifix +'/top-deals/' + carvar + "/" + subcatt}`,
            "name":`${ (articledetaildata.subcategory==null)||(articledetaildata.subcategory==undefined) ? '' : articledetaildata.subcategory }`}
        }
    ]
});
return(
    <>
    <title>{( (articledetaildata.metaTitle==undefined)||(articledetaildata.metaTitle==null) ) ? articledetaildata.headline : articledetaildata.metaTitle}</title>
    <meta name="description" content={( (articledetaildata.summary==undefined)||(articledetaildata.summary==null) )?' ':articledetaildata.summary} />
    <meta name="keywords" content={( (articledetaildata.keywords==undefined)||(articledetaildata.keywords==null) )?' ':articledetaildata.keywords} />   
    {/* <link rel="canonical" href={DomainPrefixes.UrlPrifix +'/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.webTitleUrl+'-'+articledetaildata.id} /> */}
    <meta name="theme-color" content="#dc0228" />
    <meta property="og:title" content={articledetaildata.headline} />
    <meta property="og:description" content={articledetaildata.summary} />
    <meta property="og:url" content={DomainPrefixes.UrlPrifix +'/' + carvar + "/" + subcatt+ articledetaildata.webTitleUrl+'-'+articledetaildata.id} />
    <meta property="og:image" content={DomainPrefixes.ImagePath + articledetaildata.imagePath} />
    <meta property="og:site_name" content="English Jagran" />
    <meta property="og:type" content="Article" />
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_1)}}  />
    {/* <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  /> */}
    {        
        ( urlRoughter.match('top-deals') ) ? 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_3)}}  />) : 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  />)
    }
    </>
)
}
export default Meta;