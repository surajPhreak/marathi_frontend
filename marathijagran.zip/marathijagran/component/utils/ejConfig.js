const environment = process.env.NODE_ENV === "production";

const DomainPrefixes = {
  UrlPrifix: "https://www.marathijagran.com",
  ImagePath: "https://img.marathijagran.com/",
};

//const apiEndUrl = "http://34.93.183.178:3001/";
//const apiEndUrl = "https://stg-api.marathijagran.com/";
const apiEndUrl = "https://api.marathijagran.com/";
//const apiEndUrl = "http://localhost:3001/";
const DMP_BASE_URL = 'https://stg-jnmdmp.jagran.com/api/v1/';
const DMP_AUTH_TOKEN = 'Q6P5sPR703b2oSw7OBWti950a6wF9aYesx9bQBXx4meutugUxdDwgf5L8kspzuGr';

const PageAPI = {
  Category_API: apiEndUrl + "posts/parentcategory/",

  HomePone_API: apiEndUrl + "posts/homePosts/1/5",
  TagwordBase_API: apiEndUrl + "posts/tagwise/",
  NonAMPArticle_API: apiEndUrl + "post/",
  Authors_API: apiEndUrl + "authors/",
  AuthorListing_API1: apiEndUrl + "posts/author2/",
  AuthorProfile_API1: apiEndUrl + "authors/",
  Latestarticles_API: apiEndUrl + "posts/onlyPosts/",
  SubcategoryListing_API: apiEndUrl + "posts/catWithSubCat2/",
  HomeCategory_API: apiEndUrl + "posts/parentcategory/",

  Article_API: apiEndUrl + "post/amp/",
  KeywordBase_API: apiEndUrl + "search/",
  Related_TagBase_API: apiEndUrl + "posts/tagwiseArray2/1/5?tags=",
  webStories_API:"https://api-webstory.jnm.digital/webstoryapi/marathi/ampstorieshome/6",
  
  feed_LatestPosts_API: apiEndUrl + "posts/LatestPostsForFeeds/",
  feed_Category_API: apiEndUrl + "posts/feedByCategory/",
  feed_SubcategoryListing_API: apiEndUrl + "posts/feedcatWithSubCat2/",
  feed_TagwordBase_API: apiEndUrl + "posts/feedtagwise/",
  ANONYMOUSUSERTRACKING_API: DMP_BASE_URL+"anonymous/visit"
};
function padTo2Digits(num) {
  return num.toString().padStart(2, "0");
}
function convertToISOFormat(timeString) {
  let datavalue = new Date(timeString);
  const updatedDate =
    datavalue.getFullYear() +
    "-" +
    padTo2Digits(datavalue.getMonth() + 1) +
    "-" +
    datavalue.getDate() +
    "T" +
    padTo2Digits(datavalue.getHours()) +
    ":" +
    padTo2Digits(datavalue.getMinutes()) +
    ":" +
    padTo2Digits(datavalue.getSeconds()) +
    "+05:30";
  return updatedDate;
}

const formatDate = (date) => {
  const newDate = new Date(date);
  let month = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  return `${newDate.getDate()}-${
    month[newDate.getMonth()]
  }-${newDate.getFullYear()}`;
};
function getFullTime(istdataformate) {
  function addZero(i) {
    if (i < 10) {
      i = "0" + i;
    }
    return i;
  }
  var TimeVal = new Date(istdataformate);

  let hh = addZero(TimeVal.getHours());
  let AmPm = hh < 12 ? "AM" : "PM";

  hh %= 12;
  hh = hh || 12;
  let mm = addZero(TimeVal.getMinutes());
  let ss = addZero(TimeVal.getSeconds() ? TimeVal.getSeconds() : "");
  return hh+":"+mm+":"+ss+""+ AmPm;
}
function getCookie(name) {
  if (typeof document !== 'undefined') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.startsWith(name + '=')) {
        return decodeURIComponent(cookie.substring(name.length + 1));
      }
    }
  }
  return null;
}
function setCookie(name, value,day) {
  if (typeof document !== 'undefined') {
    let date=day?day:365
    const maxAge = date * 24 * 60 * 60; 
    const expires = new Date(Date.now() + maxAge * 1000); 
    document.cookie = name + "=" + value + "; expires=" + expires.toUTCString() + "; path=/";
  }
}
function removeCookie(name) {
  document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}

export { DomainPrefixes, PageAPI, convertToISOFormat, getFullTime, formatDate, getCookie, setCookie, removeCookie, DMP_AUTH_TOKEN};
