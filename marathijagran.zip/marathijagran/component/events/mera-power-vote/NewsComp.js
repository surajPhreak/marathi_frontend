import axios from "axios";
//import { DomainPrefixes, PageAPI } from "../../../../../component/utils/ejConfig";
import { DomainPrefixes, PageAPI } from "../../utils/ejConfig";
import Image from 'next/image'
import { useState } from "react";
const NewsComp = (props) => {
    const {categoryData, compHeadTxt, utm, tagHeadUrl, link} = props;
    const utmData = utm?utm:''
    function removeLastId(str) {
        const reLast = /-\d+$/;
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    const PreRenderd = categoryData ? categoryData.posts : '';
    const [post, setPost] = useState(2);
    const [posts, setPosts] = useState(PreRenderd); 
    const [hidebtn, setHidebtn] = useState(true);

  //  const getMorePost = async () => {  
  //   try {
  //     const res = await axios('/api/ajaxCalls' ,{params:{url: `${PageAPI.TagwordBase_API+'year-ender-2022/'+post+'/10'}`}});
  //     const newPosts = await res.data;   
  //       const dataPost = newPosts.posts;
  //     setPosts((post) => [...post, ...dataPost]);   
  //       setPost(post + 1);

  //    }
  //   catch (err) {
  //     setHidebtn(false)
  //   }

  // };

    return(
            <div className="yearender list-article">
                <div className="master-div">
                <div className="allhead">
               {tagHeadUrl ? <h2><a href={tagHeadUrl}>{compHeadTxt}</a></h2> :                
                <h2><a href={'/tag/'+link} title={categoryData[0].category} >
                {(compHeadTxt!=null && compHeadTxt!=undefined)? compHeadTxt : categoryData[0].category}
                </a></h2>
                }

                
                </div>
                <ul className="list">
                    {
                       categoryData.map( (data, index) => { 
                            //const ImpPath = data.imagePath.split(',');
                            
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';
                            return(              
                            <li className="article" key={index}>                            
                                <figure><a href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id+utmData} title={data.headline}>
                                    <Image width={100} height={100} unoptimized src={DomainPrefixes.ImagePath+data.imagePath} alt={data.headline} /></a></figure>
                                <div className="summary">
                                    {/* <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.subcategory?data.subcategory:data.category}</span>{data.pubDate}</span></div> */}
                                    <p><a href={'/'+data.categoryUrl+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id+utmData} title={data.headline}>{data.headline}{(data.isLiveBlog)?(<b className="liveBlink"></b>):""}</a></p>
                                </div>
                            </li>)                
                        })
                    }
                </ul>
                {categoryData && categoryData.sitemeta && posts.length< categoryData.sitemeta.count &&
                <div className="load-more"><button id="pagination-btn" className="btn btn-primary" onClick={getMorePost}>Load More</button>
                </div>}
                
                </div>
          <style>
        {`
        .yearender.list-article .list li{width:23%;}
        .yearender.list-article .list li:nth-child(2n + 2){margin-right:20px;}
        .yearender.list-article .list li:nth-last-child(2), .yearender.list-article .list li:last-child{margin-bottom: 15px;padding-bottom: 15px;border-bottom:1px solid var(--light-grey);}
        .yearender.list-article .list li .summary {overflow: hidden; height: 106px;}
        .yearender.list-article h2{font-size: 1.2rem; font-weight: 600;}  
        @media screen and (max-width:  1024px) {
           .yearender.list-article  .list-article .list
          {overflow-x: scroll; overflow-y: hidden; justify-content: flex-start; display: flex;
            flex-wrap: wrap; margin-left: -20px; margin-right: -20px;padding: 0 20px;}
        .yearender.list-article .list li .summary{ overflow: inherit;height: inherit;}
     .yearender.list-article .list li{ width: 100%; white-space: normal;}
      .main-content{margin-bottom:0px;}
     }
        `}
    </style>
            </div>
            
    )
   
}
export default NewsComp;