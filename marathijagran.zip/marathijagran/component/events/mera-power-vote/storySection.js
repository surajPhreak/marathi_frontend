import React from 'react';
import Image from 'next/image';
import { DomainPrefixes, PageAPI } from "../../../component/utils/ejConfig";
import {useRouter} from 'next/router';

function StorySection(props) {
    const {data} = props
    const data1 = data.posts;
    const router = useRouter().asPath;
    return (
        <>           
            <div className="StorySection sectionThree">
                { router.match('/student') || router.match('/farmer') | router.match('/urban') | router.match('/women') ?
                <div className="container">
                    <div className="lineBg"><img src="https://www.jagranimages.com/images/merapowervote/lineBg.png" alt='' /></div>
                    <div className="row">
                        <div className="col-lg-12 text-center">
                            <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
                                <h2>में तैयार हूँ</h2>
                                <h1>मतदान को</h1>
                            </div>
                        </div>
                    </div>
                </div>
                : ''}


                <div className="carouselSlide">
                        <div className="owl-carousel owl-theme">
                            {data1.map((item, index)=>{
                           return(
                            <React.Fragment key={index}>
                            <div>
                                <Image unoptimized width={442} height={552} src={DomainPrefixes.ImagePath +item.imagePath} alt={item.headline} />
                                <div className="slideText">
                                <a href={'/'+item.categoryUrl+'/'+item.webTitleUrl}><h2>{item.headline}</h2></a>

                                    {/* <a href={(item)}>
                                        <h2>{item.headline}</h2>
                                    </a> */}
                                </div>
                            </div>
                            </React.Fragment>
                            )
                           })}
                        </div>
                    </div>
       
            </div>  
        </>
    )
}

export default StorySection