import { DomainPrefixes } from "../../../component/utils/ejConfig";
const topDeals = (props) => {
    const {topDealsData} = props;
    return(
        <div className="master-div">
            <div className="allhead"><h2><a href="/top-deals" title="Top Deals">Top Deals</a></h2></div>
            <ul className="list">
                {
                    topDealsData.map( (data, index) => { return (              
                        <li className="article" key={index}>                            
                            <figure><a href={'/'+data.titleUrl} title={data.english_headline_t}><img src={DomainPrefixes.ImagePath+data.image_path_t} alt={data.english_headline_t} /></a></figure>
                            <div className="summary">
                                <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.categoryName}</span></span></div>
                                <p><a href={'/'+data.titleUrl} title={data.english_headline_t}>{data.english_headline_t}</a></p>
                            </div>
                        </li>    )                
                     })
                }
            </ul>
        </div>
    )
}
export default topDeals; 