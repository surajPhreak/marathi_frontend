import React, { useState, useEffect } from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/Schedule.module.css';

export default function Schedule(props) {
    const { data } = props

    const [useData, setData] = useState(data);
    const [activeIndex, setActiveIndex] = useState(0); // Set initial activeIndex to 0
    const [DateElection, setDateElection] =useState('19 एप्रिल 2024');

    useEffect(() => {
        setData(data); // Update data when props change
    }, [data]);

    const toggleNavBar = (index) => {
        setActiveIndex(index === activeIndex ? null : index);
    };

    const handleSelectChange = async (event) => {
        const selectedValue = event.target.value;
        if(selectedValue=='phase1'){
        setDateElection('19 एप्रिल 2024')
        }
        if(selectedValue=='phase2'){
            setDateElection('26 एप्रिल 2024')
        }
        if(selectedValue=='phase3'){
            setDateElection('7 मे 2024')
        }
        if(selectedValue=='phase4'){
            setDateElection('13 मे 2024')
        }
        if(selectedValue=='phase5'){
            setDateElection('20 मे 2024')
        }
        if(selectedValue=='phase6'){
            setDateElection('25 मे 2024')
        }
        if(selectedValue=='phase7'){
            setDateElection('1 जून 2024')
        }
        try {
            const res = await fetch(`https://json-plus3331.jagran.com/election/schedules/${selectedValue}.json`);
            if (!res.ok) {
                throw new Error('Failed to fetch posts');
            }
            const newPosts = await res.json();
            setData(newPosts);
            setActiveIndex(0); // Reset activeIndex to 0 when phase changes
        } catch (error) {
            console.error('Error fetching posts:', error);
        }
    };

    return (
        <>
            <div className={`${styles.Schedule} mb30`}>
                <div className={styles.top}>
                    <h1>निवडणूक वेळापत्रक 2024</h1>

                    <ul className={styles.phases}>
                        <li>543 जागा</li>
                        <li>
                            <select onChange={handleSelectChange}>
                                <option value={'phase1'}>Phase1</option>
                                <option value={'phase2'}>Phase2</option>
                                <option value={'phase3'}>Phase3</option>
                                <option value={'phase4'}>Phase4</option>
                                <option value={'phase5'}>Phase5</option>
                                <option value={'phase6'}>Phase6</option>
                                <option value={'phase7'}>Phase7</option>
                            </select>
                        </li>
                    </ul>
                </div>

                <ul className={styles.pollingDetail}>
                    <li>{useData.root.phase.length} States</li>
                    <li>{useData.root.phases_count} Seats</li>
                    <li>Polling date: {DateElection}</li>
                    <li>मोजणीची तारीख:  <b>4 जून 2024</b></li>
                </ul>

                <ul className={styles.scheduleDetail}>
                    {useData.root.phase.map((item, index) => {
                        return (
                            <React.Fragment key={index}>
                                <li>
                                    <div className={styles.heading}>
                                        {/* <a href={`/elections/lok-sabha/${item.state_name_en.replace(' ', '-').toLowerCase()}.html`}>{item.state_name_hn}</a> */}
                                        <span>{item.state_name_mh}</span>
                                        <span>{item.constituency.length} जागा</span>
                                        {item.length !== 0 ? <i className={`${styles.navIcon} ${activeIndex === index ? `${styles.navIconActive}` : ''}`} onClick={() => toggleNavBar(index)}>{activeIndex === index ? '-' : '+'}</i> : ''}
                                    </div>
                                    <ul className={`${styles.link} ${styles.header__submenu} ${activeIndex === index ? `${styles.header__submenu__opensubmenu}` : ''}`}>
                                        {item.constituency.map((constituency, i) => {
                                            return (
                                                <React.Fragment key={i}>
                                                    {/* <li><a href={`/elections/lok-sabha/constituency/${constituency.loksabha_en.replace(' ', '-').toLowerCase()}.html`}>{constituency.loksabha_gj}</a></li> */}
                                                    <li>{constituency.loksabha_mh}</li>
                                                </React.Fragment>
                                            )
                                        })}
                                    </ul>
                                </li>
                            </React.Fragment>
                        )
                    })}
                </ul>
            </div>
        </>
    )
}
