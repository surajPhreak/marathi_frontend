import React from 'react'
import { useState } from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/ConsituencyWinner.module.css'

export default function ConsituencyWinner(props) {
    const {data, name, payload1} = props;

const [selectedOption, setSelectedOption] = useState('');
const [displayedData, setDisplayedData] = useState(data);
const [isOpen, setOpen] = useState(true);

const handleSelectChange = async (event) => {
  const selectedValue = event.target.value;
  try {
    const res = await fetch(`https://api.jagran.com/api/jagran/election/ls/mh/constituencydetail/${name}/${selectedValue}`, payload1);
    if (!res.ok) {
      throw new Error('Failed to fetch posts');
    }
    const newPosts = await res.json();

    setSelectedOption(selectedValue);
    setDisplayedData(newPosts);

    setOpen(true); // Use setOpen to update the isOpen state

  } catch (error) {
    console.error('Error fetching posts:', error.message);
    setSelectedOption(selectedValue);
    setOpen(false); // Use setOpen to update the isOpen state
  }
};

    return (
        <>
            <div className={`${styles.ConsituencyWinner} mb30`}>
                <div className={styles.top}>
                    <h2>{displayedData.loksabhaMH}, {displayedData.statenameHN} चा विजेता</h2>
                    <div className={styles.select}>
                        <select value={selectedOption} onChange={handleSelectChange}>
                            <option value="2019">2019</option>
                            {/* <option value="2014">2014</option>
                            <option value="2009">2009</option>
                            <option value="2004">2004</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1996">1996</option>
                            <option value="1991">1991</option>
                            <option value="1989">1989</option>
                            <option value="1984">1984</option>
                            <option value="1980">1980</option>
                            <option value="1977">1977</option>
                            <option value="1971">1971</option>
                            <option value="1967">1967</option>
                            <option value="1962">1962</option>
                            <option value="1957">1957</option>
                            <option value="1952">1952</option> */}
                        </select>
                    </div>
                </div>
                {isOpen==true?
                <ul className={`${styles.list}`}>
                    <li>
                        <div className={styles.topBlock}>
                            <div className={styles.image}>
                                <Image unoptimized width={94} height={94} src={`https://www.jagranimages.com/images/electionImages/${displayedData.candidateNameEN.replaceAll(' ', '-')}.jpg`}
  onError={(e) => {e.target.src = 'https://www.jagranimages.com/images/electionImages/default-election-images.jpg';  }}
/>
                            </div>
                            <div className={styles.text}>
                                {/* <div className={styles.heading}><a href={`/elections/candidates/${displayedData.candidateNameEN.toLowerCase().replaceAll(' ','-')}/${displayedData.candidateId}.html`}>{displayedData.candidateNameMH}</a></div> */}
                                <div className={styles.heading}>{displayedData.candidateNameMH}</div>
                                
                                <ul className={styles.partyDetail}>
                                    <li>
                                        <span>पार्टी :</span> 
                                        <a href={`https://www.marathijagran.com/elections/${displayedData.candidatePartyShortNameEN.toLowerCase()}/party.html`}>{displayedData.candidatePartyNameMH}
                                        <svg><use href={`/electionsprite.svg#${displayedData.candidatePartyShortNameEN.toLowerCase()}`}></use></svg></a>
                                    </li>
                                    <li>
                                        <span>मिळालेली मते :</span> 
                                        {displayedData.candidateVoteRecieved}
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                   
                    <li>
                        <div className={styles.name}>मत %</div>
                        <div className={styles.detail}>{displayedData.votePercentage}</div>
                    </li>
                    <li>
                        <div className={styles.name}>पुरुष मतदार</div>
                        <div className={styles.detail}>{displayedData.maleVoter}</div>
                    </li>
                    <li>
                        <div className={styles.name}>महिला मतदार</div>
                        <div className={styles.detail}>{displayedData.femaleVoter}</div>
                    </li>
                    <li>
                        <div className={styles.name}>एकूण मतदार</div>
                        <div className={styles.detail}>{displayedData.totalVoter}</div>
                    </li>

                    <li className={styles.nearestCon}>
                        <div className={styles.name}>जवळचा प्रतिस्पर्धी</div>
                        {/* <div className={styles.detail}>
                            <a href={`/elections/candidates/${displayedData.nearestCandidateNameEn.toLowerCase().replaceAll(' ','-')}/${displayedData.nearestCandidateId}.html`}>{displayedData.nearestCandidateNameMH}</a></div> */}
                            <div className={styles.detail}>{displayedData.nearestCandidateNameMH}</div>
                    </li>
                    <li>
                        <div className={styles.name}>पार्टी</div>
                        <div className={styles.detail}><a href={`https://www.marathijagran.com/elections/${displayedData.nearestCandidatePartyShortNameEn.toLowerCase()}/party.html`}>{displayedData.nearestCandidatePartyNameMH}</a></div>
                        <div className={styles.logo}>
                        <svg><use href={`/electionsprite.svg#${displayedData.nearestCandidatePartyShortNameEn.toLowerCase()}`}></use></svg>
                        </div>
                    </li>
                    <li>
                        <div className={styles.name}>मिळालेली मते</div>
                        <div className={styles.detail}>{displayedData.nearestCandidateVoteRecieved}</div>
                    </li>
                    <li>
                        <div className={styles.name}>पराभवाचे अंतर</div>
                        <div className={styles.detail}>{displayedData.lossDiff}</div>
                    </li>
                </ul>:
                <div className={styles.list}>no data found</div>
                }

            </div>
        </>
    )
}