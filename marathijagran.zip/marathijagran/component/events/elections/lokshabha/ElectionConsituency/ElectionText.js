import React, { useState } from 'react'
import styles from '../../../../../public/css/ElectionText.module.css'
import { useRouter } from 'next/router';
import css from '../../../../../public/css/candidateShare.module.css';

export default function ElectionText(props) {
    const {data, label} = props
    
    const [displayCount, setDisplayCount] = useState(true)

    const loadMoreItems  = ()=>{
     setDisplayCount(!displayCount)
    }

    const router = useRouter();
    const routerURL = router.asPath;

    return (
        <>
            <div className={`${styles.ElectionText} mb30`}>
                <div className={`${styles.hiddenDiv} ${styles.discript}`} style={{ height: displayCount ? '200px' : 'auto', overflow : 'hidden' }} dangerouslySetInnerHTML={{ __html: data.loksabhaSeatDescriptionMH }}
          />
            <div className={css.socialBox}>
        <div className={styles.socialList}>
        {/* <ul className={css.socialIcon}>
                            <li>
                                <a target='_blank' rel='noreferrer' title='facebook' href={`https://www.facebook.com/sharer.php?u=https://www.jagran.com${routerURL}`}>
                                    <div className={css.icon}>
                                        <svg><use href="/sprite.svg#facebook"></use></svg>
                                    </div>
                                    
                                </a>
                            </li>
                            <li>
                                <a target='_blank' rel='noreferrer' title='twitter' href={`https://twitter.com/share?url=https://www.jagran.com${routerURL}&via=JagranaNews`}>
                                    <div className={css.icon}>
                                        <svg><use href="/sprite.svg#twitter"></use></svg>
                                    </div>
                                   
                                </a>
                            </li>
                            <li>
                                <a target='_blank' rel='noreferrer' title='whatsapp' href={`https://api.whatsapp.com/send?text=https://www.jagran.com${routerURL}`}>
                                    <div className={css.icon}>
                                        <svg><use href="/sprite.svg#whatsapp"></use></svg>
                                    </div>
                                    
                                </a>
                            </li>
                            
                        </ul> */}
                        {displayCount ? (<div className={styles.audekhein} style={{ textAlign : 'center' }}>
                       <a onClick={loadMoreItems}>पुढे वाचा </a>
                    </div>) : (<div className={`${styles.audekhein} ${styles.small}`} style={{ textAlign : 'center' }}>
                       <a onClick={loadMoreItems}>कमी करणे </a>
                    </div>) }
                        </div>
          </div>
                {/* {displayCount && <div className={styles.audekhein}>
                       <a onClick={loadMoreItems}>और पढ़ें </a>
                    </div> } */}

             
                </div>
        </>
    )
}