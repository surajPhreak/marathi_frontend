import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/ElectionPartyDetail.module.css'

export default function ElectionPartyDetail(props) {
    const { data }=  props
  return (
    <>
        <div className={`${styles.ElectionPartyDetail} mb30`}>
            <div className={styles.block}>
                <div className={styles.image}>
                    <svg><use href={`/electionsprite.svg#${data.shortPartyNameEN?data.shortPartyNameEN.toLowerCase(): ''}`}></use></svg>
                </div>

                <h1>{data.partyNameMH}</h1>
            </div>
            <p>{data.partyDescriptionMH}</p>
        </div>
    </>
  )
}