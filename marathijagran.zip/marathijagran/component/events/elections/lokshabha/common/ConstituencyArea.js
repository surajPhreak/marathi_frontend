
import styles from '../../../../../public/css/ConstituencyArea.module.css'
import { useState } from 'react';

function ConsituncyLinkComp(props) {
    const { data, label } = props

    const [displayCount, setDisplayCount] = useState(true)
    

    const loadMoreItems  = ()=>{
     setDisplayCount(!displayCount)
    }
 
    const handleSelectChange = async (event) => {
        const selectedValue = event.target.value;
        urlloadevent(selectedValue)
      }

    // const filteredCities = cities.filter(state =>{
    //     if(statename=='delhi'){
    //       return  state['state_value'] == 'delhi-ncr'

    //     }
    //     else{
    //         return   state['state_value'] == statename
    //     }
    // });

    
    return (
        <>
        <div className={`${styles.electionNav}`}>
        <div className={styles.top}>
            <h1>{`${label} लोकसभा `}</h1>
            {/* <div className={styles.select}>
            <select onChange={handleSelectChange}>
            <option value="राज्य चुनें ">अपना राज्य चुनें </option>    
            <option value="/elections/lok-sabha/uttar-pradesh.html">उत्&zwj;तर प्रदेश</option>
<option value="/elections/lok-sabha/andaman-and-nicobar-islands.html">अंडमान निकोबार द्वीप समूह</option><option value="/elections/lok-sabha/andhra-pradesh.html">आंध्रप्रदेश</option><option value="/elections/lok-sabha/arunachal-pradesh.html">अरुणाचल प्रदेश</option><option value="/elections/lok-sabha/assam.html">असम</option><option value="/elections/lok-sabha/bihar.html">बिहार</option><option value="/elections/lok-sabha/chandigarh.html">चंडीगढ़</option><option value="/elections/lok-sabha/chhattisgarh.html">छत्&zwj;तीसगढ़</option>
<option value="/elections/lok-sabha/dadra-and-nagar-haveli.html">दादर और नागर हवेली</option><option value="/elections/lok-sabha/daman-and-diu.html">दमन और दीव</option><option value="/elections/lok-sabha/goa.html">गोवा</option><option value="/elections/lok-sabha/haryana.html">हरियाणा</option><option value="/elections/lok-sabha/himachal-pradesh.html">हिमाचल प्रदेश</option><option value="/elections/lok-sabha/jammu-and-kashmir.html">जम्मू और कश्मीर</option><option value="/elections/lok-sabha/jharkhand.html">झारखंड</option><option value="/elections/lok-sabha/karnataka.html">कर्नाटक</option><option value="/elections/lok-sabha/kerala.html">केरल</option><option value="/elections/lok-sabha/lakshadweep.html">लक्षद्वीप</option><option value="/elections/lok-sabha/madhya-pradesh.html">मध्यप्रदेश</option><option value="/elections/lok-sabha/maharashtra.html">महाराष्ट्र</option><option value="/elections/lok-sabha/manipur.html">मणिपुर</option><option value="/elections/lok-sabha/meghalaya.html">मेघालय</option><option value="/elections/lok-sabha/mizoram.html">मिजोरम</option><option value="/elections/lok-sabha/nagaland.html">नगालैंड</option><option value="/elections/lok-sabha/nct-of-delhi.html">राष्&zwj;ट्रीय राजधानी क्षेत्र दिल्&zwj;ली</option>
<option value="/elections/lok-sabha/odisha.html">ओडिशा</option><option value="/elections/lok-sabha/punjab.html">पंजाब</option><option value="/elections/lok-sabha/rajasthan.html">राजस्&zwj;थान</option>
<option value="/elections/lok-sabha/sikkim.html">सिक्किम</option><option value="/elections/lok-sabha/tamil-nadu.html">तमिलनाडु</option><option value="/elections/lok-sabha/telangana.html">तेलंगाना</option><option value="/elections/lok-sabha/tripura.html">त्रिपुरा</option><option value="/elections/lok-sabha/uttarakhand.html">उत्&zwj;तराखंड</option>
<option value="/elections/lok-sabha/west-bengal.html">पश्चिम बंगाल</option>

            </select>
            </div> */}
        </div>
        </div>
        
          <div className={`${styles.listcities} ${styles.citynav}`}>
            
           
                    {data.length>0&&data.slice(0, 12).map((city) => (
                        <>
                        <a href={`/elections/lok-sabha/constituency/${city.loksabhaEN.toLowerCase().replaceAll(' ', '-')}.html`} title={city.loksabhaMH}>{city.loksabhaMH}</a>
                        </>
                    )
                   )}
                                       
                     {data.length > 9? displayCount ? (
                         <a className={`${styles.aurdekhein} ${styles.gap}`} onClick={loadMoreItems}>
                            मुख्य लोकसभा मतदारसंघ निवडा <svg width="18px" height="18px" viewBox="-1.5 0 15 15" xmlns="http://www.w3.org/2000/svg">
  <path fill="#000000" fill-rule="evenodd" d="M574,120 C575.324428,120 580,114.054994 580,110.833333 C580,107.611672 577.313708,105 574,105 C570.686292,105 568,107.611672 568,110.833333 C568,114.054994 572.675572,120 574,120 Z M574,113.333333 C575.420161,113.333333 576.571429,112.214045 576.571429,110.833333 C576.571429,109.452621 575.420161,108.333333 574,108.333333 C572.579839,108.333333 571.428571,109.452621 571.428571,110.833333 C571.428571,112.214045 572.579839,113.333333 574,113.333333 Z" transform="translate(-568 -105)"/>
</svg></a>
                    ) : (
                        <a className={styles.aurdekhein} onClick={loadMoreItems}>कमी करणे <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM8.96963 8.96965C9.26252 8.67676 9.73739 8.67676 10.0303 8.96965L12 10.9393L13.9696 8.96967C14.2625 8.67678 14.7374 8.67678 15.0303 8.96967C15.3232 9.26256 15.3232 9.73744 15.0303 10.0303L13.0606 12L15.0303 13.9696C15.3232 14.2625 15.3232 14.7374 15.0303 15.0303C14.7374 15.3232 14.2625 15.3232 13.9696 15.0303L12 13.0607L10.0303 15.0303C9.73742 15.3232 9.26254 15.3232 8.96965 15.0303C8.67676 14.7374 8.67676 14.2625 8.96965 13.9697L10.9393 12L8.96963 10.0303C8.67673 9.73742 8.67673 9.26254 8.96963 8.96965Z" fill="#000000"/>
                        </svg></a>
                    ):'' }


                    <div className={displayCount ? styles.displayText : ''}>
                    {data.slice(9).map((city) => (
                        <>
                        <a href={`/elections/lok-sabha/constituency/${city.loksabhaEN.toLowerCase().replaceAll(' ', '-')}.html`} title={city.loksabhaMH}>{city.loksabhaMH}</a>
                        </>
                    )
                   )}
                   </div>
          </div>
          </>
    )
}

export default ConsituncyLinkComp
