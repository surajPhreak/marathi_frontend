import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/ResultGraph.module.css'
import { useState, useEffect } from 'react'

export default function ResultGraph(props) {

  const { data, payload1 } = props;
  const [selectedState, setSelectedState] = useState('maharashtra');
  const [selectedYear, setSelectedYear] = useState('2019');
  const [showdata, setshowdata] = useState(data);


  const [animationDone, setAnimationDone] = useState(false);

  useEffect(() => {
    setAnimationDone(false)
    // setAnimationDone(true) ;
   let time= setTimeout(()=>{
      // setAnimationDone(item.party_total_seat)
       updatePie()
    }, 100)
    return ()=>{clearInterval(time)}
  }, [data]); // Trigger animation when data changes
 
  
  const updatePie=()=>{
    setAnimationDone(true)
  }

  useEffect(() => {
    if (selectedState && selectedYear) {

      fetch(`https://api.jagran.com/api/jagran/election/ls/mh/toptwopartiesbystate/${selectedState}/${selectedYear}`, 
      payload1
      // {
      //   headers: {
      //     Authorization:
      //       process.env.BEARER_STRING + process.env.BEARER_TOKEN1,
      //   }, }
        
        
        ).then((response) => response.json()).then((data) => setshowdata(data));
        
    }
    updatePie();
  }, [selectedState, selectedYear]);
 

  const handleStateChange = (e) => {
    const newState = e.target.value;
    setSelectedState(newState);
    setSelectedYear('2019'); // Reset selectedYear to 2019 when selectedState changes
    updatePie(); // Optionally trigger any updates needed when state changes
  };

  const handleYearChange = (e) => {
    const newYear = e.target.value;
    setSelectedYear(newYear);
    updatePie();
  };

  return (
    <>
      <div className={styles.ResultGraph}>
        <div className={styles.top}>
          <h2>परिणाम</h2>

          <div className={styles.select}>
          <select id="stateName" onChange={(e) => handleStateChange(e, 'state')} value={selectedState}>
          <option value="maharashtra" name="SELECTED">महाराष्ट्र</option> <option value="uttar-pradesh">उत्तर प्रदेश</option><option value="bihar">बिहार</option><option value="nct-of-delhi">दिल्ली</option><option value="punjab">पंजाब</option><option value="haryana">हरियाणा</option><option value="uttarakhand">उत्तराखंड</option><option value="jharkhand">झारखण्ड</option><option value="himachal-pradesh">हिमाचल प्रदेश</option><option value="jammu-and-kashmir">जम्मू-कश्मीर</option><option value="west-bengal">पश्चिम बंगाल</option><option value="odisha">ओडिशा</option><option value="gujarat">गुजरात</option><option value="rajasthan">राजस्थान</option><option value="madhya-pradesh">मध्यप्रदेश</option><option value="kerala">केरल</option><option value="chhattisgarh">छत्तीसगढ़</option>
            </select>
          </div>

          <div className={styles.select}>
          <select id="stateName" onChange={(e) => handleYearChange(e)} value={selectedYear}>
  {[2019, 2014, 2009, 2004,
    ...(selectedState !== 'chhattisgarh' && selectedState !== 'uttarakhand' && selectedState !== 'jharkhand' ? 
      [1999, 1998, 1996,
        ...(selectedState !== 'bihar' && selectedState !== 'haryana' && selectedState !== 'jammu-and-kashmir' ? 
          [1991, 1989, 1984, 1980, 1977, 1971, 1967,
            ...(selectedState !== 'gujarat' && selectedState !== 'maharashtra' && selectedState !== 'kerala' ? 
              [1962,
                ...(selectedState !== 'kerala' ? 
                  [1957, 1952] 
                  : []
                )
              ]
              : []
            )
          ]
          : []
        )
      ] 
      : []
    )
  ].filter(year => (
    // Filter out years not available for the selected state
    (selectedState === 'maharashtra' || year >= 1957) &&
    (selectedState === 'uttarakhand' || year >= 1952)
  )).map(year => (
    <option key={year} value={year}>{year}</option>
  ))}
</select>


          </div>
        </div>

        <ul className={styles.table}>
          <li>
            <div className={styles.party}>पार्टी</div>
            <div className={styles.result}>परिणाम</div>
            <div className={styles.year}>मत %</div>
          </li>
          <li className={`styles.${showdata.firstShortPartyNameEn.toLowerCase()}`}>
            <div className={styles.party}>
              <Image unoptimized width={20} height={20} src={`https://www.jagran.com/assets/images/events/partylogos/${showdata.firstShortPartyNameEn.toLowerCase()}-logo.png`} />
              {showdata.firstShortPartyNameMh}
            </div>
            <div className={styles.result}>{showdata.firstPartySeats}</div>
            <div className={styles.year}>{showdata.firstPartyPercentage}</div>
          </li>

         {showdata.secondShortPartyNameMh!='null'?<li className={`styles.${showdata.secondShortPartyNameEn.toLowerCase()}`}>
            <div className={styles.party}>
              <Image unoptimized width={20} height={20} src={`https://www.jagran.com/assets/images/events/partylogos/${showdata.secondShortPartyNameEn.toLowerCase()}-logo.png`} />
              {showdata.secondShortPartyNameMh}
            </div>
            <div className={styles.result}>{showdata.secondPartySeats}</div>
            <div className={styles.year}>{showdata.secondPartyPercentage}</div>
          </li>:'' }


          {<li>
            <div className={styles.party}>
              <Image unoptimized width={20} height={20} src='https://www.jagran.com/assets/images/events/partylogos/other-logo.png' />
              इतर
            </div>
            <div className={styles.result}>{showdata.otherTotalSeat}</div>
            <div className={styles.year}>{showdata.otherPartyPercentage}</div>
          </li> }

          

        </ul>

        <div className={styles.graph}>
        
{animationDone ?
        <ul className={styles.graphBars}>
        <li>
          <div className={`${styles.total} ${showdata.firstShortPartyNameEn?styles[showdata.firstShortPartyNameEn.toLowerCase()]:''}`} style={{ height: `${showdata.firstPartyPercentage?showdata.firstPartyPercentage+'%':'0'}`}}><span>{showdata.firstPartySeats}</span></div>
          <div className={`${styles.bar} ${showdata.firstShortPartyNameEn?styles[showdata.firstShortPartyNameEn.toLowerCase()]:''} getthisele`} data-progress={showdata.firstPartyPercentage}></div>
        </li>
        {showdata.secondShortPartyNameEn !='null'?<li>
          <div className={`${styles.total} ${showdata.secondShortPartyNameEn?styles[showdata.secondShortPartyNameEn.toLowerCase()]:''}`} style={{ height: `${showdata.secondPartyPercentage?showdata.secondPartyPercentage+'%':'0'}`, background: `${showdata.secondShortPartyNameEn}` }}><span>{showdata.secondPartySeats}</span></div>
          <div className={`${styles.bar} ${showdata.secondShortPartyNameEn?styles[showdata.secondShortPartyNameEn.toLowerCase()]:''} getthisele`} data-progress={showdata.secondPartyPercentage}></div>
        </li>:''}
        <li>
          <div className={styles.total} style={{ height: `${showdata.otherPartyPercentage?showdata.otherPartyPercentage+'%':'0'}`, background: 'rgb(204, 204, 204)' }}><span>{showdata.otherTotalSeat}</span></div>
          <div className={`${styles.bar} ${styles.other} getthisele`} data-progress={showdata.otherPartyPercentage}></div>
        </li>

      </ul> 
          :
'' }
        </div>
     

        <div className={styles.detail}>
          <ul>
            <li><span>महिला मतदार</span>{showdata.totalFemaleVoter.toLocaleString()}</li>
            <li><span>पुरुष मतदार</span>{showdata.totalMaleVoter.toLocaleString()}</li>
            <li><span>एकूण मतदार</span>{showdata.totalMaleAndFemale.toLocaleString()}</li>
          </ul>
        </div>

 
      </div>
    </>
  )
}