import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/Announcement.module.css'
export default function Announcement (props) {
    const { data, imageName, dataLink } = props
  return (
    <>
        <div className={`${styles.Announcement} mb30`}>
            <div className={styles.topText}>
                <h2>घोषणापत्र</h2>

                <div className={styles.image}>
                    <Image unoptimized width={89} height={101} src={`https://www.jagranimages.com/images/manifesto_logoa.jpg`} />
                </div>

                <p>अगर वोटर हैं आप, तो घोषणा पत्र भी हो आपका। बनाइए अपना घोषणा पत्र जिसे नीति नियंताओं तक पहुंचाने में हम देंगे आप का साथ। क्योंकि हर वोट कुछ कहता है।</p>
            </div>

            <h3>घोषणापत्र बनाना है बेहद आसान</h3>

            <ul className={styles.stepList}>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={16} height={22} src={`https://www.jagranimages.com/images/icn-2a.png`} />
                    </div>
                    <div className={styles.detail}>अपनी प्राथमिकता चुनें</div>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={16} height={22} src={`https://www.jagranimages.com/images/icn-3a.png`} />
                    </div>
                    <div className={styles.detail}>जानकारी दें</div>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={16} height={14} src={`https://www.jagranimages.com/images/icn-4a.png`} />
                    </div>
                    <div className={styles.detail}>सबमिट करें</div>
                </li>
            </ul>

            <ul className={styles.list}>
                <li>नीचे दिए बिन्दुओं को अपनी ज़रूरत के अनुसार 1 से 12 के वरीयता क्रम में रखें.</li>
                <li>क्लिक करके वरीयता सुनिश्चित करें.</li>
                <li>किसी बिंदु के क्रम को बदलने के लिए उसे दोबारा क्लिक करें या पूरे क्रम को बदलने के लिए अंत में दिए गए Reset का बटन दबाएँ</li>
            </ul>

            <ul className={styles.rateMenifesto}>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Corruption free governance / भ्रष्टाचार मुक्त शासन</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Inflation and  economy / महंगाई एवं अर्थव्यवस्था</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Education and Skill Development / शिक्षा एवं कौशल विकास</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Job creation & job sustainability / रोजगार सृजन एवं स्थिरता</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Women Safety and Empowerment / महिला सुरक्षा एवं सशक्तिकरण</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Law & Order / कानून -  व्यवस्था</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Road  & Infrastructure  development / सड़क एवं ढांचागत विकास</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>National Security & Internal Insurgency  / राष्ट्रीय सुरक्षा एवं आंतरिक विद्रोह</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Agriculture Reforms & Farmers conditions / कृषि सुधार एवं किसानों की स्थिति</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Social justice & equality / सामाजिक न्याय एवं समानता</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Secularism & Communal Harmony / धर्मनिरपेक्षता एवं धार्मिक सौहार्द</p>
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={17} height={20} src={`https://www.jagranimages.com/images/cursor-sign.png`} />
                    </div>
                    <p>Health and Social Welfare scheme / स्वास्थ्य एवं सामाजिक कल्याण योजना</p>
                </li>
            </ul>

            <div className={styles.button}>
                <a href='#' className={styles.btn}>Submit</a>
                <a href='#' className={`${styles.btn} ${styles.reset}`}>Reset</a>
            </div>
        </div>
    </>
  )
}
