import React, { useState } from 'react'
import styles from '../../../../../public/css/ElectionText.module.css'
import { useRouter } from 'next/router';

export default function ElectionTextState(props) {
    const {data, label} = props

    const [displayCount, setDisplayCount] = useState(true)

    const loadMoreItems  = ()=>{
     setDisplayCount(!displayCount)
    }

    const router = useRouter();
    const handleSelectChange = async (event) => {
        const selectedValue = event.target.value;
    
        router.push(selectedValue);
       
      }
    return (
        <>
            {/* <div className={`${styles.ElectionText} mb30`}>
                <div className={styles.top}>
                    <h1>{`${label} लोकसभा `}</h1>
                    <div className={styles.select}>
                    <select onChange={handleSelectChange}>
                    <option value="/elections/lok-sabha/uttar-pradesh.html">उत्&zwj;तर प्रदेश</option>
<option value="/elections/lok-sabha/andaman-and-nicobar-islands.html">अंडमान निकोबार द्वीप समूह</option><option value="/elections/lok-sabha/andhra-pradesh.html">आंध्रप्रदेश</option><option value="/elections/lok-sabha/arunachal-pradesh.html">अरुणाचल प्रदेश</option><option value="/elections/lok-sabha/assam.html">असम</option><option value="/elections/lok-sabha/bihar.html">बिहार</option><option value="/elections/lok-sabha/chandigarh.html">चंडीगढ़</option><option value="/elections/lok-sabha/chhattisgarh.html">छत्&zwj;तीसगढ़</option>
<option value="/elections/lok-sabha/dadra-and-nagar-haveli.html">दादर और नागर हवेली</option><option value="/elections/lok-sabha/daman-and-diu.html">दमन और दीव</option><option value="/elections/lok-sabha/goa.html">गोवा</option><option value="/elections/lok-sabha/haryana.html">हरियाणा</option><option value="/elections/lok-sabha/himachal-pradesh.html">हिमाचल प्रदेश</option><option value="/elections/lok-sabha/jammu-and-kashmir.html">जम्मू और कश्मीर</option><option value="/elections/lok-sabha/jharkhand.html">झारखंड</option><option value="/elections/lok-sabha/karnataka.html">कर्नाटक</option><option value="/elections/lok-sabha/kerala.html">केरल</option><option value="/elections/lok-sabha/lakshadweep.html">लक्षद्वीप</option><option value="/elections/lok-sabha/madhya-pradesh.html">मध्यप्रदेश</option><option value="/elections/lok-sabha/maharashtra.html">महाराष्ट्र</option><option value="/elections/lok-sabha/manipur.html">मणिपुर</option><option value="/elections/lok-sabha/meghalaya.html">मेघालय</option><option value="/elections/lok-sabha/mizoram.html">मिजोरम</option><option value="/elections/lok-sabha/nagaland.html">नगालैंड</option><option value="/elections/lok-sabha/nct-of-delhi.html">राष्&zwj;ट्रीय राजधानी क्षेत्र दिल्&zwj;ली</option>
<option value="/elections/lok-sabha/odisha.html">ओडिशा</option><option value="/elections/lok-sabha/punjab.html">पंजाब</option><option value="/elections/lok-sabha/rajasthan.html">राजस्&zwj;थान</option>
<option value="/elections/lok-sabha/sikkim.html">सिक्किम</option><option value="/elections/lok-sabha/tamil-nadu.html">तमिलनाडु</option><option value="/elections/lok-sabha/telangana.html">तेलंगाना</option><option value="/elections/lok-sabha/tripura.html">त्रिपुरा</option><option value="/elections/lok-sabha/uttarakhand.html">उत्&zwj;तराखंड</option>
<option value="/elections/lok-sabha/west-bengal.html">पश्चिम बंगाल</option>

                    </select>
                    </div>
                </div>
                    <p className={`${styles.hiddenDiv} ${styles.discript}`} style={{ height: displayCount ? '200px' : 'auto', overflow : 'hidden' }}>{data.stateDescription}</p>
                    
                    {displayCount ? (<div className={styles.audekhein}>
                       <a onClick={loadMoreItems}>और पढ़ें </a>
                    </div>) : (<div className={`${styles.audekhein} ${styles.small}`}>
                       <a onClick={loadMoreItems}>छोटा करें </a>
                    </div>) }
                </div> */}


<div className={`${styles.ElectionText} mb30`}>
                <div className={styles.top}>
                    <h1>महाराष्ट्र लोकसभा</h1>

                </div>

                    <p className={`${styles.hiddenDiv} ${styles.discript}`} style={{ height: displayCount ? '200px' : 'auto', overflow : 'hidden' }}>महाराष्ट्र हे भारताच्या दक्षिण मध्य भागात स्थित भारतातील एक राज्य आहे. भारतातील सर्वात श्रीमंत राज्यांमध्ये त्याची गणना होते. त्याची राजधानी मुंबई आहे, जी भारतातील सर्वात मोठे शहर आहे आणि देशाची आर्थिक राजधानी म्हणूनही ओळखली जाते. येथील पुणे शहराची गणना भारतातील महानगरांमध्ये केली जाते, जे भारतातील 8 व्या क्रमांकाचे मोठे शहर आहे. 2011 मध्ये महाराष्ट्राची लोकसंख्या 11.23 कोटी होती, जगात फक्त 11 देश आहेत ज्यांची लोकसंख्या महाराष्ट्रापेक्षा जास्त आहे. मुंबई, अहमदनगर, पुणे, संभाजीनगर, कोल्हापूर, नाशिक, नागपूर, ठाणे, शिर्डी, सोलापूर, अकोला, लातूर, धाराशिव, अमरावती आणि नांदेड ही महाराष्ट्रातील इतर प्रमुख शहरे आहेत. 1 मे 1960 रोजी कोकण, मराठवाडा, पश्चिम महाराष्ट्र, दक्षिण महाराष्ट्र, उत्तर महाराष्ट्र, खान्देश आणि विदर्भ या विभागांना एकत्र करून महाराष्ट्राची निर्मिती झाली. महाराष्ट्राचा बहुतांश भाग बेसाल्ट खडकांनी बनलेला आहे. अरबी समुद्र त्याच्या पश्चिम सीमेवर आहे. गोवा, कर्नाटक, तेलंगणा, छत्तीसगड, मध्य प्रदेश, गुजरात ही शेजारची राज्ये आहेत. महाराष्ट्र 307713 किमी परिसरात पसरलेला असून त्याची अधिकृत भाषा मराठी आहे. सध्या राज्यात एकनाथ शिंदे यांच्या नेतृत्वाखाली एनडीएचे सरकार आहे. महाराष्ट्रात विधानसभेच्या 288 आणि लोकसभेच्या 48 जागा आहेत.</p>
                    
                    {displayCount ? (<div className={styles.audekhein} style={{ textAlign : 'center' }}>
                       <a onClick={loadMoreItems}>अजून पहा</a>
                    </div>) : (<div className={`${styles.audekhein} ${styles.small}`} style={{ textAlign : 'center' }}>
                       <a onClick={loadMoreItems}>लहान करणे</a>
                    </div>) }
                </div>
        </>
    )
}