import React from 'react';
import { useRouter } from "next/router";

function Breadcrumdetails(props) {

const router = useRouter();
const routPath = router.asPath;

console.log(props.data)

    return (
        <>
        <section className="breadcrum">            
            <ul id="breadcrum1">
                <li><a href="/">News</a></li>
                {/* <li><a href="/elections.html">election </a></li> */}
                 {props.page!='condidate'?<li>{routPath !== '/elections/lok-sabha.html' ? <a href="/elections/lok-sabha.html">Lok Sabha</a> : 'Lok Sabha'}</li>:<li><a href='/elections/lok-sabha/candidates.html'>Candidates</a></li>}         
                <li>{props.data ? props.data.replaceAll("-", " ").toUpperCase() : ''}</li>
            </ul>
            </section>

        </>
      )
}

export default Breadcrumdetails
