// import React from 'react';
//import { useRouter } from "next/router";

function BreadcrumSeoSchema(props) {
const {data, routPath} = props
const updatedData = data && data.replaceAll('-', ' ');



    const schemaAarray_4 = [];
    schemaAarray_4.push(` {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [ 
        {"@type": "ListItem", "position": 1, "item": { "@id": "https://www.marathijagran.com", "name": "News"} }, 
        ${props.page!='condidate'?`{"@type": "ListItem", "position": 2, "item": { "@id": "https://www.marathijagran.com/elections/lok-sabha.html", "name":"lok sabha"} }`:`{"@type": "ListItem", "position": 3, "item": { "@id": "https://www.marathijagran.com/elections/lok-sabha/candidates.html", "name":"condidate"} }`} 
        ${data?`, {"@type": "ListItem", "position": 3, "item": { "@id": "https://www.marathijagran.com${routPath}", "name": "${updatedData}"} } `:''} ]} `)
  
    return (
        <>
            <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schemaAarray_4 }}></script>
        </>
    );
}

export default BreadcrumSeoSchema;




// import React from 'react';
// import { useSearchParams } from 'next/navigation'

// function BreadcrumSeoSchema(props) {
// const {data} = props
// const updatedData = data && data.replaceAll('-', ' ');

// const searchParams = useSearchParams()
// const routPath = searchParams ? searchParams.asPath : '';
// // console.log('===========' + routPath)

//     const schemaAarray_4 = [];
//     schemaAarray_4.push(` {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [ {"@type": "ListItem", "position": 1, "item": { "@id": "https://www.jagran.com", "name": "Hindi News"} }, {"@type": "ListItem", "position": 2, "item": { "@id": "https://www.jagran.com/elections.html", "name":"election"} }, ${props.page!='condidate'?`{"@type": "ListItem", "position": 3, "item": { "@id": "https://www.jagran.com/elections/lok-sabha.html", "name":"lok sabha"} }`:`{"@type": "ListItem", "position": 3, "item": { "@id": "https://www.jagran.com/elections/lok-sabha/candidates.html", "name":"condidate"} }`} ${data?`, {"@type": "ListItem", "position": 4, "item": { "@id": "https://www.jagran.com${routPath}", "name": "${updatedData}"} } `:''} ]} `)
  
//     return (
//         <div>
//             <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schemaAarray_4 }}></script>
//         </div>
//     );
// }

// export default BreadcrumSeoSchema;