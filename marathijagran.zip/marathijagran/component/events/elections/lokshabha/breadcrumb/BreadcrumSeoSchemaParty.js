import React from 'react';
import { useRouter } from "next/router";

function BreadcrumSeoSchemaParty(props) {
const {data, routPath} = props
const updatedData = data && data.replaceAll('-', ' ');


    const schemaAarray_4 = [];
    schemaAarray_4.push(` {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [ 
        
    {"@type": "ListItem", "position": 1, "item": { "@id": "https://www.marathijagran.com", "name": "News"} }, 
    {"@type": "ListItem", "position": 2, "item": { "@id": "https://www.marathijagran.com/election/parties.html", "name":"election"} } 
    ${data!='party'?`,{"@type": "ListItem", "position": 3, "item": { "@id": "https://www.marathijagran.com${routPath}", "name":"election"} }`:''} 
  

]} `)
  
    return (
        <>
            <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schemaAarray_4 }}></script>
        </>
    );
}

export default BreadcrumSeoSchemaParty;