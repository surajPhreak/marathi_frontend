import React from 'react';
import { useRouter } from "next/router";

function BreadcrumParty(props) {

const router = useRouter();
const routPath = router.asPath;


    return (
        <>
        <section className="breadcrum">  
            <ul id="breadcrum1">
                <li><a href="/">News</a></li>
                {/* <li><a href="/elections.html">election </a></li> */}
                {props.data !='party'?<li><a href="/elections/parties.html">parties </a></li>:''}
                <li>{props.data ? props.data.replaceAll("-", " ").toUpperCase() : ''}</li>
            </ul>
            </section>
        </>
      )
}

export default BreadcrumParty
