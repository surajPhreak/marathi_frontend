import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/MainParty.module.css'

export default function MainParty(props) {
  const {data, id} = props
  return (
    <>
        <div className={`${styles.MainParty} mb30`}>
            <div className={styles.top}>
                <h2>देश की प्रमुख पार्टियां</h2>
            </div>

            <ul className={styles.partylist}>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
                <li>
                    <div className={styles.icon}>
                        <Image unoptimized width={30} height={30} src="https://www.jagran.com/assets/images/events/partylogos/bjp-logo.png" />
                    </div>
                    आप
                </li>
            </ul>
        </div>
    </>
  )
}