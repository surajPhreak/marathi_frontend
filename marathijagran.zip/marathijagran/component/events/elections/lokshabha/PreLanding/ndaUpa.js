import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/NdaUpa.module.css'


export default function NdaUpa(props) {
  const {data, id} = props
  return (
    <>
        <div className={`${styles.NdaUpa} mb30`}>
        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="342px" viewBox="0 0 650 342" version="1.1">
    <g className="stroke_g" fillRule="evenodd" fill="none" stroke-width="1" stroke="none" id="Page-1">
        <g stroke-width="3" fillRule="nonzero" fill="#333333" transform="translate(-68.000000, -145.000000)" id="Elections-Home-Web-v1">
            <g transform="translate(60.000000, 144.000000)" id="graph">
                <g id="seats-back" transform="translate(9.000000, 0.000000)">
                    <g transform="translate(0.000000, 1.960486)">
                        <polygon
                            className=""
                            points="303.933011 158.662221 312.366038 158.665538 312.369355 167.059336 303.936329 167.056019"
                            transform="translate(308.151183, 162.860778) rotate(-4.800000) translate(-308.151183, -162.860778) "
                            stroke="#a15f33"
                            id="a"
                            data-index="262"
                        ></polygon>
                        <polygon
                            className=""
                            points="290.793108 160.312168 299.225306 160.31871 299.231848 168.713336 290.79965 168.706794"
                            transform="translate(295.012478, 164.512752) rotate(-9.600000) translate(-295.012478, -164.512752) "
                            stroke="#a15f33"
                            id="a"
                            data-index="252"
                        ></polygon>
                        <polygon
                            className=""
                            points="277.838527 163.050383 286.269372 163.059966 286.278955 171.455946 277.848111 171.446363"
                            transform="translate(282.058741, 167.253164) rotate(-14.400000) translate(-282.058741, -167.253164) "
                            stroke="#a15f33"
                            id="a"
                            data-index="209"
                        ></polygon>
                        <polygon
                            className=""
                            points="265.160154 166.857703 273.589156 166.87006 273.601513 175.267882 265.172511 175.255526"
                            transform="translate(269.380834, 171.062793) rotate(-19.200000) translate(-269.380834, -171.062793) "
                            stroke="#a15f33"
                            id="a"
                            data-index="199"
                        ></polygon>
                        <polygon
                            className=""
                            points="240.98522 177.565723 249.409291 177.582519 249.426087 185.985272 241.002016 185.968476"
                            transform="translate(245.205653, 181.775498) rotate(-28.800000) translate(-245.205653, -181.775498) "
                            stroke="#a15f33"
                            id="a"
                            data-index="187"
                        ></polygon>
                        <polygon
                            className=""
                            points="229.658222 184.391412 238.079343 184.40975 238.097682 192.815453 229.676561 192.797115"
                            transform="translate(233.877952, 188.603432) rotate(-33.600000) translate(-233.877952, -188.603432) "
                            stroke="#a15f33"
                            id="a"
                            data-index="173"
                        ></polygon>
                        <polygon
                            className=""
                            points="218.945373 192.136708 227.363328 192.156075 227.382695 200.564945 218.96474 200.545578"
                            transform="translate(223.164034, 196.350827) rotate(-38.400000) translate(-223.164034, -196.350827) "
                            stroke="#a15f33"
                            id="a"
                            data-index="136"
                        ></polygon>
                        <polygon
                            className=""
                            points="208.921792 200.747329 217.336453 200.767183 217.356307 209.179346 208.941645 209.159493"
                            transform="translate(213.139049, 204.963338) rotate(-43.200000) translate(-213.139049, -204.963338) "
                            stroke="#a15f33"
                            id="a"
                            data-index="126"
                        ></polygon>
                        <polygon
                            className=""
                            points="191.218215 220.317463 199.626278 220.336623 199.645438 228.755385 191.237375 228.736225"
                            transform="translate(195.431826, 224.536424) rotate(-52.800000) translate(-195.431826, -224.536424) "
                            stroke="#a15f33"
                            id="a"
                            data-index="116"
                        ></polygon>
                        <polygon
                            className=""
                            points="183.662321 231.139767 192.067263 231.157766 192.085263 239.579648 183.68032 239.561649"
                            transform="translate(187.873792, 235.359707) rotate(-57.600000) translate(-187.873792, -235.359707) "
                            stroke="#a15f33"
                            id="a"
                            data-index="86"
                        ></polygon>
                        <polygon
                            className=""
                            points="177.043029 242.553939 185.445088 242.570274 185.461423 250.995039 177.059364 250.978704"
                            transform="translate(181.252226, 246.774489) rotate(-62.400000) translate(-181.252226, -246.774489) "
                            stroke="#a15f33"
                            id="a"
                            data-index="63"
                        ></polygon>
                        <polygon
                            className=""
                            points="171.406722 254.47993 179.806216 254.494143 179.820429 262.921473 171.420935 262.90726"
                            transform="translate(175.613575, 258.700701) rotate(-67.200000) translate(-175.613575, -258.700701) "
                            stroke="#a15f33"
                            id="a"
                            data-index="53"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.941457 142.873585 312.374533 142.876601 312.377548 151.27035 303.944473 151.267334"
                            transform="translate(308.159503, 147.071968) rotate(-4.360000) translate(-308.159503, -147.071968) "
                            stroke="#a15f33"
                            id="a"
                            data-index="263"
                        ></polygon>
                        <polygon
                            className=""
                            points="288.605206 144.71978 297.037438 144.726224 297.043882 153.120816 288.611649 153.114372"
                            transform="translate(292.824544, 148.920298) rotate(-9.450000) translate(-292.824544, -148.920298) "
                            stroke="#a15f33"
                            id="a"
                            data-index="253"
                        ></polygon>
                        <polygon
                            className=""
                            points="273.494586 147.912598 281.925384 147.922267 281.935052 156.318294 273.504255 156.308625"
                            transform="translate(277.714819, 152.115446) rotate(-14.540000) translate(-277.714819, -152.115446) "
                            stroke="#a15f33"
                            id="a"
                            data-index="210"
                        ></polygon>
                        <polygon
                            className=""
                            points="258.728796 152.426912 267.157611 152.439501 267.1702 160.837511 258.741385 160.824922"
                            transform="translate(262.949498, 156.632211) rotate(-19.630000) translate(-262.949498, -156.632211) "
                            stroke="#a15f33"
                            id="a"
                            data-index="200"
                        ></polygon>
                        <polygon
                            className=""
                            points="234.540446 163.13877 242.964775 163.1554 242.981405 171.557897 234.557077 171.541266"
                            transform="translate(238.760926, 167.348333) rotate(-28.360000) translate(-238.760926, -167.348333) "
                            stroke="#a15f33"
                            id="a"
                            data-index="188"
                        ></polygon>
                        <polygon
                            className=""
                            points="221.287333 171.032779 229.70855 171.051077 229.726848 179.456684 221.305631 179.438386"
                            transform="translate(225.507091, 175.244732) rotate(-33.450000) translate(-225.507091, -175.244732) "
                            stroke="#a15f33"
                            id="a"
                            data-index="174"
                        ></polygon>
                        <polygon
                            className=""
                            points="208.79079 180.066153 217.20865 180.085542 217.228039 188.494506 208.810179 188.475117"
                            transform="translate(213.009414, 184.280330) rotate(-38.540000) translate(-213.009414, -184.280330) "
                            stroke="#a15f33"
                            id="a"
                            data-index="137"
                        ></polygon>
                        <polygon
                            className=""
                            points="197.149347 190.167699 205.563711 190.187569 205.583581 198.600031 197.169217 198.58016"
                            transform="translate(201.366464, 194.383865) rotate(-43.630000) translate(-201.366464, -194.383865) "
                            stroke="#a15f33"
                            id="a"
                            data-index="127"
                        ></polygon>
                        <polygon
                            className=""
                            points="179.434605 209.74664 187.842962 209.76588 187.862202 218.184347 179.453845 218.165107"
                            transform="translate(183.648404, 213.965494) rotate(-52.360000) translate(-183.648404, -213.965494) "
                            stroke="#a15f33"
                            id="a"
                            data-index="117"
                        ></polygon>
                        <polygon
                            className=""
                            points="170.555861 222.324685 178.960898 222.342728 178.978941 230.764516 170.573905 230.746473"
                            transform="translate(174.767401, 226.544600) rotate(-57.450000) translate(-174.767401, -226.544600) "
                            stroke="#a15f33"
                            id="a"
                            data-index="87"
                        ></polygon>
                        <polygon
                            className=""
                            points="162.833605 235.63775 171.235585 235.654029 171.251864 244.078874 162.849885 244.062595"
                            transform="translate(167.042735, 239.858312) rotate(-62.540000) translate(-167.042735, -239.858312) "
                            stroke="#a15f33"
                            id="a"
                            data-index="64"
                        ></polygon>
                        <polygon
                            className=""
                            points="156.328685 249.580852 164.727967 249.594854 164.74197 258.022396 156.342687 258.008394"
                            transform="translate(160.535327, 253.801624) rotate(-67.630000) translate(-160.535327, -253.801624) "
                            stroke="#a15f33"
                            id="a"
                            data-index="54"
                        ></polygon>
                        <polygon
                            className=""
                            points="148.148967 274.642813 156.544699 274.651931 156.553817 283.083023 148.158085 283.073906"
                            transform="translate(152.351392, 278.862918) rotate(-76.360000) translate(-152.351392, -278.862918) "
                            stroke="#a15f33"
                            id="a"
                            data-index="44"
                        ></polygon>
                        <polygon
                            className=""
                            points="145.178704 289.730554 153.573103 289.736403 153.578952 298.168829 145.184554 298.16298"
                            transform="translate(149.378828, 293.949692) rotate(-81.450000) translate(-149.378828, -293.949692) "
                            stroke="#a15f33"
                            id="a"
                            data-index="18"
                        ></polygon>
                        <polygon
                            className=""
                            points="143.564806 305.021676 151.958471 305.024073 151.960867 313.457233 143.567203 313.454836"
                            transform="translate(147.762837, 309.239454) rotate(-86.540000) translate(-147.762837, -309.239454) "
                            stroke="#a15f33"
                            id="a"
                            data-index="9"
                        ></polygon>
                        <polygon
                            className=""
                            points="143.319952 320.395547 151.713504 320.394416 151.712373 328.827689 143.318821 328.82882"
                            transform="translate(147.516162, 324.611618) rotate(-91.630000) translate(-147.516162, -324.611618) "
                            stroke="#a15f33"
                            id="a"
                            data-index="0"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.928511 127.09493 312.361623 127.097699 312.364391 135.491412 303.93128 135.488643"
                            transform="translate(308.146451, 131.293171) rotate(-4.000000) translate(-308.146451, -131.293171) "
                            stroke="#a15f33"
                            id="a"
                            data-index="264"
                        ></polygon>
                        <polygon
                            className=""
                            points="290.755682 128.471161 299.188216 128.476644 299.193699 136.870935 290.761165 136.865451"
                            transform="translate(294.974690, 132.671048) rotate(-8.000000) translate(-294.974690, -132.671048) "
                            stroke="#a15f33"
                            id="a"
                            data-index="254"
                        ></polygon>
                        <polygon
                            className=""
                            points="277.711748 130.758384 286.143334 130.766475 286.151425 139.161714 277.71984 139.153623"
                            transform="translate(281.931587, 134.960049) rotate(-12.000000) translate(-281.931587, -134.960049) "
                            stroke="#a15f33"
                            id="a"
                            data-index="219"
                        ></polygon>
                        <polygon
                            className=""
                            points="264.860273 133.945481 273.290555 133.956023 273.301097 142.352565 264.870814 142.342023"
                            transform="translate(269.080685, 138.149023) rotate(-16.000000) translate(-269.080685, -138.149023) "
                            stroke="#a15f33"
                            id="a"
                            data-index="211"
                        ></polygon>
                        <polygon
                            className=""
                            points="252.263874 138.016953 260.692525 138.02974 260.705312 146.427913 252.276661 146.415126"
                            transform="translate(256.484593, 142.222433) rotate(-20.000000) translate(-256.484593, -142.222433) "
                            stroke="#a15f33"
                            id="a"
                            data-index="201"
                        ></polygon>
                        <polygon
                            className=""
                            points="228.080253 148.729579 236.504789 148.746071 236.521281 157.148359 228.096745 157.131867"
                            transform="translate(232.300767, 152.938969) rotate(-28.000000) translate(-232.300767, -152.938969) "
                            stroke="#a15f33"
                            id="a"
                            data-index="189"
                        ></polygon>
                        <polygon
                            className=""
                            points="216.610848 155.3186 225.032981 155.336479 225.05086 163.741171 216.628728 163.723291"
                            transform="translate(220.830854, 159.529885) rotate(-32.000000) translate(-220.830854, -159.529885) "
                            stroke="#a15f33"
                            id="a"
                            data-index="175"
                        ></polygon>
                        <polygon
                            className=""
                            points="205.63158 162.68798 214.05114 162.706899 214.070059 171.114164 205.6505 171.095245"
                            transform="translate(209.850820, 166.901072) rotate(-36.000000) translate(-209.850820, -166.901072) "
                            stroke="#a15f33"
                            id="a"
                            data-index="146"
                        ></polygon>
                        <polygon
                            className=""
                            points="195.195929 170.801844 203.612795 170.821435 203.632386 179.231393 195.215519 179.211802"
                            transform="translate(199.414157, 175.016618) rotate(-40.000000) translate(-199.414157, -175.016618) "
                            stroke="#a15f33"
                            id="a"
                            data-index="138"
                        ></polygon>
                        <polygon
                            className=""
                            points="185.35472 179.620686 193.768826 179.640567 193.788707 188.053285 185.374601 188.033404"
                            transform="translate(189.571713, 183.836986) rotate(-44.000000) translate(-189.571713, -183.836986) "
                            stroke="#a15f33"
                            id="a"
                            data-index="128"
                        ></polygon>
                        <polygon
                            className=""
                            points="167.644207 199.198308 176.052807 199.21761 176.072109 207.635835 167.663509 207.616533"
                            transform="translate(171.858158, 203.417072) rotate(-52.000000) translate(-171.858158, -203.417072) "
                            stroke="#a15f33"
                            id="a"
                            data-index="118"
                        ></polygon>
                        <polygon
                            className=""
                            points="159.861143 209.861744 168.267103 209.880188 168.285548 218.301052 159.879587 218.282608"
                            transform="translate(164.073345, 214.081398) rotate(-56.000000) translate(-164.073345, -214.081398) "
                            stroke="#a15f33"
                            id="a"
                            data-index="96"
                        ></polygon>
                        <polygon
                            className=""
                            points="152.844581 221.039932 161.248047 221.05716 161.265275 229.480519 152.861809 229.463291"
                            transform="translate(157.054928, 225.260225) rotate(-60.000000) translate(-157.054928, -225.260225) "
                            stroke="#a15f33"
                            id="a"
                            data-index="88"
                        ></polygon>
                        <polygon
                            className=""
                            points="146.628678 232.678425 155.029843 232.694101 155.045519 241.11976 146.644354 241.104084"
                            transform="translate(150.837099, 236.899092) rotate(-64.000000) translate(-150.837099, -236.899092) "
                            stroke="#a15f33"
                            id="a"
                            data-index="65"
                        ></polygon>
                        <polygon
                            className=""
                            points="141.24369 244.720525 149.642792 244.734344 149.656611 253.162066 141.257509 253.148247"
                            transform="translate(145.450151, 248.941295) rotate(-68.000000) translate(-145.450151, -248.941295) "
                            stroke="#a15f33"
                            id="a"
                            data-index="55"
                        ></polygon>
                        <polygon
                            className=""
                            points="133.067107 269.779198 141.462955 269.788537 141.472294 278.219514 133.076446 278.210175"
                            transform="translate(137.269700, 273.999356) rotate(-76.000000) translate(-137.269700, -273.999356) "
                            stroke="#a15f33"
                            id="a"
                            data-index="45"
                        ></polygon>
                        <polygon
                            className=""
                            points="130.315291 282.673679 138.71001 282.680483 138.716814 291.112588 130.322095 291.105784"
                            transform="translate(134.516052, 286.893134) rotate(-80.000000) translate(-134.516052, -286.893134) "
                            stroke="#a15f33"
                            id="a"
                            data-index="31"
                        ></polygon>
                        <polygon
                            className=""
                            points="128.473755 295.728178 136.867709 295.732314 136.871845 304.165184 128.477891 304.161048"
                            transform="translate(132.672800, 299.946681) rotate(-84.000000) translate(-132.672800, -299.946681) "
                            stroke="#a15f33"
                            id="a"
                            data-index="19"
                        ></polygon>
                        <polygon
                            className=""
                            points="127.551446 308.879081 135.945014 308.880468 135.946401 317.313725 127.552833 317.312337"
                            transform="translate(131.748923, 313.096403) rotate(-88.000000) translate(-131.748923, -313.096403) "
                            stroke="#a15f33"
                            id="a"
                            data-index="10"
                        ></polygon>
                        <polygon
                            className=""
                            points="127.552833 322.062301 135.946401 322.060913 135.945014 330.49417 127.551446 330.495557"
                            transform="translate(131.748923, 326.278235) rotate(-92.000000) translate(-131.748923, -326.278235) "
                            stroke="#a15f33"
                            id="a"
                            data-index="1"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.935275 111.32131 312.368415 111.323865 312.37097 119.717549 303.93783 119.714994"
                            transform="translate(308.153122, 115.519430) rotate(-3.690000) translate(-308.153122, -115.519430) "
                            stroke="#a15f33"
                            id="a"
                            data-index="265"
                        ></polygon>
                        <polygon
                            className=""
                            points="292.07664 112.42517 300.509352 112.429989 300.514171 120.824101 292.081459 120.819282"
                            transform="translate(296.295405, 116.624636) rotate(-7.010000) translate(-296.295405, -116.624636) "
                            stroke="#a15f33"
                            id="a"
                            data-index="255"
                        ></polygon>
                        <polygon
                            className=""
                            points="280.302376 114.210549 288.734402 114.217568 288.74142 122.612366 280.309395 122.605348"
                            transform="translate(284.521898, 118.411458) rotate(-10.330000) translate(-284.521898, -118.411458) "
                            stroke="#a15f33"
                            id="a"
                            data-index="239"
                        ></polygon>
                        <polygon
                            className=""
                            points="268.61715 116.679893 277.048236 116.689023 277.057366 125.084761 268.62628 125.075631"
                            transform="translate(272.837258, 120.882327) rotate(-13.660000) translate(-272.837258, -120.882327) "
                            stroke="#a15f33"
                            id="a"
                            data-index="220"
                        ></polygon>
                        <polygon
                            className=""
                            points="257.130351 119.810101 265.560263 119.821214 265.571376 128.218126 257.141464 128.207014"
                            transform="translate(261.350864, 124.014114) rotate(-16.980000) translate(-261.350864, -124.014114) "
                            stroke="#a15f33"
                            id="a"
                            data-index="212"
                        ></polygon>
                        <polygon
                            className=""
                            points="245.845246 123.597085 254.273762 123.610031 254.286708 132.008339 245.858192 131.995394"
                            transform="translate(250.065977, 127.802712) rotate(-20.300000) translate(-250.065977, -127.802712) "
                            stroke="#a15f33"
                            id="a"
                            data-index="202"
                        ></polygon>
                        <polygon
                            className=""
                            points="221.64015 134.316998 230.064864 134.333369 230.081234 142.735479 221.65652 142.719109"
                            transform="translate(225.860692, 138.526239) rotate(-27.690000) translate(-225.860692, -138.526239) "
                            stroke="#a15f33"
                            id="a"
                            data-index="190"
                        ></polygon>
                        <polygon
                            className=""
                            points="211.25963 140.125286 219.682376 140.142854 219.699943 148.546933 211.277198 148.529365"
                            transform="translate(215.479787, 144.336109) rotate(-31.010000) translate(-215.479787, -144.336109) "
                            stroke="#a15f33"
                            id="a"
                            data-index="176"
                        ></polygon>
                        <polygon
                            className=""
                            points="201.234774 146.522226 209.655425 146.540755 209.673954 154.946928 201.253302 154.9284"
                            transform="translate(205.454364, 150.734577) rotate(-34.330000) translate(-205.454364, -150.734577) "
                            stroke="#a15f33"
                            id="a"
                            data-index="158"
                        ></polygon>
                        <polygon
                            className=""
                            points="191.570822 153.508172 199.989275 153.527415 200.008519 161.935786 191.590065 161.916543"
                            transform="translate(195.789670, 157.721979) rotate(-37.660000) translate(-195.789670, -157.721979) "
                            stroke="#a15f33"
                            id="a"
                            data-index="147"
                        ></polygon>
                        <polygon
                            className=""
                            points="182.358231 161.017742 190.774426 161.037439 190.794123 169.448069 182.377929 169.428372"
                            transform="translate(186.576177, 165.232906) rotate(-40.980000) translate(-186.576177, -165.232906) "
                            stroke="#a15f33"
                            id="a"
                            data-index="139"
                        ></polygon>
                        <polygon
                            className=""
                            points="173.598294 169.045879 182.012192 169.065766 182.032079 177.478692 173.618181 177.458805"
                            transform="translate(177.815186, 173.262285) rotate(-44.300000) translate(-177.815186, -173.262285) "
                            stroke="#a15f33"
                            id="a"
                            data-index="129"
                        ></polygon>
                        <polygon
                            className=""
                            points="155.870803 188.63876 164.279612 188.658113 164.298965 197.076128 155.890156 197.056775"
                            transform="translate(160.084884, 192.857444) rotate(-51.690000) translate(-160.084884, -192.857444) "
                            stroke="#a15f33"
                            id="a"
                            data-index="119"
                        ></polygon>
                        <polygon
                            className=""
                            points="148.763097 198.147944 157.169699 198.166634 157.18839 206.586857 148.781788 206.568166"
                            transform="translate(152.975744, 202.367400) rotate(-55.010000) translate(-152.975744, -202.367400) "
                            stroke="#a15f33"
                            id="a"
                            data-index="107"
                        ></polygon>
                        <polygon
                            className=""
                            points="142.220759 208.051103 150.625246 208.068881 150.643023 216.491219 142.238537 216.473441"
                            transform="translate(146.431891, 212.271161) rotate(-58.330000) translate(-146.431891, -212.271161) "
                            stroke="#a15f33"
                            id="a"
                            data-index="89"
                        ></polygon>
                        <polygon
                            className=""
                            points="136.248704 218.346429 144.651189 218.363052 144.667812 226.787391 136.265327 226.770769"
                            transform="translate(140.458258, 222.566910) rotate(-61.660000) translate(-140.458258, -222.566910) "
                            stroke="#a15f33"
                            id="a"
                            data-index="73"
                        ></polygon>
                        <polygon
                            className=""
                            points="130.902821 228.937551 139.303458 228.952798 139.318705 237.378987 130.918069 237.363739"
                            transform="translate(135.110763, 233.158269) rotate(-64.980000) translate(-135.110763, -233.158269) "
                            stroke="#a15f33"
                            id="a"
                            data-index="66"
                        ></polygon>
                        <polygon
                            className=""
                            points="126.18221 239.81931 134.581168 239.832978 134.594837 248.260844 126.195878 248.247176"
                            transform="translate(130.388523, 244.040077) rotate(-68.300000) translate(-130.388523, -244.040077) "
                            stroke="#a15f33"
                            id="a"
                            data-index="56"
                        ></polygon>
                        <polygon
                            className=""
                            points="117.996194 264.898486 126.392144 264.908014 126.401673 273.338889 118.005723 273.32936"
                            transform="translate(122.198933, 269.118687) rotate(-75.690000) translate(-122.198933, -269.118687) "
                            stroke="#a15f33"
                            id="a"
                            data-index="46"
                        ></polygon>
                        <polygon
                            className=""
                            points="115.389588 276.464718 123.784553 276.472164 123.791998 284.904023 115.397033 284.896578"
                            transform="translate(119.590793, 280.684371) rotate(-79.010000) translate(-119.590793, -280.684371) "
                            stroke="#a15f33"
                            id="a"
                            data-index="32"
                        ></polygon>
                        <polygon
                            className=""
                            points="113.460257 288.162045 121.854485 288.167308 121.859748 296.599904 113.46552 296.594641"
                            transform="translate(117.660003, 292.380974) rotate(-82.330000) translate(-117.660003, -292.380974) "
                            stroke="#a15f33"
                            id="a"
                            data-index="30"
                        ></polygon>
                        <polygon
                            className=""
                            points="112.211951 299.986802 120.605698 299.989805 120.6087 308.422882 112.214953 308.41988"
                            transform="translate(116.410325, 304.204842) rotate(-85.660000) translate(-116.410325, -304.204842) "
                            stroke="#a15f33"
                            id="a"
                            data-index="20"
                        ></polygon>
                        <polygon
                            className=""
                            points="111.656339 311.82829 120.049871 311.828998 120.050579 320.262291 111.657047 320.261583"
                            transform="translate(115.853459, 316.045291) rotate(-88.980000) translate(-115.853459, -316.045291) "
                            stroke="#a15f33"
                            id="a"
                            data-index="11"
                        ></polygon>
                        <polygon
                            className=""
                            points="111.790494 323.682141 120.184077 323.680546 120.182482 332.113787 111.788898 332.115382"
                            transform="translate(115.986488, 327.897964) rotate(-92.300000) translate(-115.986488, -327.897964) "
                            stroke="#a15f33"
                            id="a"
                            data-index="2"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.92488 79.78974 312.358061 79.7919575 312.360278 88.1856009 303.927097 88.1833834"
                            transform="translate(308.142579, 83.987670) rotate(-3.200000) translate(-308.142579, -83.987670) "
                            stroke="#a15f33"
                            id="a"
                            data-index="266"
                        ></polygon>
                        <polygon
                            className=""
                            points="291.836251 80.7702822 300.269102 80.7745064 300.273327 89.1684795 291.840475 89.1642553"
                            transform="translate(296.054789, 84.969381) rotate(-6.130000) translate(-296.054789, -84.969381) "
                            stroke="#a15f33"
                            id="a"
                            data-index="256"
                        ></polygon>
                        <polygon
                            className=""
                            points="279.813967 82.3644243 288.246285 82.3706111 288.252472 90.7651171 279.820154 90.7589302"
                            transform="translate(284.033220, 86.564771) rotate(-9.060000) translate(-284.033220, -86.564771) "
                            stroke="#a15f33"
                            id="a"
                            data-index="240"
                        ></polygon>
                        <polygon
                            className=""
                            points="267.848971 84.5765664 276.280556 84.5846575 276.288647 92.9798968 267.857062 92.9718056"
                            transform="translate(272.068809, 88.778232) rotate(-12.000000) translate(-272.068809, -88.778232) "
                            stroke="#a15f33"
                            id="a"
                            data-index="233"
                        ></polygon>
                        <polygon
                            className=""
                            points="256.053927 87.3858898 264.484591 87.3957941 264.494495 95.7919544 256.063831 95.7820501"
                            transform="translate(260.274211, 91.588922) rotate(-14.930000) translate(-260.274211, -91.588922) "
                            stroke="#a15f33"
                            id="a"
                            data-index="221"
                        ></polygon>
                        <polygon
                            className=""
                            points="244.418796 90.7915472 252.848359 90.8031611 252.859973 99.2004228 244.43041 99.1888089"
                            transform="translate(248.639384, 94.995985) rotate(-17.860000) translate(-248.639384, -94.995985) "
                            stroke="#a15f33"
                            id="a"
                            data-index="213"
                        ></polygon>
                        <polygon
                            className=""
                            points="232.9353 94.7992682 241.363588 94.8124755 241.376795 103.211012 232.948507 103.197805"
                            transform="translate(237.156047, 99.005140) rotate(-20.800000) translate(-237.156047, -99.005140) "
                            stroke="#a15f33"
                            id="a"
                            data-index="203"
                        ></polygon>
                        <polygon
                            className=""
                            points="208.744563 105.515808 217.169555 105.531983 217.18573 113.933815 208.760738 113.91764"
                            transform="translate(212.965146, 109.724811) rotate(-27.200000) translate(-212.965146, -109.724811) "
                            stroke="#a15f33"
                            id="a"
                            data-index="191"
                        ></polygon>
                        <polygon
                            className=""
                            points="198.103314 111.304592 206.526595 111.321865 206.543867 119.725409 198.120587 119.708137"
                            transform="translate(202.323591, 115.515001) rotate(-30.130000) translate(-202.323591, -115.515001) "
                            stroke="#a15f33"
                            id="a"
                            data-index="177"
                        ></polygon>
                        <polygon
                            className=""
                            points="187.773492 117.627233 196.194958 117.645422 196.213148 126.050782 187.791682 126.032592"
                            transform="translate(191.993320, 121.839007) rotate(-33.060000) translate(-191.993320, -121.839007) "
                            stroke="#a15f33"
                            id="a"
                            data-index="167"
                        ></polygon>
                        <polygon
                            className=""
                            points="177.748611 124.491418 186.16817 124.510338 186.18709 132.917603 177.76753 132.898683"
                            transform="translate(181.967850, 128.704511) rotate(-36.000000) translate(-181.967850, -128.704511) "
                            stroke="#a15f33"
                            id="a"
                            data-index="159"
                        ></polygon>
                        <polygon
                            className=""
                            points="168.123057 131.832529 176.540653 131.851977 176.560101 140.261205 168.142505 140.241757"
                            transform="translate(172.341579, 136.046867) rotate(-38.930000) translate(-172.341579, -136.046867) "
                            stroke="#a15f33"
                            id="a"
                            data-index="148"
                        ></polygon>
                        <polygon
                            className=""
                            points="158.8873 139.653854 167.302889 139.673627 167.322662 148.084864 158.907074 148.06509"
                            transform="translate(163.104981, 143.869359) rotate(-41.860000) translate(-163.104981, -143.869359) "
                            stroke="#a15f33"
                            id="a"
                            data-index="140"
                        ></polygon>
                        <polygon
                            className=""
                            points="150.036109 147.96398 158.44966 147.983873 158.469553 156.397146 150.056001 156.377254"
                            transform="translate(154.252831, 152.180563) rotate(-44.800000) translate(-154.252831, -152.180563) "
                            stroke="#a15f33"
                            id="a"
                            data-index="130"
                        ></polygon>
                        <polygon
                            className=""
                            points="132.319809 167.547821 140.728949 167.56725 140.748378 175.984934 132.339237 175.965505"
                            transform="translate(136.534093, 171.766377) rotate(-51.200000) translate(-136.534093, -171.766377) "
                            stroke="#a15f33"
                            id="a"
                            data-index="120"
                        ></polygon>
                        <polygon
                            className=""
                            points="124.965759 177.144601 133.372938 177.163492 133.391829 185.583138 124.98465 185.564247"
                            transform="translate(129.178794, 181.363870) rotate(-54.130000) translate(-129.178794, -181.363870) "
                            stroke="#a15f33"
                            id="a"
                            data-index="108"
                        ></polygon>
                        <polygon
                            className=""
                            points="118.1143 187.103165 126.519583 187.121321 126.537739 195.542863 118.132456 195.524707"
                            transform="translate(122.326020, 191.323014) rotate(-57.060000) translate(-122.326020, -191.323014) "
                            stroke="#a15f33"
                            id="a"
                            data-index="97"
                        ></polygon>
                        <polygon
                            className=""
                            points="111.762638 197.433159 120.166104 197.450387 120.183332 205.873745 111.779866 205.856518"
                            transform="translate(115.972985, 201.653452) rotate(-60.000000) translate(-115.972985, -201.653452) "
                            stroke="#a15f33"
                            id="a"
                            data-index="90"
                        ></polygon>
                        <polygon
                            className=""
                            points="105.970569 208.03732 114.372328 208.053443 114.38845 216.478508 105.986691 216.462386"
                            transform="translate(110.179510, 212.257914) rotate(-62.930000) translate(-110.179510, -212.257914) "
                            stroke="#a15f33"
                            id="a"
                            data-index="74"
                        ></polygon>
                        <polygon
                            className=""
                            points="100.730723 218.922506 109.130896 218.937354 109.145745 227.364005 100.745571 227.349156"
                            transform="translate(104.938234, 223.143255) rotate(-65.860000) translate(-104.938234, -223.143255) "
                            stroke="#a15f33"
                            id="a"
                            data-index="67"
                        ></polygon>
                        <polygon
                            className=""
                            points="96.0418187 230.098668 104.440541 230.112082 104.453955 238.540184 96.0552325 238.52677"
                            transform="translate(100.247887, 234.319426) rotate(-68.800000) translate(-100.247887, -234.319426) "
                            stroke="#a15f33"
                            id="a"
                            data-index="57"
                        ></polygon>
                        <polygon
                            className=""
                            points="87.8620725 255.16455 96.258188 255.174376 96.2680139 263.605085 87.8718984 263.595259"
                            transform="translate(92.065043, 259.384818) rotate(-75.200000) translate(-92.065043, -259.384818) "
                            stroke="#a15f33"
                            id="a"
                            data-index="47"
                        ></polygon>
                        <polygon
                            className=""
                            points="84.0729695 271.880773 92.4678453 271.887993 92.4750649 280.319941 84.0801892 280.312722"
                            transform="translate(88.274017, 276.100357) rotate(-79.360000) translate(-88.274017, -276.100357) "
                            stroke="#a15f33"
                            id="a"
                            data-index="33"
                        ></polygon>
                        <polygon
                            className=""
                            points="80.6468121 298.015774 89.040549 298.018707 89.0434825 306.451795 80.6497456 306.448861"
                            transform="translate(84.845147, 302.233784) rotate(-85.760000) translate(-84.845147, -302.233784) "
                            stroke="#a15f33"
                            id="a"
                            data-index="21"
                        ></polygon>
                        <polygon
                            className=""
                            points="80.0238265 312.05077 88.4173543 312.051346 88.4179306 320.484643 80.0244028 320.484067"
                            transform="translate(84.220879, 316.267706) rotate(-89.170000) translate(-84.220879, -316.267706) "
                            stroke="#a15f33"
                            id="a"
                            data-index="12"
                        ></polygon>
                        <polygon
                            className=""
                            points="80.2405124 326.09802 88.6341124 326.096231 88.6323233 334.529455 80.2387233 334.531245"
                            transform="translate(84.436418, 330.313738) rotate(-92.580000) translate(-84.436418, -330.313738) "
                            stroke="#a15f33"
                            id="a"
                            data-index="3"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.924108 64.0289732 312.357304 64.0310526 312.359383 72.424681 303.926187 72.4226016"
                            transform="translate(308.141745, 68.226827) rotate(-3.000000) translate(-308.141745, -68.226827) "
                            stroke="#a15f33"
                            id="a"
                            data-index="267"
                        ></polygon>
                        <polygon
                            className=""
                            points="290.718582 65.0621086 299.151452 65.0662445 299.155588 73.4601986 290.722718 73.4560627"
                            transform="translate(294.937085, 69.261154) rotate(-6.000000) translate(-294.937085, -69.261154) "
                            stroke="#a15f33"
                            id="a"
                            data-index="257"
                        ></polygon>
                        <polygon
                            className=""
                            points="277.585671 66.7815607 286.018003 66.7877079 286.02415 75.182201 277.591819 75.1760538"
                            transform="translate(281.804911, 70.981881) rotate(-9.000000) translate(-281.804911, -70.981881) "
                            stroke="#a15f33"
                            id="a"
                            data-index="241"
                        ></polygon>
                        <polygon
                            className=""
                            points="264.561378 69.1826272 272.992963 69.1907184 273.001054 77.5859576 264.569469 77.5778665"
                            transform="translate(268.781216, 73.384292) rotate(-12.000000) translate(-268.781216, -73.384292) "
                            stroke="#a15f33"
                            id="a"
                            data-index="234"
                        ></polygon>
                        <polygon
                            className=""
                            points="251.681406 72.258738 260.112046 72.2686844 260.121992 80.6648689 251.691352 80.6549225"
                            transform="translate(255.901699, 76.461803) rotate(-15.000000) translate(-255.901699, -76.461803) "
                            stroke="#a15f33"
                            id="a"
                            data-index="222"
                        ></polygon>
                        <polygon
                            className=""
                            points="238.981061 76.001473 247.410567 76.0131658 247.422259 84.4104844 238.992754 84.3987917"
                            transform="translate(243.201660, 80.205979) rotate(-18.000000) translate(-243.201660, -80.205979) "
                            stroke="#a15f33"
                            id="a"
                            data-index="214"
                        ></polygon>
                        <polygon
                            className=""
                            points="226.495157 80.4005857 234.923353 80.4138966 234.936663 88.8125256 226.508468 88.7992147"
                            transform="translate(230.715910, 84.606556) rotate(-21.000000) translate(-230.715910, -84.606556) "
                            stroke="#a15f33"
                            id="a"
                            data-index="204"
                        ></polygon>
                        <polygon
                            className=""
                            points="202.302887 91.1179954 210.727992 91.134089 210.744085 99.5358086 202.31898 99.5197149"
                            transform="translate(206.523486, 95.326902) rotate(-27.000000) translate(-206.523486, -95.326902) "
                            stroke="#a15f33"
                            id="a"
                            data-index="192"
                        ></polygon>
                        <polygon
                            className=""
                            points="190.662828 97.4069408 199.086187 97.4241685 199.103415 105.827634 190.680056 105.810407"
                            transform="translate(194.883121, 101.617288) rotate(-30.000000) translate(-194.883121, -101.617288) "
                            stroke="#a15f33"
                            id="a"
                            data-index="178"
                        ></polygon>
                        <polygon
                            className=""
                            points="179.369645 104.293641 187.791149 104.311814 187.809322 112.717135 179.387818 112.698962"
                            transform="translate(183.589483, 108.505388) rotate(-33.000000) translate(-183.589483, -108.505388) "
                            stroke="#a15f33"
                            id="a"
                            data-index="168"
                        ></polygon>
                        <polygon
                            className=""
                            points="168.454288 111.759231 176.873847 111.77815 176.892766 120.185415 168.473207 120.166496"
                            transform="translate(172.673527, 115.972323) rotate(-36.000000) translate(-172.673527, -115.972323) "
                            stroke="#a15f33"
                            id="a"
                            data-index="160"
                        ></polygon>
                        <polygon
                            className=""
                            points="157.946669 119.78326 166.364217 119.802718 166.383675 128.211995 157.966127 128.192536"
                            transform="translate(162.165172, 123.997627) rotate(-39.000000) translate(-162.165172, -123.997627) "
                            stroke="#a15f33"
                            id="a"
                            data-index="149"
                        ></polygon>
                        <polygon
                            className=""
                            points="147.875584 128.343745 156.291075 128.363529 156.310859 136.774862 147.895367 136.755078"
                            transform="translate(152.093221, 132.559303) rotate(-42.000000) translate(-152.093221, -132.559303) "
                            stroke="#a15f33"
                            id="a"
                            data-index="141"
                        ></polygon>
                        <polygon
                            className=""
                            points="138.268629 137.417231 146.682041 137.437124 146.701934 145.850536 138.288522 145.830644"
                            transform="translate(142.485281, 141.633884) rotate(-45.000000) translate(-142.485281, -141.633884) "
                            stroke="#a15f33"
                            id="a"
                            data-index="131"
                        ></polygon>
                        <polygon
                            className=""
                            points="120.551061 157.002428 128.960337 157.021886 128.979795 165.439434 120.570519 165.419976"
                            transform="translate(124.765428, 161.220931) rotate(-51.000000) translate(-124.765428, -161.220931) "
                            stroke="#a15f33"
                            id="a"
                            data-index="121"
                        ></polygon>
                        <polygon
                            className=""
                            points="112.488992 167.460472 120.896257 167.479391 120.915176 175.89895 112.507911 175.880031"
                            transform="translate(116.702084, 171.679711) rotate(-54.000000) translate(-116.702084, -171.679711) "
                            stroke="#a15f33"
                            id="a"
                            data-index="109"
                        ></polygon>
                        <polygon
                            className=""
                            points="104.988008 178.324331 113.393329 178.342504 113.411502 186.764008 105.006181 186.745835"
                            transform="translate(109.199755, 182.544169) rotate(-57.000000) translate(-109.199755, -182.544169) "
                            stroke="#a15f33"
                            id="a"
                            data-index="98"
                        ></polygon>
                        <polygon
                            className=""
                            points="98.0686576 189.564234 106.472123 189.581462 106.489351 198.004821 98.0858853 197.987593"
                            transform="translate(102.279004, 193.784528) rotate(-60.000000) translate(-102.279004, -193.784528) "
                            stroke="#a15f33"
                            id="a"
                            data-index="91"
                        ></polygon>
                        <polygon
                            className=""
                            points="91.7498955 201.149377 100.151615 201.165471 100.167709 209.590576 91.7659891 209.574482"
                            transform="translate(95.958802, 205.369977) rotate(-63.000000) translate(-95.958802, -205.369977) "
                            stroke="#a15f33"
                            id="a"
                            data-index="75"
                        ></polygon>
                        <polygon
                            className=""
                            points="86.0490287 213.048008 94.44913 213.062792 94.4639133 221.489515 86.0638119 221.474731"
                            transform="translate(90.256471, 217.268762) rotate(-66.000000) translate(-90.256471, -217.268762) "
                            stroke="#a15f33"
                            id="a"
                            data-index="68"
                        ></polygon>
                        <polygon
                            className=""
                            points="80.9816709 225.227515 89.3802999 225.240826 89.3936108 233.669022 80.9949818 233.655711"
                            transform="translate(85.187641, 229.448269) rotate(-69.000000) translate(-85.187641, -229.448269) "
                            stroke="#a15f33"
                            id="a"
                            data-index="58"
                        ></polygon>
                        <polygon
                            className=""
                            points="72.8012166 250.294945 81.1974011 250.304892 81.2073476 258.735532 72.811163 258.725585"
                            transform="translate(77.004282, 254.515238) rotate(-75.000000) translate(-77.004282, -254.515238) "
                            stroke="#a15f33"
                            id="a"
                            data-index="48"
                        ></polygon>
                        <polygon
                            className=""
                            points="68.3709362 269.839152 76.765762 269.846242 76.772852 278.27824 68.3780262 278.27115"
                            transform="translate(72.571894, 274.058696) rotate(-79.560000) translate(-72.571894, -274.058696) "
                            stroke="#a15f33"
                            id="a"
                            data-index="34"
                        ></polygon>
                        <polygon
                            className=""
                            points="64.944394 295.9757 73.3381518 295.978771 73.3412226 304.411837 64.9474647 304.408767"
                            transform="translate(69.142808, 300.193769) rotate(-85.560000) translate(-69.142808, -300.193769) "
                            stroke="#a15f33"
                            id="a"
                            data-index="22"
                        ></polygon>
                        <polygon
                            className=""
                            points="64.2219585 311.251493 72.6154891 311.25216 72.6161556 319.685454 64.222625 319.684787"
                            transform="translate(68.419057, 315.468473) rotate(-89.040000) translate(-68.419057, -315.468473) "
                            stroke="#a15f33"
                            id="a"
                            data-index="13"
                        ></polygon>
                        <polygon
                            className=""
                            points="64.4322873 326.542996 72.8258837 326.541249 72.8241361 334.974477 64.4305397 334.976224"
                            transform="translate(68.628212, 330.758737) rotate(-92.520000) translate(-68.628212, -330.758737) "
                            stroke="#a15f33"
                            id="a"
                            data-index="4"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.940011 48.2700905 312.37322 48.2720455 312.375175 56.6656612 303.941966 56.6637062"
                            transform="translate(308.157593, 52.467876) rotate(-2.820000) translate(-308.157593, -52.467876) "
                            stroke="#a15f33"
                            id="a"
                            data-index="268"
                        ></polygon>
                        <polygon
                            className=""
                            points="293.22189 49.008547 301.654879 49.0120766 301.658409 57.4059116 293.225419 57.402382"
                            transform="translate(297.440149, 53.207229) rotate(-5.110000) translate(-297.440149, -53.207229) "
                            stroke="#a15f33"
                            id="a"
                            data-index="258"
                        ></polygon>
                        <polygon
                            className=""
                            points="282.495557 50.1785966 290.9282 50.1836849 290.933288 58.577866 282.500645 58.5727778"
                            transform="translate(286.714422, 54.378231) rotate(-7.410000) translate(-286.714422, -54.378231) "
                            stroke="#a15f33"
                            id="a"
                            data-index="246"
                        ></polygon>
                        <polygon
                            className=""
                            points="271.871407 51.768202 280.303582 51.7748097 280.31019 60.1694586 271.878014 60.1628509"
                            transform="translate(276.090798, 55.968830) rotate(-9.700000) translate(-276.090798, -55.968830) "
                            stroke="#a15f33"
                            id="a"
                            data-index="242"
                        ></polygon>
                        <polygon
                            className=""
                            points="261.273785 53.7886881 269.705371 53.7967792 269.713462 62.1920184 261.281877 62.1839273"
                            transform="translate(265.493624, 57.990353) rotate(-12.000000) translate(-265.493624, -57.990353) "
                            stroke="#a15f33"
                            id="a"
                            data-index="235"
                        ></polygon>
                        <polygon
                            className=""
                            points="250.811763 56.2192653 259.242644 56.2287817 259.252161 64.6247251 250.82128 64.6152087"
                            transform="translate(255.031962, 60.421995) rotate(-14.290000) translate(-255.031962, -60.421995) "
                            stroke="#a15f33"
                            id="a"
                            data-index="227"
                        ></polygon>
                        <polygon
                            className=""
                            points="240.455804 59.0639239 248.88587 59.0748049 248.896751 67.4715639 240.466685 67.460683"
                            transform="translate(244.676278, 63.267744) rotate(-16.580000) translate(-244.676278, -63.267744) "
                            stroke="#a15f33"
                            id="a"
                            data-index="223"
                        ></polygon>
                        <polygon
                            className=""
                            points="230.178057 62.3332268 238.607197 62.3454082 238.619378 70.7430936 230.190239 70.7309121"
                            transform="translate(234.398718, 66.538160) rotate(-18.880000) translate(-234.398718, -66.538160) "
                            stroke="#a15f33"
                            id="a"
                            data-index="215"
                        ></polygon>
                        <polygon
                            className=""
                            points="220.084299 65.9935324 228.512415 66.0069308 228.525813 74.405639 220.097697 74.3922406"
                            transform="translate(224.305056, 70.199586) rotate(-21.170000) translate(-224.305056, -70.199586) "
                            stroke="#a15f33"
                            id="a"
                            data-index="205"
                        ></polygon>
                        <polygon
                            className=""
                            points="195.877225 76.715149 204.302431 76.7311688 204.318451 85.1327875 195.893245 85.1167676"
                            transform="translate(200.097838, 80.923968) rotate(-26.820000) translate(-200.097838, -80.923968) "
                            stroke="#a15f33"
                            id="a"
                            data-index="193"
                        ></polygon>
                        <polygon
                            className=""
                            points="186.388714 81.7280901 194.812603 81.7450005 194.829514 90.147936 186.405625 90.1310256"
                            transform="translate(190.609114, 85.938013) rotate(-29.110000) translate(-190.609114, -85.938013) "
                            stroke="#a15f33"
                            id="a"
                            data-index="183"
                        ></polygon>
                        <polygon
                            className=""
                            points="177.069124 87.1387309 185.491623 87.1564271 185.509319 95.5607525 177.08682 95.5430563"
                            transform="translate(181.289222, 91.349742) rotate(-31.410000) translate(-181.289222, -91.349742) "
                            stroke="#a15f33"
                            id="a"
                            data-index="179"
                        ></polygon>
                        <polygon
                            className=""
                            points="168.014369 92.8913918 176.435425 92.9097571 176.453791 101.315525 168.032734 101.297159"
                            transform="translate(172.234080, 97.103458) rotate(-33.700000) translate(-172.234080, -97.103458) "
                            stroke="#a15f33"
                            id="a"
                            data-index="169"
                        ></polygon>
                        <polygon
                            className=""
                            points="159.159964 99.0270439 167.579524 99.0459632 167.598443 107.453228 159.178884 107.434309"
                            transform="translate(163.379204, 103.240136) rotate(-36.000000) translate(-163.379204, -103.240136) "
                            stroke="#a15f33"
                            id="a"
                            data-index="161"
                        ></polygon>
                        <polygon
                            className=""
                            points="150.597037 105.482546 159.015066 105.501895 159.034416 113.910691 150.616386 113.891341"
                            transform="translate(154.815726, 109.696618) rotate(-38.290000) translate(-154.815726, -109.696618) "
                            stroke="#a15f33"
                            id="a"
                            data-index="154"
                        ></polygon>
                        <polygon
                            className=""
                            points="142.300232 112.273498 150.716701 112.293155 150.736358 120.70351 142.319888 120.683854"
                            transform="translate(146.518295, 116.488504) rotate(-40.580000) translate(-146.518295, -116.488504) "
                            stroke="#a15f33"
                            id="a"
                            data-index="150"
                        ></polygon>
                        <polygon
                            className=""
                            points="134.248419 119.420827 142.663302 119.440666 142.683141 127.852607 134.268257 127.832769"
                            transform="translate(138.465780, 123.636717) rotate(-42.880000) translate(-138.465780, -123.636717) "
                            stroke="#a15f33"
                            id="a"
                            data-index="142"
                        ></polygon>
                        <polygon
                            className=""
                            points="126.524463 126.850978 134.937757 126.870871 134.957649 135.284401 126.544355 135.264509"
                            transform="translate(130.741056, 131.067690) rotate(-45.170000) translate(-130.741056, -131.067690) "
                            stroke="#a15f33"
                            id="a"
                            data-index="132"
                        ></polygon>
                        <polygon
                            className=""
                            points="108.794896 146.445958 117.204295 146.465442 117.223779 154.882868 108.81438 154.863384"
                            transform="translate(113.009338, 150.664413) rotate(-50.820000) translate(-113.009338, -150.664413) "
                            stroke="#a15f33"
                            id="a"
                            data-index="122"
                        ></polygon>
                        <polygon
                            className=""
                            points="102.176541 154.86714 110.584396 154.886241 110.603497 163.30521 102.195642 163.286109"
                            transform="translate(106.390019, 159.086175) rotate(-53.110000) translate(-106.390019, -159.086175) "
                            stroke="#a15f33"
                            id="a"
                            data-index="110"
                        ></polygon>
                        <polygon
                            className=""
                            points="95.8749881 163.583355 104.28133 163.601949 104.299924 172.022432 95.8935819 172.003838"
                            transform="translate(100.087456, 167.802894) rotate(-55.410000) translate(-100.087456, -167.802894) "
                            stroke="#a15f33"
                            id="a"
                            data-index="103"
                        ></polygon>
                        <polygon
                            className=""
                            points="89.9550874 172.5049 98.3599669 172.52287 98.3779368 180.944815 89.9730573 180.926845"
                            transform="translate(94.166512, 176.724858) rotate(-57.700000) translate(-94.166512, -176.724858) "
                            stroke="#a15f33"
                            id="a"
                            data-index="99"
                        ></polygon>
                        <polygon
                            className=""
                            points="84.3746767 181.69531 92.7781426 181.712538 92.7953703 190.135896 84.3919044 190.118669"
                            transform="translate(88.585023, 185.915603) rotate(-60.000000) translate(-88.585023, -185.915603) "
                            stroke="#a15f33"
                            id="a"
                            data-index="92"
                        ></polygon>
                        <polygon
                            className=""
                            points="79.1911829 191.060001 87.5933049 191.076379 87.6096833 199.501082 79.2075614 199.484703"
                            transform="translate(83.400433, 195.280541) rotate(-62.290000) translate(-83.400433, -195.280541) "
                            stroke="#a15f33"
                            id="a"
                            data-index="80"
                        ></polygon>
                        <polygon
                            className=""
                            points="74.3878182 200.623486 82.7886683 200.638911 82.804093 209.064885 74.4032428 209.049461"
                            transform="translate(78.595956, 204.844186) rotate(-64.580000) translate(-78.595956, -204.844186) "
                            stroke="#a15f33"
                            id="a"
                            data-index="76"
                        ></polygon>
                        <polygon
                            className=""
                            points="69.9538282 210.413435 78.3534818 210.427803 78.3678493 218.854974 69.9681957 218.840606"
                            transform="translate(74.160839, 214.634204) rotate(-66.880000) translate(-74.160839, -214.634204) "
                            stroke="#a15f33"
                            id="a"
                            data-index="69"
                        ></polygon>
                        <polygon
                            className=""
                            points="65.9348411 220.329093 74.3333913 220.342316 74.3466143 228.77059 65.948064 228.757367"
                            transform="translate(70.140728, 224.549841) rotate(-69.170000) translate(-70.140728, -224.549841) "
                            stroke="#a15f33"
                            id="a"
                            data-index="59"
                        ></polygon>
                        <polygon
                            className=""
                            points="57.7473329 245.410138 66.1435803 245.420192 66.1536348 253.85077 57.7573874 253.840715"
                            transform="translate(61.950484, 249.630454) rotate(-74.820000) translate(-61.950484, -249.630454) "
                            stroke="#a15f33"
                            id="a"
                            data-index="49"
                        ></polygon>
                        <polygon
                            className=""
                            points="54.9663443 256.557848 63.3617926 256.566394 63.3703379 264.99777 54.9748896 264.989225"
                            transform="translate(59.168341, 260.777809) rotate(-77.280000) translate(-59.168341, -260.777809) "
                            stroke="#a15f33"
                            id="a"
                            data-index="39"
                        ></polygon>
                        <polygon
                            className=""
                            points="52.6769748 267.768285 61.0717588 267.775265 61.0787385 276.207305 52.6839544 276.200326"
                            transform="translate(56.877857, 271.987795) rotate(-79.730000) translate(-56.877857, -271.987795) "
                            stroke="#a15f33"
                            id="a"
                            data-index="35"
                        ></polygon>
                        <polygon
                            className=""
                            points="49.2460285 293.919415 57.6398061 293.922609 57.6430003 302.355656 49.2492227 302.352462"
                            transform="translate(53.444514, 298.137535) rotate(-85.380000) translate(-53.444514, -298.137535) "
                            stroke="#a15f33"
                            id="a"
                            data-index="23"
                        ></polygon>
                        <polygon
                            className=""
                            points="48.42171 310.427522 56.8152436 310.428272 56.8159933 318.861563 48.4224598 318.860813"
                            transform="translate(52.618852, 314.644543) rotate(-88.920000) translate(-52.618852, -314.644543) "
                            stroke="#a15f33"
                            id="a"
                            data-index="14"
                        ></polygon>
                        <polygon
                            className=""
                            points="48.6228833 326.955031 57.016476 326.953325 57.0147699 335.386557 48.6211772 335.388263"
                            transform="translate(52.818827, 331.170794) rotate(-92.460000) translate(-52.818827, -331.170794) "
                            stroke="#a15f33"
                            id="a"
                            data-index="5"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.956025 32.5135441 312.389244 32.5153886 312.391089 40.9089937 303.95787 40.9071493"
                            transform="translate(308.173557, 36.711269) rotate(-2.660000) translate(-308.173557, -36.711269) "
                            stroke="#a15f33"
                            id="a"
                            data-index="269"
                        ></polygon>
                        <polygon
                            className=""
                            points="292.357849 33.2853712 300.790852 33.2888256 300.794306 41.6826472 292.361303 41.6791929"
                            transform="translate(296.576078, 37.484009) rotate(-5.000000) translate(-296.576078, -37.484009) "
                            stroke="#a15f33"
                            id="a"
                            data-index="259"
                        ></polygon>
                        <polygon
                            className=""
                            points="280.850393 34.5214758 289.28305 34.5265103 289.288085 42.9206774 280.855427 42.9156429"
                            transform="translate(285.069239, 38.721077) rotate(-7.330000) translate(-285.069239, -38.721077) "
                            stroke="#a15f33"
                            id="a"
                            data-index="247"
                        ></polygon>
                        <polygon
                            className=""
                            points="269.403062 36.2221138 277.835246 36.2286952 277.841828 44.6233349 269.409643 44.6167535"
                            transform="translate(273.622445, 40.422724) rotate(-9.660000) translate(-273.622445, -40.422724) "
                            stroke="#a15f33"
                            id="a"
                            data-index="243"
                        ></polygon>
                        <polygon
                            className=""
                            points="257.986193 38.3947489 266.417778 38.40284 266.425869 46.7980793 257.994284 46.7899881"
                            transform="translate(262.206031, 42.596414) rotate(-12.000000) translate(-262.206031, -42.596414) "
                            stroke="#a15f33"
                            id="a"
                            data-index="236"
                        ></polygon>
                        <polygon
                            className=""
                            points="246.716233 41.0172269 255.147101 41.0267677 255.156642 49.4227244 246.725774 49.4131836"
                            transform="translate(250.936438, 45.219976) rotate(-14.330000) translate(-250.936438, -45.219976) "
                            stroke="#a15f33"
                            id="a"
                            data-index="228"
                        ></polygon>
                        <polygon
                            className=""
                            points="235.562847 44.0935132 243.992882 44.1044406 244.003809 52.5012301 235.573774 52.4903027"
                            transform="translate(239.783328, 48.297372) rotate(-16.660000) translate(-239.783328, -48.297372) "
                            stroke="#a15f33"
                            id="a"
                            data-index="224"
                        ></polygon>
                        <polygon
                            className=""
                            points="224.497505 47.6346142 232.926593 47.6468615 232.93884 56.044598 224.509752 56.0323507"
                            transform="translate(228.718172, 51.839606) rotate(-19.000000) translate(-228.718172, -51.839606) "
                            stroke="#a15f33"
                            id="a"
                            data-index="216"
                        ></polygon>
                        <polygon
                            className=""
                            points="213.633067 51.6044188 222.061108 51.6178991 222.074589 60.0166825 213.646548 60.0032021"
                            transform="translate(217.853828, 55.810551) rotate(-21.330000) translate(-217.853828, -55.810551) "
                            stroke="#a15f33"
                            id="a"
                            data-index="206"
                        ></polygon>
                        <polygon
                            className=""
                            points="189.45263 62.3143875 197.877925 62.3303412 197.893879 70.7318706 189.468584 70.7159168"
                            transform="translate(193.673255, 66.523129) rotate(-26.660000) translate(-193.673255, -66.523129) "
                            stroke="#a15f33"
                            id="a"
                            data-index="194"
                        ></polygon>
                        <polygon
                            className=""
                            points="179.17381 67.714058 187.597764 67.7309281 187.614634 76.1337987 179.19068 76.1169286"
                            transform="translate(183.394222, 71.923928) rotate(-29.000000) translate(-183.394222, -71.923928) "
                            stroke="#a15f33"
                            id="a"
                            data-index="184"
                        ></polygon>
                        <polygon
                            className=""
                            points="169.167637 73.5012452 177.590186 73.518916 177.607857 81.9231921 169.185308 81.9055213"
                            transform="translate(173.387747, 77.712219) rotate(-31.330000) translate(-173.387747, -77.712219) "
                            stroke="#a15f33"
                            id="a"
                            data-index="180"
                        ></polygon>
                        <polygon
                            className=""
                            points="159.406265 79.6885688 167.827347 79.7069234 167.845702 88.1126653 159.424619 88.0943107"
                            transform="translate(163.625983, 83.900617) rotate(-33.660000) translate(-163.625983, -83.900617) "
                            stroke="#a15f33"
                            id="a"
                            data-index="170"
                        ></polygon>
                        <polygon
                            className=""
                            points="149.865641 86.2948567 158.285201 86.3137759 158.30412 94.721041 149.88456 94.7021217"
                            transform="translate(154.084881, 90.507949) rotate(-36.000000) translate(-154.084881, -90.507949) "
                            stroke="#a15f33"
                            id="a"
                            data-index="162"
                        ></polygon>
                        <polygon
                            className=""
                            points="140.643072 93.2527342 149.061075 93.2720903 149.080431 101.680913 140.662429 101.661557"
                            transform="translate(144.861752, 97.466823) rotate(-38.330000) translate(-144.861752, -97.466823) "
                            stroke="#a15f33"
                            id="a"
                            data-index="155"
                        ></polygon>
                        <polygon
                            className=""
                            points="131.712462 100.578104 140.128876 100.597769 140.148541 109.008179 131.732127 108.988514"
                            transform="translate(135.930502, 104.793142) rotate(-40.660000) translate(-135.930502, -104.793142) "
                            stroke="#a15f33"
                            id="a"
                            data-index="151"
                        ></polygon>
                        <polygon
                            className=""
                            points="123.052242 108.292571 131.467042 108.312416 131.486887 116.72444 123.072087 116.704596"
                            transform="translate(127.269565, 112.508506) rotate(-43.000000) translate(-127.269565, -112.508506) "
                            stroke="#a15f33"
                            id="a"
                            data-index="143"
                        ></polygon>
                        <polygon
                            className=""
                            points="114.750739 116.317458 123.163922 116.337349 123.183814 124.75099 114.770631 124.731099"
                            transform="translate(118.967277, 120.534224) rotate(-45.330000) translate(-118.967277, -120.534224) "
                            stroke="#a15f33"
                            id="a"
                            data-index="133"
                        ></polygon>
                        <polygon
                            className=""
                            points="97.0405686 135.890966 105.450076 135.910472 105.469582 144.327789 97.0600745 144.308283"
                            transform="translate(101.255075, 140.109377) rotate(-50.660000) translate(-101.255075, -140.109377) "
                            stroke="#a15f33"
                            id="a"
                            data-index="123"
                        ></polygon>
                        <polygon
                            className=""
                            points="89.8583013 144.98538 98.2662303 145.004502 98.2853526 153.423397 89.8774235 153.404275"
                            transform="translate(94.071827, 149.204389) rotate(-53.000000) translate(-94.071827, -149.204389) "
                            stroke="#a15f33"
                            id="a"
                            data-index="111"
                        ></polygon>
                        <polygon
                            className=""
                            points="83.0834232 154.323532 91.4898168 154.342145 91.5084303 162.762576 83.1020367 162.743962"
                            transform="translate(87.295927, 158.543054) rotate(-55.330000) translate(-87.295927, -158.543054) "
                            stroke="#a15f33"
                            id="a"
                            data-index="104"
                        ></polygon>
                        <polygon
                            className=""
                            points="76.6956481 163.928222 85.1005527 163.946204 85.1185345 172.368123 76.7136299 172.350142"
                            transform="translate(80.907091, 168.148173) rotate(-57.660000) translate(-80.907091, -168.148173) "
                            stroke="#a15f33"
                            id="a"
                            data-index="100"
                        ></polygon>
                        <polygon
                            className=""
                            points="70.6806959 173.826386 79.0841617 173.843613 79.1013894 182.266972 70.6979236 182.249744"
                            transform="translate(74.891043, 178.046679) rotate(-60.000000) translate(-74.891043, -178.046679) "
                            stroke="#a15f33"
                            id="a"
                            data-index="93"
                        ></polygon>
                        <polygon
                            className=""
                            points="65.0999097 183.91707 73.5020088 183.933432 73.5183715 192.358158 65.1162724 192.341795"
                            transform="translate(69.309141, 188.137614) rotate(-62.330000) translate(-69.309141, -188.137614) "
                            stroke="#a15f33"
                            id="a"
                            data-index="81"
                        ></polygon>
                        <polygon
                            className=""
                            points="59.9359463 194.225364 68.3367535 194.240753 68.352143 202.666771 59.9513358 202.651381"
                            transform="translate(64.144045, 198.446067) rotate(-64.660000) translate(-64.144045, -198.446067) "
                            stroke="#a15f33"
                            id="a"
                            data-index="77"
                        ></polygon>
                        <polygon
                            className=""
                            points="55.1779296 204.779734 63.5775231 204.794044 63.5918328 213.221275 55.1922393 213.206965"
                            transform="translate(59.384881, 209.000505) rotate(-67.000000) translate(-59.384881, -209.000505) "
                            stroke="#a15f33"
                            id="a"
                            data-index="70"
                        ></polygon>
                        <polygon
                            className=""
                            points="50.8743825 215.472533 59.2728591 215.485673 59.2859988 223.914021 50.8875222 223.900881"
                            transform="translate(55.080191, 219.693277) rotate(-69.330000) translate(-55.080191, -219.693277) "
                            stroke="#a15f33"
                            id="a"
                            data-index="60"
                        ></polygon>
                        <polygon
                            className=""
                            points="42.6957347 240.525948 51.0920385 240.536098 51.1021887 248.966619 42.7058849 248.956469"
                            transform="translate(46.898962, 244.746283) rotate(-74.660000) translate(-46.898962, -244.746283) "
                            stroke="#a15f33"
                            id="a"
                            data-index="50"
                        ></polygon>
                        <polygon
                            className=""
                            points="39.5419704 253.092583 47.9374187 253.101128 47.945964 261.532505 39.5505157 261.523959"
                            transform="translate(43.743967, 257.312544) rotate(-77.280000) translate(-43.743967, -257.312544) "
                            stroke="#a15f33"
                            id="a"
                            data-index="40"
                        ></polygon>
                        <polygon
                            className=""
                            points="36.9773239 265.741056 45.3720693 265.747931 45.3789448 274.180011 36.9841994 274.173135"
                            transform="translate(41.178134, 269.960533) rotate(-79.890000) translate(-41.178134, -269.960533) "
                            stroke="#a15f33"
                            id="a"
                            data-index="36"
                        ></polygon>
                        <polygon
                            className=""
                            points="33.5500214 291.863324 41.9438171 291.866628 41.9471209 300.299657 33.5533252 300.296353"
                            transform="translate(37.748571, 296.081491) rotate(-85.220000) translate(-37.748571, -296.081491) "
                            stroke="#a15f33"
                            id="a"
                            data-index="27"
                        ></polygon>
                        <polygon
                            className=""
                            points="32.7486754 305.188312 41.1422472 305.189755 41.1436903 313.623008 32.7501185 313.621565"
                            transform="translate(36.946183, 309.405660) rotate(-87.920000) translate(-36.946183, -309.405660) "
                            stroke="#a15f33"
                            id="a"
                            data-index="24"
                        ></polygon>
                        <polygon
                            className=""
                            points="32.5782313 318.48678 40.9717553 318.486356 40.9713317 326.919657 32.5778078 326.920081"
                            transform="translate(36.774782, 322.703219) rotate(-90.610000) translate(-36.774782, -322.703219) "
                            stroke="#a15f33"
                            id="a"
                            data-index="15"
                        ></polygon>
                        <polygon
                            className=""
                            points="33.0349273 331.778687 41.4285786 331.7764 41.4262922 340.209574 33.0326409 340.21186"
                            transform="translate(37.230610, 335.994130) rotate(-93.300000) translate(-37.230610, -335.994130) "
                            stroke="#a15f33"
                            id="a"
                            data-index="6"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.955583 16.7596886 312.388811 16.7614362 312.390558 25.1550325 303.95733 25.1532849"
                            transform="translate(308.173071, 20.957361) rotate(-2.520000) translate(-308.173071, -20.957361) "
                            stroke="#a15f33"
                            id="a"
                            data-index="270"
                        ></polygon>
                        <polygon
                            className=""
                            points="294.010878 17.3590925 302.443946 17.3621495 302.447003 25.7559053 294.013935 25.7528482"
                            transform="translate(298.228940, 21.557499) rotate(-4.420000) translate(-298.228940, -21.557499) "
                            stroke="#a15f33"
                            id="a"
                            data-index="260"
                        ></polygon>
                        <polygon
                            className=""
                            points="284.143802 18.2805376 292.576626 18.2848839 292.580973 26.6788839 284.148148 26.6745377"
                            transform="translate(288.362387, 22.479711) rotate(-6.310000) translate(-288.362387, -22.479711) "
                            stroke="#a15f33"
                            id="a"
                            data-index="250"
                        ></polygon>
                        <polygon
                            className=""
                            points="274.260803 19.5327632 282.693297 19.5383864 282.69892 27.9327172 274.266427 27.9270939"
                            transform="translate(278.479862, 23.732740) rotate(-8.210000) translate(-278.479862, -23.732740) "
                            stroke="#a15f33"
                            id="a"
                            data-index="248"
                        ></polygon>
                        <polygon
                            className=""
                            points="264.476658 21.1012292 272.90874 21.1080982 272.915609 29.5028411 264.483527 29.4959722"
                            transform="translate(268.696134, 25.302035) rotate(-10.100000) translate(-268.696134, -25.302035) "
                            stroke="#a15f33"
                            id="a"
                            data-index="244"
                        ></polygon>
                        <polygon
                            className=""
                            points="254.6986 23.0008097 263.130186 23.0089009 263.138277 31.4041401 254.706691 31.396049"
                            transform="translate(258.918438, 27.202475) rotate(-12.000000) translate(-258.918438, -27.202475) "
                            stroke="#a15f33"
                            id="a"
                            data-index="237"
                        ></polygon>
                        <polygon
                            className=""
                            points="245.040187 25.209447 253.471199 25.2187187 253.480471 33.6145309 245.049458 33.6052592"
                            transform="translate(249.260329, 29.411989) rotate(-13.890000) translate(-249.260329, -29.411989) "
                            stroke="#a15f33"
                            id="a"
                            data-index="231"
                        ></polygon>
                        <polygon
                            className=""
                            points="235.460303 27.7338931 243.890665 27.7443049 243.901077 36.1407666 235.470714 36.1303548"
                            transform="translate(239.680690, 31.937330) rotate(-15.780000) translate(-239.680690, -31.937330) "
                            stroke="#a15f33"
                            id="a"
                            data-index="229"
                        ></polygon>
                        <polygon
                            className=""
                            points="225.91941 30.5872448 234.349046 30.598757 234.360558 38.995946 225.930923 38.9844338"
                            transform="translate(230.139984, 34.791595) rotate(-17.680000) translate(-230.139984, -34.791595) "
                            stroke="#a15f33"
                            id="a"
                            data-index="225"
                        ></polygon>
                        <polygon
                            className=""
                            points="216.528313 33.7363679 224.957154 33.7489246 224.96971 42.1469078 216.540869 42.1343511"
                            transform="translate(220.749012, 37.941638) rotate(-19.570000) translate(-220.749012, -37.941638) "
                            stroke="#a15f33"
                            id="a"
                            data-index="217"
                        ></polygon>
                        <polygon
                            className=""
                            points="207.197968 37.2111238 215.625943 37.2246754 215.639495 45.6235248 207.21152 45.6099731"
                            transform="translate(211.418732, 41.417324) rotate(-21.470000) translate(-211.418732, -41.417324) "
                            stroke="#a15f33"
                            id="a"
                            data-index="207"
                        ></polygon>
                        <polygon
                            className=""
                            points="183.014112 47.922741 191.439485 47.9386365 191.45538 56.340088 183.030007 56.3241925"
                            transform="translate(187.234746, 52.131415) rotate(-26.520000) translate(-187.234746, -52.131415) "
                            stroke="#a15f33"
                            id="a"
                            data-index="197"
                        ></polygon>
                        <polygon
                            className=""
                            points="174.175113 52.4956367 182.599406 52.5122899 182.616059 60.9148212 174.191766 60.898168"
                            transform="translate(178.395586, 56.705229) rotate(-28.420000) translate(-178.395586, -56.705229) "
                            stroke="#a15f33"
                            id="a"
                            data-index="195"
                        ></polygon>
                        <polygon
                            className=""
                            points="165.538664 57.331374 173.961835 57.3487084 173.97917 65.7523612 165.555998 65.7350269"
                            transform="translate(169.758917, 61.541868) rotate(-30.310000) translate(-169.758917, -61.541868) "
                            stroke="#a15f33"
                            id="a"
                            data-index="185"
                        ></polygon>
                        <polygon
                            className=""
                            points="157.022877 62.475806 165.444878 62.493749 165.462821 70.8985721 157.04082 70.8806291"
                            transform="translate(161.242849, 66.687189) rotate(-32.210000) translate(-161.242849, -66.687189) "
                            stroke="#a15f33"
                            id="a"
                            data-index="181"
                        ></polygon>
                        <polygon
                            className=""
                            points="148.726649 67.8691911 157.147449 67.8876613 157.165919 76.293686 148.745119 76.2752158"
                            transform="translate(152.946284, 72.081439) rotate(-34.100000) translate(-152.946284, -72.081439) "
                            stroke="#a15f33"
                            id="a"
                            data-index="171"
                        ></polygon>
                        <polygon
                            className=""
                            points="140.571318 73.5626695 148.990878 73.5815887 149.009797 81.9888537 140.590237 81.9699345"
                            transform="translate(144.790557, 77.775762) rotate(-36.000000) translate(-144.790557, -77.775762) "
                            stroke="#a15f33"
                            id="a"
                            data-index="165"
                        ></polygon>
                        <polygon
                            className=""
                            points="132.651594 79.4901232 141.069893 79.5094065 141.089176 87.9179322 132.670878 87.8986489"
                            transform="translate(136.870385, 83.704028) rotate(-37.890000) translate(-136.870385, -83.704028) "
                            stroke="#a15f33"
                            id="a"
                            data-index="163"
                        ></polygon>
                        <polygon
                            className=""
                            points="124.932677 85.6743641 133.349694 85.6939276 133.369257 94.1037351 124.95224 94.0841716"
                            transform="translate(129.150967, 89.889050) rotate(-39.780000) translate(-129.150967, -89.889050) "
                            stroke="#a15f33"
                            id="a"
                            data-index="156"
                        ></polygon>
                        <polygon
                            className=""
                            points="117.3838 92.1433626 125.799513 92.163122 125.819272 100.574234 117.40356 100.554475"
                            transform="translate(121.601536, 96.358798) rotate(-41.680000) translate(-121.601536, -96.358798) "
                            stroke="#a15f33"
                            id="a"
                            data-index="152"
                        ></polygon>
                        <polygon
                            className=""
                            points="110.09263 98.8219942 118.507035 98.8418623 118.526903 107.254282 110.112498 107.234414"
                            transform="translate(114.309766, 103.038138) rotate(-43.570000) translate(-114.309766, -103.038138) "
                            stroke="#a15f33"
                            id="a"
                            data-index="144"
                        ></polygon>
                        <polygon
                            className=""
                            points="102.990034 105.773584 111.40312 105.793475 111.42301 114.207213 103.009924 114.187323"
                            transform="translate(107.206522, 109.990399) rotate(-45.470000) translate(-107.206522, -109.990399) "
                            stroke="#a15f33"
                            id="a"
                            data-index="134"
                        ></polygon>
                        <polygon
                            className=""
                            points="85.2772568 125.349942 93.6868597 125.369467 93.7063844 133.786688 85.2967815 133.767163"
                            transform="translate(89.491821, 129.568315) rotate(-50.520000) translate(-89.491821, -129.568315) "
                            stroke="#a15f33"
                            id="a"
                            data-index="124"
                        ></polygon>
                        <polygon
                            className=""
                            points="79.0722291 133.106083 87.4805464 133.125312 87.4997757 141.54382 79.0914584 141.52459"
                            transform="translate(83.286002, 137.324951) rotate(-52.420000) translate(-83.286002, -137.324951) "
                            stroke="#a15f33"
                            id="a"
                            data-index="114"
                        ></polygon>
                        <polygon
                            className=""
                            points="73.1596192 141.02041 81.5666798 141.039262 81.5855314 149.459026 73.1784708 149.440174"
                            transform="translate(77.372575, 145.239718) rotate(-54.310000) translate(-77.372575, -145.239718) "
                            stroke="#a15f33"
                            id="a"
                            data-index="112"
                        ></polygon>
                        <polygon
                            className=""
                            points="67.4833639 149.167965 75.8891892 149.186354 75.9075784 157.607353 67.5017531 157.588964"
                            transform="translate(71.695471, 153.387659) rotate(-56.210000) translate(-71.695471, -153.387659) "
                            stroke="#a15f33"
                            id="a"
                            data-index="105"
                        ></polygon>
                        <polygon
                            className=""
                            points="62.1093813 157.454126 70.5140107 157.471975 70.5318597 165.89417 62.1272303 165.876321"
                            transform="translate(66.320620, 161.674148) rotate(-58.100000) translate(-66.320620, -161.674148) "
                            stroke="#a15f33"
                            id="a"
                            data-index="101"
                        ></polygon>
                        <polygon
                            className=""
                            points="56.986715 165.957461 65.3901809 165.974689 65.4074086 174.398047 57.0039427 174.38082"
                            transform="translate(61.197062, 170.177754) rotate(-60.000000) translate(-61.197062, -170.177754) "
                            stroke="#a15f33"
                            id="a"
                            data-index="94"
                        ></polygon>
                        <polygon
                            className=""
                            points="52.1748539 174.579218 60.5772056 174.595752 60.5937401 183.020225 52.1913884 183.003691"
                            transform="translate(56.384297, 178.799721) rotate(-61.890000) translate(-56.384297, -178.799721) "
                            stroke="#a15f33"
                            id="a"
                            data-index="84"
                        ></polygon>
                        <polygon
                            className=""
                            points="47.6513296 183.354324 56.0526153 183.370093 56.0683847 191.795632 47.6670989 191.779862"
                            transform="translate(51.859857, 187.574978) rotate(-63.780000) translate(-51.859857, -187.574978) "
                            stroke="#a15f33"
                            id="a"
                            data-index="82"
                        ></polygon>
                        <polygon
                            className=""
                            points="43.3994667 192.320787 51.799734 192.335718 51.814665 200.762275 43.4143977 200.747344"
                            transform="translate(47.607066, 196.541531) rotate(-65.680000) translate(-47.607066, -196.541531) "
                            stroke="#a15f33"
                            id="a"
                            data-index="78"
                        ></polygon>
                        <polygon
                            className=""
                            points="39.4686407 201.374477 47.8679523 201.388509 47.8819843 209.816022 39.4826727 209.80199"
                            transform="translate(43.675313, 205.595250) rotate(-67.570000) translate(-43.675313, -205.595250) "
                            stroke="#a15f33"
                            id="a"
                            data-index="71"
                        ></polygon>
                        <polygon
                            className=""
                            points="35.8215787 210.601237 44.2199913 210.614303 44.2330579 219.042715 35.8346453 219.029649"
                            transform="translate(40.027318, 214.821976) rotate(-69.470000) translate(-40.027318, -214.821976) "
                            stroke="#a15f33"
                            id="a"
                            data-index="61"
                        ></polygon>
                        <polygon
                            className=""
                            points="27.6416411 235.658166 36.0379947 235.6684 36.0482284 244.098871 27.6518748 244.088637"
                            transform="translate(31.844935, 239.878518) rotate(-74.520000) translate(-31.844935, -239.878518) "
                            stroke="#a15f33"
                            id="a"
                            data-index="51"
                        ></polygon>
                        <polygon
                            className=""
                            points="24.1175965 249.627318 32.5130448 249.635863 32.5215901 258.067239 24.1261417 258.058694"
                            transform="translate(28.319593, 253.847279) rotate(-77.280000) translate(-28.319593, -253.847279) "
                            stroke="#a15f33"
                            id="a"
                            data-index="41"
                        ></polygon>
                        <polygon
                            className=""
                            points="21.2824854 263.697938 29.6771974 263.704722 29.6839816 272.136835 21.2892696 272.130051"
                            transform="translate(25.483234, 267.917387) rotate(-80.030000) translate(-25.483234, -267.917387) "
                            stroke="#a15f33"
                            id="a"
                            data-index="37"
                        ></polygon>
                        <polygon
                            className=""
                            points="17.8545805 289.823825 26.2483925 289.827224 26.2517922 298.260237 17.8579801 298.256837"
                            transform="translate(22.053186, 294.042031) rotate(-85.080000) translate(-22.053186, -294.042031) "
                            stroke="#a15f33"
                            id="a"
                            data-index="28"
                        ></polygon>
                        <polygon
                            className=""
                            points="16.9680939 304.043397 25.3616714 304.044916 25.3631907 312.478163 16.9696132 312.476644"
                            transform="translate(21.165642, 308.260780) rotate(-87.810000) translate(-21.165642, -308.260780) "
                            stroke="#a15f33"
                            id="a"
                            data-index="25"
                        ></polygon>
                        <polygon
                            className=""
                            points="16.7629731 318.289003 25.156496 318.288628 25.1561211 326.721929 16.7625981 326.722304"
                            transform="translate(20.959547, 322.505466) rotate(-90.540000) translate(-20.959547, -322.505466) "
                            stroke="#a15f33"
                            id="a"
                            data-index="16"
                        ></polygon>
                        <polygon
                            className=""
                            points="17.2396769 332.5283 25.6333257 332.526035 25.63106 340.95921 17.2374111 340.961476"
                            transform="translate(21.435368, 336.743755) rotate(-93.270000) translate(-21.435368, -336.743755) "
                            stroke="#a15f33"
                            id="a"
                            data-index="7"
                        ></polygon>
                        <polygon
                            className=""
                            points="303.922117 1.00880907 312.355352 1.01047366 312.357017 9.40406285 303.923781 9.40239826"
                            transform="translate(308.139567, 5.206436) rotate(-2.400000) translate(-308.139567, -5.206436) "
                            stroke="#a15f33"
                            id="a"
                            data-index="271"
                        ></polygon>
                        <polygon
                            className=""
                            points="293.342642 1.62622979 301.775721 1.6292182 301.778709 10.0229634 293.34563 10.019975"
                            transform="translate(297.560675, 5.824597) rotate(-4.320000) translate(-297.560675, -5.824597) "
                            stroke="#a15f33"
                            id="a"
                            data-index="261"
                        ></polygon>
                        <polygon
                            className=""
                            points="282.789965 2.59602961 291.2228 2.60032843 291.227099 10.9943179 282.794264 10.9900191"
                            transform="translate(287.008532, 6.795174) rotate(-6.240000) translate(-287.008532, -6.795174) "
                            stroke="#a15f33"
                            id="a"
                            data-index="251"
                        ></polygon>
                        <polygon
                            className=""
                            points="272.275939 3.91712222 280.708443 3.92271214 280.714033 12.3170331 272.281529 12.3114432"
                            transform="translate(276.494986, 8.117078) rotate(-8.160000) translate(-276.494986, -8.117078) "
                            stroke="#a15f33"
                            id="a"
                            data-index="249"
                        ></polygon>
                        <polygon
                            className=""
                            points="261.81237 5.58802698 270.244456 5.59488291 270.251312 13.9896211 261.819226 13.9827652"
                            transform="translate(266.031841, 9.788824) rotate(-10.080000) translate(-266.031841, -9.788824) "
                            stroke="#a15f33"
                            id="a"
                            data-index="245"
                        ></polygon>
                        <polygon
                            className=""
                            points="251.411008 7.60687058 259.842593 7.61496172 259.850684 16.010201 251.419099 16.0021098"
                            transform="translate(255.630846, 11.808536) rotate(-12.000000) translate(-255.630846, -11.808536) "
                            stroke="#a15f33"
                            id="a"
                            data-index="238"
                        ></polygon>
                        <polygon
                            className=""
                            points="241.083533 9.9713891 249.514536 9.98067914 249.523826 18.3765011 241.092823 18.367211"
                            transform="translate(245.303679, 14.173945) rotate(-13.920000) translate(-245.303679, -14.173945) "
                            stroke="#a15f33"
                            id="a"
                            data-index="232"
                        ></polygon>
                        <polygon
                            className=""
                            points="230.841543 12.6789306 239.271884 12.6893778 239.282331 21.0858614 230.85199 21.0754141"
                            transform="translate(235.061937, 16.882396) rotate(-15.840000) translate(-235.061937, -16.882396) "
                            stroke="#a15f33"
                            id="a"
                            data-index="230"
                        ></polygon>
                        <polygon
                            className=""
                            points="220.696539 15.7264579 229.126142 15.7380154 229.1377 24.1352367 220.708096 24.1236792"
                            transform="translate(224.917119, 19.930847) rotate(-17.760000) translate(-224.917119, -19.930847) "
                            stroke="#a15f33"
                            id="a"
                            data-index="226"
                        ></polygon>
                        <polygon
                            className=""
                            points="210.659912 19.1105524 219.088705 19.1231683 219.101321 27.5211999 210.672528 27.508584"
                            transform="translate(214.880616, 23.315876) rotate(-19.680000) translate(-214.880616, -23.315876) "
                            stroke="#a15f33"
                            id="a"
                            data-index="218"
                        ></polygon>
                        <polygon
                            className=""
                            points="200.742932 22.8274174 209.170846 22.841035 209.184463 31.239946 200.75655 31.2263284"
                            transform="translate(204.963698, 27.033682) rotate(-21.600000) translate(-204.963698, -27.033682) "
                            stroke="#a15f33"
                            id="a"
                            data-index="208"
                        ></polygon>
                        <polygon
                            className=""
                            points="176.546651 33.5471767 184.97209 33.5630219 184.987936 41.964407 176.562496 41.9485617"
                            transform="translate(180.767293, 37.755792) rotate(-26.400000) translate(-180.767293, -37.755792) "
                            stroke="#a15f33"
                            id="a"
                            data-index="198"
                        ></polygon>
                        <polygon
                            className=""
                            points="167.135132 38.3934889 175.559484 38.410104 175.576099 46.8125772 167.151747 46.7959621"
                            transform="translate(171.355616, 42.603033) rotate(-28.320000) translate(-171.355616, -42.603033) "
                            stroke="#a15f33"
                            id="a"
                            data-index="196"
                        ></polygon>
                        <polygon
                            className=""
                            points="157.892131 43.5509342 166.315345 43.5682446 166.332656 51.9718551 157.909442 51.9545447"
                            transform="translate(162.112394, 47.761395) rotate(-30.240000) translate(-162.112394, -47.761395) "
                            stroke="#a15f33"
                            id="a"
                            data-index="186"
                        ></polygon>
                        <polygon
                            className=""
                            points="148.828026 49.0137247 157.250059 49.0316527 157.267987 57.4364445 148.845954 57.4185165"
                            transform="translate(153.048006, 53.225085) rotate(-32.160000) translate(-153.048006, -53.225085) "
                            stroke="#a15f33"
                            id="a"
                            data-index="182"
                        ></polygon>
                        <polygon
                            className=""
                            points="139.952992 54.7757297 148.373805 54.7941947 148.39227 63.2002065 139.971457 63.1817415"
                            transform="translate(144.172631, 58.987968) rotate(-34.080000) translate(-144.172631, -58.987968) "
                            stroke="#a15f33"
                            id="a"
                            data-index="172"
                        ></polygon>
                        <polygon
                            className=""
                            points="131.276995 60.8304823 139.696554 60.8494015 139.715474 69.2566665 131.295914 69.2377473"
                            transform="translate(135.496234, 65.043574) rotate(-36.000000) translate(-135.496234, -65.043574) "
                            stroke="#a15f33"
                            id="a"
                            data-index="166"
                        ></polygon>
                        <polygon
                            className=""
                            points="122.809774 67.1711868 131.228052 67.1904752 131.247341 75.5990211 122.829062 75.5797327"
                            transform="translate(127.028557, 71.385104) rotate(-37.920000) translate(-127.028557, -71.385104) "
                            stroke="#a15f33"
                            id="a"
                            data-index="164"
                        ></polygon>
                        <polygon
                            className=""
                            points="114.560835 73.7907266 122.977811 73.8102976 122.997382 82.2201461 114.580406 82.2005751"
                            transform="translate(118.779108, 78.005436) rotate(-39.840000) translate(-118.779108, -78.005436) "
                            stroke="#a15f33"
                            id="a"
                            data-index="157"
                        ></polygon>
                        <polygon
                            className=""
                            points="106.539439 80.6816715 114.955096 80.7014373 114.974862 89.1126045 106.559204 89.0928387"
                            transform="translate(110.757150, 84.897138) rotate(-41.760000) translate(-110.757150, -84.897138) "
                            stroke="#a15f33"
                            id="a"
                            data-index="153"
                        ></polygon>
                        <polygon
                            className=""
                            points="98.7545897 87.8362868 107.168918 87.8561585 107.18879 96.2686545 98.7744614 96.2487828"
                            transform="translate(102.971690, 92.052471) rotate(-43.680000) translate(-102.971690, -92.052471) "
                            stroke="#a15f33"
                            id="a"
                            data-index="145"
                        ></polygon>
                        <polygon
                            className=""
                            points="91.2150274 95.2465414 99.6280231 95.2664298 99.6479116 103.680259 91.2349159 103.66037"
                            transform="translate(95.431469, 99.463400) rotate(-45.600000) translate(-95.431469, -99.463400) "
                            stroke="#a15f33"
                            id="a"
                            data-index="135"
                        ></polygon>
                        <polygon
                            className=""
                            points="73.4940881 114.83533 81.9037729 114.85487 81.9233133 123.27201 73.5136286 123.25247"
                            transform="translate(77.708701, 119.053670) rotate(-50.400000) translate(-77.708701, -119.053670) "
                            stroke="#a15f33"
                            id="a"
                            data-index="125"
                        ></polygon>
                        <polygon
                            className=""
                            points="66.8777854 123.073016 75.2861699 123.092263 75.3054168 131.510703 66.8970324 131.491456"
                            transform="translate(71.091601, 127.291860) rotate(-52.320000) translate(-71.091601, -127.291860) "
                            stroke="#a15f33"
                            id="a"
                            data-index="115"
                        ></polygon>
                        <polygon
                            className=""
                            points="60.5425506 131.526786 68.9496574 131.545653 68.9685244 139.965371 60.5614177 139.946504"
                            transform="translate(64.755538, 135.746078) rotate(-54.240000) translate(-64.755538, -135.746078) "
                            stroke="#a15f33"
                            id="a"
                            data-index="113"
                        ></polygon>
                        <polygon
                            className=""
                            points="54.4954944 140.187148 62.9013517 140.20555 62.9197542 148.626517 54.5138968 148.608115"
                            transform="translate(58.707624, 144.406833) rotate(-56.160000) translate(-58.707624, -144.406833) "
                            stroke="#a15f33"
                            id="a"
                            data-index="106"
                        ></polygon>
                        <polygon
                            className=""
                            points="48.7434037 149.044379 57.1480456 149.062235 57.1659007 157.484417 48.7612588 157.466562"
                            transform="translate(52.954652, 153.264398) rotate(-58.080000) translate(-52.954652, -153.264398) "
                            stroke="#a15f33"
                            id="a"
                            data-index="102"
                        ></polygon>
                        <polygon
                            className=""
                            points="43.2927342 158.088537 51.6962 158.105764 51.7134277 166.529123 43.3099619 166.511895"
                            transform="translate(47.503081, 162.308830) rotate(-60.000000) translate(-47.503081, -162.308830) "
                            stroke="#a15f33"
                            id="a"
                            data-index="95"
                        ></polygon>
                        <polygon
                            className=""
                            points="38.1496031 167.309465 46.5519375 167.325988 46.5684604 175.750478 38.166126 175.733955"
                            transform="translate(42.359032, 171.529972) rotate(-61.920000) translate(-42.359032, -171.529972) "
                            stroke="#a15f33"
                            id="a"
                            data-index="85"
                        ></polygon>
                        <polygon
                            className=""
                            points="33.3197822 176.696812 41.721035 176.712556 41.7367789 185.138128 33.3355261 185.122384"
                            transform="translate(37.528281, 180.917470) rotate(-63.840000) translate(-37.528281, -180.917470) "
                            stroke="#a15f33"
                            id="a"
                            data-index="83"
                        ></polygon>
                        <polygon
                            className=""
                            points="28.8086915 186.240037 37.2089172 186.254932 37.2238114 194.681531 28.8235858 194.666636"
                            transform="translate(33.016251, 190.460784) rotate(-65.760000) translate(-33.016251, -190.460784) "
                            stroke="#a15f33"
                            id="a"
                            data-index="79"
                        ></polygon>
                        <polygon
                            className=""
                            points="24.621393 195.928426 33.0206508 195.942404 33.0346285 204.369971 24.6353707 204.355993"
                            transform="translate(28.828011, 200.149198) rotate(-67.680000) translate(-28.828011, -200.149198) "
                            stroke="#a15f33"
                            id="a"
                            data-index="72"
                        ></polygon>
                        <polygon
                            className=""
                            points="20.7625852 205.7511 29.1609387 205.764098 29.1739371 214.192569 20.7755836 214.179571"
                            transform="translate(24.968261, 209.971835) rotate(-69.600000) translate(-24.968261, -209.971835) "
                            stroke="#a15f33"
                            id="a"
                            data-index="62"
                        ></polygon>
                        <polygon
                            className=""
                            points="12.5802052 230.822562 20.9766018 230.832867 20.9869068 239.263295 12.5905102 239.25299"
                            transform="translate(16.783556, 235.042929) rotate(-74.400000) translate(-16.783556, -235.042929) "
                            stroke="#a15f33"
                            id="a"
                            data-index="52"
                        ></polygon>
                        <polygon
                            className=""
                            points="9.90274766 241.027498 18.2984924 241.036641 18.3076347 249.46772 9.91189001 249.458578"
                            transform="translate(14.105191, 245.247609) rotate(-76.320000) translate(-14.105191, -245.247609) "
                            stroke="#a15f33"
                            id="a"
                            data-index="43"
                        ></polygon>
                        <polygon
                            className=""
                            points="7.57029343 251.316078 15.9654655 251.324016 15.9734042 259.755669 7.57823205 259.74773"
                            transform="translate(11.771849, 255.535873) rotate(-78.240000) translate(-11.771849, -255.535873) "
                            stroke="#a15f33"
                            id="a"
                            data-index="42"
                        ></polygon>
                        <polygon
                            className=""
                            points="5.58545847 261.676748 13.9801399 261.683447 13.9868391 270.11559 5.59215771 270.108891"
                            transform="translate(9.786149, 265.896169) rotate(-80.160000) translate(-9.786149, -265.896169) "
                            stroke="#a15f33"
                            id="a"
                            data-index="38"
                        ></polygon>
                        <polygon
                            className=""
                            points="1.18653552 302.947929 9.58011791 302.94951 9.58169945 311.382752 1.18811706 311.381171"
                            transform="translate(5.384117, 307.165340) rotate(-87.720000) translate(-5.384117, -307.165340) "
                            stroke="#a15f33"
                            id="a"
                            data-index="26"
                        ></polygon>
                        <polygon
                            className=""
                            points="2.24069866 288.25927 10.634281 288.260851 10.6358626 296.694093 2.2422802 296.692512"
                            transform="translate(6.438281, 292.476681) rotate(-87.720000) translate(-6.438281, -292.476681) "
                            stroke="#a15f33"
                            id="a"
                            data-index="29"
                        ></polygon>
                        <polygon
                            className=""
                            points="0.948260018 318.107705 9.34178223 318.107372 9.34144894 326.540675 0.947926726 326.541008"
                            transform="translate(5.144854, 322.324190) rotate(-90.480000) translate(-5.144854, -322.324190) "
                            stroke="#a15f33"
                            id="a"
                            data-index="17"
                        ></polygon>
                        <polygon
                            className=""
                            points="1.44356411 333.261456 9.83721062 333.259211 9.83496558 341.692389 1.44131907 341.694634"
                            transform="translate(5.639265, 337.476922) rotate(-93.240000) translate(-5.639265, -337.476922) "
                            stroke="#a15f33"
                            id="a"
                            data-index="8"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.399358 158.665538 338.832385 158.662221 338.829067 167.056019 330.396041 167.059336"
                            transform="translate(334.614213, 162.860778) rotate(4.800000) translate(-334.614213, -162.860778) "
                            stroke="#a15f33"
                            id="a"
                            data-index="272"
                        ></polygon>
                        <polygon
                            className=""
                            points="343.540089 160.31871 351.972288 160.312168 351.965746 168.706794 343.533547 168.713336"
                            transform="translate(347.752918, 164.512752) rotate(9.600000) translate(-347.752918, -164.512752) "
                            stroke="#a15f33"
                            id="a"
                            data-index="282"
                        ></polygon>
                        <polygon
                            className=""
                            points="356.496024 163.059966 364.926869 163.050383 364.917285 171.446363 356.486441 171.455946"
                            transform="translate(360.706655, 167.253164) rotate(14.400000) translate(-360.706655, -167.253164) "
                            stroke="#a15f33"
                            id="a"
                            data-index="325"
                        ></polygon>
                        <polygon
                            className=""
                            points="369.176239 166.87006 377.605242 166.857703 377.592885 175.255526 369.163883 175.267882"
                            transform="translate(373.384562, 171.062793) rotate(19.200000) translate(-373.384562, -171.062793) "
                            stroke="#a15f33"
                            id="a"
                            data-index="335"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.390863 142.876601 338.823938 142.873585 338.820923 151.267334 330.387847 151.27035"
                            transform="translate(334.605893, 147.071968) rotate(4.360000) translate(-334.605893, -147.071968) "
                            stroke="#a15f33"
                            id="a"
                            data-index="273"
                        ></polygon>
                        <polygon
                            className=""
                            points="345.727957 144.726224 354.16019 144.71978 354.153746 153.114372 345.721514 153.120816"
                            transform="translate(349.940852, 148.920298) rotate(9.450000) translate(-349.940852, -148.920298) "
                            stroke="#a15f33"
                            id="a"
                            data-index="283"
                        ></polygon>
                        <polygon
                            className=""
                            points="360.840012 147.922267 369.270809 147.912598 369.261141 156.308625 360.830343 156.318294"
                            transform="translate(365.050576, 152.115446) rotate(14.540000) translate(-365.050576, -152.115446) "
                            stroke="#a15f33"
                            id="a"
                            data-index="326"
                        ></polygon>
                        <polygon
                            className=""
                            points="375.607785 152.439501 384.0366 152.426912 384.024011 160.824922 375.595196 160.837511"
                            transform="translate(379.815898, 156.632211) rotate(19.630000) translate(-379.815898, -156.632211) "
                            stroke="#a15f33"
                            id="a"
                            data-index="336"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.403773 127.097699 338.836885 127.09493 338.834116 135.488643 330.401004 135.491412"
                            transform="translate(334.618944, 131.293171) rotate(4.000000) translate(-334.618944, -131.293171) "
                            stroke="#a15f33"
                            id="a"
                            data-index="274"
                        ></polygon>
                        <polygon
                            className=""
                            points="343.57718 128.476644 352.009714 128.471161 352.004231 136.865451 343.571697 136.870935"
                            transform="translate(347.790705, 132.671048) rotate(8.000000) translate(-347.790705, -132.671048) "
                            stroke="#a15f33"
                            id="a"
                            data-index="284"
                        ></polygon>
                        <polygon
                            className=""
                            points="356.622062 130.766475 365.053647 130.758384 365.045556 139.153623 356.613971 139.161714"
                            transform="translate(360.833809, 134.960049) rotate(12.000000) translate(-360.833809, -134.960049) "
                            stroke="#a15f33"
                            id="a"
                            data-index="292"
                        ></polygon>
                        <polygon
                            className=""
                            points="369.474841 133.956023 377.905123 133.945481 377.894581 142.342023 369.464299 142.352565"
                            transform="translate(373.684711, 138.149023) rotate(16.000000) translate(-373.684711, -138.149023) "
                            stroke="#a15f33"
                            id="a"
                            data-index="327"
                        ></polygon>
                        <polygon
                            className=""
                            points="382.072871 138.02974 390.501522 138.016953 390.488735 146.415126 382.060084 146.427913"
                            transform="translate(386.280803, 142.222433) rotate(20.000000) translate(-386.280803, -142.222433) "
                            stroke="#a15f33"
                            id="a"
                            data-index="337"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.396981 111.323865 338.830121 111.32131 338.827566 119.714994 330.394426 119.717549"
                            transform="translate(334.612273, 115.519430) rotate(3.690000) translate(-334.612273, -115.519430) "
                            stroke="#a15f33"
                            id="a"
                            data-index="275"
                        ></polygon>
                        <polygon
                            className=""
                            points="342.256044 112.429989 350.688756 112.42517 350.683937 120.819282 342.251225 120.824101"
                            transform="translate(346.469990, 116.624636) rotate(7.010000) translate(-346.469990, -116.624636) "
                            stroke="#a15f33"
                            id="a"
                            data-index="285"
                        ></polygon>
                        <polygon
                            className=""
                            points="354.030994 114.217568 362.46302 114.210549 362.456001 122.605348 354.023975 122.612366"
                            transform="translate(358.243498, 118.411458) rotate(10.330000) translate(-358.243498, -118.411458) "
                            stroke="#a15f33"
                            id="a"
                            data-index="293"
                        ></polygon>
                        <polygon
                            className=""
                            points="365.71716 116.689023 374.148246 116.679893 374.139116 125.075631 365.70803 125.084761"
                            transform="translate(369.928138, 120.882327) rotate(13.660000) translate(-369.928138, -120.882327) "
                            stroke="#a15f33"
                            id="a"
                            data-index="306"
                        ></polygon>
                        <polygon
                            className=""
                            points="377.205133 119.821214 385.635044 119.810101 385.623932 128.207014 377.19402 128.218126"
                            transform="translate(381.414532, 124.014114) rotate(16.980000) translate(-381.414532, -124.014114) "
                            stroke="#a15f33"
                            id="a"
                            data-index="328"
                        ></polygon>
                        <polygon
                            className=""
                            points="388.491634 123.610031 396.92015 123.597085 396.907204 131.995394 388.478688 132.008339"
                            transform="translate(392.699419, 127.802712) rotate(20.300000) translate(-392.699419, -127.802712) "
                            stroke="#a15f33"
                            id="a"
                            data-index="338"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.407335 79.7919575 338.840516 79.78974 338.838299 88.1833834 330.405118 88.1856009"
                            transform="translate(334.622817, 83.987670) rotate(3.200000) translate(-334.622817, -83.987670) "
                            stroke="#a15f33"
                            id="a"
                            data-index="276"
                        ></polygon>
                        <polygon
                            className=""
                            points="342.496293 80.7745064 350.929145 80.7702822 350.924921 89.1642553 342.492069 89.1684795"
                            transform="translate(346.710607, 84.969381) rotate(6.130000) translate(-346.710607, -84.969381) "
                            stroke="#a15f33"
                            id="a"
                            data-index="286"
                        ></polygon>
                        <polygon
                            className=""
                            points="354.51911 82.3706111 362.951429 82.3644243 362.945242 90.7589302 354.512924 90.7651171"
                            transform="translate(358.732176, 86.564771) rotate(9.060000) translate(-358.732176, -86.564771) "
                            stroke="#a15f33"
                            id="a"
                            data-index="294"
                        ></polygon>
                        <polygon
                            className=""
                            points="366.48484 84.5846575 374.916425 84.5765664 374.908334 92.9718056 366.476749 92.9798968"
                            transform="translate(370.696587, 88.778232) rotate(12.000000) translate(-370.696587, -88.778232) "
                            stroke="#a15f33"
                            id="a"
                            data-index="307"
                        ></polygon>
                        <polygon
                            className=""
                            points="378.280805 87.3957941 386.711469 87.3858898 386.701565 95.7820501 378.2709 95.7919544"
                            transform="translate(382.491185, 91.588922) rotate(14.930000) translate(-382.491185, -91.588922) "
                            stroke="#a15f33"
                            id="a"
                            data-index="313"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.408092 64.0310526 338.841288 64.0289732 338.839209 72.4226016 330.406013 72.424681"
                            transform="translate(334.623651, 68.226827) rotate(3.000000) translate(-334.623651, -68.226827) "
                            stroke="#a15f33"
                            id="a"
                            data-index="277"
                        ></polygon>
                        <polygon
                            className=""
                            points="343.613943 65.0662445 352.046814 65.0621086 352.042678 73.4560627 343.609807 73.4601986"
                            transform="translate(347.828311, 69.261154) rotate(6.000000) translate(-347.828311, -69.261154) "
                            stroke="#a15f33"
                            id="a"
                            data-index="287"
                        ></polygon>
                        <polygon
                            className=""
                            points="356.747393 66.7877079 365.179724 66.7815607 365.173577 75.1760538 356.741246 75.182201"
                            transform="translate(360.960485, 70.981881) rotate(9.000000) translate(-360.960485, -70.981881) "
                            stroke="#a15f33"
                            id="a"
                            data-index="295"
                        ></polygon>
                        <polygon
                            className=""
                            points="369.772433 69.1907184 378.204018 69.1826272 378.195927 77.5778665 369.764341 77.5859576"
                            transform="translate(373.984180, 73.384292) rotate(12.000000) translate(-373.984180, -73.384292) "
                            stroke="#a15f33"
                            id="a"
                            data-index="308"
                        ></polygon>
                        <polygon
                            className=""
                            points="382.65335 72.2686844 391.08399 72.258738 391.074044 80.6549225 382.643404 80.6648689"
                            transform="translate(386.863697, 76.461803) rotate(15.000000) translate(-386.863697, -76.461803) "
                            stroke="#a15f33"
                            id="a"
                            data-index="314"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.392176 48.2720455 338.825385 48.2700905 338.82343 56.6637062 330.390221 56.6656612"
                            transform="translate(334.607803, 52.467876) rotate(2.820000) translate(-334.607803, -52.467876) "
                            stroke="#a15f33"
                            id="a"
                            data-index="278"
                        ></polygon>
                        <polygon
                            className=""
                            points="341.110516 49.0120766 349.543506 49.008547 349.539976 57.402382 341.106987 57.4059116"
                            transform="translate(345.325246, 53.207229) rotate(5.110000) translate(-345.325246, -53.207229) "
                            stroke="#a15f33"
                            id="a"
                            data-index="288"
                        ></polygon>
                        <polygon
                            className=""
                            points="351.837196 50.1836849 360.269839 50.1785966 360.264751 58.5727778 351.832108 58.577866"
                            transform="translate(356.050973, 54.378231) rotate(7.410000) translate(-356.050973, -54.378231) "
                            stroke="#a15f33"
                            id="a"
                            data-index="296"
                        ></polygon>
                        <polygon
                            className=""
                            points="362.461814 51.7748097 370.893989 51.768202 370.887382 60.1628509 362.455206 60.1694586"
                            transform="translate(366.674598, 55.968830) rotate(9.700000) translate(-366.674598, -55.968830) "
                            stroke="#a15f33"
                            id="a"
                            data-index="302"
                        ></polygon>
                        <polygon
                            className=""
                            points="373.060025 53.7967792 381.49161 53.7886881 381.483519 62.1839273 373.051934 62.1920184"
                            transform="translate(377.271772, 57.990353) rotate(12.000000) translate(-377.271772, -57.990353) "
                            stroke="#a15f33"
                            id="a"
                            data-index="309"
                        ></polygon>
                        <polygon
                            className=""
                            points="383.522752 56.2287817 391.953633 56.2192653 391.944116 64.6152087 383.513235 64.6247251"
                            transform="translate(387.733434, 60.421995) rotate(14.290000) translate(-387.733434, -60.421995) "
                            stroke="#a15f33"
                            id="a"
                            data-index="315"
                        ></polygon>
                        <polygon
                            className=""
                            points="393.879526 59.0748049 402.309591 59.0639239 402.29871 67.460683 393.868645 67.4715639"
                            transform="translate(398.089118, 63.267744) rotate(16.580000) translate(-398.089118, -63.267744) "
                            stroke="#a15f33"
                            id="a"
                            data-index="319"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.376151 32.5153886 338.809371 32.5135441 338.807526 40.9071493 330.374307 40.9089937"
                            transform="translate(334.591839, 36.711269) rotate(2.660000) translate(-334.591839, -36.711269) "
                            stroke="#a15f33"
                            id="a"
                            data-index="279"
                        ></polygon>
                        <polygon
                            className=""
                            points="341.974544 33.2888256 350.407547 33.2853712 350.404092 41.6791929 341.97109 41.6826472"
                            transform="translate(346.189318, 37.484009) rotate(5.000000) translate(-346.189318, -37.484009) "
                            stroke="#a15f33"
                            id="a"
                            data-index="289"
                        ></polygon>
                        <polygon
                            className=""
                            points="353.482345 34.5265103 361.915003 34.5214758 361.909968 42.9156429 353.477311 42.9206774"
                            transform="translate(357.696157, 38.721077) rotate(7.330000) translate(-357.696157, -38.721077) "
                            stroke="#a15f33"
                            id="a"
                            data-index="297"
                        ></polygon>
                        <polygon
                            className=""
                            points="364.930149 36.2286952 373.362334 36.2221138 373.355753 44.6167535 364.923568 44.6233349"
                            transform="translate(369.142951, 40.422724) rotate(9.660000) translate(-369.142951, -40.422724) "
                            stroke="#a15f33"
                            id="a"
                            data-index="303"
                        ></polygon>
                        <polygon
                            className=""
                            points="376.347618 38.40284 384.779203 38.3947489 384.771112 46.7899881 376.339527 46.7980793"
                            transform="translate(380.559365, 42.596414) rotate(12.000000) translate(-380.559365, -42.596414) "
                            stroke="#a15f33"
                            id="a"
                            data-index="310"
                        ></polygon>
                        <polygon
                            className=""
                            points="387.618295 41.0267677 396.049162 41.0172269 396.039622 49.4131836 387.608754 49.4227244"
                            transform="translate(391.828958, 45.219976) rotate(14.330000) translate(-391.828958, -45.219976) "
                            stroke="#a15f33"
                            id="a"
                            data-index="316"
                        ></polygon>
                        <polygon
                            className=""
                            points="398.772514 44.1044406 407.202549 44.0935132 407.191622 52.4903027 398.761587 52.5012301"
                            transform="translate(402.982068, 48.297372) rotate(16.660000) translate(-402.982068, -48.297372) "
                            stroke="#a15f33"
                            id="a"
                            data-index="320"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.376585 16.7614362 338.809813 16.7596886 338.808066 25.1532849 330.374837 25.1550325"
                            transform="translate(334.592325, 20.957361) rotate(2.520000) translate(-334.592325, -20.957361) "
                            stroke="#a15f33"
                            id="a"
                            data-index="280"
                        ></polygon>
                        <polygon
                            className=""
                            points="340.32145 17.3621495 348.754518 17.3590925 348.751461 25.7528482 340.318392 25.7559053"
                            transform="translate(344.536455, 21.557499) rotate(4.420000) translate(-344.536455, -21.557499) "
                            stroke="#a15f33"
                            id="a"
                            data-index="290"
                        ></polygon>
                        <polygon
                            className=""
                            points="350.188769 18.2848839 358.621594 18.2805376 358.617248 26.6745377 350.184423 26.6788839"
                            transform="translate(354.403009, 22.479711) rotate(6.310000) translate(-354.403009, -22.479711) "
                            stroke="#a15f33"
                            id="a"
                            data-index="298"
                        ></polygon>
                        <polygon
                            className=""
                            points="360.072099 19.5383864 368.504593 19.5327632 368.498969 27.9270939 360.066476 27.9327172"
                            transform="translate(364.285534, 23.732740) rotate(8.210000) translate(-364.285534, -23.732740) "
                            stroke="#a15f33"
                            id="a"
                            data-index="300"
                        ></polygon>
                        <polygon
                            className=""
                            points="369.856656 21.1080982 378.288738 21.1012292 378.281869 29.4959722 369.849787 29.5028411"
                            transform="translate(374.069262, 25.302035) rotate(10.100000) translate(-374.069262, -25.302035) "
                            stroke="#a15f33"
                            id="a"
                            data-index="304"
                        ></polygon>
                        <polygon
                            className=""
                            points="379.63521 23.0089009 388.066796 23.0008097 388.058704 31.396049 379.627119 31.4041401"
                            transform="translate(383.846957, 27.202475) rotate(12.000000) translate(-383.846957, -27.202475) "
                            stroke="#a15f33"
                            id="a"
                            data-index="311"
                        ></polygon>
                        <polygon
                            className=""
                            points="389.294197 25.2187187 397.725209 25.209447 397.715937 33.6052592 389.284925 33.6145309"
                            transform="translate(393.505067, 29.411989) rotate(13.890000) translate(-393.505067, -29.411989) "
                            stroke="#a15f33"
                            id="a"
                            data-index="317"
                        ></polygon>
                        <polygon
                            className=""
                            points="398.87473 27.7443049 407.305093 27.7338931 407.294681 36.1303548 398.864319 36.1407666"
                            transform="translate(403.084706, 31.937330) rotate(15.780000) translate(-403.084706, -31.937330) "
                            stroke="#a15f33"
                            id="a"
                            data-index="321"
                        ></polygon>
                        <polygon
                            className=""
                            points="408.41635 30.598757 416.845985 30.5872448 416.834473 38.9844338 408.404838 38.995946"
                            transform="translate(412.625412, 34.791595) rotate(17.680000) translate(-412.625412, -34.791595) "
                            stroke="#a15f33"
                            id="a"
                            data-index="323"
                        ></polygon>
                        <polygon
                            className=""
                            points="330.410044 1.01047366 338.843279 1.00880907 338.841614 9.40239826 330.408379 9.40406285"
                            transform="translate(334.625829, 5.206436) rotate(2.400000) translate(-334.625829, -5.206436) "
                            stroke="#a15f33"
                            id="a"
                            data-index="281"
                        ></polygon>
                        <polygon
                            className=""
                            points="340.989675 1.6292182 349.422754 1.62622979 349.419766 10.019975 340.986687 10.0229634"
                            transform="translate(345.204720, 5.824597) rotate(4.320000) translate(-345.204720, -5.824597) "
                            stroke="#a15f33"
                            id="a"
                            data-index="291"
                        ></polygon>
                        <polygon
                            className=""
                            points="351.542595 2.60032843 359.97543 2.59602961 359.971132 10.9900191 351.538297 10.9943179"
                            transform="translate(355.756863, 6.795174) rotate(6.240000) translate(-355.756863, -6.795174) "
                            stroke="#a15f33"
                            id="a"
                            data-index="299"
                        ></polygon>
                        <polygon
                            className=""
                            points="362.056953 3.92271214 370.489457 3.91712222 370.483867 12.3114432 362.051363 12.3170331"
                            transform="translate(366.270410, 8.117078) rotate(8.160000) translate(-366.270410, -8.117078) "
                            stroke="#a15f33"
                            id="a"
                            data-index="301"
                        ></polygon>
                        <polygon
                            className=""
                            points="372.52094 5.59488291 380.953026 5.58802698 380.94617 13.9827652 372.514084 13.9896211"
                            transform="translate(376.733555, 9.788824) rotate(10.080000) translate(-376.733555, -9.788824) "
                            stroke="#a15f33"
                            id="a"
                            data-index="305"
                        ></polygon>
                        <polygon
                            className=""
                            points="382.922803 7.61496172 391.354388 7.60687058 391.346297 16.0021098 382.914712 16.010201"
                            transform="translate(387.134550, 11.808536) rotate(12.000000) translate(-387.134550, -11.808536) "
                            stroke="#a15f33"
                            id="a"
                            data-index="312"
                        ></polygon>
                        <polygon
                            className=""
                            points="393.25086 9.98067914 401.681863 9.9713891 401.672573 18.367211 393.24157 18.3765011"
                            transform="translate(397.461716, 14.173945) rotate(13.920000) translate(-397.461716, -14.173945) "
                            stroke="#a15f33"
                            id="a"
                            data-index="318"
                        ></polygon>
                        <polygon
                            className=""
                            points="403.493512 12.6893778 411.923853 12.6789306 411.913405 21.0754141 403.483064 21.0858614"
                            transform="translate(407.703459, 16.882396) rotate(15.840000) translate(-407.703459, -16.882396) "
                            stroke="#a15f33"
                            id="a"
                            data-index="322"
                        ></polygon>
                        <polygon
                            className=""
                            points="413.639254 15.7380154 422.068857 15.7264579 422.057299 24.1236792 413.627696 24.1352367"
                            transform="translate(417.848277, 19.930847) rotate(17.760000) translate(-417.848277, -19.930847) "
                            stroke="#a15f33"
                            id="a"
                            data-index="324"
                        ></polygon>
                        <polygon
                            className=""
                            points="395.316591 177.582519 403.740663 177.565723 403.723867 185.968476 395.299795 185.985272"
                            transform="translate(399.520229, 181.775498) rotate(28.800000) translate(-399.520229, -181.775498) "
                            stroke="#a15f33"
                            id="a"
                            data-index="345"
                        ></polygon>
                        <polygon
                            className=""
                            points="406.646539 184.40975 415.06766 184.391412 415.049321 192.797115 406.6282 192.815453"
                            transform="translate(410.847930, 188.603432) rotate(33.600000) translate(-410.847930, -188.603432) "
                            stroke="#1372a1"
                            id="a"
                            data-index="355"
                        ></polygon>
                        <polygon
                            className=""
                            points="417.362554 192.156075 425.780509 192.136708 425.761142 200.545578 417.343187 200.564945"
                            transform="translate(421.561848, 196.350827) rotate(38.400000) translate(-421.561848, -196.350827) "
                            stroke="#1372a1"
                            id="a"
                            data-index="396"
                        ></polygon>
                        <polygon
                            className=""
                            points="427.389429 200.767183 435.80409 200.747329 435.784237 209.159493 427.369575 209.179346"
                            transform="translate(431.586833, 204.963338) rotate(43.200000) translate(-431.586833, -204.963338) "
                            stroke="#1372a1"
                            id="a"
                            data-index="408"
                        ></polygon>
                        <polygon
                            className=""
                            points="401.761108 163.1554 410.185436 163.13877 410.168805 171.541266 401.744477 171.557897"
                            transform="translate(405.964956, 167.348333) rotate(28.360000) translate(-405.964956, -167.348333) "
                            stroke="#a15f33"
                            id="a"
                            data-index="346"
                        ></polygon>
                        <polygon
                            className=""
                            points="415.017332 171.051077 423.438549 171.032779 423.420251 179.438386 414.999034 179.456684"
                            transform="translate(419.218791, 175.244732) rotate(33.450000) translate(-419.218791, -175.244732) "
                            stroke="#1372a1"
                            id="a"
                            data-index="356"
                        ></polygon>
                        <polygon
                            className=""
                            points="427.517232 180.085542 435.935092 180.066153 435.915703 188.475117 427.497843 188.494506"
                            transform="translate(431.716468, 184.280330) rotate(38.540000) translate(-431.716468, -184.280330) "
                            stroke="#1372a1"
                            id="a"
                            data-index="397"
                        ></polygon>
                        <polygon
                            className=""
                            points="439.162172 190.187569 447.576535 190.167699 447.556665 198.58016 439.142302 198.600031"
                            transform="translate(443.359418, 194.383865) rotate(43.630000) translate(-443.359418, -194.383865) "
                            stroke="#1372a1"
                            id="a"
                            data-index="409"
                        ></polygon>
                        <polygon
                            className=""
                            points="408.221093 148.746071 416.645629 148.729579 416.629137 157.131867 408.204601 157.148359"
                            transform="translate(412.425115, 152.938969) rotate(28.000000) translate(-412.425115, -152.938969) "
                            stroke="#a15f33"
                            id="a"
                            data-index="347"
                        ></polygon>
                        <polygon
                            className=""
                            points="419.692901 155.336479 428.115034 155.3186 428.097155 163.723291 419.675022 163.741171"
                            transform="translate(423.895028, 159.529885) rotate(32.000000) translate(-423.895028, -159.529885) "
                            stroke="#1372a1"
                            id="a"
                            data-index="357"
                        ></polygon>
                        <polygon
                            className=""
                            points="430.674742 162.706899 439.094302 162.68798 439.075383 171.095245 430.655823 171.114164"
                            transform="translate(434.875062, 166.901072) rotate(36.000000) translate(-434.875062, -166.901072) "
                            stroke="#1372a1"
                            id="a"
                            data-index="378"
                        ></polygon>
                        <polygon
                            className=""
                            points="441.113087 170.821435 449.529953 170.801844 449.510363 179.211802 441.093496 179.231393"
                            transform="translate(445.311725, 175.016618) rotate(40.000000) translate(-445.311725, -175.016618) "
                            stroke="#1372a1"
                            id="a"
                            data-index="398"
                        ></polygon>
                        <polygon
                            className=""
                            points="450.957056 179.640567 459.371162 179.620686 459.351282 188.033404 450.937175 188.053285"
                            transform="translate(455.154169, 183.836986) rotate(44.000000) translate(-455.154169, -183.836986) "
                            stroke="#1372a1"
                            id="a"
                            data-index="410"
                        ></polygon>
                        <polygon
                            className=""
                            points="414.661019 134.333369 423.085733 134.316998 423.069362 142.719109 414.644648 142.735479"
                            transform="translate(418.865190, 138.526239) rotate(27.690000) translate(-418.865190, -138.526239) "
                            stroke="#a15f33"
                            id="a"
                            data-index="348"
                        ></polygon>
                        <polygon
                            className=""
                            points="425.043506 140.142854 433.466252 140.125286 433.448684 148.529365 425.025939 148.546933"
                            transform="translate(429.246095, 144.336109) rotate(31.010000) translate(-429.246095, -144.336109) "
                            stroke="#1372a1"
                            id="a"
                            data-index="358"
                        ></polygon>
                        <polygon
                            className=""
                            points="435.070457 146.540755 443.491109 146.522226 443.47258 154.9284 435.051928 154.946928"
                            transform="translate(439.271518, 150.734577) rotate(34.330000) translate(-439.271518, -150.734577) "
                            stroke="#1372a1"
                            id="a"
                            data-index="365"
                        ></polygon>
                        <polygon
                            className=""
                            points="444.736607 153.527415 453.155061 153.508172 453.135817 161.916543 444.717364 161.935786"
                            transform="translate(448.936212, 157.721979) rotate(37.660000) translate(-448.936212, -157.721979) "
                            stroke="#1372a1"
                            id="a"
                            data-index="379"
                        ></polygon>
                        <polygon
                            className=""
                            points="453.951456 161.037439 462.367651 161.017742 462.347953 169.428372 453.931759 169.448069"
                            transform="translate(458.149705, 165.232906) rotate(40.980000) translate(-458.149705, -165.232906) "
                            stroke="#1372a1"
                            id="a"
                            data-index="399"
                        ></polygon>
                        <polygon
                            className=""
                            points="462.71369 169.065766 471.127588 169.045879 471.107701 177.458805 462.693803 177.478692"
                            transform="translate(466.910696, 173.262285) rotate(44.300000) translate(-466.910696, -173.262285) "
                            stroke="#1372a1"
                            id="a"
                            data-index="411"
                        ></polygon>
                        <polygon
                            className=""
                            points="391.877524 90.8031611 400.307086 90.7915472 400.295472 99.1888089 391.86591 99.2004228"
                            transform="translate(396.086498, 94.995985) rotate(17.860000) translate(-396.086498, -94.995985) "
                            stroke="#a15f33"
                            id="a"
                            data-index="329"
                        ></polygon>
                        <polygon
                            className=""
                            points="403.362295 94.8124755 411.790583 94.7992682 411.777375 103.197805 403.349087 103.211012"
                            transform="translate(407.569835, 99.005140) rotate(20.800000) translate(-407.569835, -99.005140) "
                            stroke="#a15f33"
                            id="a"
                            data-index="339"
                        ></polygon>
                        <polygon
                            className=""
                            points="427.556327 105.531983 435.981319 105.515808 435.965145 113.91764 427.540152 113.933815"
                            transform="translate(431.760736, 109.724811) rotate(27.200000) translate(-431.760736, -109.724811) "
                            stroke="#a15f33"
                            id="a"
                            data-index="349"
                        ></polygon>
                        <polygon
                            className=""
                            points="438.199287 111.321865 446.622568 111.304592 446.605295 119.708137 438.182015 119.725409"
                            transform="translate(442.402291, 115.515001) rotate(30.130000) translate(-442.402291, -115.515001) "
                            stroke="#1372a1"
                            id="a"
                            data-index="359"
                        ></polygon>
                        <polygon
                            className=""
                            points="448.530924 117.645422 456.95239 117.627233 456.9342 126.032592 448.512734 126.050782"
                            transform="translate(452.732562, 121.839007) rotate(33.060000) translate(-452.732562, -121.839007) "
                            stroke="#1372a1"
                            id="a"
                            data-index="366"
                        ></polygon>
                        <polygon
                            className=""
                            points="458.557712 124.510338 466.977271 124.491418 466.958352 132.898683 458.538793 132.917603"
                            transform="translate(462.758032, 128.704511) rotate(36.000000) translate(-462.758032, -128.704511) "
                            stroke="#1372a1"
                            id="a"
                            data-index="380"
                        ></polygon>
                        <polygon
                            className=""
                            points="468.18523 131.851977 476.602825 131.832529 476.583377 140.241757 468.165782 140.261205"
                            transform="translate(472.384303, 136.046867) rotate(38.930000) translate(-472.384303, -136.046867) "
                            stroke="#1372a1"
                            id="a"
                            data-index="386"
                        ></polygon>
                        <polygon
                            className=""
                            points="477.422993 139.673627 485.838582 139.653854 485.818808 148.06509 477.40322 148.084864"
                            transform="translate(481.620901, 143.869359) rotate(41.860000) translate(-481.620901, -143.869359) "
                            stroke="#1372a1"
                            id="a"
                            data-index="400"
                        ></polygon>
                        <polygon
                            className=""
                            points="486.276222 147.983873 494.689773 147.96398 494.669881 156.377254 486.25633 156.397146"
                            transform="translate(490.473051, 152.180563) rotate(44.800000) translate(-490.473051, -152.180563) "
                            stroke="#1372a1"
                            id="a"
                            data-index="412"
                        ></polygon>
                        <polygon
                            className=""
                            points="397.315315 76.0131658 405.744821 76.001473 405.733129 84.3987917 397.303623 84.4104844"
                            transform="translate(401.524222, 80.205979) rotate(18.000000) translate(-401.524222, -80.205979) "
                            stroke="#a15f33"
                            id="a"
                            data-index="330"
                        ></polygon>
                        <polygon
                            className=""
                            points="409.80253 80.4138966 418.230725 80.4005857 418.217414 88.7992147 409.789219 88.8125256"
                            transform="translate(414.009972, 84.606556) rotate(21.000000) translate(-414.009972, -84.606556) "
                            stroke="#a15f33"
                            id="a"
                            data-index="340"
                        ></polygon>
                        <polygon
                            className=""
                            points="433.99789 91.134089 442.422995 91.1179954 442.406902 99.5197149 433.981797 99.5358086"
                            transform="translate(438.202396, 95.326902) rotate(27.000000) translate(-438.202396, -95.326902) "
                            stroke="#a15f33"
                            id="a"
                            data-index="350"
                        ></polygon>
                        <polygon
                            className=""
                            points="445.639695 97.4241685 454.063054 97.4069408 454.045826 105.810407 445.622468 105.827634"
                            transform="translate(449.842761, 101.617288) rotate(30.000000) translate(-449.842761, -101.617288) "
                            stroke="#1372a1"
                            id="a"
                            data-index="360"
                        ></polygon>
                        <polygon
                            className=""
                            points="456.934734 104.311814 465.356237 104.293641 465.338064 112.698962 456.916561 112.717135"
                            transform="translate(461.136399, 108.505388) rotate(33.000000) translate(-461.136399, -108.505388) "
                            stroke="#1372a1"
                            id="a"
                            data-index="367"
                        ></polygon>
                        <polygon
                            className=""
                            points="467.852035 111.77815 476.271595 111.759231 476.252675 120.166496 467.833116 120.185415"
                            transform="translate(472.052355, 115.972323) rotate(36.000000) translate(-472.052355, -115.972323) "
                            stroke="#1372a1"
                            id="a"
                            data-index="381"
                        ></polygon>
                        <polygon
                            className=""
                            points="478.361665 119.802718 486.779213 119.78326 486.759755 128.192536 478.342207 128.211995"
                            transform="translate(482.560710, 123.997627) rotate(39.000000) translate(-482.560710, -123.997627) "
                            stroke="#1372a1"
                            id="a"
                            data-index="387"
                        ></polygon>
                        <polygon
                            className=""
                            points="488.434807 128.363529 496.850299 128.343745 496.830515 136.755078 488.415023 136.774862"
                            transform="translate(492.632661, 132.559303) rotate(42.000000) translate(-492.632661, -132.559303) "
                            stroke="#1372a1"
                            id="a"
                            data-index="401"
                        ></polygon>
                        <polygon
                            className=""
                            points="498.043841 137.437124 506.457253 137.417231 506.437361 145.830644 498.023948 145.850536"
                            transform="translate(502.240601, 141.633884) rotate(45.000000) translate(-502.240601, -141.633884) "
                            stroke="#1372a1"
                            id="a"
                            data-index="413"
                        ></polygon>
                        <polygon
                            className=""
                            points="406.118686 62.3454082 414.547825 62.3332268 414.535643 70.7309121 406.106504 70.7430936"
                            transform="translate(410.327164, 66.538160) rotate(18.880000) translate(-410.327164, -66.538160) "
                            stroke="#a15f33"
                            id="a"
                            data-index="331"
                        ></polygon>
                        <polygon
                            className=""
                            points="416.213467 66.0069308 424.641583 65.9935324 424.628185 74.3922406 416.200069 74.405639"
                            transform="translate(420.420826, 70.199586) rotate(21.170000) translate(-420.420826, -70.199586) "
                            stroke="#a15f33"
                            id="a"
                            data-index="341"
                        ></polygon>
                        <polygon
                            className=""
                            points="440.423451 76.7311688 448.848657 76.715149 448.832637 85.1167676 440.407431 85.1327875"
                            transform="translate(444.628044, 80.923968) rotate(26.820000) translate(-444.628044, -80.923968) "
                            stroke="#a15f33"
                            id="a"
                            data-index="351"
                        ></polygon>
                        <polygon
                            className=""
                            points="449.913279 81.7450005 458.337168 81.7280901 458.320258 90.1310256 449.896369 90.147936"
                            transform="translate(454.116768, 85.938013) rotate(29.110000) translate(-454.116768, -85.938013) "
                            stroke="#1372a1"
                            id="a"
                            data-index="361"
                        ></polygon>
                        <polygon
                            className=""
                            points="459.234259 87.1564271 467.656758 87.1387309 467.639062 95.5430563 459.216563 95.5607525"
                            transform="translate(463.436660, 91.349742) rotate(31.410000) translate(-463.436660, -91.349742) "
                            stroke="#1372a1"
                            id="a"
                            data-index="368"
                        ></polygon>
                        <polygon
                            className=""
                            points="468.290457 92.9097571 476.711514 92.8913918 476.693148 101.297159 468.272091 101.315525"
                            transform="translate(472.491803, 97.103458) rotate(33.700000) translate(-472.491803, -97.103458) "
                            stroke="#1372a1"
                            id="a"
                            data-index="372"
                        ></polygon>
                        <polygon
                            className=""
                            points="477.146358 99.0459632 485.565918 99.0270439 485.546998 107.434309 477.127439 107.453228"
                            transform="translate(481.346678, 103.240136) rotate(36.000000) translate(-481.346678, -103.240136) "
                            stroke="#1372a1"
                            id="a"
                            data-index="382"
                        ></polygon>
                        <polygon
                            className=""
                            points="485.710816 105.501895 494.128845 105.482546 494.109496 113.891341 485.691467 113.910691"
                            transform="translate(489.910156, 109.696618) rotate(38.290000) translate(-489.910156, -109.696618) "
                            stroke="#1372a1"
                            id="a"
                            data-index="388"
                        ></polygon>
                        <polygon
                            className=""
                            points="494.009181 112.293155 502.42565 112.273498 502.405994 120.683854 493.989525 120.70351"
                            transform="translate(498.207587, 116.488504) rotate(40.580000) translate(-498.207587, -116.488504) "
                            stroke="#1372a1"
                            id="a"
                            data-index="392"
                        ></polygon>
                        <polygon
                            className=""
                            points="502.06258 119.440666 510.477463 119.420827 510.457625 127.832769 502.042742 127.852607"
                            transform="translate(506.260102, 123.636717) rotate(42.880000) translate(-506.260102, -123.636717) "
                            stroke="#1372a1"
                            id="a"
                            data-index="402"
                        ></polygon>
                        <polygon
                            className=""
                            points="509.788125 126.870871 518.20142 126.850978 518.181527 135.264509 509.768233 135.284401"
                            transform="translate(513.984826, 131.067690) rotate(45.170000) translate(-513.984826, -131.067690) "
                            stroke="#1372a1"
                            id="a"
                            data-index="414"
                        ></polygon>
                        <polygon
                            className=""
                            points="411.79929 47.6468615 420.228378 47.6346142 420.21613 56.0323507 411.787042 56.044598"
                            transform="translate(416.007710, 51.839606) rotate(19.000000) translate(-416.007710, -51.839606) "
                            stroke="#a15f33"
                            id="a"
                            data-index="332"
                        ></polygon>
                        <polygon
                            className=""
                            points="422.664774 51.6178991 431.092815 51.6044188 431.079335 60.0032021 422.651293 60.0166825"
                            transform="translate(426.872054, 55.810551) rotate(21.330000) translate(-426.872054, -55.810551) "
                            stroke="#a15f33"
                            id="a"
                            data-index="342"
                        ></polygon>
                        <polygon
                            className=""
                            points="446.847957 62.3303412 455.273252 62.3143875 455.257298 70.7159168 446.832003 70.7318706"
                            transform="translate(451.052627, 66.523129) rotate(26.660000) translate(-451.052627, -66.523129) "
                            stroke="#a15f33"
                            id="a"
                            data-index="352"
                        ></polygon>
                        <polygon
                            className=""
                            points="457.128119 67.7309281 465.552072 67.714058 465.535202 76.1169286 457.111248 76.1337987"
                            transform="translate(461.331660, 71.923928) rotate(29.000000) translate(-461.331660, -71.923928) "
                            stroke="#1372a1"
                            id="a"
                            data-index="362"
                        ></polygon>
                        <polygon
                            className=""
                            points="467.135696 73.518916 475.558245 73.5012452 475.540574 81.9055213 467.118025 81.9231921"
                            transform="translate(471.338135, 77.712219) rotate(31.330000) translate(-471.338135, -77.712219) "
                            stroke="#1372a1"
                            id="a"
                            data-index="369"
                        ></polygon>
                        <polygon
                            className=""
                            points="476.898535 79.7069234 485.319617 79.6885688 485.301263 88.0943107 476.88018 88.1126653"
                            transform="translate(481.099899, 83.900617) rotate(33.660000) translate(-481.099899, -83.900617) "
                            stroke="#1372a1"
                            id="a"
                            data-index="373"
                        ></polygon>
                        <polygon
                            className=""
                            points="486.440681 86.3137759 494.860241 86.2948567 494.841322 94.7021217 486.421762 94.721041"
                            transform="translate(490.641002, 90.507949) rotate(36.000000) translate(-490.641002, -90.507949) "
                            stroke="#1372a1"
                            id="a"
                            data-index="383"
                        ></polygon>
                        <polygon
                            className=""
                            points="495.664808 93.2720903 504.08281 93.2527342 504.063454 101.661557 495.645452 101.680913"
                            transform="translate(499.864131, 97.466823) rotate(38.330000) translate(-499.864131, -97.466823) "
                            stroke="#1372a1"
                            id="a"
                            data-index="389"
                        ></polygon>
                        <polygon
                            className=""
                            points="504.597006 100.597769 513.01342 100.578104 512.993755 108.988514 504.577341 109.008179"
                            transform="translate(508.795381, 104.793142) rotate(40.660000) translate(-508.795381, -104.793142) "
                            stroke="#1372a1"
                            id="a"
                            data-index="393"
                        ></polygon>
                        <polygon
                            className=""
                            points="513.25884 108.312416 521.67364 108.292571 521.653795 116.704596 513.238995 116.72444"
                            transform="translate(517.456318, 112.508506) rotate(43.000000) translate(-517.456318, -112.508506) "
                            stroke="#1372a1"
                            id="a"
                            data-index="403"
                        ></polygon>
                        <polygon
                            className=""
                            points="521.56196 116.337349 529.975143 116.317458 529.955251 124.731099 521.542068 124.75099"
                            transform="translate(525.758605, 120.534224) rotate(45.330000) translate(-525.758605, -120.534224) "
                            stroke="#1372a1"
                            id="a"
                            data-index="415"
                        ></polygon>
                        <polygon
                            className=""
                            points="419.768728 33.7489246 428.19757 33.7363679 428.185013 42.1343511 419.756172 42.1469078"
                            transform="translate(423.976871, 37.941638) rotate(19.570000) translate(-423.976871, -37.941638) "
                            stroke="#a15f33"
                            id="a"
                            data-index="333"
                        ></polygon>
                        <polygon
                            className=""
                            points="429.099939 37.2246754 437.527914 37.2111238 437.514362 45.6099731 429.086387 45.6235248"
                            transform="translate(433.307150, 41.417324) rotate(21.470000) translate(-433.307150, -41.417324) "
                            stroke="#a15f33"
                            id="a"
                            data-index="343"
                        ></polygon>
                        <polygon
                            className=""
                            points="453.286398 47.9386365 461.711771 47.922741 461.695875 56.3241925 453.270502 56.340088"
                            transform="translate(457.491136, 52.131415) rotate(26.520000) translate(-457.491136, -52.131415) "
                            stroke="#1372a1"
                            id="a"
                            data-index="353"
                        ></polygon>
                        <polygon
                            className=""
                            points="462.126476 52.5122899 470.550769 52.4956367 470.534116 60.898168 462.109823 60.9148212"
                            transform="translate(466.330296, 56.705229) rotate(28.420000) translate(-466.330296, -56.705229) "
                            stroke="#1372a1"
                            id="a"
                            data-index="363"
                        ></polygon>
                        <polygon
                            className=""
                            points="470.764047 57.3487084 479.187218 57.331374 479.169884 65.7350269 470.746712 65.7523612"
                            transform="translate(474.966965, 61.541868) rotate(30.310000) translate(-474.966965, -61.541868) "
                            stroke="#1372a1"
                            id="a"
                            data-index="370"
                        ></polygon>
                        <polygon
                            className=""
                            points="479.281004 62.493749 487.703005 62.475806 487.685062 70.8806291 479.263061 70.8985721"
                            transform="translate(483.483033, 66.687189) rotate(32.210000) translate(-483.483033, -66.687189) "
                            stroke="#1372a1"
                            id="a"
                            data-index="374"
                        ></polygon>
                        <polygon
                            className=""
                            points="487.578433 67.8876613 495.999233 67.8691911 495.980763 76.2752158 487.559963 76.293686"
                            transform="translate(491.779598, 72.081439) rotate(34.100000) translate(-491.779598, -72.081439) "
                            stroke="#1372a1"
                            id="a"
                            data-index="376"
                        ></polygon>
                        <polygon
                            className=""
                            points="495.735005 73.5815887 504.154564 73.5626695 504.135645 81.9699345 495.716085 81.9888537"
                            transform="translate(499.935325, 77.775762) rotate(36.000000) translate(-499.935325, -77.775762) "
                            stroke="#1372a1"
                            id="a"
                            data-index="384"
                        ></polygon>
                        <polygon
                            className=""
                            points="503.655989 79.5094065 512.074288 79.4901232 512.055005 87.8986489 503.636706 87.9179322"
                            transform="translate(507.855497, 83.704028) rotate(37.890000) translate(-507.855497, -83.704028) "
                            stroke="#1372a1"
                            id="a"
                            data-index="390"
                        ></polygon>
                        <polygon
                            className=""
                            points="511.376188 85.6939276 519.793205 85.6743641 519.773642 94.0841716 511.356625 94.1037351"
                            transform="translate(515.574915, 89.889050) rotate(39.780000) translate(-515.574915, -89.889050) "
                            stroke="#1372a1"
                            id="a"
                            data-index="394"
                        ></polygon>
                        <polygon
                            className=""
                            points="518.92637 92.163122 527.342082 92.1433626 527.322323 100.554475 518.90661 100.574234"
                            transform="translate(523.124346, 96.358798) rotate(41.680000) translate(-523.124346, -96.358798) "
                            stroke="#1372a1"
                            id="a"
                            data-index="404"
                        ></polygon>
                        <polygon
                            className=""
                            points="526.218847 98.8418623 534.633252 98.8219942 534.613384 107.234414 526.198979 107.254282"
                            transform="translate(530.416116, 103.038138) rotate(43.570000) translate(-530.416116, -103.038138) "
                            stroke="#1372a1"
                            id="a"
                            data-index="406"
                        ></polygon>
                        <polygon
                            className=""
                            points="533.322763 105.793475 541.735848 105.773584 541.715958 114.187323 533.302872 114.207213"
                            transform="translate(537.519360, 109.990399) rotate(45.470000) translate(-537.519360, -109.990399) "
                            stroke="#1372a1"
                            id="a"
                            data-index="416"
                        ></polygon>
                        <polygon
                            className=""
                            points="425.637177 19.1231683 434.06597 19.1105524 434.053354 27.508584 425.624561 27.5211999"
                            transform="translate(429.845266, 23.315876) rotate(19.680000) translate(-429.845266, -23.315876) "
                            stroke="#a15f33"
                            id="a"
                            data-index="334"
                        ></polygon>
                        <polygon
                            className=""
                            points="435.555036 22.841035 443.98295 22.8274174 443.969332 31.2263284 435.541419 31.239946"
                            transform="translate(439.762184, 27.033682) rotate(21.600000) translate(-439.762184, -27.033682) "
                            stroke="#a15f33"
                            id="a"
                            data-index="344"
                        ></polygon>
                        <polygon
                            className=""
                            points="459.753792 33.5630219 468.179231 33.5471767 468.163386 41.9485617 459.737947 41.964407"
                            transform="translate(463.958589, 37.755792) rotate(26.400000) translate(-463.958589, -37.755792) "
                            stroke="#1372a1"
                            id="a"
                            data-index="354"
                        ></polygon>
                        <polygon
                            className=""
                            points="469.166399 38.410104 477.59075 38.3934889 477.574135 46.7959621 469.149783 46.8125772"
                            transform="translate(473.370267, 42.603033) rotate(28.320000) translate(-473.370267, -42.603033) "
                            stroke="#1372a1"
                            id="a"
                            data-index="364"
                        ></polygon>
                        <polygon
                            className=""
                            points="478.410537 43.5682446 486.833751 43.5509342 486.81644 51.9545447 478.393226 51.9718551"
                            transform="translate(482.613488, 47.761395) rotate(30.240000) translate(-482.613488, -47.761395) "
                            stroke="#1372a1"
                            id="a"
                            data-index="371"
                        ></polygon>
                        <polygon
                            className=""
                            points="487.475823 49.0316527 495.897856 49.0137247 495.879928 57.4185165 487.457895 57.4364445"
                            transform="translate(491.677876, 53.225085) rotate(32.160000) translate(-491.677876, -53.225085) "
                            stroke="#1372a1"
                            id="a"
                            data-index="375"
                        ></polygon>
                        <polygon
                            className=""
                            points="496.352077 54.7941947 504.77289 54.7757297 504.754425 63.1817415 496.333612 63.2002065"
                            transform="translate(500.553251, 58.987968) rotate(34.080000) translate(-500.553251, -58.987968) "
                            stroke="#1372a1"
                            id="a"
                            data-index="377"
                        ></polygon>
                        <polygon
                            className=""
                            points="505.029328 60.8494015 513.448887 60.8304823 513.429968 69.2377473 505.010409 69.2566665"
                            transform="translate(509.229648, 65.043574) rotate(36.000000) translate(-509.229648, -65.043574) "
                            stroke="#1372a1"
                            id="a"
                            data-index="385"
                        ></polygon>
                        <polygon
                            className=""
                            points="513.49783 67.1904752 521.916108 67.1711868 521.89682 75.5797327 513.478541 75.5990211"
                            transform="translate(517.697325, 71.385104) rotate(37.920000) translate(-517.697325, -71.385104) "
                            stroke="#1372a1"
                            id="a"
                            data-index="391"
                        ></polygon>
                        <polygon
                            className=""
                            points="521.748071 73.8102976 530.165047 73.7907266 530.145476 82.2005751 521.7285 82.2201461"
                            transform="translate(525.946774, 78.005436) rotate(39.840000) translate(-525.946774, -78.005436) "
                            stroke="#1372a1"
                            id="a"
                            data-index="395"
                        ></polygon>
                        <polygon
                            className=""
                            points="529.770786 80.7014373 538.186444 80.6816715 538.166678 89.0928387 529.751021 89.1126045"
                            transform="translate(533.968732, 84.897138) rotate(41.760000) translate(-533.968732, -84.897138) "
                            stroke="#1372a1"
                            id="a"
                            data-index="405"
                        ></polygon>
                        <polygon
                            className=""
                            points="537.556964 87.8561585 545.971292 87.8362868 545.951421 96.2487828 537.537092 96.2686545"
                            transform="translate(541.754192, 92.052471) rotate(43.680000) translate(-541.754192, -92.052471) "
                            stroke="#1372a1"
                            id="a"
                            data-index="407"
                        ></polygon>
                        <polygon
                            className=""
                            points="545.097859 95.2664298 553.510855 95.2465414 553.490966 103.66037 545.077971 103.680259"
                            transform="translate(549.294413, 99.463400) rotate(45.600000) translate(-549.294413, -99.463400) "
                            stroke="#1372a1"
                            id="a"
                            data-index="417"
                        ></polygon>
                        <polygon
                            className=""
                            points="445.099604 220.336623 453.507667 220.317463 453.488507 228.736225 445.080444 228.755385"
                            transform="translate(449.294056, 224.536424) rotate(52.800000) translate(-449.294056, -224.536424) "
                            stroke="#1372a1"
                            id="a"
                            data-index="418"
                        ></polygon>
                        <polygon
                            className=""
                            points="452.658619 231.157766 461.063561 231.139767 461.045562 239.561649 452.64062 239.579648"
                            transform="translate(456.852090, 235.359707) rotate(57.600000) translate(-456.852090, -235.359707) "
                            stroke="#1372a1"
                            id="a"
                            data-index="428"
                        ></polygon>
                        <polygon
                            className=""
                            points="459.280794 242.570274 467.682853 242.553939 467.666518 250.978704 459.264459 250.995039"
                            transform="translate(463.473656, 246.774489) rotate(62.400000) translate(-463.473656, -246.774489) "
                            stroke="#535758"
                            id="a"
                            data-index="465"
                        ></polygon>
                        <polygon
                            className=""
                            points="456.88292 209.76588 465.291277 209.74664 465.272037 218.165107 456.86368 218.184347"
                            transform="translate(461.077479, 213.965494) rotate(52.360000) translate(-461.077479, -213.965494) "
                            stroke="#1372a1"
                            id="a"
                            data-index="419"
                        ></polygon>
                        <polygon
                            className=""
                            points="465.764984 222.342728 474.170021 222.324685 474.151977 230.746473 465.746941 230.764516"
                            transform="translate(469.958481, 226.544600) rotate(57.450000) translate(-469.958481, -226.544600) "
                            stroke="#1372a1"
                            id="a"
                            data-index="429"
                        ></polygon>
                        <polygon
                            className=""
                            points="473.490297 235.654029 481.892277 235.63775 481.875997 244.062595 473.474018 244.078874"
                            transform="translate(477.683147, 239.858312) rotate(62.540000) translate(-477.683147, -239.858312) "
                            stroke="#535758"
                            id="a"
                            data-index="466"
                        ></polygon>
                        <polygon
                            className=""
                            points="479.997915 249.594854 488.397197 249.580852 488.383195 258.008394 479.983912 258.022396"
                            transform="translate(484.190555, 253.801624) rotate(67.630000) translate(-484.190555, -253.801624) "
                            stroke="#535758"
                            id="a"
                            data-index="477"
                        ></polygon>
                        <polygon
                            className=""
                            points="468.673075 199.21761 477.081675 199.198308 477.062373 207.616533 468.653773 207.635835"
                            transform="translate(472.867724, 203.417072) rotate(52.000000) translate(-472.867724, -203.417072) "
                            stroke="#1372a1"
                            id="a"
                            data-index="420"
                        ></polygon>
                        <polygon
                            className=""
                            points="476.458779 209.880188 484.864739 209.861744 484.846295 218.282608 476.440335 218.301052"
                            transform="translate(480.652537, 214.081398) rotate(56.000000) translate(-480.652537, -214.081398) "
                            stroke="#1372a1"
                            id="a"
                            data-index="430"
                        ></polygon>
                        <polygon
                            className=""
                            points="483.477835 221.05716 491.881301 221.039932 491.864073 229.463291 483.460608 229.480519"
                            transform="translate(487.670954, 225.260225) rotate(60.000000) translate(-487.670954, -225.260225) "
                            stroke="#007e46"
                            id="a"
                            data-index="449"
                        ></polygon>
                        <polygon
                            className=""
                            points="489.696039 232.694101 498.097204 232.678425 498.081528 241.104084 489.680363 241.11976"
                            transform="translate(493.888784, 236.899092) rotate(64.000000) translate(-493.888784, -236.899092) "
                            stroke="#535758"
                            id="a"
                            data-index="467"
                        ></polygon>
                        <polygon
                            className=""
                            points="495.08309 244.734344 503.482192 244.720525 503.468374 253.148247 495.069271 253.162066"
                            transform="translate(499.275732, 248.941295) rotate(68.000000) translate(-499.275732, -248.941295) "
                            stroke="#535758"
                            id="a"
                            data-index="478"
                        ></polygon>
                        <polygon
                            className=""
                            points="480.44627 188.658113 488.855079 188.63876 488.835726 197.056775 480.426917 197.076128"
                            transform="translate(484.640998, 192.857444) rotate(51.690000) translate(-484.640998, -192.857444) "
                            stroke="#1372a1"
                            id="a"
                            data-index="421"
                        ></polygon>
                        <polygon
                            className=""
                            points="487.556183 198.166634 495.962785 198.147944 495.944094 206.568166 487.537492 206.586857"
                            transform="translate(491.750138, 202.367400) rotate(55.010000) translate(-491.750138, -202.367400) "
                            stroke="#1372a1"
                            id="a"
                            data-index="431"
                        ></polygon>
                        <polygon
                            className=""
                            points="494.100637 208.068881 502.505123 208.051103 502.487345 216.473441 494.082859 216.491219"
                            transform="translate(498.293991, 212.271161) rotate(58.330000) translate(-498.293991, -212.271161) "
                            stroke="#1372a1"
                            id="a"
                            data-index="438"
                        ></polygon>
                        <polygon
                            className=""
                            points="500.074693 218.363052 508.477178 218.346429 508.460555 226.770769 500.05807 226.787391"
                            transform="translate(504.267624, 222.566910) rotate(61.660000) translate(-504.267624, -222.566910) "
                            stroke="#007e46"
                            id="a"
                            data-index="450"
                        ></polygon>
                        <polygon
                            className=""
                            points="505.422425 228.952798 513.823061 228.937551 513.807813 237.363739 505.407177 237.378987"
                            transform="translate(509.615119, 233.158269) rotate(64.980000) translate(-509.615119, -233.158269) "
                            stroke="#535758"
                            id="a"
                            data-index="468"
                        ></polygon>
                        <polygon
                            className=""
                            points="510.144714 239.832978 518.543672 239.81931 518.530004 248.247176 510.131046 248.260844"
                            transform="translate(514.337359, 244.040077) rotate(68.300000) translate(-514.337359, -244.040077) "
                            stroke="#535758"
                            id="a"
                            data-index="479"
                        ></polygon>
                        <polygon
                            className=""
                            points="503.996933 167.56725 512.406074 167.547821 512.386645 175.965505 503.977504 175.984934"
                            transform="translate(508.191789, 171.766377) rotate(51.200000) translate(-508.191789, -171.766377) "
                            stroke="#1372a1"
                            id="a"
                            data-index="422"
                        ></polygon>
                        <polygon
                            className=""
                            points="511.352944 177.163492 519.760123 177.144601 519.741232 185.564247 511.334053 185.583138"
                            transform="translate(515.547088, 181.363870) rotate(54.130000) translate(-515.547088, -181.363870) "
                            stroke="#1372a1"
                            id="a"
                            data-index="432"
                        ></polygon>
                        <polygon
                            className=""
                            points="518.206299 187.121321 526.611582 187.103165 526.593426 195.524707 518.188143 195.542863"
                            transform="translate(522.399863, 191.323014) rotate(57.060000) translate(-522.399863, -191.323014) "
                            stroke="#1372a1"
                            id="a"
                            data-index="439"
                        ></polygon>
                        <polygon
                            className=""
                            points="524.559778 197.450387 532.963244 197.433159 532.946016 205.856518 524.54255 205.873745"
                            transform="translate(528.752897, 201.653452) rotate(60.000000) translate(-528.752897, -201.653452) "
                            stroke="#007e46"
                            id="a"
                            data-index="451"
                        ></polygon>
                        <polygon
                            className=""
                            points="530.353554 208.053443 538.755313 208.03732 538.739191 216.462386 530.337432 216.478508"
                            transform="translate(534.546372, 212.257914) rotate(62.930000) translate(-534.546372, -212.257914) "
                            stroke="#007e46"
                            id="a"
                            data-index="457"
                        ></polygon>
                        <polygon
                            className=""
                            points="515.765545 157.021886 524.174821 157.002428 524.155363 165.419976 515.746087 165.439434"
                            transform="translate(519.960454, 161.220931) rotate(51.000000) translate(-519.960454, -161.220931) "
                            stroke="#1372a1"
                            id="a"
                            data-index="423"
                        ></polygon>
                        <polygon
                            className=""
                            points="523.829626 167.479391 532.236891 167.460472 532.217971 175.880031 523.810706 175.89895"
                            transform="translate(528.023799, 171.679711) rotate(54.000000) translate(-528.023799, -171.679711) "
                            stroke="#1372a1"
                            id="a"
                            data-index="433"
                        ></polygon>
                        <polygon
                            className=""
                            points="531.332553 178.342504 539.737875 178.324331 539.719702 186.745835 531.31438 186.764008"
                            transform="translate(535.526128, 182.544169) rotate(57.000000) translate(-535.526128, -182.544169) "
                            stroke="#1372a1"
                            id="a"
                            data-index="440"
                        ></polygon>
                        <polygon
                            className=""
                            points="538.253759 189.581462 546.657225 189.564234 546.639997 197.987593 538.236531 198.004821"
                            transform="translate(542.446878, 193.784528) rotate(60.000000) translate(-542.446878, -193.784528) "
                            stroke="#007e46"
                            id="a"
                            data-index="452"
                        ></polygon>
                        <polygon
                            className=""
                            points="544.574267 201.165471 552.975987 201.149377 552.959893 209.574482 544.558174 209.590576"
                            transform="translate(548.767080, 205.369977) rotate(63.000000) translate(-548.767080, -205.369977) "
                            stroke="#535758"
                            id="a"
                            data-index="458"
                        ></polygon>
                        <polygon
                            className=""
                            points="527.521587 146.465442 535.930986 146.445958 535.911502 154.863384 527.502103 154.882868"
                            transform="translate(531.716545, 150.664413) rotate(50.820000) translate(-531.716545, -150.664413) "
                            stroke="#1372a1"
                            id="a"
                            data-index="424"
                        ></polygon>
                        <polygon
                            className=""
                            points="534.141486 154.886241 542.549341 154.86714 542.53024 163.286109 534.122385 163.30521"
                            transform="translate(538.335863, 159.086175) rotate(53.110000) translate(-538.335863, -159.086175) "
                            stroke="#1372a1"
                            id="a"
                            data-index="434"
                        ></polygon>
                        <polygon
                            className=""
                            points="540.444552 163.601949 548.850894 163.583355 548.8323 172.003838 540.425959 172.022432"
                            transform="translate(544.638426, 167.802894) rotate(55.410000) translate(-544.638426, -167.802894) "
                            stroke="#1372a1"
                            id="a"
                            data-index="441"
                        ></polygon>
                        <polygon
                            className=""
                            points="546.365915 172.52287 554.770795 172.5049 554.752825 180.926845 546.347945 180.944815"
                            transform="translate(550.559370, 176.724858) rotate(57.700000) translate(-550.559370, -176.724858) "
                            stroke="#007e46"
                            id="a"
                            data-index="445"
                        ></polygon>
                        <polygon
                            className=""
                            points="551.94774 181.712538 560.351205 181.69531 560.333978 190.118669 551.930512 190.135896"
                            transform="translate(556.140859, 185.915603) rotate(60.000000) translate(-556.140859, -185.915603) "
                            stroke="#007e46"
                            id="a"
                            data-index="453"
                        ></polygon>
                        <polygon
                            className=""
                            points="557.132577 191.076379 565.534699 191.060001 565.518321 199.484703 557.116199 199.501082"
                            transform="translate(561.325449, 195.280541) rotate(62.290000) translate(-561.325449, -195.280541) "
                            stroke="#535758"
                            id="a"
                            data-index="459"
                        ></polygon>
                        <polygon
                            className=""
                            points="539.275806 135.910472 547.685314 135.890966 547.665808 144.308283 539.2563 144.327789"
                            transform="translate(543.470807, 140.109377) rotate(50.660000) translate(-543.470807, -140.109377) "
                            stroke="#1372a1"
                            id="a"
                            data-index="425"
                        ></polygon>
                        <polygon
                            className=""
                            points="546.459652 145.004502 554.867581 144.98538 554.848459 153.404275 546.44053 153.423397"
                            transform="translate(550.654055, 149.204389) rotate(53.000000) translate(-550.654055, -149.204389) "
                            stroke="#1372a1"
                            id="a"
                            data-index="435"
                        ></polygon>
                        <polygon
                            className=""
                            points="553.236065 154.342145 561.642459 154.323532 561.623845 162.743962 553.217452 162.762576"
                            transform="translate(557.429955, 158.543054) rotate(55.330000) translate(-557.429955, -158.543054) "
                            stroke="#1372a1"
                            id="a"
                            data-index="442"
                        ></polygon>
                        <polygon
                            className=""
                            points="559.625329 163.946204 568.030234 163.928222 568.012252 172.350142 559.607348 172.368123"
                            transform="translate(563.818791, 168.148173) rotate(57.660000) translate(-563.818791, -168.148173) "
                            stroke="#007e46"
                            id="a"
                            data-index="446"
                        ></polygon>
                        <polygon
                            className=""
                            points="565.64172 173.843613 574.045186 173.826386 574.027959 182.249744 565.624493 182.266972"
                            transform="translate(569.834839, 178.046679) rotate(60.000000) translate(-569.834839, -178.046679) "
                            stroke="#007e46"
                            id="a"
                            data-index="454"
                        ></polygon>
                        <polygon
                            className=""
                            points="571.223873 183.933432 579.625972 183.91707 579.60961 192.341795 571.207511 192.358158"
                            transform="translate(575.416742, 188.137614) rotate(62.330000) translate(-575.416742, -188.137614) "
                            stroke="#535758"
                            id="a"
                            data-index="460"
                        ></polygon>
                        <polygon
                            className=""
                            points="551.039022 125.369467 559.448625 125.349942 559.429101 133.767163 551.019498 133.786688"
                            transform="translate(555.234062, 129.568315) rotate(50.520000) translate(-555.234062, -129.568315) "
                            stroke="#1372a1"
                            id="a"
                            data-index="426"
                        ></polygon>
                        <polygon
                            className=""
                            points="557.245336 133.125312 565.653653 133.106083 565.634424 141.52459 557.226106 141.54382"
                            transform="translate(561.439880, 137.324951) rotate(52.420000) translate(-561.439880, -137.324951) "
                            stroke="#1372a1"
                            id="a"
                            data-index="436"
                        ></polygon>
                        <polygon
                            className=""
                            points="563.159202 141.039262 571.566263 141.02041 571.547411 149.440174 563.140351 149.459026"
                            transform="translate(567.353307, 145.239718) rotate(54.310000) translate(-567.353307, -145.239718) "
                            stroke="#007e46"
                            id="a"
                            data-index="443"
                        ></polygon>
                        <polygon
                            className=""
                            points="568.836693 149.186354 577.242518 149.167965 577.224129 157.588964 568.818304 157.607353"
                            transform="translate(573.030411, 153.387659) rotate(56.210000) translate(-573.030411, -153.387659) "
                            stroke="#007e46"
                            id="a"
                            data-index="447"
                        ></polygon>
                        <polygon
                            className=""
                            points="574.211871 157.471975 582.616501 157.454126 582.598652 165.876321 574.194022 165.89417"
                            transform="translate(578.405262, 161.674148) rotate(58.100000) translate(-578.405262, -161.674148) "
                            stroke="#007e46"
                            id="a"
                            data-index="455"
                        ></polygon>
                        <polygon
                            className=""
                            points="579.335701 165.974689 587.739167 165.957461 587.721939 174.38082 579.318474 174.398047"
                            transform="translate(583.528820, 170.177754) rotate(60.000000) translate(-583.528820, -170.177754) "
                            stroke="#535758"
                            id="a"
                            data-index="461"
                        ></polygon>
                        <polygon
                            className=""
                            points="584.148677 174.595752 592.551028 174.579218 592.534494 183.003691 584.132142 183.020225"
                            transform="translate(588.341585, 178.799721) rotate(61.890000) translate(-588.341585, -178.799721) "
                            stroke="#535758"
                            id="a"
                            data-index="463"
                        ></polygon>
                        <polygon
                            className=""
                            points="562.822109 114.85487 571.231794 114.83533 571.212254 123.25247 562.802569 123.27201"
                            transform="translate(567.017181, 119.053670) rotate(50.400000) translate(-567.017181, -119.053670) "
                            stroke="#1372a1"
                            id="a"
                            data-index="427"
                        ></polygon>
                        <polygon
                            className=""
                            points="569.439712 123.092263 577.848097 123.073016 577.82885 131.491456 569.420465 131.510703"
                            transform="translate(573.634281, 127.291860) rotate(52.320000) translate(-573.634281, -127.291860) "
                            stroke="#1372a1"
                            id="a"
                            data-index="437"
                        ></polygon>
                        <polygon
                            className=""
                            points="575.776225 131.545653 584.183332 131.526786 584.164464 139.946504 575.757358 139.965371"
                            transform="translate(579.970345, 135.746078) rotate(54.240000) translate(-579.970345, -135.746078) "
                            stroke="#007e46"
                            id="a"
                            data-index="444"
                        ></polygon>
                        <polygon
                            className=""
                            points="581.82453 140.20555 590.230388 140.187148 590.211985 148.608115 581.806128 148.626517"
                            transform="translate(586.018258, 144.406833) rotate(56.160000) translate(-586.018258, -144.406833) "
                            stroke="#007e46"
                            id="a"
                            data-index="448"
                        ></polygon>
                        <polygon
                            className=""
                            points="587.577837 149.062235 595.982478 149.044379 595.964623 157.466562 587.559981 157.484417"
                            transform="translate(591.771230, 153.264398) rotate(58.080000) translate(-591.771230, -153.264398) "
                            stroke="#007e46"
                            id="a"
                            data-index="456"
                        ></polygon>
                        <polygon
                            className=""
                            points="593.029682 158.105764 601.433148 158.088537 601.41592 166.511895 593.012454 166.529123"
                            transform="translate(597.222801, 162.308830) rotate(60.000000) translate(-597.222801, -162.308830) "
                            stroke="#535758"
                            id="a"
                            data-index="462"
                        ></polygon>
                        <polygon
                            className=""
                            points="598.173945 167.325988 606.576279 167.309465 606.559756 175.733955 598.157422 175.750478"
                            transform="translate(602.366850, 171.529972) rotate(61.920000) translate(-602.366850, -171.529972) "
                            stroke="#535758"
                            id="a"
                            data-index="464"
                        ></polygon>
                        <polygon
                            className=""
                            points="488.181183 274.651931 496.576915 274.642813 496.567797 283.073906 488.172065 283.083023"
                            transform="translate(492.374490, 278.862918) rotate(76.360000) translate(-492.374490, -278.862918) "
                            stroke="#535758"
                            id="a"
                            data-index="490"
                        ></polygon>
                        <polygon
                            className=""
                            points="491.152779 289.736403 499.547178 289.730554 499.541328 298.16298 491.14693 298.168829"
                            transform="translate(495.347054, 293.949692) rotate(81.450000) translate(-495.347054, -293.949692) "
                            stroke="#535758"
                            id="a"
                            data-index="503"
                        ></polygon>
                        <polygon
                            className=""
                            points="503.262927 269.788537 511.658775 269.779198 511.649436 278.210175 503.253588 278.219514"
                            transform="translate(507.456182, 273.999356) rotate(76.000000) translate(-507.456182, -273.999356) "
                            stroke="#535758"
                            id="a"
                            data-index="491"
                        ></polygon>
                        <polygon
                            className=""
                            points="506.015872 282.680483 514.410591 282.673679 514.403787 291.105784 506.009068 291.112588"
                            transform="translate(510.209830, 286.893134) rotate(80.000000) translate(-510.209830, -286.893134) "
                            stroke="#535758"
                            id="a"
                            data-index="504"
                        ></polygon>
                        <polygon
                            className=""
                            points="507.858173 295.732314 516.252127 295.728178 516.247991 304.161048 507.854037 304.165184"
                            transform="translate(512.053082, 299.946681) rotate(84.000000) translate(-512.053082, -299.946681) "
                            stroke="#535758"
                            id="a"
                            data-index="513"
                        ></polygon>
                        <polygon
                            className=""
                            points="518.333738 264.908014 526.729688 264.898486 526.72016 273.32936 518.32421 273.338889"
                            transform="translate(522.526949, 269.118687) rotate(75.690000) translate(-522.526949, -269.118687) "
                            stroke="#535758"
                            id="a"
                            data-index="492"
                        ></polygon>
                        <polygon
                            className=""
                            points="520.941329 276.472164 529.336295 276.464718 529.328849 284.896578 520.933884 284.904023"
                            transform="translate(525.135089, 280.684371) rotate(79.010000) translate(-525.135089, -280.684371) "
                            stroke="#535758"
                            id="a"
                            data-index="505"
                        ></polygon>
                        <polygon
                            className=""
                            points="522.871397 288.167308 531.265625 288.162045 531.260362 296.594641 522.866134 296.599904"
                            transform="translate(527.065879, 292.380974) rotate(82.330000) translate(-527.065879, -292.380974) "
                            stroke="#535758"
                            id="a"
                            data-index="514"
                        ></polygon>
                        <polygon
                            className=""
                            points="535.594986 218.937354 543.995159 218.922506 543.980311 227.349156 535.580138 227.364005"
                            transform="translate(539.787649, 223.143255) rotate(65.860000) translate(-539.787649, -223.143255) "
                            stroke="#535758"
                            id="a"
                            data-index="469"
                        ></polygon>
                        <polygon
                            className=""
                            points="540.285341 230.112082 548.684063 230.098668 548.67065 238.52677 540.271927 238.540184"
                            transform="translate(544.477995, 234.319426) rotate(68.800000) translate(-544.477995, -234.319426) "
                            stroke="#535758"
                            id="a"
                            data-index="480"
                        ></polygon>
                        <polygon
                            className=""
                            points="548.467694 255.174376 556.86381 255.16455 556.853984 263.595259 548.457868 263.605085"
                            transform="translate(552.660839, 259.384818) rotate(75.200000) translate(-552.660839, -259.384818) "
                            stroke="#535758"
                            id="a"
                            data-index="493"
                        ></polygon>
                        <polygon
                            className=""
                            points="552.258037 271.887993 560.652913 271.880773 560.645693 280.312722 552.250817 280.319941"
                            transform="translate(556.451865, 276.100357) rotate(79.360000) translate(-556.451865, -276.100357) "
                            stroke="#535758"
                            id="a"
                            data-index="506"
                        ></polygon>
                        <polygon
                            className=""
                            points="550.276752 213.062792 558.676853 213.048008 558.66207 221.474731 550.261969 221.489515"
                            transform="translate(554.469411, 217.268762) rotate(66.000000) translate(-554.469411, -217.268762) "
                            stroke="#535758"
                            id="a"
                            data-index="470"
                        ></polygon>
                        <polygon
                            className=""
                            points="555.345582 225.240826 563.744211 225.227515 563.7309 233.655711 555.332271 233.669022"
                            transform="translate(559.538241, 229.448269) rotate(69.000000) translate(-559.538241, -229.448269) "
                            stroke="#535758"
                            id="a"
                            data-index="481"
                        ></polygon>
                        <polygon
                            className=""
                            points="563.528481 250.304892 571.924666 250.294945 571.914719 258.725585 563.518535 258.735532"
                            transform="translate(567.721600, 254.515238) rotate(75.000000) translate(-567.721600, -254.515238) "
                            stroke="#535758"
                            id="a"
                            data-index="494"
                        ></polygon>
                        <polygon
                            className=""
                            points="567.96012 269.846242 576.354946 269.839152 576.347856 278.27115 567.95303 278.27824"
                            transform="translate(572.153988, 274.058696) rotate(79.560000) translate(-572.153988, -274.058696) "
                            stroke="#535758"
                            id="a"
                            data-index="507"
                        ></polygon>
                        <polygon
                            className=""
                            points="561.937214 200.638911 570.338064 200.623486 570.322639 209.049461 561.921789 209.064885"
                            transform="translate(566.129927, 204.844186) rotate(64.580000) translate(-566.129927, -204.844186) "
                            stroke="#535758"
                            id="a"
                            data-index="471"
                        ></polygon>
                        <polygon
                            className=""
                            points="566.3724 210.427803 574.772054 210.413435 574.757686 218.840606 566.358033 218.854974"
                            transform="translate(570.565043, 214.634204) rotate(66.880000) translate(-570.565043, -214.634204) "
                            stroke="#535758"
                            id="a"
                            data-index="482"
                        ></polygon>
                        <polygon
                            className=""
                            points="570.392491 220.342316 578.791041 220.329093 578.777818 228.757367 570.379268 228.77059"
                            transform="translate(574.585154, 224.549841) rotate(69.170000) translate(-574.585154, -224.549841) "
                            stroke="#535758"
                            id="a"
                            data-index="486"
                        ></polygon>
                        <polygon
                            className=""
                            points="578.582302 245.420192 586.978549 245.410138 586.968495 253.840715 578.572247 253.85077"
                            transform="translate(582.775398, 249.630454) rotate(74.820000) translate(-582.775398, -249.630454) "
                            stroke="#535758"
                            id="a"
                            data-index="495"
                        ></polygon>
                        <polygon
                            className=""
                            points="581.36409 256.566394 589.759538 256.557848 589.750993 264.989225 581.355544 264.99777"
                            transform="translate(585.557541, 260.777809) rotate(77.280000) translate(-585.557541, -260.777809) "
                            stroke="#535758"
                            id="a"
                            data-index="499"
                        ></polygon>
                        <polygon
                            className=""
                            points="583.654123 267.775265 592.048907 267.768285 592.041928 276.200326 583.647144 276.207305"
                            transform="translate(587.848026, 271.987795) rotate(79.730000) translate(-587.848026, -271.987795) "
                            stroke="#535758"
                            id="a"
                            data-index="508"
                        ></polygon>
                        <polygon
                            className=""
                            points="576.389129 194.240753 584.789936 194.225364 584.774546 202.651381 576.373739 202.666771"
                            transform="translate(580.581837, 198.446067) rotate(64.660000) translate(-580.581837, -198.446067) "
                            stroke="#535758"
                            id="a"
                            data-index="472"
                        ></polygon>
                        <polygon
                            className=""
                            points="581.148359 204.794044 589.547953 204.779734 589.533643 213.206965 581.134049 213.221275"
                            transform="translate(585.341001, 209.000505) rotate(67.000000) translate(-585.341001, -209.000505) "
                            stroke="#535758"
                            id="a"
                            data-index="483"
                        ></polygon>
                        <polygon
                            className=""
                            points="585.453023 215.485673 593.8515 215.472533 593.83836 223.900881 585.439883 223.914021"
                            transform="translate(589.645691, 219.693277) rotate(69.330000) translate(-589.645691, -219.693277) "
                            stroke="#535758"
                            id="a"
                            data-index="487"
                        ></polygon>
                        <polygon
                            className=""
                            points="593.633844 240.536098 602.030147 240.525948 602.019997 248.956469 593.623693 248.966619"
                            transform="translate(597.826920, 244.746283) rotate(74.660000) translate(-597.826920, -244.746283) "
                            stroke="#535758"
                            id="a"
                            data-index="496"
                        ></polygon>
                        <polygon
                            className=""
                            points="596.788463 253.101128 605.183912 253.092583 605.175366 261.523959 596.779918 261.532505"
                            transform="translate(600.981915, 257.312544) rotate(77.280000) translate(-600.981915, -257.312544) "
                            stroke="#535758"
                            id="a"
                            data-index="500"
                        ></polygon>
                        <polygon
                            className=""
                            points="599.353813 265.747931 607.748558 265.741056 607.741683 274.173135 599.346937 274.180011"
                            transform="translate(603.547748, 269.960533) rotate(79.890000) translate(-603.547748, -269.960533) "
                            stroke="#535758"
                            id="a"
                            data-index="509"
                        ></polygon>
                        <polygon
                            className=""
                            points="588.673267 183.370093 597.074553 183.354324 597.058783 191.779862 588.657497 191.795632"
                            transform="translate(592.866025, 187.574978) rotate(63.780000) translate(-592.866025, -187.574978) "
                            stroke="#535758"
                            id="a"
                            data-index="473"
                        ></polygon>
                        <polygon
                            className=""
                            points="592.926148 192.335718 601.326415 192.320787 601.311484 200.747344 592.911217 200.762275"
                            transform="translate(597.118816, 196.541531) rotate(65.680000) translate(-597.118816, -196.541531) "
                            stroke="#535758"
                            id="a"
                            data-index="475"
                        ></polygon>
                        <polygon
                            className=""
                            points="596.85793 201.388509 605.257241 201.374477 605.243209 209.80199 596.843898 209.816022"
                            transform="translate(601.050570, 205.595250) rotate(67.570000) translate(-601.050570, -205.595250) "
                            stroke="#535758"
                            id="a"
                            data-index="484"
                        ></polygon>
                        <polygon
                            className=""
                            points="600.505891 210.614303 608.904303 210.601237 608.891237 219.029649 600.492824 219.042715"
                            transform="translate(604.698564, 214.821976) rotate(69.470000) translate(-604.698564, -214.821976) "
                            stroke="#535758"
                            id="a"
                            data-index="488"
                        ></polygon>
                        <polygon
                            className=""
                            points="608.687887 235.6684 617.084241 235.658166 617.074007 244.088637 608.677654 244.098871"
                            transform="translate(612.880947, 239.878518) rotate(74.520000) translate(-612.880947, -239.878518) "
                            stroke="#535758"
                            id="a"
                            data-index="497"
                        ></polygon>
                        <polygon
                            className=""
                            points="612.212837 249.635863 620.608286 249.627318 620.59974 258.058694 612.204292 258.067239"
                            transform="translate(616.406289, 253.847279) rotate(77.280000) translate(-616.406289, -253.847279) "
                            stroke="#535758"
                            id="a"
                            data-index="501"
                        ></polygon>
                        <polygon
                            className=""
                            points="615.048685 263.704722 623.443397 263.697938 623.436613 272.130051 615.041901 272.136835"
                            transform="translate(619.242649, 267.917387) rotate(80.030000) translate(-619.242649, -267.917387) "
                            stroke="#535758"
                            id="a"
                            data-index="510"
                        ></polygon>
                        <polygon
                            className=""
                            points="603.004847 176.712556 611.4061 176.696812 611.390356 185.122384 602.989103 185.138128"
                            transform="translate(607.197602, 180.917470) rotate(63.840000) translate(-607.197602, -180.917470) "
                            stroke="#535758"
                            id="a"
                            data-index="474"
                        ></polygon>
                        <polygon
                            className=""
                            points="607.516965 186.254932 615.917191 186.240037 615.902296 194.666636 607.502071 194.681531"
                            transform="translate(611.709631, 190.460784) rotate(65.760000) translate(-611.709631, -190.460784) "
                            stroke="#535758"
                            id="a"
                            data-index="476"
                        ></polygon>
                        <polygon
                            className=""
                            points="611.705231 195.942404 620.104489 195.928426 620.090511 204.355993 611.691254 204.369971"
                            transform="translate(615.897871, 200.149198) rotate(67.680000) translate(-615.897871, -200.149198) "
                            stroke="#535758"
                            id="a"
                            data-index="485"
                        ></polygon>
                        <polygon
                            className=""
                            points="615.564943 205.764098 623.963297 205.7511 623.950299 214.179571 615.551945 214.192569"
                            transform="translate(619.757621, 209.971835) rotate(69.600000) translate(-619.757621, -209.971835) "
                            stroke="#535758"
                            id="a"
                            data-index="489"
                        ></polygon>
                        <polygon
                            className=""
                            points="623.74928 230.832867 632.145677 230.822562 632.135372 239.25299 623.738975 239.263295"
                            transform="translate(627.942326, 235.042929) rotate(74.400000) translate(-627.942326, -235.042929) "
                            stroke="#535758"
                            id="a"
                            data-index="498"
                        ></polygon>
                        <polygon
                            className=""
                            points="626.42739 241.036641 634.823134 241.027498 634.813992 249.458578 626.418247 249.46772"
                            transform="translate(630.620691, 245.247609) rotate(76.320000) translate(-630.620691, -245.247609) "
                            stroke="#535758"
                            id="a"
                            data-index="502"
                        ></polygon>
                        <polygon
                            className=""
                            points="628.760417 251.324016 637.155589 251.316078 637.14765 259.74773 628.752478 259.755669"
                            transform="translate(632.954033, 255.535873) rotate(78.240000) translate(-632.954033, -255.535873) "
                            stroke="#535758"
                            id="a"
                            data-index="511"
                        ></polygon>
                        <polygon
                            className=""
                            points="630.745742 261.683447 639.140424 261.676748 639.133724 270.108891 630.739043 270.11559"
                            transform="translate(634.939733, 265.896169) rotate(80.160000) translate(-634.939733, -265.896169) "
                            stroke="#535758"
                            id="a"
                            data-index="512"
                        ></polygon>
                        <polygon
                            className=""
                            points="492.767412 305.024073 501.161076 305.021676 501.158679 313.454836 492.765015 313.457233"
                            transform="translate(496.963045, 309.239454) rotate(86.540000) translate(-496.963045, -309.239454) "
                            stroke="#535758"
                            id="a"
                            data-index="522"
                        ></polygon>
                        <polygon
                            className=""
                            points="493.012378 320.394416 501.40593 320.395547 501.407061 328.82882 493.01351 328.827689"
                            transform="translate(497.209720, 324.611618) rotate(91.630000) translate(-497.209720, -324.611618) "
                            stroke="#535758"
                            id="a"
                            data-index="531"
                        ></polygon>
                        <polygon
                            className=""
                            points="508.780869 308.880468 517.174437 308.879081 517.173049 317.312337 508.779481 317.313725"
                            transform="translate(512.976959, 313.096403) rotate(88.000000) translate(-512.976959, -313.096403) "
                            stroke="#535758"
                            id="a"
                            data-index="523"
                        ></polygon>
                        <polygon
                            className=""
                            points="508.779481 322.060913 517.173049 322.062301 517.174437 330.495557 508.780869 330.49417"
                            transform="translate(512.976959, 326.278235) rotate(92.000000) translate(-512.976959, -326.278235) "
                            stroke="#535758"
                            id="a"
                            data-index="532"
                        ></polygon>
                        <polygon
                            className=""
                            points="524.120184 299.989805 532.513932 299.986802 532.510929 308.41988 524.117182 308.422882"
                            transform="translate(528.315557, 304.204842) rotate(85.660000) translate(-528.315557, -304.204842) "
                            stroke="#535758"
                            id="a"
                            data-index="515"
                        ></polygon>
                        <polygon
                            className=""
                            points="524.676011 311.828998 533.069543 311.82829 533.068835 320.261583 524.675303 320.262291"
                            transform="translate(528.872423, 316.045291) rotate(88.980000) translate(-528.872423, -316.045291) "
                            stroke="#535758"
                            id="a"
                            data-index="524"
                        ></polygon>
                        <polygon
                            className=""
                            points="524.541805 323.680546 532.935388 323.682141 532.936984 332.115382 524.5434 332.113787"
                            transform="translate(528.739394, 327.897964) rotate(92.300000) translate(-528.739394, -327.897964) "
                            stroke="#535758"
                            id="a"
                            data-index="533"
                        ></polygon>
                        <polygon
                            className=""
                            points="555.685333 298.018707 564.07907 298.015774 564.076137 306.448861 555.6824 306.451795"
                            transform="translate(559.880735, 302.233784) rotate(85.760000) translate(-559.880735, -302.233784) "
                            stroke="#535758"
                            id="a"
                            data-index="516"
                        ></polygon>
                        <polygon
                            className=""
                            points="556.308528 312.051346 564.702056 312.05077 564.701479 320.484067 556.307952 320.484643"
                            transform="translate(560.505004, 316.267706) rotate(89.170000) translate(-560.505004, -316.267706) "
                            stroke="#535758"
                            id="a"
                            data-index="525"
                        ></polygon>
                        <polygon
                            className=""
                            points="556.09177 326.096231 564.48537 326.09802 564.487159 334.531245 556.093559 334.529455"
                            transform="translate(560.289464, 330.313738) rotate(92.580000) translate(-560.289464, -330.313738) "
                            stroke="#535758"
                            id="a"
                            data-index="534"
                        ></polygon>
                        <polygon
                            className=""
                            points="571.38773 295.978771 579.781488 295.9757 579.778417 304.408767 571.38466 304.411837"
                            transform="translate(575.583074, 300.193769) rotate(85.560000) translate(-575.583074, -300.193769) "
                            stroke="#535758"
                            id="a"
                            data-index="517"
                        ></polygon>
                        <polygon
                            className=""
                            points="572.110393 311.25216 580.503924 311.251493 580.503257 319.684787 572.109727 319.685454"
                            transform="translate(576.306825, 315.468473) rotate(89.040000) translate(-576.306825, -315.468473) "
                            stroke="#535758"
                            id="a"
                            data-index="526"
                        ></polygon>
                        <polygon
                            className=""
                            points="571.899998 326.541249 580.293595 326.542996 580.295342 334.976224 571.901746 334.974477"
                            transform="translate(576.097670, 330.758737) rotate(92.520000) translate(-576.097670, -330.758737) "
                            stroke="#535758"
                            id="a"
                            data-index="535"
                        ></polygon>
                        <polygon
                            className=""
                            points="587.086076 293.922609 595.479854 293.919415 595.476659 302.352462 587.082882 302.355656"
                            transform="translate(591.281368, 298.137535) rotate(85.380000) translate(-591.281368, -298.137535) "
                            stroke="#535758"
                            id="a"
                            data-index="518"
                        ></polygon>
                        <polygon
                            className=""
                            points="587.910639 310.428272 596.304172 310.427522 596.303422 318.860813 587.909889 318.861563"
                            transform="translate(592.107030, 314.644543) rotate(88.920000) translate(-592.107030, -314.644543) "
                            stroke="#535758"
                            id="a"
                            data-index="527"
                        ></polygon>
                        <polygon
                            className=""
                            points="587.709406 326.953325 596.102999 326.955031 596.104705 335.388263 587.711112 335.386557"
                            transform="translate(591.907056, 331.170794) rotate(92.460000) translate(-591.907056, -331.170794) "
                            stroke="#535758"
                            id="a"
                            data-index="536"
                        ></polygon>
                        <polygon
                            className=""
                            points="602.782065 291.866628 611.175861 291.863324 611.172557 300.296353 602.778761 300.299657"
                            transform="translate(606.977311, 296.081491) rotate(85.220000) translate(-606.977311, -296.081491) "
                            stroke="#535758"
                            id="a"
                            data-index="519"
                        ></polygon>
                        <polygon
                            className=""
                            points="603.583635 305.189755 611.977207 305.188312 611.975764 313.621565 603.582192 313.623008"
                            transform="translate(607.779699, 309.405660) rotate(87.920000) translate(-607.779699, -309.405660) "
                            stroke="#535758"
                            id="a"
                            data-index="528"
                        ></polygon>
                        <polygon
                            className=""
                            points="603.754127 318.486356 612.147651 318.48678 612.148074 326.920081 603.75455 326.919657"
                            transform="translate(607.951101, 322.703219) rotate(90.610000) translate(-607.951101, -322.703219) "
                            stroke="#535758"
                            id="a"
                            data-index="537"
                        ></polygon>
                        <polygon
                            className=""
                            points="603.297304 331.7764 611.690955 331.778687 611.693241 340.21186 603.29959 340.209574"
                            transform="translate(607.495272, 335.994130) rotate(93.300000) translate(-607.495272, -335.994130) "
                            stroke="#535758"
                            id="a"
                            data-index="540"
                        ></polygon>
                        <polygon
                            className=""
                            points="618.47749 289.827224 626.871302 289.823825 626.867902 298.256837 618.47409 298.260237"
                            transform="translate(622.672696, 294.042031) rotate(85.080000) translate(-622.672696, -294.042031) "
                            stroke="#535758"
                            id="a"
                            data-index="520"
                        ></polygon>
                        <polygon
                            className=""
                            points="634.289937 288.778034 642.683749 288.774635 642.680349 297.207647 634.286537 297.211047"
                            transform="translate(638.485143, 292.992841) rotate(85.080000) translate(-638.485143, -292.992841) "
                            stroke="#535758"
                            id="a"
                            data-index="521"
                        ></polygon>
                        <polygon
                            className=""
                            points="619.364211 304.044916 627.757788 304.043397 627.756269 312.476644 619.362691 312.478163"
                            transform="translate(623.560240, 308.260780) rotate(87.810000) translate(-623.560240, -308.260780) "
                            stroke="#535758"
                            id="a"
                            data-index="529"
                        ></polygon>
                        <polygon
                            className=""
                            points="619.569386 318.288628 627.962909 318.289003 627.963284 326.722304 619.569761 326.721929"
                            transform="translate(623.766335, 322.505466) rotate(90.540000) translate(-623.766335, -322.505466) "
                            stroke="#535758"
                            id="a"
                            data-index="538"
                        ></polygon>
                        <polygon
                            className=""
                            points="619.092556 332.526035 627.486205 332.5283 627.488471 340.961476 619.094822 340.95921"
                            transform="translate(623.290514, 336.743755) rotate(93.270000) translate(-623.290514, -336.743755) "
                            stroke="#535758"
                            id="a"
                            data-index="541"
                        ></polygon>
                        <polygon
                            className=""
                            points="635.145764 302.94951 643.539347 302.947929 643.537765 311.381171 635.144183 311.382752"
                            transform="translate(639.341765, 307.165340) rotate(87.720000) translate(-639.341765, -307.165340) "
                            stroke="#535758"
                            id="a"
                            data-index="530"
                        ></polygon>
                        <polygon
                            className=""
                            points="635.3841 318.107372 643.777622 318.107705 643.777955 326.541008 635.384433 326.540675"
                            transform="translate(639.581028, 322.324190) rotate(90.480000) translate(-639.581028, -322.324190) "
                            stroke="#535758"
                            id="a"
                            data-index="539"
                        ></polygon>
                        <polygon
                            className=""
                            points="634.888672 333.259211 643.282318 333.261456 643.284563 341.694634 634.890917 341.692389"
                            transform="translate(639.086617, 337.476922) rotate(93.240000) translate(-639.086617, -337.476922) "
                            stroke="#999999"
                            id="a"
                            data-index="542"
                        ></polygon>
                    </g>
                </g>
            </g>
        </g>
    </g>
    <g className="fill_g" id="Page-1" stroke="none" stroke-width="1" fill="none" fillRule="evenodd">
        <g id="Elections-Home-Web-v1" transform="translate(-69.000000, -144.000000)" fillRule="nonzero">
            <g id="graph" transform="translate(60.000000, 144.000000)">
                <g transform="translate(9.000000, 0.000000)" id="seats-front">
                    <g>
                        <polygon
                            className=""
                            data-index="262"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.151183, 162.860778) rotate(-4.800000) translate(-308.151183, -162.860778) "
                            points="303.933011 158.662221 312.366038 158.665538 312.369355 167.059336 303.936329 167.056019"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="252"
                            id="a"
                            fill="#ff9650"
                            transform="translate(295.012478, 164.512752) rotate(-9.600000) translate(-295.012478, -164.512752) "
                            points="290.793108 160.312168 299.225306 160.31871 299.231848 168.713336 290.79965 168.706794"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="209"
                            id="a"
                            fill="#ff9650"
                            transform="translate(282.058741, 167.253164) rotate(-14.400000) translate(-282.058741, -167.253164) "
                            points="277.838527 163.050383 286.269372 163.059966 286.278955 171.455946 277.848111 171.446363"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="199"
                            id="a"
                            fill="#ff9650"
                            transform="translate(269.380834, 171.062793) rotate(-19.200000) translate(-269.380834, -171.062793) "
                            points="265.160154 166.857703 273.589156 166.87006 273.601513 175.267882 265.172511 175.255526"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="187"
                            id="a"
                            fill="#ff9650"
                            transform="translate(245.205653, 181.775498) rotate(-28.800000) translate(-245.205653, -181.775498) "
                            points="240.98522 177.565723 249.409291 177.582519 249.426087 185.985272 241.002016 185.968476"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="173"
                            id="a"
                            fill="#ff9650"
                            transform="translate(233.877952, 188.603432) rotate(-33.600000) translate(-233.877952, -188.603432) "
                            points="229.658222 184.391412 238.079343 184.40975 238.097682 192.815453 229.676561 192.797115"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="136"
                            id="a"
                            fill="#ff9650"
                            transform="translate(223.164034, 196.350827) rotate(-38.400000) translate(-223.164034, -196.350827) "
                            points="218.945373 192.136708 227.363328 192.156075 227.382695 200.564945 218.96474 200.545578"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="126"
                            id="a"
                            fill="#ff9650"
                            transform="translate(213.139049, 204.963338) rotate(-43.200000) translate(-213.139049, -204.963338) "
                            points="208.921792 200.747329 217.336453 200.767183 217.356307 209.179346 208.941645 209.159493"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="116"
                            id="a"
                            fill="#ff9650"
                            transform="translate(195.431826, 224.536424) rotate(-52.800000) translate(-195.431826, -224.536424) "
                            points="191.218215 220.317463 199.626278 220.336623 199.645438 228.755385 191.237375 228.736225"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="86"
                            id="a"
                            fill="#ff9650"
                            transform="translate(187.873792, 235.359707) rotate(-57.600000) translate(-187.873792, -235.359707) "
                            points="183.662321 231.139767 192.067263 231.157766 192.085263 239.579648 183.68032 239.561649"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="63"
                            id="a"
                            fill="#ff9650"
                            transform="translate(181.252226, 246.774489) rotate(-62.400000) translate(-181.252226, -246.774489) "
                            points="177.043029 242.553939 185.445088 242.570274 185.461423 250.995039 177.059364 250.978704"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="53"
                            id="a"
                            fill="#ff9650"
                            transform="translate(175.613575, 258.700701) rotate(-67.200000) translate(-175.613575, -258.700701) "
                            points="171.406722 254.47993 179.806216 254.494143 179.820429 262.921473 171.420935 262.90726"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="263"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.159503, 147.071968) rotate(-4.360000) translate(-308.159503, -147.071968) "
                            points="303.941457 142.873585 312.374533 142.876601 312.377548 151.27035 303.944473 151.267334"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="253"
                            id="a"
                            fill="#ff9650"
                            transform="translate(292.824544, 148.920298) rotate(-9.450000) translate(-292.824544, -148.920298) "
                            points="288.605206 144.71978 297.037438 144.726224 297.043882 153.120816 288.611649 153.114372"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="210"
                            id="a"
                            fill="#ff9650"
                            transform="translate(277.714819, 152.115446) rotate(-14.540000) translate(-277.714819, -152.115446) "
                            points="273.494586 147.912598 281.925384 147.922267 281.935052 156.318294 273.504255 156.308625"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="200"
                            id="a"
                            fill="#ff9650"
                            transform="translate(262.949498, 156.632211) rotate(-19.630000) translate(-262.949498, -156.632211) "
                            points="258.728796 152.426912 267.157611 152.439501 267.1702 160.837511 258.741385 160.824922"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="188"
                            id="a"
                            fill="#ff9650"
                            transform="translate(238.760926, 167.348333) rotate(-28.360000) translate(-238.760926, -167.348333) "
                            points="234.540446 163.13877 242.964775 163.1554 242.981405 171.557897 234.557077 171.541266"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="174"
                            id="a"
                            fill="#ff9650"
                            transform="translate(225.507091, 175.244732) rotate(-33.450000) translate(-225.507091, -175.244732) "
                            points="221.287333 171.032779 229.70855 171.051077 229.726848 179.456684 221.305631 179.438386"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="137"
                            id="a"
                            fill="#ff9650"
                            transform="translate(213.009414, 184.280330) rotate(-38.540000) translate(-213.009414, -184.280330) "
                            points="208.79079 180.066153 217.20865 180.085542 217.228039 188.494506 208.810179 188.475117"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="127"
                            id="a"
                            fill="#ff9650"
                            transform="translate(201.366464, 194.383865) rotate(-43.630000) translate(-201.366464, -194.383865) "
                            points="197.149347 190.167699 205.563711 190.187569 205.583581 198.600031 197.169217 198.58016"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="117"
                            id="a"
                            fill="#ff9650"
                            transform="translate(183.648404, 213.965494) rotate(-52.360000) translate(-183.648404, -213.965494) "
                            points="179.434605 209.74664 187.842962 209.76588 187.862202 218.184347 179.453845 218.165107"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="87"
                            id="a"
                            fill="#ff9650"
                            transform="translate(174.767401, 226.544600) rotate(-57.450000) translate(-174.767401, -226.544600) "
                            points="170.555861 222.324685 178.960898 222.342728 178.978941 230.764516 170.573905 230.746473"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="64"
                            id="a"
                            fill="#ff9650"
                            transform="translate(167.042735, 239.858312) rotate(-62.540000) translate(-167.042735, -239.858312) "
                            points="162.833605 235.63775 171.235585 235.654029 171.251864 244.078874 162.849885 244.062595"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="54"
                            id="a"
                            fill="#ff9650"
                            transform="translate(160.535327, 253.801624) rotate(-67.630000) translate(-160.535327, -253.801624) "
                            points="156.328685 249.580852 164.727967 249.594854 164.74197 258.022396 156.342687 258.008394"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="44"
                            id="a"
                            fill="#ff9650"
                            transform="translate(152.351392, 278.862918) rotate(-76.360000) translate(-152.351392, -278.862918) "
                            points="148.148967 274.642813 156.544699 274.651931 156.553817 283.083023 148.158085 283.073906"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="18"
                            id="a"
                            fill="#ff9650"
                            transform="translate(149.378828, 293.949692) rotate(-81.450000) translate(-149.378828, -293.949692) "
                            points="145.178704 289.730554 153.573103 289.736403 153.578952 298.168829 145.184554 298.16298"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="9"
                            id="a"
                            fill="#ff9650"
                            transform="translate(147.762837, 309.239454) rotate(-86.540000) translate(-147.762837, -309.239454) "
                            points="143.564806 305.021676 151.958471 305.024073 151.960867 313.457233 143.567203 313.454836"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="0"
                            id="a"
                            fill="#ff9650"
                            transform="translate(147.516162, 324.611618) rotate(-91.630000) translate(-147.516162, -324.611618) "
                            points="143.319952 320.395547 151.713504 320.394416 151.712373 328.827689 143.318821 328.82882"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="264"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.146451, 131.293171) rotate(-4.000000) translate(-308.146451, -131.293171) "
                            points="303.928511 127.09493 312.361623 127.097699 312.364391 135.491412 303.93128 135.488643"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="254"
                            id="a"
                            fill="#ff9650"
                            transform="translate(294.974690, 132.671048) rotate(-8.000000) translate(-294.974690, -132.671048) "
                            points="290.755682 128.471161 299.188216 128.476644 299.193699 136.870935 290.761165 136.865451"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="219"
                            id="a"
                            fill="#ff9650"
                            transform="translate(281.931587, 134.960049) rotate(-12.000000) translate(-281.931587, -134.960049) "
                            points="277.711748 130.758384 286.143334 130.766475 286.151425 139.161714 277.71984 139.153623"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="211"
                            id="a"
                            fill="#ff9650"
                            transform="translate(269.080685, 138.149023) rotate(-16.000000) translate(-269.080685, -138.149023) "
                            points="264.860273 133.945481 273.290555 133.956023 273.301097 142.352565 264.870814 142.342023"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="201"
                            id="a"
                            fill="#ff9650"
                            transform="translate(256.484593, 142.222433) rotate(-20.000000) translate(-256.484593, -142.222433) "
                            points="252.263874 138.016953 260.692525 138.02974 260.705312 146.427913 252.276661 146.415126"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="189"
                            id="a"
                            fill="#ff9650"
                            transform="translate(232.300767, 152.938969) rotate(-28.000000) translate(-232.300767, -152.938969) "
                            points="228.080253 148.729579 236.504789 148.746071 236.521281 157.148359 228.096745 157.131867"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="175"
                            id="a"
                            fill="#ff9650"
                            transform="translate(220.830854, 159.529885) rotate(-32.000000) translate(-220.830854, -159.529885) "
                            points="216.610848 155.3186 225.032981 155.336479 225.05086 163.741171 216.628728 163.723291"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="146"
                            id="a"
                            fill="#ff9650"
                            transform="translate(209.850820, 166.901072) rotate(-36.000000) translate(-209.850820, -166.901072) "
                            points="205.63158 162.68798 214.05114 162.706899 214.070059 171.114164 205.6505 171.095245"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="138"
                            id="a"
                            fill="#ff9650"
                            transform="translate(199.414157, 175.016618) rotate(-40.000000) translate(-199.414157, -175.016618) "
                            points="195.195929 170.801844 203.612795 170.821435 203.632386 179.231393 195.215519 179.211802"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="128"
                            id="a"
                            fill="#ff9650"
                            transform="translate(189.571713, 183.836986) rotate(-44.000000) translate(-189.571713, -183.836986) "
                            points="185.35472 179.620686 193.768826 179.640567 193.788707 188.053285 185.374601 188.033404"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="118"
                            id="a"
                            fill="#ff9650"
                            transform="translate(171.858158, 203.417072) rotate(-52.000000) translate(-171.858158, -203.417072) "
                            points="167.644207 199.198308 176.052807 199.21761 176.072109 207.635835 167.663509 207.616533"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="96"
                            id="a"
                            fill="#ff9650"
                            transform="translate(164.073345, 214.081398) rotate(-56.000000) translate(-164.073345, -214.081398) "
                            points="159.861143 209.861744 168.267103 209.880188 168.285548 218.301052 159.879587 218.282608"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="88"
                            id="a"
                            fill="#ff9650"
                            transform="translate(157.054928, 225.260225) rotate(-60.000000) translate(-157.054928, -225.260225) "
                            points="152.844581 221.039932 161.248047 221.05716 161.265275 229.480519 152.861809 229.463291"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="65"
                            id="a"
                            fill="#ff9650"
                            transform="translate(150.837099, 236.899092) rotate(-64.000000) translate(-150.837099, -236.899092) "
                            points="146.628678 232.678425 155.029843 232.694101 155.045519 241.11976 146.644354 241.104084"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="55"
                            id="a"
                            fill="#ff9650"
                            transform="translate(145.450151, 248.941295) rotate(-68.000000) translate(-145.450151, -248.941295) "
                            points="141.24369 244.720525 149.642792 244.734344 149.656611 253.162066 141.257509 253.148247"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="45"
                            id="a"
                            fill="#ff9650"
                            transform="translate(137.269700, 273.999356) rotate(-76.000000) translate(-137.269700, -273.999356) "
                            points="133.067107 269.779198 141.462955 269.788537 141.472294 278.219514 133.076446 278.210175"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="31"
                            id="a"
                            fill="#ff9650"
                            transform="translate(134.516052, 286.893134) rotate(-80.000000) translate(-134.516052, -286.893134) "
                            points="130.315291 282.673679 138.71001 282.680483 138.716814 291.112588 130.322095 291.105784"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="19"
                            id="a"
                            fill="#ff9650"
                            transform="translate(132.672800, 299.946681) rotate(-84.000000) translate(-132.672800, -299.946681) "
                            points="128.473755 295.728178 136.867709 295.732314 136.871845 304.165184 128.477891 304.161048"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="10"
                            id="a"
                            fill="#ff9650"
                            transform="translate(131.748923, 313.096403) rotate(-88.000000) translate(-131.748923, -313.096403) "
                            points="127.551446 308.879081 135.945014 308.880468 135.946401 317.313725 127.552833 317.312337"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="1"
                            id="a"
                            fill="#ff9650"
                            transform="translate(131.748923, 326.278235) rotate(-92.000000) translate(-131.748923, -326.278235) "
                            points="127.552833 322.062301 135.946401 322.060913 135.945014 330.49417 127.551446 330.495557"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="265"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.153122, 115.519430) rotate(-3.690000) translate(-308.153122, -115.519430) "
                            points="303.935275 111.32131 312.368415 111.323865 312.37097 119.717549 303.93783 119.714994"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="255"
                            id="a"
                            fill="#ff9650"
                            transform="translate(296.295405, 116.624636) rotate(-7.010000) translate(-296.295405, -116.624636) "
                            points="292.07664 112.42517 300.509352 112.429989 300.514171 120.824101 292.081459 120.819282"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="239"
                            id="a"
                            fill="#ff9650"
                            transform="translate(284.521898, 118.411458) rotate(-10.330000) translate(-284.521898, -118.411458) "
                            points="280.302376 114.210549 288.734402 114.217568 288.74142 122.612366 280.309395 122.605348"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="220"
                            id="a"
                            fill="#ff9650"
                            transform="translate(272.837258, 120.882327) rotate(-13.660000) translate(-272.837258, -120.882327) "
                            points="268.61715 116.679893 277.048236 116.689023 277.057366 125.084761 268.62628 125.075631"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="212"
                            id="a"
                            fill="#ff9650"
                            transform="translate(261.350864, 124.014114) rotate(-16.980000) translate(-261.350864, -124.014114) "
                            points="257.130351 119.810101 265.560263 119.821214 265.571376 128.218126 257.141464 128.207014"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="202"
                            id="a"
                            fill="#ff9650"
                            transform="translate(250.065977, 127.802712) rotate(-20.300000) translate(-250.065977, -127.802712) "
                            points="245.845246 123.597085 254.273762 123.610031 254.286708 132.008339 245.858192 131.995394"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="190"
                            id="a"
                            fill="#ff9650"
                            transform="translate(225.860692, 138.526239) rotate(-27.690000) translate(-225.860692, -138.526239) "
                            points="221.64015 134.316998 230.064864 134.333369 230.081234 142.735479 221.65652 142.719109"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="176"
                            id="a"
                            fill="#ff9650"
                            transform="translate(215.479787, 144.336109) rotate(-31.010000) translate(-215.479787, -144.336109) "
                            points="211.25963 140.125286 219.682376 140.142854 219.699943 148.546933 211.277198 148.529365"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="158"
                            id="a"
                            fill="#ff9650"
                            transform="translate(205.454364, 150.734577) rotate(-34.330000) translate(-205.454364, -150.734577) "
                            points="201.234774 146.522226 209.655425 146.540755 209.673954 154.946928 201.253302 154.9284"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="147"
                            id="a"
                            fill="#ff9650"
                            transform="translate(195.789670, 157.721979) rotate(-37.660000) translate(-195.789670, -157.721979) "
                            points="191.570822 153.508172 199.989275 153.527415 200.008519 161.935786 191.590065 161.916543"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="139"
                            id="a"
                            fill="#ff9650"
                            transform="translate(186.576177, 165.232906) rotate(-40.980000) translate(-186.576177, -165.232906) "
                            points="182.358231 161.017742 190.774426 161.037439 190.794123 169.448069 182.377929 169.428372"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="129"
                            id="a"
                            fill="#ff9650"
                            transform="translate(177.815186, 173.262285) rotate(-44.300000) translate(-177.815186, -173.262285) "
                            points="173.598294 169.045879 182.012192 169.065766 182.032079 177.478692 173.618181 177.458805"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="119"
                            id="a"
                            fill="#ff9650"
                            transform="translate(160.084884, 192.857444) rotate(-51.690000) translate(-160.084884, -192.857444) "
                            points="155.870803 188.63876 164.279612 188.658113 164.298965 197.076128 155.890156 197.056775"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="107"
                            id="a"
                            fill="#ff9650"
                            transform="translate(152.975744, 202.367400) rotate(-55.010000) translate(-152.975744, -202.367400) "
                            points="148.763097 198.147944 157.169699 198.166634 157.18839 206.586857 148.781788 206.568166"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="89"
                            id="a"
                            fill="#ff9650"
                            transform="translate(146.431891, 212.271161) rotate(-58.330000) translate(-146.431891, -212.271161) "
                            points="142.220759 208.051103 150.625246 208.068881 150.643023 216.491219 142.238537 216.473441"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="73"
                            id="a"
                            fill="#ff9650"
                            transform="translate(140.458258, 222.566910) rotate(-61.660000) translate(-140.458258, -222.566910) "
                            points="136.248704 218.346429 144.651189 218.363052 144.667812 226.787391 136.265327 226.770769"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="66"
                            id="a"
                            fill="#ff9650"
                            transform="translate(135.110763, 233.158269) rotate(-64.980000) translate(-135.110763, -233.158269) "
                            points="130.902821 228.937551 139.303458 228.952798 139.318705 237.378987 130.918069 237.363739"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="56"
                            id="a"
                            fill="#ff9650"
                            transform="translate(130.388523, 244.040077) rotate(-68.300000) translate(-130.388523, -244.040077) "
                            points="126.18221 239.81931 134.581168 239.832978 134.594837 248.260844 126.195878 248.247176"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="46"
                            id="a"
                            fill="#ff9650"
                            transform="translate(122.198933, 269.118687) rotate(-75.690000) translate(-122.198933, -269.118687) "
                            points="117.996194 264.898486 126.392144 264.908014 126.401673 273.338889 118.005723 273.32936"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="32"
                            id="a"
                            fill="#ff9650"
                            transform="translate(119.590793, 280.684371) rotate(-79.010000) translate(-119.590793, -280.684371) "
                            points="115.389588 276.464718 123.784553 276.472164 123.791998 284.904023 115.397033 284.896578"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="30"
                            id="a"
                            fill="#ff9650"
                            transform="translate(117.660003, 292.380974) rotate(-82.330000) translate(-117.660003, -292.380974) "
                            points="113.460257 288.162045 121.854485 288.167308 121.859748 296.599904 113.46552 296.594641"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="20"
                            id="a"
                            fill="#ff9650"
                            transform="translate(116.410325, 304.204842) rotate(-85.660000) translate(-116.410325, -304.204842) "
                            points="112.211951 299.986802 120.605698 299.989805 120.6087 308.422882 112.214953 308.41988"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="11"
                            id="a"
                            fill="#ff9650"
                            transform="translate(115.853459, 316.045291) rotate(-88.980000) translate(-115.853459, -316.045291) "
                            points="111.656339 311.82829 120.049871 311.828998 120.050579 320.262291 111.657047 320.261583"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="2"
                            id="a"
                            fill="#ff9650"
                            transform="translate(115.986488, 327.897964) rotate(-92.300000) translate(-115.986488, -327.897964) "
                            points="111.790494 323.682141 120.184077 323.680546 120.182482 332.113787 111.788898 332.115382"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="266"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.142579, 83.987670) rotate(-3.200000) translate(-308.142579, -83.987670) "
                            points="303.92488 79.78974 312.358061 79.7919575 312.360278 88.1856009 303.927097 88.1833834"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="256"
                            id="a"
                            fill="#ff9650"
                            transform="translate(296.054789, 84.969381) rotate(-6.130000) translate(-296.054789, -84.969381) "
                            points="291.836251 80.7702822 300.269102 80.7745064 300.273327 89.1684795 291.840475 89.1642553"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="240"
                            id="a"
                            fill="#ff9650"
                            transform="translate(284.033220, 86.564771) rotate(-9.060000) translate(-284.033220, -86.564771) "
                            points="279.813967 82.3644243 288.246285 82.3706111 288.252472 90.7651171 279.820154 90.7589302"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="233"
                            id="a"
                            fill="#ff9650"
                            transform="translate(272.068809, 88.778232) rotate(-12.000000) translate(-272.068809, -88.778232) "
                            points="267.848971 84.5765664 276.280556 84.5846575 276.288647 92.9798968 267.857062 92.9718056"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="221"
                            id="a"
                            fill="#ff9650"
                            transform="translate(260.274211, 91.588922) rotate(-14.930000) translate(-260.274211, -91.588922) "
                            points="256.053927 87.3858898 264.484591 87.3957941 264.494495 95.7919544 256.063831 95.7820501"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="213"
                            id="a"
                            fill="#ff9650"
                            transform="translate(248.639384, 94.995985) rotate(-17.860000) translate(-248.639384, -94.995985) "
                            points="244.418796 90.7915472 252.848359 90.8031611 252.859973 99.2004228 244.43041 99.1888089"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="203"
                            id="a"
                            fill="#ff9650"
                            transform="translate(237.156047, 99.005140) rotate(-20.800000) translate(-237.156047, -99.005140) "
                            points="232.9353 94.7992682 241.363588 94.8124755 241.376795 103.211012 232.948507 103.197805"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="191"
                            id="a"
                            fill="#ff9650"
                            transform="translate(212.965146, 109.724811) rotate(-27.200000) translate(-212.965146, -109.724811) "
                            points="208.744563 105.515808 217.169555 105.531983 217.18573 113.933815 208.760738 113.91764"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="177"
                            id="a"
                            fill="#ff9650"
                            transform="translate(202.323591, 115.515001) rotate(-30.130000) translate(-202.323591, -115.515001) "
                            points="198.103314 111.304592 206.526595 111.321865 206.543867 119.725409 198.120587 119.708137"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="167"
                            id="a"
                            fill="#ff9650"
                            transform="translate(191.993320, 121.839007) rotate(-33.060000) translate(-191.993320, -121.839007) "
                            points="187.773492 117.627233 196.194958 117.645422 196.213148 126.050782 187.791682 126.032592"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="159"
                            id="a"
                            fill="#ff9650"
                            transform="translate(181.967850, 128.704511) rotate(-36.000000) translate(-181.967850, -128.704511) "
                            points="177.748611 124.491418 186.16817 124.510338 186.18709 132.917603 177.76753 132.898683"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="148"
                            id="a"
                            fill="#ff9650"
                            transform="translate(172.341579, 136.046867) rotate(-38.930000) translate(-172.341579, -136.046867) "
                            points="168.123057 131.832529 176.540653 131.851977 176.560101 140.261205 168.142505 140.241757"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="140"
                            id="a"
                            fill="#ff9650"
                            transform="translate(163.104981, 143.869359) rotate(-41.860000) translate(-163.104981, -143.869359) "
                            points="158.8873 139.653854 167.302889 139.673627 167.322662 148.084864 158.907074 148.06509"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="130"
                            id="a"
                            fill="#ff9650"
                            transform="translate(154.252831, 152.180563) rotate(-44.800000) translate(-154.252831, -152.180563) "
                            points="150.036109 147.96398 158.44966 147.983873 158.469553 156.397146 150.056001 156.377254"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="120"
                            id="a"
                            fill="#ff9650"
                            transform="translate(136.534093, 171.766377) rotate(-51.200000) translate(-136.534093, -171.766377) "
                            points="132.319809 167.547821 140.728949 167.56725 140.748378 175.984934 132.339237 175.965505"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="108"
                            id="a"
                            fill="#ff9650"
                            transform="translate(129.178794, 181.363870) rotate(-54.130000) translate(-129.178794, -181.363870) "
                            points="124.965759 177.144601 133.372938 177.163492 133.391829 185.583138 124.98465 185.564247"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="97"
                            id="a"
                            fill="#ff9650"
                            transform="translate(122.326020, 191.323014) rotate(-57.060000) translate(-122.326020, -191.323014) "
                            points="118.1143 187.103165 126.519583 187.121321 126.537739 195.542863 118.132456 195.524707"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="90"
                            id="a"
                            fill="#ff9650"
                            transform="translate(115.972985, 201.653452) rotate(-60.000000) translate(-115.972985, -201.653452) "
                            points="111.762638 197.433159 120.166104 197.450387 120.183332 205.873745 111.779866 205.856518"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="74"
                            id="a"
                            fill="#ff9650"
                            transform="translate(110.179510, 212.257914) rotate(-62.930000) translate(-110.179510, -212.257914) "
                            points="105.970569 208.03732 114.372328 208.053443 114.38845 216.478508 105.986691 216.462386"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="67"
                            id="a"
                            fill="#ff9650"
                            transform="translate(104.938234, 223.143255) rotate(-65.860000) translate(-104.938234, -223.143255) "
                            points="100.730723 218.922506 109.130896 218.937354 109.145745 227.364005 100.745571 227.349156"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="57"
                            id="a"
                            fill="#ff9650"
                            transform="translate(100.247887, 234.319426) rotate(-68.800000) translate(-100.247887, -234.319426) "
                            points="96.0418187 230.098668 104.440541 230.112082 104.453955 238.540184 96.0552325 238.52677"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="47"
                            id="a"
                            fill="#ff9650"
                            transform="translate(92.065043, 259.384818) rotate(-75.200000) translate(-92.065043, -259.384818) "
                            points="87.8620725 255.16455 96.258188 255.174376 96.2680139 263.605085 87.8718984 263.595259"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="33"
                            id="a"
                            fill="#ff9650"
                            transform="translate(88.274017, 276.100357) rotate(-79.360000) translate(-88.274017, -276.100357) "
                            points="84.0729695 271.880773 92.4678453 271.887993 92.4750649 280.319941 84.0801892 280.312722"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="21"
                            id="a"
                            fill="#ff9650"
                            transform="translate(84.845147, 302.233784) rotate(-85.760000) translate(-84.845147, -302.233784) "
                            points="80.6468121 298.015774 89.040549 298.018707 89.0434825 306.451795 80.6497456 306.448861"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="12"
                            id="a"
                            fill="#ff9650"
                            transform="translate(84.220879, 316.267706) rotate(-89.170000) translate(-84.220879, -316.267706) "
                            points="80.0238265 312.05077 88.4173543 312.051346 88.4179306 320.484643 80.0244028 320.484067"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="3"
                            id="a"
                            fill="#ff9650"
                            transform="translate(84.436418, 330.313738) rotate(-92.580000) translate(-84.436418, -330.313738) "
                            points="80.2405124 326.09802 88.6341124 326.096231 88.6323233 334.529455 80.2387233 334.531245"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="267"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.141745, 68.226827) rotate(-3.000000) translate(-308.141745, -68.226827) "
                            points="303.924108 64.0289732 312.357304 64.0310526 312.359383 72.424681 303.926187 72.4226016"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="257"
                            id="a"
                            fill="#ff9650"
                            transform="translate(294.937085, 69.261154) rotate(-6.000000) translate(-294.937085, -69.261154) "
                            points="290.718582 65.0621086 299.151452 65.0662445 299.155588 73.4601986 290.722718 73.4560627"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="241"
                            id="a"
                            fill="#ff9650"
                            transform="translate(281.804911, 70.981881) rotate(-9.000000) translate(-281.804911, -70.981881) "
                            points="277.585671 66.7815607 286.018003 66.7877079 286.02415 75.182201 277.591819 75.1760538"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="234"
                            id="a"
                            fill="#ff9650"
                            transform="translate(268.781216, 73.384292) rotate(-12.000000) translate(-268.781216, -73.384292) "
                            points="264.561378 69.1826272 272.992963 69.1907184 273.001054 77.5859576 264.569469 77.5778665"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="222"
                            id="a"
                            fill="#ff9650"
                            transform="translate(255.901699, 76.461803) rotate(-15.000000) translate(-255.901699, -76.461803) "
                            points="251.681406 72.258738 260.112046 72.2686844 260.121992 80.6648689 251.691352 80.6549225"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="214"
                            id="a"
                            fill="#ff9650"
                            transform="translate(243.201660, 80.205979) rotate(-18.000000) translate(-243.201660, -80.205979) "
                            points="238.981061 76.001473 247.410567 76.0131658 247.422259 84.4104844 238.992754 84.3987917"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="204"
                            id="a"
                            fill="#ff9650"
                            transform="translate(230.715910, 84.606556) rotate(-21.000000) translate(-230.715910, -84.606556) "
                            points="226.495157 80.4005857 234.923353 80.4138966 234.936663 88.8125256 226.508468 88.7992147"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="192"
                            id="a"
                            fill="#ff9650"
                            transform="translate(206.523486, 95.326902) rotate(-27.000000) translate(-206.523486, -95.326902) "
                            points="202.302887 91.1179954 210.727992 91.134089 210.744085 99.5358086 202.31898 99.5197149"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="178"
                            id="a"
                            fill="#ff9650"
                            transform="translate(194.883121, 101.617288) rotate(-30.000000) translate(-194.883121, -101.617288) "
                            points="190.662828 97.4069408 199.086187 97.4241685 199.103415 105.827634 190.680056 105.810407"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="168"
                            id="a"
                            fill="#ff9650"
                            transform="translate(183.589483, 108.505388) rotate(-33.000000) translate(-183.589483, -108.505388) "
                            points="179.369645 104.293641 187.791149 104.311814 187.809322 112.717135 179.387818 112.698962"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="160"
                            id="a"
                            fill="#ff9650"
                            transform="translate(172.673527, 115.972323) rotate(-36.000000) translate(-172.673527, -115.972323) "
                            points="168.454288 111.759231 176.873847 111.77815 176.892766 120.185415 168.473207 120.166496"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="149"
                            id="a"
                            fill="#ff9650"
                            transform="translate(162.165172, 123.997627) rotate(-39.000000) translate(-162.165172, -123.997627) "
                            points="157.946669 119.78326 166.364217 119.802718 166.383675 128.211995 157.966127 128.192536"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="141"
                            id="a"
                            fill="#ff9650"
                            transform="translate(152.093221, 132.559303) rotate(-42.000000) translate(-152.093221, -132.559303) "
                            points="147.875584 128.343745 156.291075 128.363529 156.310859 136.774862 147.895367 136.755078"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="131"
                            id="a"
                            fill="#ff9650"
                            transform="translate(142.485281, 141.633884) rotate(-45.000000) translate(-142.485281, -141.633884) "
                            points="138.268629 137.417231 146.682041 137.437124 146.701934 145.850536 138.288522 145.830644"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="121"
                            id="a"
                            fill="#ff9650"
                            transform="translate(124.765428, 161.220931) rotate(-51.000000) translate(-124.765428, -161.220931) "
                            points="120.551061 157.002428 128.960337 157.021886 128.979795 165.439434 120.570519 165.419976"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="109"
                            id="a"
                            fill="#ff9650"
                            transform="translate(116.702084, 171.679711) rotate(-54.000000) translate(-116.702084, -171.679711) "
                            points="112.488992 167.460472 120.896257 167.479391 120.915176 175.89895 112.507911 175.880031"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="98"
                            id="a"
                            fill="#ff9650"
                            transform="translate(109.199755, 182.544169) rotate(-57.000000) translate(-109.199755, -182.544169) "
                            points="104.988008 178.324331 113.393329 178.342504 113.411502 186.764008 105.006181 186.745835"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="91"
                            id="a"
                            fill="#ff9650"
                            transform="translate(102.279004, 193.784528) rotate(-60.000000) translate(-102.279004, -193.784528) "
                            points="98.0686576 189.564234 106.472123 189.581462 106.489351 198.004821 98.0858853 197.987593"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="75"
                            id="a"
                            fill="#ff9650"
                            transform="translate(95.958802, 205.369977) rotate(-63.000000) translate(-95.958802, -205.369977) "
                            points="91.7498955 201.149377 100.151615 201.165471 100.167709 209.590576 91.7659891 209.574482"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="68"
                            id="a"
                            fill="#ff9650"
                            transform="translate(90.256471, 217.268762) rotate(-66.000000) translate(-90.256471, -217.268762) "
                            points="86.0490287 213.048008 94.44913 213.062792 94.4639133 221.489515 86.0638119 221.474731"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="58"
                            id="a"
                            fill="#ff9650"
                            transform="translate(85.187641, 229.448269) rotate(-69.000000) translate(-85.187641, -229.448269) "
                            points="80.9816709 225.227515 89.3802999 225.240826 89.3936108 233.669022 80.9949818 233.655711"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="48"
                            id="a"
                            fill="#ff9650"
                            transform="translate(77.004282, 254.515238) rotate(-75.000000) translate(-77.004282, -254.515238) "
                            points="72.8012166 250.294945 81.1974011 250.304892 81.2073476 258.735532 72.811163 258.725585"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="34"
                            id="a"
                            fill="#ff9650"
                            transform="translate(72.571894, 274.058696) rotate(-79.560000) translate(-72.571894, -274.058696) "
                            points="68.3709362 269.839152 76.765762 269.846242 76.772852 278.27824 68.3780262 278.27115"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="22"
                            id="a"
                            fill="#ff9650"
                            transform="translate(69.142808, 300.193769) rotate(-85.560000) translate(-69.142808, -300.193769) "
                            points="64.944394 295.9757 73.3381518 295.978771 73.3412226 304.411837 64.9474647 304.408767"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="13"
                            id="a"
                            fill="#ff9650"
                            transform="translate(68.419057, 315.468473) rotate(-89.040000) translate(-68.419057, -315.468473) "
                            points="64.2219585 311.251493 72.6154891 311.25216 72.6161556 319.685454 64.222625 319.684787"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="4"
                            id="a"
                            fill="#ff9650"
                            transform="translate(68.628212, 330.758737) rotate(-92.520000) translate(-68.628212, -330.758737) "
                            points="64.4322873 326.542996 72.8258837 326.541249 72.8241361 334.974477 64.4305397 334.976224"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="268"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.157593, 52.467876) rotate(-2.820000) translate(-308.157593, -52.467876) "
                            points="303.940011 48.2700905 312.37322 48.2720455 312.375175 56.6656612 303.941966 56.6637062"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="258"
                            id="a"
                            fill="#ff9650"
                            transform="translate(297.440149, 53.207229) rotate(-5.110000) translate(-297.440149, -53.207229) "
                            points="293.22189 49.008547 301.654879 49.0120766 301.658409 57.4059116 293.225419 57.402382"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="246"
                            id="a"
                            fill="#ff9650"
                            transform="translate(286.714422, 54.378231) rotate(-7.410000) translate(-286.714422, -54.378231) "
                            points="282.495557 50.1785966 290.9282 50.1836849 290.933288 58.577866 282.500645 58.5727778"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="242"
                            id="a"
                            fill="#ff9650"
                            transform="translate(276.090798, 55.968830) rotate(-9.700000) translate(-276.090798, -55.968830) "
                            points="271.871407 51.768202 280.303582 51.7748097 280.31019 60.1694586 271.878014 60.1628509"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="235"
                            id="a"
                            fill="#ff9650"
                            transform="translate(265.493624, 57.990353) rotate(-12.000000) translate(-265.493624, -57.990353) "
                            points="261.273785 53.7886881 269.705371 53.7967792 269.713462 62.1920184 261.281877 62.1839273"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="227"
                            id="a"
                            fill="#ff9650"
                            transform="translate(255.031962, 60.421995) rotate(-14.290000) translate(-255.031962, -60.421995) "
                            points="250.811763 56.2192653 259.242644 56.2287817 259.252161 64.6247251 250.82128 64.6152087"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="223"
                            id="a"
                            fill="#ff9650"
                            transform="translate(244.676278, 63.267744) rotate(-16.580000) translate(-244.676278, -63.267744) "
                            points="240.455804 59.0639239 248.88587 59.0748049 248.896751 67.4715639 240.466685 67.460683"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="215"
                            id="a"
                            fill="#ff9650"
                            transform="translate(234.398718, 66.538160) rotate(-18.880000) translate(-234.398718, -66.538160) "
                            points="230.178057 62.3332268 238.607197 62.3454082 238.619378 70.7430936 230.190239 70.7309121"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="205"
                            id="a"
                            fill="#ff9650"
                            transform="translate(224.305056, 70.199586) rotate(-21.170000) translate(-224.305056, -70.199586) "
                            points="220.084299 65.9935324 228.512415 66.0069308 228.525813 74.405639 220.097697 74.3922406"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="193"
                            id="a"
                            fill="#ff9650"
                            transform="translate(200.097838, 80.923968) rotate(-26.820000) translate(-200.097838, -80.923968) "
                            points="195.877225 76.715149 204.302431 76.7311688 204.318451 85.1327875 195.893245 85.1167676"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="183"
                            id="a"
                            fill="#ff9650"
                            transform="translate(190.609114, 85.938013) rotate(-29.110000) translate(-190.609114, -85.938013) "
                            points="186.388714 81.7280901 194.812603 81.7450005 194.829514 90.147936 186.405625 90.1310256"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="179"
                            id="a"
                            fill="#ff9650"
                            transform="translate(181.289222, 91.349742) rotate(-31.410000) translate(-181.289222, -91.349742) "
                            points="177.069124 87.1387309 185.491623 87.1564271 185.509319 95.5607525 177.08682 95.5430563"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="169"
                            id="a"
                            fill="#ff9650"
                            transform="translate(172.234080, 97.103458) rotate(-33.700000) translate(-172.234080, -97.103458) "
                            points="168.014369 92.8913918 176.435425 92.9097571 176.453791 101.315525 168.032734 101.297159"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="161"
                            id="a"
                            fill="#ff9650"
                            transform="translate(163.379204, 103.240136) rotate(-36.000000) translate(-163.379204, -103.240136) "
                            points="159.159964 99.0270439 167.579524 99.0459632 167.598443 107.453228 159.178884 107.434309"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="154"
                            id="a"
                            fill="#ff9650"
                            transform="translate(154.815726, 109.696618) rotate(-38.290000) translate(-154.815726, -109.696618) "
                            points="150.597037 105.482546 159.015066 105.501895 159.034416 113.910691 150.616386 113.891341"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="150"
                            id="a"
                            fill="#ff9650"
                            transform="translate(146.518295, 116.488504) rotate(-40.580000) translate(-146.518295, -116.488504) "
                            points="142.300232 112.273498 150.716701 112.293155 150.736358 120.70351 142.319888 120.683854"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="142"
                            id="a"
                            fill="#ff9650"
                            transform="translate(138.465780, 123.636717) rotate(-42.880000) translate(-138.465780, -123.636717) "
                            points="134.248419 119.420827 142.663302 119.440666 142.683141 127.852607 134.268257 127.832769"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="132"
                            id="a"
                            fill="#ff9650"
                            transform="translate(130.741056, 131.067690) rotate(-45.170000) translate(-130.741056, -131.067690) "
                            points="126.524463 126.850978 134.937757 126.870871 134.957649 135.284401 126.544355 135.264509"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="122"
                            id="a"
                            fill="#ff9650"
                            transform="translate(113.009338, 150.664413) rotate(-50.820000) translate(-113.009338, -150.664413) "
                            points="108.794896 146.445958 117.204295 146.465442 117.223779 154.882868 108.81438 154.863384"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="110"
                            id="a"
                            fill="#ff9650"
                            transform="translate(106.390019, 159.086175) rotate(-53.110000) translate(-106.390019, -159.086175) "
                            points="102.176541 154.86714 110.584396 154.886241 110.603497 163.30521 102.195642 163.286109"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="103"
                            id="a"
                            fill="#ff9650"
                            transform="translate(100.087456, 167.802894) rotate(-55.410000) translate(-100.087456, -167.802894) "
                            points="95.8749881 163.583355 104.28133 163.601949 104.299924 172.022432 95.8935819 172.003838"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="99"
                            id="a"
                            fill="#ff9650"
                            transform="translate(94.166512, 176.724858) rotate(-57.700000) translate(-94.166512, -176.724858) "
                            points="89.9550874 172.5049 98.3599669 172.52287 98.3779368 180.944815 89.9730573 180.926845"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="92"
                            id="a"
                            fill="#ff9650"
                            transform="translate(88.585023, 185.915603) rotate(-60.000000) translate(-88.585023, -185.915603) "
                            points="84.3746767 181.69531 92.7781426 181.712538 92.7953703 190.135896 84.3919044 190.118669"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="80"
                            id="a"
                            fill="#ff9650"
                            transform="translate(83.400433, 195.280541) rotate(-62.290000) translate(-83.400433, -195.280541) "
                            points="79.1911829 191.060001 87.5933049 191.076379 87.6096833 199.501082 79.2075614 199.484703"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="76"
                            id="a"
                            fill="#ff9650"
                            transform="translate(78.595956, 204.844186) rotate(-64.580000) translate(-78.595956, -204.844186) "
                            points="74.3878182 200.623486 82.7886683 200.638911 82.804093 209.064885 74.4032428 209.049461"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="69"
                            id="a"
                            fill="#ff9650"
                            transform="translate(74.160839, 214.634204) rotate(-66.880000) translate(-74.160839, -214.634204) "
                            points="69.9538282 210.413435 78.3534818 210.427803 78.3678493 218.854974 69.9681957 218.840606"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="59"
                            id="a"
                            fill="#ff9650"
                            transform="translate(70.140728, 224.549841) rotate(-69.170000) translate(-70.140728, -224.549841) "
                            points="65.9348411 220.329093 74.3333913 220.342316 74.3466143 228.77059 65.948064 228.757367"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="49"
                            id="a"
                            fill="#ff9650"
                            transform="translate(61.950484, 249.630454) rotate(-74.820000) translate(-61.950484, -249.630454) "
                            points="57.7473329 245.410138 66.1435803 245.420192 66.1536348 253.85077 57.7573874 253.840715"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="39"
                            id="a"
                            fill="#ff9650"
                            transform="translate(59.168341, 260.777809) rotate(-77.280000) translate(-59.168341, -260.777809) "
                            points="54.9663443 256.557848 63.3617926 256.566394 63.3703379 264.99777 54.9748896 264.989225"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="35"
                            id="a"
                            fill="#ff9650"
                            transform="translate(56.877857, 271.987795) rotate(-79.730000) translate(-56.877857, -271.987795) "
                            points="52.6769748 267.768285 61.0717588 267.775265 61.0787385 276.207305 52.6839544 276.200326"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="23"
                            id="a"
                            fill="#ff9650"
                            transform="translate(53.444514, 298.137535) rotate(-85.380000) translate(-53.444514, -298.137535) "
                            points="49.2460285 293.919415 57.6398061 293.922609 57.6430003 302.355656 49.2492227 302.352462"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="14"
                            id="a"
                            fill="#ff9650"
                            transform="translate(52.618852, 314.644543) rotate(-88.920000) translate(-52.618852, -314.644543) "
                            points="48.42171 310.427522 56.8152436 310.428272 56.8159933 318.861563 48.4224598 318.860813"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="5"
                            id="a"
                            fill="#ff9650"
                            transform="translate(52.818827, 331.170794) rotate(-92.460000) translate(-52.818827, -331.170794) "
                            points="48.6228833 326.955031 57.016476 326.953325 57.0147699 335.386557 48.6211772 335.388263"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="269"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.173557, 36.711269) rotate(-2.660000) translate(-308.173557, -36.711269) "
                            points="303.956025 32.5135441 312.389244 32.5153886 312.391089 40.9089937 303.95787 40.9071493"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="259"
                            id="a"
                            fill="#ff9650"
                            transform="translate(296.576078, 37.484009) rotate(-5.000000) translate(-296.576078, -37.484009) "
                            points="292.357849 33.2853712 300.790852 33.2888256 300.794306 41.6826472 292.361303 41.6791929"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="247"
                            id="a"
                            fill="#ff9650"
                            transform="translate(285.069239, 38.721077) rotate(-7.330000) translate(-285.069239, -38.721077) "
                            points="280.850393 34.5214758 289.28305 34.5265103 289.288085 42.9206774 280.855427 42.9156429"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="243"
                            id="a"
                            fill="#ff9650"
                            transform="translate(273.622445, 40.422724) rotate(-9.660000) translate(-273.622445, -40.422724) "
                            points="269.403062 36.2221138 277.835246 36.2286952 277.841828 44.6233349 269.409643 44.6167535"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="236"
                            id="a"
                            fill="#ff9650"
                            transform="translate(262.206031, 42.596414) rotate(-12.000000) translate(-262.206031, -42.596414) "
                            points="257.986193 38.3947489 266.417778 38.40284 266.425869 46.7980793 257.994284 46.7899881"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="228"
                            id="a"
                            fill="#ff9650"
                            transform="translate(250.936438, 45.219976) rotate(-14.330000) translate(-250.936438, -45.219976) "
                            points="246.716233 41.0172269 255.147101 41.0267677 255.156642 49.4227244 246.725774 49.4131836"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="224"
                            id="a"
                            fill="#ff9650"
                            transform="translate(239.783328, 48.297372) rotate(-16.660000) translate(-239.783328, -48.297372) "
                            points="235.562847 44.0935132 243.992882 44.1044406 244.003809 52.5012301 235.573774 52.4903027"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="216"
                            id="a"
                            fill="#ff9650"
                            transform="translate(228.718172, 51.839606) rotate(-19.000000) translate(-228.718172, -51.839606) "
                            points="224.497505 47.6346142 232.926593 47.6468615 232.93884 56.044598 224.509752 56.0323507"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="206"
                            id="a"
                            fill="#ff9650"
                            transform="translate(217.853828, 55.810551) rotate(-21.330000) translate(-217.853828, -55.810551) "
                            points="213.633067 51.6044188 222.061108 51.6178991 222.074589 60.0166825 213.646548 60.0032021"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="194"
                            id="a"
                            fill="#ff9650"
                            transform="translate(193.673255, 66.523129) rotate(-26.660000) translate(-193.673255, -66.523129) "
                            points="189.45263 62.3143875 197.877925 62.3303412 197.893879 70.7318706 189.468584 70.7159168"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="184"
                            id="a"
                            fill="#ff9650"
                            transform="translate(183.394222, 71.923928) rotate(-29.000000) translate(-183.394222, -71.923928) "
                            points="179.17381 67.714058 187.597764 67.7309281 187.614634 76.1337987 179.19068 76.1169286"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="180"
                            id="a"
                            fill="#ff9650"
                            transform="translate(173.387747, 77.712219) rotate(-31.330000) translate(-173.387747, -77.712219) "
                            points="169.167637 73.5012452 177.590186 73.518916 177.607857 81.9231921 169.185308 81.9055213"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="170"
                            id="a"
                            fill="#ff9650"
                            transform="translate(163.625983, 83.900617) rotate(-33.660000) translate(-163.625983, -83.900617) "
                            points="159.406265 79.6885688 167.827347 79.7069234 167.845702 88.1126653 159.424619 88.0943107"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="162"
                            id="a"
                            fill="#ff9650"
                            transform="translate(154.084881, 90.507949) rotate(-36.000000) translate(-154.084881, -90.507949) "
                            points="149.865641 86.2948567 158.285201 86.3137759 158.30412 94.721041 149.88456 94.7021217"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="155"
                            id="a"
                            fill="#ff9650"
                            transform="translate(144.861752, 97.466823) rotate(-38.330000) translate(-144.861752, -97.466823) "
                            points="140.643072 93.2527342 149.061075 93.2720903 149.080431 101.680913 140.662429 101.661557"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="151"
                            id="a"
                            fill="#ff9650"
                            transform="translate(135.930502, 104.793142) rotate(-40.660000) translate(-135.930502, -104.793142) "
                            points="131.712462 100.578104 140.128876 100.597769 140.148541 109.008179 131.732127 108.988514"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="143"
                            id="a"
                            fill="#ff9650"
                            transform="translate(127.269565, 112.508506) rotate(-43.000000) translate(-127.269565, -112.508506) "
                            points="123.052242 108.292571 131.467042 108.312416 131.486887 116.72444 123.072087 116.704596"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="133"
                            id="a"
                            fill="#ff9650"
                            transform="translate(118.967277, 120.534224) rotate(-45.330000) translate(-118.967277, -120.534224) "
                            points="114.750739 116.317458 123.163922 116.337349 123.183814 124.75099 114.770631 124.731099"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="123"
                            id="a"
                            fill="#ff9650"
                            transform="translate(101.255075, 140.109377) rotate(-50.660000) translate(-101.255075, -140.109377) "
                            points="97.0405686 135.890966 105.450076 135.910472 105.469582 144.327789 97.0600745 144.308283"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="111"
                            id="a"
                            fill="#ff9650"
                            transform="translate(94.071827, 149.204389) rotate(-53.000000) translate(-94.071827, -149.204389) "
                            points="89.8583013 144.98538 98.2662303 145.004502 98.2853526 153.423397 89.8774235 153.404275"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="104"
                            id="a"
                            fill="#ff9650"
                            transform="translate(87.295927, 158.543054) rotate(-55.330000) translate(-87.295927, -158.543054) "
                            points="83.0834232 154.323532 91.4898168 154.342145 91.5084303 162.762576 83.1020367 162.743962"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="100"
                            id="a"
                            fill="#ff9650"
                            transform="translate(80.907091, 168.148173) rotate(-57.660000) translate(-80.907091, -168.148173) "
                            points="76.6956481 163.928222 85.1005527 163.946204 85.1185345 172.368123 76.7136299 172.350142"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="93"
                            id="a"
                            fill="#ff9650"
                            transform="translate(74.891043, 178.046679) rotate(-60.000000) translate(-74.891043, -178.046679) "
                            points="70.6806959 173.826386 79.0841617 173.843613 79.1013894 182.266972 70.6979236 182.249744"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="81"
                            id="a"
                            fill="#ff9650"
                            transform="translate(69.309141, 188.137614) rotate(-62.330000) translate(-69.309141, -188.137614) "
                            points="65.0999097 183.91707 73.5020088 183.933432 73.5183715 192.358158 65.1162724 192.341795"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="77"
                            id="a"
                            fill="#ff9650"
                            transform="translate(64.144045, 198.446067) rotate(-64.660000) translate(-64.144045, -198.446067) "
                            points="59.9359463 194.225364 68.3367535 194.240753 68.352143 202.666771 59.9513358 202.651381"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="70"
                            id="a"
                            fill="#ff9650"
                            transform="translate(59.384881, 209.000505) rotate(-67.000000) translate(-59.384881, -209.000505) "
                            points="55.1779296 204.779734 63.5775231 204.794044 63.5918328 213.221275 55.1922393 213.206965"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="60"
                            id="a"
                            fill="#ff9650"
                            transform="translate(55.080191, 219.693277) rotate(-69.330000) translate(-55.080191, -219.693277) "
                            points="50.8743825 215.472533 59.2728591 215.485673 59.2859988 223.914021 50.8875222 223.900881"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="50"
                            id="a"
                            fill="#ff9650"
                            transform="translate(46.898962, 244.746283) rotate(-74.660000) translate(-46.898962, -244.746283) "
                            points="42.6957347 240.525948 51.0920385 240.536098 51.1021887 248.966619 42.7058849 248.956469"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="40"
                            id="a"
                            fill="#ff9650"
                            transform="translate(43.743967, 257.312544) rotate(-77.280000) translate(-43.743967, -257.312544) "
                            points="39.5419704 253.092583 47.9374187 253.101128 47.945964 261.532505 39.5505157 261.523959"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="36"
                            id="a"
                            fill="#ff9650"
                            transform="translate(41.178134, 269.960533) rotate(-79.890000) translate(-41.178134, -269.960533) "
                            points="36.9773239 265.741056 45.3720693 265.747931 45.3789448 274.180011 36.9841994 274.173135"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="27"
                            id="a"
                            fill="#ff9650"
                            transform="translate(37.748571, 296.081491) rotate(-85.220000) translate(-37.748571, -296.081491) "
                            points="33.5500214 291.863324 41.9438171 291.866628 41.9471209 300.299657 33.5533252 300.296353"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="24"
                            id="a"
                            fill="#ff9650"
                            transform="translate(36.946183, 309.405660) rotate(-87.920000) translate(-36.946183, -309.405660) "
                            points="32.7486754 305.188312 41.1422472 305.189755 41.1436903 313.623008 32.7501185 313.621565"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="15"
                            id="a"
                            fill="#ff9650"
                            transform="translate(36.774782, 322.703219) rotate(-90.610000) translate(-36.774782, -322.703219) "
                            points="32.5782313 318.48678 40.9717553 318.486356 40.9713317 326.919657 32.5778078 326.920081"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="6"
                            id="a"
                            fill="#ff9650"
                            transform="translate(37.230610, 335.994130) rotate(-93.300000) translate(-37.230610, -335.994130) "
                            points="33.0349273 331.778687 41.4285786 331.7764 41.4262922 340.209574 33.0326409 340.21186"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="270"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.173071, 20.957361) rotate(-2.520000) translate(-308.173071, -20.957361) "
                            points="303.955583 16.7596886 312.388811 16.7614362 312.390558 25.1550325 303.95733 25.1532849"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="260"
                            id="a"
                            fill="#ff9650"
                            transform="translate(298.228940, 21.557499) rotate(-4.420000) translate(-298.228940, -21.557499) "
                            points="294.010878 17.3590925 302.443946 17.3621495 302.447003 25.7559053 294.013935 25.7528482"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="250"
                            id="a"
                            fill="#ff9650"
                            transform="translate(288.362387, 22.479711) rotate(-6.310000) translate(-288.362387, -22.479711) "
                            points="284.143802 18.2805376 292.576626 18.2848839 292.580973 26.6788839 284.148148 26.6745377"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="248"
                            id="a"
                            fill="#ff9650"
                            transform="translate(278.479862, 23.732740) rotate(-8.210000) translate(-278.479862, -23.732740) "
                            points="274.260803 19.5327632 282.693297 19.5383864 282.69892 27.9327172 274.266427 27.9270939"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="244"
                            id="a"
                            fill="#ff9650"
                            transform="translate(268.696134, 25.302035) rotate(-10.100000) translate(-268.696134, -25.302035) "
                            points="264.476658 21.1012292 272.90874 21.1080982 272.915609 29.5028411 264.483527 29.4959722"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="237"
                            id="a"
                            fill="#ff9650"
                            transform="translate(258.918438, 27.202475) rotate(-12.000000) translate(-258.918438, -27.202475) "
                            points="254.6986 23.0008097 263.130186 23.0089009 263.138277 31.4041401 254.706691 31.396049"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="231"
                            id="a"
                            fill="#ff9650"
                            transform="translate(249.260329, 29.411989) rotate(-13.890000) translate(-249.260329, -29.411989) "
                            points="245.040187 25.209447 253.471199 25.2187187 253.480471 33.6145309 245.049458 33.6052592"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="229"
                            id="a"
                            fill="#ff9650"
                            transform="translate(239.680690, 31.937330) rotate(-15.780000) translate(-239.680690, -31.937330) "
                            points="235.460303 27.7338931 243.890665 27.7443049 243.901077 36.1407666 235.470714 36.1303548"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="225"
                            id="a"
                            fill="#ff9650"
                            transform="translate(230.139984, 34.791595) rotate(-17.680000) translate(-230.139984, -34.791595) "
                            points="225.91941 30.5872448 234.349046 30.598757 234.360558 38.995946 225.930923 38.9844338"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="217"
                            id="a"
                            fill="#ff9650"
                            transform="translate(220.749012, 37.941638) rotate(-19.570000) translate(-220.749012, -37.941638) "
                            points="216.528313 33.7363679 224.957154 33.7489246 224.96971 42.1469078 216.540869 42.1343511"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="207"
                            id="a"
                            fill="#ff9650"
                            transform="translate(211.418732, 41.417324) rotate(-21.470000) translate(-211.418732, -41.417324) "
                            points="207.197968 37.2111238 215.625943 37.2246754 215.639495 45.6235248 207.21152 45.6099731"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="197"
                            id="a"
                            fill="#ff9650"
                            transform="translate(187.234746, 52.131415) rotate(-26.520000) translate(-187.234746, -52.131415) "
                            points="183.014112 47.922741 191.439485 47.9386365 191.45538 56.340088 183.030007 56.3241925"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="195"
                            id="a"
                            fill="#ff9650"
                            transform="translate(178.395586, 56.705229) rotate(-28.420000) translate(-178.395586, -56.705229) "
                            points="174.175113 52.4956367 182.599406 52.5122899 182.616059 60.9148212 174.191766 60.898168"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="185"
                            id="a"
                            fill="#ff9650"
                            transform="translate(169.758917, 61.541868) rotate(-30.310000) translate(-169.758917, -61.541868) "
                            points="165.538664 57.331374 173.961835 57.3487084 173.97917 65.7523612 165.555998 65.7350269"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="181"
                            id="a"
                            fill="#ff9650"
                            transform="translate(161.242849, 66.687189) rotate(-32.210000) translate(-161.242849, -66.687189) "
                            points="157.022877 62.475806 165.444878 62.493749 165.462821 70.8985721 157.04082 70.8806291"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="171"
                            id="a"
                            fill="#ff9650"
                            transform="translate(152.946284, 72.081439) rotate(-34.100000) translate(-152.946284, -72.081439) "
                            points="148.726649 67.8691911 157.147449 67.8876613 157.165919 76.293686 148.745119 76.2752158"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="165"
                            id="a"
                            fill="#ff9650"
                            transform="translate(144.790557, 77.775762) rotate(-36.000000) translate(-144.790557, -77.775762) "
                            points="140.571318 73.5626695 148.990878 73.5815887 149.009797 81.9888537 140.590237 81.9699345"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="163"
                            id="a"
                            fill="#ff9650"
                            transform="translate(136.870385, 83.704028) rotate(-37.890000) translate(-136.870385, -83.704028) "
                            points="132.651594 79.4901232 141.069893 79.5094065 141.089176 87.9179322 132.670878 87.8986489"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="156"
                            id="a"
                            fill="#ff9650"
                            transform="translate(129.150967, 89.889050) rotate(-39.780000) translate(-129.150967, -89.889050) "
                            points="124.932677 85.6743641 133.349694 85.6939276 133.369257 94.1037351 124.95224 94.0841716"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="152"
                            id="a"
                            fill="#ff9650"
                            transform="translate(121.601536, 96.358798) rotate(-41.680000) translate(-121.601536, -96.358798) "
                            points="117.3838 92.1433626 125.799513 92.163122 125.819272 100.574234 117.40356 100.554475"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="144"
                            id="a"
                            fill="#ff9650"
                            transform="translate(114.309766, 103.038138) rotate(-43.570000) translate(-114.309766, -103.038138) "
                            points="110.09263 98.8219942 118.507035 98.8418623 118.526903 107.254282 110.112498 107.234414"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="134"
                            id="a"
                            fill="#ff9650"
                            transform="translate(107.206522, 109.990399) rotate(-45.470000) translate(-107.206522, -109.990399) "
                            points="102.990034 105.773584 111.40312 105.793475 111.42301 114.207213 103.009924 114.187323"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="124"
                            id="a"
                            fill="#ff9650"
                            transform="translate(89.491821, 129.568315) rotate(-50.520000) translate(-89.491821, -129.568315) "
                            points="85.2772568 125.349942 93.6868597 125.369467 93.7063844 133.786688 85.2967815 133.767163"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="114"
                            id="a"
                            fill="#ff9650"
                            transform="translate(83.286002, 137.324951) rotate(-52.420000) translate(-83.286002, -137.324951) "
                            points="79.0722291 133.106083 87.4805464 133.125312 87.4997757 141.54382 79.0914584 141.52459"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="112"
                            id="a"
                            fill="#ff9650"
                            transform="translate(77.372575, 145.239718) rotate(-54.310000) translate(-77.372575, -145.239718) "
                            points="73.1596192 141.02041 81.5666798 141.039262 81.5855314 149.459026 73.1784708 149.440174"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="105"
                            id="a"
                            fill="#ff9650"
                            transform="translate(71.695471, 153.387659) rotate(-56.210000) translate(-71.695471, -153.387659) "
                            points="67.4833639 149.167965 75.8891892 149.186354 75.9075784 157.607353 67.5017531 157.588964"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="101"
                            id="a"
                            fill="#ff9650"
                            transform="translate(66.320620, 161.674148) rotate(-58.100000) translate(-66.320620, -161.674148) "
                            points="62.1093813 157.454126 70.5140107 157.471975 70.5318597 165.89417 62.1272303 165.876321"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="94"
                            id="a"
                            fill="#ff9650"
                            transform="translate(61.197062, 170.177754) rotate(-60.000000) translate(-61.197062, -170.177754) "
                            points="56.986715 165.957461 65.3901809 165.974689 65.4074086 174.398047 57.0039427 174.38082"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="84"
                            id="a"
                            fill="#ff9650"
                            transform="translate(56.384297, 178.799721) rotate(-61.890000) translate(-56.384297, -178.799721) "
                            points="52.1748539 174.579218 60.5772056 174.595752 60.5937401 183.020225 52.1913884 183.003691"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="82"
                            id="a"
                            fill="#ff9650"
                            transform="translate(51.859857, 187.574978) rotate(-63.780000) translate(-51.859857, -187.574978) "
                            points="47.6513296 183.354324 56.0526153 183.370093 56.0683847 191.795632 47.6670989 191.779862"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="78"
                            id="a"
                            fill="#ff9650"
                            transform="translate(47.607066, 196.541531) rotate(-65.680000) translate(-47.607066, -196.541531) "
                            points="43.3994667 192.320787 51.799734 192.335718 51.814665 200.762275 43.4143977 200.747344"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="71"
                            id="a"
                            fill="#ff9650"
                            transform="translate(43.675313, 205.595250) rotate(-67.570000) translate(-43.675313, -205.595250) "
                            points="39.4686407 201.374477 47.8679523 201.388509 47.8819843 209.816022 39.4826727 209.80199"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="61"
                            id="a"
                            fill="#ff9650"
                            transform="translate(40.027318, 214.821976) rotate(-69.470000) translate(-40.027318, -214.821976) "
                            points="35.8215787 210.601237 44.2199913 210.614303 44.2330579 219.042715 35.8346453 219.029649"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="51"
                            id="a"
                            fill="#ff9650"
                            transform="translate(31.844935, 239.878518) rotate(-74.520000) translate(-31.844935, -239.878518) "
                            points="27.6416411 235.658166 36.0379947 235.6684 36.0482284 244.098871 27.6518748 244.088637"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="41"
                            id="a"
                            fill="#ff9650"
                            transform="translate(28.319593, 253.847279) rotate(-77.280000) translate(-28.319593, -253.847279) "
                            points="24.1175965 249.627318 32.5130448 249.635863 32.5215901 258.067239 24.1261417 258.058694"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="37"
                            id="a"
                            fill="#ff9650"
                            transform="translate(25.483234, 267.917387) rotate(-80.030000) translate(-25.483234, -267.917387) "
                            points="21.2824854 263.697938 29.6771974 263.704722 29.6839816 272.136835 21.2892696 272.130051"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="28"
                            id="a"
                            fill="#ff9650"
                            transform="translate(22.053186, 294.042031) rotate(-85.080000) translate(-22.053186, -294.042031) "
                            points="17.8545805 289.823825 26.2483925 289.827224 26.2517922 298.260237 17.8579801 298.256837"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="25"
                            id="a"
                            fill="#ff9650"
                            transform="translate(21.165642, 308.260780) rotate(-87.810000) translate(-21.165642, -308.260780) "
                            points="16.9680939 304.043397 25.3616714 304.044916 25.3631907 312.478163 16.9696132 312.476644"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="16"
                            id="a"
                            fill="#ff9650"
                            transform="translate(20.959547, 322.505466) rotate(-90.540000) translate(-20.959547, -322.505466) "
                            points="16.7629731 318.289003 25.156496 318.288628 25.1561211 326.721929 16.7625981 326.722304"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="7"
                            id="a"
                            fill="#ff9650"
                            transform="translate(21.435368, 336.743755) rotate(-93.270000) translate(-21.435368, -336.743755) "
                            points="17.2396769 332.5283 25.6333257 332.526035 25.63106 340.95921 17.2374111 340.961476"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="271"
                            id="a"
                            fill="#ff9650"
                            transform="translate(308.139567, 5.206436) rotate(-2.400000) translate(-308.139567, -5.206436) "
                            points="303.922117 1.00880907 312.355352 1.01047366 312.357017 9.40406285 303.923781 9.40239826"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="261"
                            id="a"
                            fill="#ff9650"
                            transform="translate(297.560675, 5.824597) rotate(-4.320000) translate(-297.560675, -5.824597) "
                            points="293.342642 1.62622979 301.775721 1.6292182 301.778709 10.0229634 293.34563 10.019975"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="251"
                            id="a"
                            fill="#ff9650"
                            transform="translate(287.008532, 6.795174) rotate(-6.240000) translate(-287.008532, -6.795174) "
                            points="282.789965 2.59602961 291.2228 2.60032843 291.227099 10.9943179 282.794264 10.9900191"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="249"
                            id="a"
                            fill="#ff9650"
                            transform="translate(276.494986, 8.117078) rotate(-8.160000) translate(-276.494986, -8.117078) "
                            points="272.275939 3.91712222 280.708443 3.92271214 280.714033 12.3170331 272.281529 12.3114432"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="245"
                            id="a"
                            fill="#ff9650"
                            transform="translate(266.031841, 9.788824) rotate(-10.080000) translate(-266.031841, -9.788824) "
                            points="261.81237 5.58802698 270.244456 5.59488291 270.251312 13.9896211 261.819226 13.9827652"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="238"
                            id="a"
                            fill="#ff9650"
                            transform="translate(255.630846, 11.808536) rotate(-12.000000) translate(-255.630846, -11.808536) "
                            points="251.411008 7.60687058 259.842593 7.61496172 259.850684 16.010201 251.419099 16.0021098"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="232"
                            id="a"
                            fill="#ff9650"
                            transform="translate(245.303679, 14.173945) rotate(-13.920000) translate(-245.303679, -14.173945) "
                            points="241.083533 9.9713891 249.514536 9.98067914 249.523826 18.3765011 241.092823 18.367211"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="230"
                            id="a"
                            fill="#ff9650"
                            transform="translate(235.061937, 16.882396) rotate(-15.840000) translate(-235.061937, -16.882396) "
                            points="230.841543 12.6789306 239.271884 12.6893778 239.282331 21.0858614 230.85199 21.0754141"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="226"
                            id="a"
                            fill="#ff9650"
                            transform="translate(224.917119, 19.930847) rotate(-17.760000) translate(-224.917119, -19.930847) "
                            points="220.696539 15.7264579 229.126142 15.7380154 229.1377 24.1352367 220.708096 24.1236792"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="218"
                            id="a"
                            fill="#ff9650"
                            transform="translate(214.880616, 23.315876) rotate(-19.680000) translate(-214.880616, -23.315876) "
                            points="210.659912 19.1105524 219.088705 19.1231683 219.101321 27.5211999 210.672528 27.508584"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="208"
                            id="a"
                            fill="#ff9650"
                            transform="translate(204.963698, 27.033682) rotate(-21.600000) translate(-204.963698, -27.033682) "
                            points="200.742932 22.8274174 209.170846 22.841035 209.184463 31.239946 200.75655 31.2263284"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="198"
                            id="a"
                            fill="#ff9650"
                            transform="translate(180.767293, 37.755792) rotate(-26.400000) translate(-180.767293, -37.755792) "
                            points="176.546651 33.5471767 184.97209 33.5630219 184.987936 41.964407 176.562496 41.9485617"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="196"
                            id="a"
                            fill="#ff9650"
                            transform="translate(171.355616, 42.603033) rotate(-28.320000) translate(-171.355616, -42.603033) "
                            points="167.135132 38.3934889 175.559484 38.410104 175.576099 46.8125772 167.151747 46.7959621"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="186"
                            id="a"
                            fill="#ff9650"
                            transform="translate(162.112394, 47.761395) rotate(-30.240000) translate(-162.112394, -47.761395) "
                            points="157.892131 43.5509342 166.315345 43.5682446 166.332656 51.9718551 157.909442 51.9545447"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="182"
                            id="a"
                            fill="#ff9650"
                            transform="translate(153.048006, 53.225085) rotate(-32.160000) translate(-153.048006, -53.225085) "
                            points="148.828026 49.0137247 157.250059 49.0316527 157.267987 57.4364445 148.845954 57.4185165"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="172"
                            id="a"
                            fill="#ff9650"
                            transform="translate(144.172631, 58.987968) rotate(-34.080000) translate(-144.172631, -58.987968) "
                            points="139.952992 54.7757297 148.373805 54.7941947 148.39227 63.2002065 139.971457 63.1817415"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="166"
                            id="a"
                            fill="#ff9650"
                            transform="translate(135.496234, 65.043574) rotate(-36.000000) translate(-135.496234, -65.043574) "
                            points="131.276995 60.8304823 139.696554 60.8494015 139.715474 69.2566665 131.295914 69.2377473"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="164"
                            id="a"
                            fill="#ff9650"
                            transform="translate(127.028557, 71.385104) rotate(-37.920000) translate(-127.028557, -71.385104) "
                            points="122.809774 67.1711868 131.228052 67.1904752 131.247341 75.5990211 122.829062 75.5797327"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="157"
                            id="a"
                            fill="#ff9650"
                            transform="translate(118.779108, 78.005436) rotate(-39.840000) translate(-118.779108, -78.005436) "
                            points="114.560835 73.7907266 122.977811 73.8102976 122.997382 82.2201461 114.580406 82.2005751"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="153"
                            id="a"
                            fill="#ff9650"
                            transform="translate(110.757150, 84.897138) rotate(-41.760000) translate(-110.757150, -84.897138) "
                            points="106.539439 80.6816715 114.955096 80.7014373 114.974862 89.1126045 106.559204 89.0928387"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="145"
                            id="a"
                            fill="#ff9650"
                            transform="translate(102.971690, 92.052471) rotate(-43.680000) translate(-102.971690, -92.052471) "
                            points="98.7545897 87.8362868 107.168918 87.8561585 107.18879 96.2686545 98.7744614 96.2487828"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="135"
                            id="a"
                            fill="#ff9650"
                            transform="translate(95.431469, 99.463400) rotate(-45.600000) translate(-95.431469, -99.463400) "
                            points="91.2150274 95.2465414 99.6280231 95.2664298 99.6479116 103.680259 91.2349159 103.66037"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="125"
                            id="a"
                            fill="#ff9650"
                            transform="translate(77.708701, 119.053670) rotate(-50.400000) translate(-77.708701, -119.053670) "
                            points="73.4940881 114.83533 81.9037729 114.85487 81.9233133 123.27201 73.5136286 123.25247"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="115"
                            id="a"
                            fill="#ff9650"
                            transform="translate(71.091601, 127.291860) rotate(-52.320000) translate(-71.091601, -127.291860) "
                            points="66.8777854 123.073016 75.2861699 123.092263 75.3054168 131.510703 66.8970324 131.491456"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="113"
                            id="a"
                            fill="#ff9650"
                            transform="translate(64.755538, 135.746078) rotate(-54.240000) translate(-64.755538, -135.746078) "
                            points="60.5425506 131.526786 68.9496574 131.545653 68.9685244 139.965371 60.5614177 139.946504"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="106"
                            id="a"
                            fill="#ff9650"
                            transform="translate(58.707624, 144.406833) rotate(-56.160000) translate(-58.707624, -144.406833) "
                            points="54.4954944 140.187148 62.9013517 140.20555 62.9197542 148.626517 54.5138968 148.608115"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="102"
                            id="a"
                            fill="#ff9650"
                            transform="translate(52.954652, 153.264398) rotate(-58.080000) translate(-52.954652, -153.264398) "
                            points="48.7434037 149.044379 57.1480456 149.062235 57.1659007 157.484417 48.7612588 157.466562"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="95"
                            id="a"
                            fill="#ff9650"
                            transform="translate(47.503081, 162.308830) rotate(-60.000000) translate(-47.503081, -162.308830) "
                            points="43.2927342 158.088537 51.6962 158.105764 51.7134277 166.529123 43.3099619 166.511895"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="85"
                            id="a"
                            fill="#ff9650"
                            transform="translate(42.359032, 171.529972) rotate(-61.920000) translate(-42.359032, -171.529972) "
                            points="38.1496031 167.309465 46.5519375 167.325988 46.5684604 175.750478 38.166126 175.733955"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="83"
                            id="a"
                            fill="#ff9650"
                            transform="translate(37.528281, 180.917470) rotate(-63.840000) translate(-37.528281, -180.917470) "
                            points="33.3197822 176.696812 41.721035 176.712556 41.7367789 185.138128 33.3355261 185.122384"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="79"
                            id="a"
                            fill="#ff9650"
                            transform="translate(33.016251, 190.460784) rotate(-65.760000) translate(-33.016251, -190.460784) "
                            points="28.8086915 186.240037 37.2089172 186.254932 37.2238114 194.681531 28.8235858 194.666636"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="72"
                            id="a"
                            fill="#ff9650"
                            transform="translate(28.828011, 200.149198) rotate(-67.680000) translate(-28.828011, -200.149198) "
                            points="24.621393 195.928426 33.0206508 195.942404 33.0346285 204.369971 24.6353707 204.355993"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="62"
                            id="a"
                            fill="#ff9650"
                            transform="translate(24.968261, 209.971835) rotate(-69.600000) translate(-24.968261, -209.971835) "
                            points="20.7625852 205.7511 29.1609387 205.764098 29.1739371 214.192569 20.7755836 214.179571"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="52"
                            id="a"
                            fill="#ff9650"
                            transform="translate(16.783556, 235.042929) rotate(-74.400000) translate(-16.783556, -235.042929) "
                            points="12.5802052 230.822562 20.9766018 230.832867 20.9869068 239.263295 12.5905102 239.25299"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="43"
                            id="a"
                            fill="#ff9650"
                            transform="translate(14.105191, 245.247609) rotate(-76.320000) translate(-14.105191, -245.247609) "
                            points="9.90274766 241.027498 18.2984924 241.036641 18.3076347 249.46772 9.91189001 249.458578"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="42"
                            id="a"
                            fill="#ff9650"
                            transform="translate(11.771849, 255.535873) rotate(-78.240000) translate(-11.771849, -255.535873) "
                            points="7.57029343 251.316078 15.9654655 251.324016 15.9734042 259.755669 7.57823205 259.74773"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="38"
                            id="a"
                            fill="#ff9650"
                            transform="translate(9.786149, 265.896169) rotate(-80.160000) translate(-9.786149, -265.896169) "
                            points="5.58545847 261.676748 13.9801399 261.683447 13.9868391 270.11559 5.59215771 270.108891"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="26"
                            id="a"
                            fill="#ff9650"
                            transform="translate(5.384117, 307.165340) rotate(-87.720000) translate(-5.384117, -307.165340) "
                            points="1.18653552 302.947929 9.58011791 302.94951 9.58169945 311.382752 1.18811706 311.381171"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="29"
                            id="a"
                            fill="#ff9650"
                            transform="translate(6.438281, 292.476681) rotate(-87.720000) translate(-6.438281, -292.476681) "
                            points="2.24069866 288.25927 10.634281 288.260851 10.6358626 296.694093 2.2422802 296.692512"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="17"
                            id="a"
                            fill="#ff9650"
                            transform="translate(5.144854, 322.324190) rotate(-90.480000) translate(-5.144854, -322.324190) "
                            points="0.948260018 318.107705 9.34178223 318.107372 9.34144894 326.540675 0.947926726 326.541008"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="8"
                            id="a"
                            fill="#ff9650"
                            transform="translate(5.639265, 337.476922) rotate(-93.240000) translate(-5.639265, -337.476922) "
                            points="1.44356411 333.261456 9.83721062 333.259211 9.83496558 341.692389 1.44131907 341.694634"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="272"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.614213, 162.860778) rotate(4.800000) translate(-334.614213, -162.860778) "
                            points="330.399358 158.665538 338.832385 158.662221 338.829067 167.056019 330.396041 167.059336"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="282"
                            id="a"
                            fill="#ff9650"
                            transform="translate(347.752918, 164.512752) rotate(9.600000) translate(-347.752918, -164.512752) "
                            points="343.540089 160.31871 351.972288 160.312168 351.965746 168.706794 343.533547 168.713336"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="325"
                            id="a"
                            fill="#ff9650"
                            transform="translate(360.706655, 167.253164) rotate(14.400000) translate(-360.706655, -167.253164) "
                            points="356.496024 163.059966 364.926869 163.050383 364.917285 171.446363 356.486441 171.455946"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="335"
                            id="a"
                            fill="#ff9650"
                            transform="translate(373.384562, 171.062793) rotate(19.200000) translate(-373.384562, -171.062793) "
                            points="369.176239 166.87006 377.605242 166.857703 377.592885 175.255526 369.163883 175.267882"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="273"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.605893, 147.071968) rotate(4.360000) translate(-334.605893, -147.071968) "
                            points="330.390863 142.876601 338.823938 142.873585 338.820923 151.267334 330.387847 151.27035"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="283"
                            id="a"
                            fill="#ff9650"
                            transform="translate(349.940852, 148.920298) rotate(9.450000) translate(-349.940852, -148.920298) "
                            points="345.727957 144.726224 354.16019 144.71978 354.153746 153.114372 345.721514 153.120816"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="326"
                            id="a"
                            fill="#ff9650"
                            transform="translate(365.050576, 152.115446) rotate(14.540000) translate(-365.050576, -152.115446) "
                            points="360.840012 147.922267 369.270809 147.912598 369.261141 156.308625 360.830343 156.318294"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="336"
                            id="a"
                            fill="#ff9650"
                            transform="translate(379.815898, 156.632211) rotate(19.630000) translate(-379.815898, -156.632211) "
                            points="375.607785 152.439501 384.0366 152.426912 384.024011 160.824922 375.595196 160.837511"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="274"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.618944, 131.293171) rotate(4.000000) translate(-334.618944, -131.293171) "
                            points="330.403773 127.097699 338.836885 127.09493 338.834116 135.488643 330.401004 135.491412"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="284"
                            id="a"
                            fill="#ff9650"
                            transform="translate(347.790705, 132.671048) rotate(8.000000) translate(-347.790705, -132.671048) "
                            points="343.57718 128.476644 352.009714 128.471161 352.004231 136.865451 343.571697 136.870935"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="292"
                            id="a"
                            fill="#ff9650"
                            transform="translate(360.833809, 134.960049) rotate(12.000000) translate(-360.833809, -134.960049) "
                            points="356.622062 130.766475 365.053647 130.758384 365.045556 139.153623 356.613971 139.161714"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="327"
                            id="a"
                            fill="#ff9650"
                            transform="translate(373.684711, 138.149023) rotate(16.000000) translate(-373.684711, -138.149023) "
                            points="369.474841 133.956023 377.905123 133.945481 377.894581 142.342023 369.464299 142.352565"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="337"
                            id="a"
                            fill="#ff9650"
                            transform="translate(386.280803, 142.222433) rotate(20.000000) translate(-386.280803, -142.222433) "
                            points="382.072871 138.02974 390.501522 138.016953 390.488735 146.415126 382.060084 146.427913"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="275"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.612273, 115.519430) rotate(3.690000) translate(-334.612273, -115.519430) "
                            points="330.396981 111.323865 338.830121 111.32131 338.827566 119.714994 330.394426 119.717549"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="285"
                            id="a"
                            fill="#ff9650"
                            transform="translate(346.469990, 116.624636) rotate(7.010000) translate(-346.469990, -116.624636) "
                            points="342.256044 112.429989 350.688756 112.42517 350.683937 120.819282 342.251225 120.824101"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="293"
                            id="a"
                            fill="#ff9650"
                            transform="translate(358.243498, 118.411458) rotate(10.330000) translate(-358.243498, -118.411458) "
                            points="354.030994 114.217568 362.46302 114.210549 362.456001 122.605348 354.023975 122.612366"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="306"
                            id="a"
                            fill="#ff9650"
                            transform="translate(369.928138, 120.882327) rotate(13.660000) translate(-369.928138, -120.882327) "
                            points="365.71716 116.689023 374.148246 116.679893 374.139116 125.075631 365.70803 125.084761"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="328"
                            id="a"
                            fill="#ff9650"
                            transform="translate(381.414532, 124.014114) rotate(16.980000) translate(-381.414532, -124.014114) "
                            points="377.205133 119.821214 385.635044 119.810101 385.623932 128.207014 377.19402 128.218126"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="338"
                            id="a"
                            fill="#ff9650"
                            transform="translate(392.699419, 127.802712) rotate(20.300000) translate(-392.699419, -127.802712) "
                            points="388.491634 123.610031 396.92015 123.597085 396.907204 131.995394 388.478688 132.008339"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="276"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.622817, 83.987670) rotate(3.200000) translate(-334.622817, -83.987670) "
                            points="330.407335 79.7919575 338.840516 79.78974 338.838299 88.1833834 330.405118 88.1856009"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="286"
                            id="a"
                            fill="#ff9650"
                            transform="translate(346.710607, 84.969381) rotate(6.130000) translate(-346.710607, -84.969381) "
                            points="342.496293 80.7745064 350.929145 80.7702822 350.924921 89.1642553 342.492069 89.1684795"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="294"
                            id="a"
                            fill="#ff9650"
                            transform="translate(358.732176, 86.564771) rotate(9.060000) translate(-358.732176, -86.564771) "
                            points="354.51911 82.3706111 362.951429 82.3644243 362.945242 90.7589302 354.512924 90.7651171"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="307"
                            id="a"
                            fill="#ff9650"
                            transform="translate(370.696587, 88.778232) rotate(12.000000) translate(-370.696587, -88.778232) "
                            points="366.48484 84.5846575 374.916425 84.5765664 374.908334 92.9718056 366.476749 92.9798968"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="313"
                            id="a"
                            fill="#ff9650"
                            transform="translate(382.491185, 91.588922) rotate(14.930000) translate(-382.491185, -91.588922) "
                            points="378.280805 87.3957941 386.711469 87.3858898 386.701565 95.7820501 378.2709 95.7919544"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="277"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.623651, 68.226827) rotate(3.000000) translate(-334.623651, -68.226827) "
                            points="330.408092 64.0310526 338.841288 64.0289732 338.839209 72.4226016 330.406013 72.424681"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="287"
                            id="a"
                            fill="#ff9650"
                            transform="translate(347.828311, 69.261154) rotate(6.000000) translate(-347.828311, -69.261154) "
                            points="343.613943 65.0662445 352.046814 65.0621086 352.042678 73.4560627 343.609807 73.4601986"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="295"
                            id="a"
                            fill="#ff9650"
                            transform="translate(360.960485, 70.981881) rotate(9.000000) translate(-360.960485, -70.981881) "
                            points="356.747393 66.7877079 365.179724 66.7815607 365.173577 75.1760538 356.741246 75.182201"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="308"
                            id="a"
                            fill="#ff9650"
                            transform="translate(373.984180, 73.384292) rotate(12.000000) translate(-373.984180, -73.384292) "
                            points="369.772433 69.1907184 378.204018 69.1826272 378.195927 77.5778665 369.764341 77.5859576"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="314"
                            id="a"
                            fill="#ff9650"
                            transform="translate(386.863697, 76.461803) rotate(15.000000) translate(-386.863697, -76.461803) "
                            points="382.65335 72.2686844 391.08399 72.258738 391.074044 80.6549225 382.643404 80.6648689"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="278"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.607803, 52.467876) rotate(2.820000) translate(-334.607803, -52.467876) "
                            points="330.392176 48.2720455 338.825385 48.2700905 338.82343 56.6637062 330.390221 56.6656612"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="288"
                            id="a"
                            fill="#ff9650"
                            transform="translate(345.325246, 53.207229) rotate(5.110000) translate(-345.325246, -53.207229) "
                            points="341.110516 49.0120766 349.543506 49.008547 349.539976 57.402382 341.106987 57.4059116"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="296"
                            id="a"
                            fill="#ff9650"
                            transform="translate(356.050973, 54.378231) rotate(7.410000) translate(-356.050973, -54.378231) "
                            points="351.837196 50.1836849 360.269839 50.1785966 360.264751 58.5727778 351.832108 58.577866"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="302"
                            id="a"
                            fill="#ff9650"
                            transform="translate(366.674598, 55.968830) rotate(9.700000) translate(-366.674598, -55.968830) "
                            points="362.461814 51.7748097 370.893989 51.768202 370.887382 60.1628509 362.455206 60.1694586"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="309"
                            id="a"
                            fill="#ff9650"
                            transform="translate(377.271772, 57.990353) rotate(12.000000) translate(-377.271772, -57.990353) "
                            points="373.060025 53.7967792 381.49161 53.7886881 381.483519 62.1839273 373.051934 62.1920184"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="315"
                            id="a"
                            fill="#ff9650"
                            transform="translate(387.733434, 60.421995) rotate(14.290000) translate(-387.733434, -60.421995) "
                            points="383.522752 56.2287817 391.953633 56.2192653 391.944116 64.6152087 383.513235 64.6247251"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="319"
                            id="a"
                            fill="#ff9650"
                            transform="translate(398.089118, 63.267744) rotate(16.580000) translate(-398.089118, -63.267744) "
                            points="393.879526 59.0748049 402.309591 59.0639239 402.29871 67.460683 393.868645 67.4715639"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="279"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.591839, 36.711269) rotate(2.660000) translate(-334.591839, -36.711269) "
                            points="330.376151 32.5153886 338.809371 32.5135441 338.807526 40.9071493 330.374307 40.9089937"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="289"
                            id="a"
                            fill="#ff9650"
                            transform="translate(346.189318, 37.484009) rotate(5.000000) translate(-346.189318, -37.484009) "
                            points="341.974544 33.2888256 350.407547 33.2853712 350.404092 41.6791929 341.97109 41.6826472"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="297"
                            id="a"
                            fill="#ff9650"
                            transform="translate(357.696157, 38.721077) rotate(7.330000) translate(-357.696157, -38.721077) "
                            points="353.482345 34.5265103 361.915003 34.5214758 361.909968 42.9156429 353.477311 42.9206774"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="303"
                            id="a"
                            fill="#ff9650"
                            transform="translate(369.142951, 40.422724) rotate(9.660000) translate(-369.142951, -40.422724) "
                            points="364.930149 36.2286952 373.362334 36.2221138 373.355753 44.6167535 364.923568 44.6233349"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="310"
                            id="a"
                            fill="#ff9650"
                            transform="translate(380.559365, 42.596414) rotate(12.000000) translate(-380.559365, -42.596414) "
                            points="376.347618 38.40284 384.779203 38.3947489 384.771112 46.7899881 376.339527 46.7980793"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="316"
                            id="a"
                            fill="#ff9650"
                            transform="translate(391.828958, 45.219976) rotate(14.330000) translate(-391.828958, -45.219976) "
                            points="387.618295 41.0267677 396.049162 41.0172269 396.039622 49.4131836 387.608754 49.4227244"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="320"
                            id="a"
                            fill="#ff9650"
                            transform="translate(402.982068, 48.297372) rotate(16.660000) translate(-402.982068, -48.297372) "
                            points="398.772514 44.1044406 407.202549 44.0935132 407.191622 52.4903027 398.761587 52.5012301"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="280"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.592325, 20.957361) rotate(2.520000) translate(-334.592325, -20.957361) "
                            points="330.376585 16.7614362 338.809813 16.7596886 338.808066 25.1532849 330.374837 25.1550325"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="290"
                            id="a"
                            fill="#ff9650"
                            transform="translate(344.536455, 21.557499) rotate(4.420000) translate(-344.536455, -21.557499) "
                            points="340.32145 17.3621495 348.754518 17.3590925 348.751461 25.7528482 340.318392 25.7559053"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="298"
                            id="a"
                            fill="#ff9650"
                            transform="translate(354.403009, 22.479711) rotate(6.310000) translate(-354.403009, -22.479711) "
                            points="350.188769 18.2848839 358.621594 18.2805376 358.617248 26.6745377 350.184423 26.6788839"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="300"
                            id="a"
                            fill="#ff9650"
                            transform="translate(364.285534, 23.732740) rotate(8.210000) translate(-364.285534, -23.732740) "
                            points="360.072099 19.5383864 368.504593 19.5327632 368.498969 27.9270939 360.066476 27.9327172"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="304"
                            id="a"
                            fill="#ff9650"
                            transform="translate(374.069262, 25.302035) rotate(10.100000) translate(-374.069262, -25.302035) "
                            points="369.856656 21.1080982 378.288738 21.1012292 378.281869 29.4959722 369.849787 29.5028411"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="311"
                            id="a"
                            fill="#ff9650"
                            transform="translate(383.846957, 27.202475) rotate(12.000000) translate(-383.846957, -27.202475) "
                            points="379.63521 23.0089009 388.066796 23.0008097 388.058704 31.396049 379.627119 31.4041401"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="317"
                            id="a"
                            fill="#ff9650"
                            transform="translate(393.505067, 29.411989) rotate(13.890000) translate(-393.505067, -29.411989) "
                            points="389.294197 25.2187187 397.725209 25.209447 397.715937 33.6052592 389.284925 33.6145309"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="321"
                            id="a"
                            fill="#ff9650"
                            transform="translate(403.084706, 31.937330) rotate(15.780000) translate(-403.084706, -31.937330) "
                            points="398.87473 27.7443049 407.305093 27.7338931 407.294681 36.1303548 398.864319 36.1407666"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="323"
                            id="a"
                            fill="#ff9650"
                            transform="translate(412.625412, 34.791595) rotate(17.680000) translate(-412.625412, -34.791595) "
                            points="408.41635 30.598757 416.845985 30.5872448 416.834473 38.9844338 408.404838 38.995946"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="281"
                            id="a"
                            fill="#ff9650"
                            transform="translate(334.625829, 5.206436) rotate(2.400000) translate(-334.625829, -5.206436) "
                            points="330.410044 1.01047366 338.843279 1.00880907 338.841614 9.40239826 330.408379 9.40406285"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="291"
                            id="a"
                            fill="#ff9650"
                            transform="translate(345.204720, 5.824597) rotate(4.320000) translate(-345.204720, -5.824597) "
                            points="340.989675 1.6292182 349.422754 1.62622979 349.419766 10.019975 340.986687 10.0229634"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="299"
                            id="a"
                            fill="#ff9650"
                            transform="translate(355.756863, 6.795174) rotate(6.240000) translate(-355.756863, -6.795174) "
                            points="351.542595 2.60032843 359.97543 2.59602961 359.971132 10.9900191 351.538297 10.9943179"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="301"
                            id="a"
                            fill="#ff9650"
                            transform="translate(366.270410, 8.117078) rotate(8.160000) translate(-366.270410, -8.117078) "
                            points="362.056953 3.92271214 370.489457 3.91712222 370.483867 12.3114432 362.051363 12.3170331"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="305"
                            id="a"
                            fill="#ff9650"
                            transform="translate(376.733555, 9.788824) rotate(10.080000) translate(-376.733555, -9.788824) "
                            points="372.52094 5.59488291 380.953026 5.58802698 380.94617 13.9827652 372.514084 13.9896211"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="312"
                            id="a"
                            fill="#ff9650"
                            transform="translate(387.134550, 11.808536) rotate(12.000000) translate(-387.134550, -11.808536) "
                            points="382.922803 7.61496172 391.354388 7.60687058 391.346297 16.0021098 382.914712 16.010201"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="318"
                            id="a"
                            fill="#ff9650"
                            transform="translate(397.461716, 14.173945) rotate(13.920000) translate(-397.461716, -14.173945) "
                            points="393.25086 9.98067914 401.681863 9.9713891 401.672573 18.367211 393.24157 18.3765011"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="322"
                            id="a"
                            fill="#ff9650"
                            transform="translate(407.703459, 16.882396) rotate(15.840000) translate(-407.703459, -16.882396) "
                            points="403.493512 12.6893778 411.923853 12.6789306 411.913405 21.0754141 403.483064 21.0858614"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="324"
                            id="a"
                            fill="#ff9650"
                            transform="translate(417.848277, 19.930847) rotate(17.760000) translate(-417.848277, -19.930847) "
                            points="413.639254 15.7380154 422.068857 15.7264579 422.057299 24.1236792 413.627696 24.1352367"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="345"
                            id="a"
                            fill="#ff9650"
                            transform="translate(397.559743, 181.775498) rotate(28.800000) translate(-397.559743, -181.775498) "
                            points="393.356105 177.582519 401.780176 177.565723 401.76338 185.968476 393.339309 185.985272"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="355"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(408.887444, 188.603432) rotate(33.600000) translate(-408.887444, -188.603432) "
                            points="404.686052 184.40975 413.107173 184.391412 413.088835 192.797115 404.667714 192.815453"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="396"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(419.601362, 196.350827) rotate(38.400000) translate(-419.601362, -196.350827) "
                            points="415.402068 192.156075 423.820023 192.136708 423.800656 200.545578 415.382701 200.564945"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="408"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(429.626347, 204.963338) rotate(43.200000) translate(-429.626347, -204.963338) "
                            points="425.428943 200.767183 433.843604 200.747329 433.823751 209.159493 425.409089 209.179346"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="346"
                            id="a"
                            fill="#ff9650"
                            transform="translate(404.004470, 167.348333) rotate(28.360000) translate(-404.004470, -167.348333) "
                            points="399.800621 163.1554 408.224949 163.13877 408.208319 171.541266 399.783991 171.557897"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="356"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(417.258305, 175.244732) rotate(33.450000) translate(-417.258305, -175.244732) "
                            points="413.056845 171.051077 421.478062 171.032779 421.459765 179.438386 413.038548 179.456684"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="397"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(429.755981, 184.280330) rotate(38.540000) translate(-429.755981, -184.280330) "
                            points="425.556746 180.085542 433.974606 180.066153 433.955217 188.475117 425.537357 188.494506"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="409"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(441.398932, 194.383865) rotate(43.630000) translate(-441.398932, -194.383865) "
                            points="437.201685 190.187569 445.616049 190.167699 445.596178 198.58016 437.181815 198.600031"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="347"
                            id="a"
                            fill="#ff9650"
                            transform="translate(410.464629, 152.938969) rotate(28.000000) translate(-410.464629, -152.938969) "
                            points="406.260607 148.746071 414.685143 148.729579 414.668651 157.131867 406.244115 157.148359"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="357"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(421.934542, 159.529885) rotate(32.000000) translate(-421.934542, -159.529885) "
                            points="417.732415 155.336479 426.154548 155.3186 426.136668 163.723291 417.714536 163.741171"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="378"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(432.914576, 166.901072) rotate(36.000000) translate(-432.914576, -166.901072) "
                            points="428.714256 162.706899 437.133815 162.68798 437.114896 171.095245 428.695337 171.114164"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="398"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(443.351238, 175.016618) rotate(40.000000) translate(-443.351238, -175.016618) "
                            points="439.1526 170.821435 447.569467 170.801844 447.549876 179.211802 439.13301 179.231393"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="410"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(453.193682, 183.836986) rotate(44.000000) translate(-453.193682, -183.836986) "
                            points="448.996569 179.640567 457.410676 179.620686 457.390795 188.033404 448.976689 188.053285"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="348"
                            id="a"
                            fill="#ff9650"
                            transform="translate(416.904704, 138.526239) rotate(27.690000) translate(-416.904704, -138.526239) "
                            points="412.700532 134.333369 421.125246 134.316998 421.108876 142.719109 412.684162 142.735479"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="358"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(427.285609, 144.336109) rotate(31.010000) translate(-427.285609, -144.336109) "
                            points="423.08302 140.142854 431.505765 140.125286 431.488198 148.529365 423.065453 148.546933"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="365"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(437.311032, 150.734577) rotate(34.330000) translate(-437.311032, -150.734577) "
                            points="433.109971 146.540755 441.530622 146.522226 441.512093 154.9284 433.091442 154.946928"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="379"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(446.975726, 157.721979) rotate(37.660000) translate(-446.975726, -157.721979) "
                            points="442.776121 153.527415 451.194574 153.508172 451.175331 161.916543 442.756877 161.935786"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="399"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(456.189218, 165.232906) rotate(40.980000) translate(-456.189218, -165.232906) "
                            points="451.99097 161.037439 460.407164 161.017742 460.387467 169.428372 451.971272 169.448069"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="411"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(464.950209, 173.262285) rotate(44.300000) translate(-464.950209, -173.262285) "
                            points="460.753204 169.065766 469.167102 169.045879 469.147215 177.458805 460.733317 177.478692"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="329"
                            id="a"
                            fill="#ff9650"
                            transform="translate(394.126012, 94.995985) rotate(17.860000) translate(-394.126012, -94.995985) "
                            points="389.917037 90.8031611 398.3466 90.7915472 398.334986 99.1888089 389.905423 99.2004228"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="339"
                            id="a"
                            fill="#ff9650"
                            transform="translate(405.609349, 99.005140) rotate(20.800000) translate(-405.609349, -99.005140) "
                            points="401.401808 94.8124755 409.830096 94.7992682 409.816889 103.197805 401.388601 103.211012"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="349"
                            id="a"
                            fill="#ff9650"
                            transform="translate(429.800249, 109.724811) rotate(27.200000) translate(-429.800249, -109.724811) "
                            points="425.595841 105.531983 434.020833 105.515808 434.004658 113.91764 425.579666 113.933815"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="359"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(440.441805, 115.515001) rotate(30.130000) translate(-440.441805, -115.515001) "
                            points="436.238801 111.321865 444.662082 111.304592 444.644809 119.708137 436.221529 119.725409"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="366"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(450.772076, 121.839007) rotate(33.060000) translate(-450.772076, -121.839007) "
                            points="446.570438 117.645422 454.991903 117.627233 454.973713 126.032592 446.552248 126.050782"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="380"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(460.797546, 128.704511) rotate(36.000000) translate(-460.797546, -128.704511) "
                            points="456.597226 124.510338 465.016785 124.491418 464.997866 132.898683 456.578306 132.917603"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="386"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(470.423817, 136.046867) rotate(38.930000) translate(-470.423817, -136.046867) "
                            points="466.224743 131.851977 474.642339 131.832529 474.622891 140.241757 466.205295 140.261205"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="400"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(479.660414, 143.869359) rotate(41.860000) translate(-479.660414, -143.869359) "
                            points="475.462507 139.673627 483.878095 139.653854 483.858322 148.06509 475.442734 148.084864"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="412"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(488.512565, 152.180563) rotate(44.800000) translate(-488.512565, -152.180563) "
                            points="484.315736 147.983873 492.729287 147.96398 492.709394 156.377254 484.295843 156.397146"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="330"
                            id="a"
                            fill="#ff9650"
                            transform="translate(399.563736, 80.205979) rotate(18.000000) translate(-399.563736, -80.205979) "
                            points="395.354829 76.0131658 403.784335 76.001473 403.772642 84.3987917 395.343136 84.4104844"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="340"
                            id="a"
                            fill="#ff9650"
                            transform="translate(412.049486, 84.606556) rotate(21.000000) translate(-412.049486, -84.606556) "
                            points="407.842043 80.4138966 416.270239 80.4005857 416.256928 88.7992147 407.828732 88.8125256"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="350"
                            id="a"
                            fill="#ff9650"
                            transform="translate(436.241910, 95.326902) rotate(27.000000) translate(-436.241910, -95.326902) "
                            points="432.037404 91.134089 440.462509 91.1179954 440.446415 99.5197149 432.02131 99.5358086"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="360"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(447.882274, 101.617288) rotate(30.000000) translate(-447.882274, -101.617288) "
                            points="443.679209 97.4241685 452.102568 97.4069408 452.08534 105.810407 443.661981 105.827634"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="367"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(459.175912, 108.505388) rotate(33.000000) translate(-459.175912, -108.505388) "
                            points="454.974247 104.311814 463.395751 104.293641 463.377578 112.698962 454.956074 112.717135"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="381"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(470.091869, 115.972323) rotate(36.000000) translate(-470.091869, -115.972323) "
                            points="465.891549 111.77815 474.311108 111.759231 474.292189 120.166496 465.872629 120.185415"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="387"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(480.600224, 123.997627) rotate(39.000000) translate(-480.600224, -123.997627) "
                            points="476.401179 119.802718 484.818727 119.78326 484.799269 128.192536 476.381721 128.211995"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="401"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(490.672175, 132.559303) rotate(42.000000) translate(-490.672175, -132.559303) "
                            points="486.474321 128.363529 494.889812 128.343745 494.870028 136.755078 486.454537 136.774862"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="413"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(500.280115, 141.633884) rotate(45.000000) translate(-500.280115, -141.633884) "
                            points="496.083355 137.437124 504.496767 137.417231 504.476874 145.830644 496.063462 145.850536"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="331"
                            id="a"
                            fill="#ff9650"
                            transform="translate(408.366678, 66.538160) rotate(18.880000) translate(-408.366678, -66.538160) "
                            points="404.158199 62.3454082 412.587338 62.3332268 412.575157 70.7309121 404.146018 70.7430936"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="341"
                            id="a"
                            fill="#ff9650"
                            transform="translate(418.460340, 70.199586) rotate(21.170000) translate(-418.460340, -70.199586) "
                            points="414.252981 66.0069308 422.681097 65.9935324 422.667699 74.3922406 414.239582 74.405639"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="351"
                            id="a"
                            fill="#ff9650"
                            transform="translate(442.667558, 80.923968) rotate(26.820000) translate(-442.667558, -80.923968) "
                            points="438.462965 76.7311688 446.88817 76.715149 446.872151 85.1167676 438.446945 85.1327875"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="361"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(452.156282, 85.938013) rotate(29.110000) translate(-452.156282, -85.938013) "
                            points="447.952793 81.7450005 456.376682 81.7280901 456.359771 90.1310256 447.935882 90.147936"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="368"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(461.476174, 91.349742) rotate(31.410000) translate(-461.476174, -91.349742) "
                            points="457.273773 87.1564271 465.696272 87.1387309 465.678576 95.5430563 457.256076 95.5607525"
                        ></polygon>
                        <polygon
                            data-index="372"
                            className=""
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(470.531316, 97.103458) rotate(33.700000) translate(-470.531316, -97.103458) "
                            points="466.32997 92.9097571 474.751027 92.8913918 474.732662 101.297159 466.311605 101.315525"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="382"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(479.386192, 103.240136) rotate(36.000000) translate(-479.386192, -103.240136) "
                            points="475.185872 99.0459632 483.605431 99.0270439 483.586512 107.434309 475.166953 107.453228"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="388"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(487.949670, 109.696618) rotate(38.290000) translate(-487.949670, -109.696618) "
                            points="483.75033 105.501895 492.168359 105.482546 492.149009 113.891341 483.73098 113.910691"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="392"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(496.247101, 116.488504) rotate(40.580000) translate(-496.247101, -116.488504) "
                            points="492.048695 112.293155 500.465164 112.273498 500.445508 120.683854 492.029038 120.70351"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="402"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(504.299616, 123.636717) rotate(42.880000) translate(-504.299616, -123.636717) "
                            points="500.102094 119.440666 508.516977 119.420827 508.497138 127.832769 500.082255 127.852607"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="414"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(512.024340, 131.067690) rotate(45.170000) translate(-512.024340, -131.067690) "
                            points="507.827639 126.870871 516.240933 126.850978 516.221041 135.264509 507.807747 135.284401"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="332"
                            id="a"
                            fill="#ff9650"
                            transform="translate(414.047224, 51.839606) rotate(19.000000) translate(-414.047224, -51.839606) "
                            points="409.838803 47.6468615 418.267891 47.6346142 418.255644 56.0323507 409.826556 56.044598"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="342"
                            id="a"
                            fill="#ff9650"
                            transform="translate(424.911568, 55.810551) rotate(21.330000) translate(-424.911568, -55.810551) "
                            points="420.704287 51.6178991 429.132329 51.6044188 429.118848 60.0032021 420.690807 60.0166825"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="352"
                            id="a"
                            fill="#ff9650"
                            transform="translate(449.092141, 66.523129) rotate(26.660000) translate(-449.092141, -66.523129) "
                            points="444.88747 62.3303412 453.312766 62.3143875 453.296812 70.7159168 444.871517 70.7318706"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="362"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(459.371174, 71.923928) rotate(29.000000) translate(-459.371174, -71.923928) "
                            points="455.167632 67.7309281 463.591586 67.714058 463.574716 76.1169286 455.150762 76.1337987"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="369"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(469.377649, 77.712219) rotate(31.330000) translate(-469.377649, -77.712219) "
                            points="465.17521 73.518916 473.597758 73.5012452 473.580088 81.9055213 465.157539 81.9231921"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="373"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(479.139412, 83.900617) rotate(33.660000) translate(-479.139412, -83.900617) "
                            points="474.938048 79.7069234 483.359131 79.6885688 483.340776 88.0943107 474.919694 88.1126653"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="383"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(488.680515, 90.507949) rotate(36.000000) translate(-488.680515, -90.507949) "
                            points="484.480195 86.3137759 492.899755 86.2948567 492.880835 94.7021217 484.461276 94.721041"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="389"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(497.903644, 97.466823) rotate(38.330000) translate(-497.903644, -97.466823) "
                            points="493.704321 93.2720903 502.122323 93.2527342 502.102967 101.661557 493.684965 101.680913"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="393"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(506.834894, 104.793142) rotate(40.660000) translate(-506.834894, -104.793142) "
                            points="502.63652 100.597769 511.052934 100.578104 511.033269 108.988514 502.616855 109.008179"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="403"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(515.495831, 112.508506) rotate(43.000000) translate(-515.495831, -112.508506) "
                            points="511.298353 108.312416 519.713153 108.292571 519.693309 116.704596 511.278509 116.72444"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="415"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(523.798119, 120.534224) rotate(45.330000) translate(-523.798119, -120.534224) "
                            points="519.601473 116.337349 528.014656 116.317458 527.994765 124.731099 519.581582 124.75099"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="333"
                            id="a"
                            fill="#ff9650"
                            transform="translate(422.016384, 37.941638) rotate(19.570000) translate(-422.016384, -37.941638) "
                            points="417.808242 33.7489246 426.237083 33.7363679 426.224527 42.1343511 417.795685 42.1469078"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="343"
                            id="a"
                            fill="#ff9650"
                            transform="translate(431.346664, 41.417324) rotate(21.470000) translate(-431.346664, -41.417324) "
                            points="427.139452 37.2246754 435.567428 37.2111238 435.553876 45.6099731 427.125901 45.6235248"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="353"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(455.530650, 52.131415) rotate(26.520000) translate(-455.530650, -52.131415) "
                            points="451.325911 47.9386365 459.751284 47.922741 459.735389 56.3241925 451.310016 56.340088"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="363"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(464.369810, 56.705229) rotate(28.420000) translate(-464.369810, -56.705229) "
                            points="460.16599 52.5122899 468.590283 52.4956367 468.57363 60.898168 460.149336 60.9148212"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="370"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(473.006479, 61.541868) rotate(30.310000) translate(-473.006479, -61.541868) "
                            points="468.80356 57.3487084 477.226732 57.331374 477.209398 65.7350269 468.786226 65.7523612"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="374"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(481.522547, 66.687189) rotate(32.210000) translate(-481.522547, -66.687189) "
                            points="477.320517 62.493749 485.742519 62.475806 485.724576 70.8806291 477.302574 70.8985721"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="376"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(489.819112, 72.081439) rotate(34.100000) translate(-489.819112, -72.081439) "
                            points="485.617947 67.8876613 494.038747 67.8691911 494.020277 76.2752158 485.599477 76.293686"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="384"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(497.974838, 77.775762) rotate(36.000000) translate(-497.974838, -77.775762) "
                            points="493.774518 73.5815887 502.194078 73.5626695 502.175159 81.9699345 493.755599 81.9888537"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="390"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(505.895011, 83.704028) rotate(37.890000) translate(-505.895011, -83.704028) "
                            points="501.695503 79.5094065 510.113802 79.4901232 510.094518 87.8986489 501.676219 87.9179322"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="394"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(513.614429, 89.889050) rotate(39.780000) translate(-513.614429, -89.889050) "
                            points="509.415702 85.6939276 517.832719 85.6743641 517.813155 94.0841716 509.396138 94.1037351"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="404"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(521.163860, 96.358798) rotate(41.680000) translate(-521.163860, -96.358798) "
                            points="516.965883 92.163122 525.381596 92.1433626 525.361836 100.554475 516.946124 100.574234"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="406"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(528.455629, 103.038138) rotate(43.570000) translate(-528.455629, -103.038138) "
                            points="524.258361 98.8418623 532.672766 98.8219942 532.652898 107.234414 524.238493 107.254282"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="416"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(535.558874, 109.990399) rotate(45.470000) translate(-535.558874, -109.990399) "
                            points="531.362276 105.793475 539.775362 105.773584 539.755472 114.187323 531.342386 114.207213"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="334"
                            id="a"
                            fill="#ff9650"
                            transform="translate(427.884779, 23.315876) rotate(19.680000) translate(-427.884779, -23.315876) "
                            points="423.676691 19.1231683 432.105484 19.1105524 432.092868 27.508584 423.664075 27.5211999"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="344"
                            id="a"
                            fill="#ff9650"
                            transform="translate(437.801698, 27.033682) rotate(21.600000) translate(-437.801698, -27.033682) "
                            points="433.59455 22.841035 442.022463 22.8274174 442.008846 31.2263284 433.580932 31.239946"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="354"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(461.998103, 37.755792) rotate(26.400000) translate(-461.998103, -37.755792) "
                            points="457.793305 33.5630219 466.218745 33.5471767 466.2029 41.9485617 457.77746 41.964407"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="364"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(471.409780, 42.603033) rotate(28.320000) translate(-471.409780, -42.603033) "
                            points="467.205912 38.410104 475.630264 38.3934889 475.613648 46.7959621 467.189297 46.8125772"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="371"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(480.653002, 47.761395) rotate(30.240000) translate(-480.653002, -47.761395) "
                            points="476.45005 43.5682446 484.873264 43.5509342 484.855954 51.9545447 476.43274 51.9718551"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="375"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(489.717390, 53.225085) rotate(32.160000) translate(-489.717390, -53.225085) "
                            points="485.515337 49.0316527 493.93737 49.0137247 493.919442 57.4185165 485.497409 57.4364445"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="377"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(498.592765, 58.987968) rotate(34.080000) translate(-498.592765, -58.987968) "
                            points="494.391591 54.7941947 502.812403 54.7757297 502.793938 63.1817415 494.373126 63.2002065"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="385"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(507.269162, 65.043574) rotate(36.000000) translate(-507.269162, -65.043574) "
                            points="503.068841 60.8494015 511.488401 60.8304823 511.469482 69.2377473 503.049922 69.2566665"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="391"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(515.736839, 71.385104) rotate(37.920000) translate(-515.736839, -71.385104) "
                            points="511.537343 67.1904752 519.955622 67.1711868 519.936334 75.5797327 511.518055 75.5990211"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="395"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(523.986288, 78.005436) rotate(39.840000) translate(-523.986288, -78.005436) "
                            points="519.787585 73.8102976 528.204561 73.7907266 528.18499 82.2005751 519.768014 82.2201461"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="405"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(532.008246, 84.897138) rotate(41.760000) translate(-532.008246, -84.897138) "
                            points="527.8103 80.7014373 536.225957 80.6816715 536.206192 89.0928387 527.790534 89.1126045"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="407"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(539.793706, 92.052471) rotate(43.680000) translate(-539.793706, -92.052471) "
                            points="535.596478 87.8561585 544.010806 87.8362868 543.990934 96.2487828 535.576606 96.2686545"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="417"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(547.333926, 99.463400) rotate(45.600000) translate(-547.333926, -99.463400) "
                            points="543.137373 95.2664298 551.550368 95.2465414 551.53048 103.66037 543.117484 103.680259"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="418"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(447.333569, 224.536424) rotate(52.800000) translate(-447.333569, -224.536424) "
                            points="443.139118 220.336623 451.547181 220.317463 451.528021 228.736225 443.119958 228.755385"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="428"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(454.891604, 235.359707) rotate(57.600000) translate(-454.891604, -235.359707) "
                            points="450.698133 231.157766 459.103075 231.139767 459.085075 239.561649 450.680133 239.579648"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="465"
                            id="a"
                            fill="#84898B"
                            transform="translate(461.513170, 246.774489) rotate(62.400000) translate(-461.513170, -246.774489) "
                            points="457.320308 242.570274 465.722367 242.553939 465.706032 250.978704 457.303973 250.995039"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="419"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(459.116992, 213.965494) rotate(52.360000) translate(-459.116992, -213.965494) "
                            points="454.922433 209.76588 463.330791 209.74664 463.311551 218.165107 454.903194 218.184347"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="429"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(467.997995, 226.544600) rotate(57.450000) translate(-467.997995, -226.544600) "
                            points="463.804498 222.342728 472.209535 222.324685 472.191491 230.746473 463.786454 230.764516"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="466"
                            id="a"
                            fill="#84898B"
                            transform="translate(475.722661, 239.858312) rotate(62.540000) translate(-475.722661, -239.858312) "
                            points="471.529811 235.654029 479.93179 235.63775 479.915511 244.062595 471.513532 244.078874"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="477"
                            id="a"
                            fill="#84898B"
                            transform="translate(482.230068, 253.801624) rotate(67.630000) translate(-482.230068, -253.801624) "
                            points="478.037429 249.594854 486.436711 249.580852 486.422708 258.008394 478.023426 258.022396"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="420"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(470.907238, 203.417072) rotate(52.000000) translate(-470.907238, -203.417072) "
                            points="466.712589 199.21761 475.121189 199.198308 475.101887 207.616533 466.693287 207.635835"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="430"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(478.692051, 214.081398) rotate(56.000000) translate(-478.692051, -214.081398) "
                            points="474.498293 209.880188 482.904253 209.861744 482.885809 218.282608 474.479848 218.301052"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="449"
                            id="a"
                            fill="#00c86e"
                            transform="translate(485.710468, 225.260225) rotate(60.000000) translate(-485.710468, -225.260225) "
                            points="481.517349 221.05716 489.920815 221.039932 489.903587 229.463291 481.500121 229.480519"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="467"
                            id="a"
                            fill="#84898B"
                            transform="translate(491.928297, 236.899092) rotate(64.000000) translate(-491.928297, -236.899092) "
                            points="487.735553 232.694101 496.136718 232.678425 496.121042 241.104084 487.719877 241.11976"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="478"
                            id="a"
                            fill="#84898B"
                            transform="translate(497.315245, 248.941295) rotate(68.000000) translate(-497.315245, -248.941295) "
                            points="493.122603 244.734344 501.521706 244.720525 501.507887 253.148247 493.108785 253.162066"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="421"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(482.680512, 192.857444) rotate(51.690000) translate(-482.680512, -192.857444) "
                            points="478.485784 188.658113 486.894593 188.63876 486.87524 197.056775 478.466431 197.076128"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="431"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(489.789652, 202.367400) rotate(55.010000) translate(-489.789652, -202.367400) "
                            points="485.595696 198.166634 494.002298 198.147944 493.983608 206.568166 485.577006 206.586857"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="438"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(496.333505, 212.271161) rotate(58.330000) translate(-496.333505, -212.271161) "
                            points="492.14015 208.068881 500.544637 208.051103 500.526859 216.473441 492.122372 216.491219"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="450"
                            id="a"
                            fill="#00c86e"
                            transform="translate(502.307138, 222.566910) rotate(61.660000) translate(-502.307138, -222.566910) "
                            points="498.114207 218.363052 506.516692 218.346429 506.500069 226.770769 498.097584 226.787391"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="468"
                            id="a"
                            fill="#84898B"
                            transform="translate(507.654632, 233.158269) rotate(64.980000) translate(-507.654632, -233.158269) "
                            points="503.461938 228.952798 511.862574 228.937551 511.847327 237.363739 503.446691 237.378987"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="479"
                            id="a"
                            fill="#84898B"
                            transform="translate(512.376873, 244.040077) rotate(68.300000) translate(-512.376873, -244.040077) "
                            points="508.184227 239.832978 516.583186 239.81931 516.569518 248.247176 508.170559 248.260844"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="422"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(506.231303, 171.766377) rotate(51.200000) translate(-506.231303, -171.766377) "
                            points="502.036447 167.56725 510.445587 167.547821 510.426158 175.965505 502.017018 175.984934"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="432"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(513.586602, 181.363870) rotate(54.130000) translate(-513.586602, -181.363870) "
                            points="509.392458 177.163492 517.799637 177.144601 517.780746 185.564247 509.373567 185.583138"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="439"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(520.439376, 191.323014) rotate(57.060000) translate(-520.439376, -191.323014) "
                            points="516.245813 187.121321 524.651096 187.103165 524.63294 195.524707 516.227657 195.542863"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="451"
                            id="a"
                            fill="#00c86e"
                            transform="translate(526.792411, 201.653452) rotate(60.000000) translate(-526.792411, -201.653452) "
                            points="522.599292 197.450387 531.002757 197.433159 530.98553 205.856518 522.582064 205.873745"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="457"
                            id="a"
                            fill="#00c86e"
                            transform="translate(532.585886, 212.257914) rotate(62.930000) translate(-532.585886, -212.257914) "
                            points="528.393068 208.053443 536.794827 208.03732 536.778704 216.462386 528.376946 216.478508"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="423"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(517.999968, 161.220931) rotate(51.000000) translate(-517.999968, -161.220931) "
                            points="513.805059 157.021886 522.214335 157.002428 522.194877 165.419976 513.785601 165.439434"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="433"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(526.063312, 171.679711) rotate(54.000000) translate(-526.063312, -171.679711) "
                            points="521.869139 167.479391 530.276404 167.460472 530.257485 175.880031 521.85022 175.89895"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="440"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(533.565641, 182.544169) rotate(57.000000) translate(-533.565641, -182.544169) "
                            points="529.372067 178.342504 537.777388 178.324331 537.759215 186.745835 529.353894 186.764008"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="452"
                            id="a"
                            fill="#00c86e"
                            transform="translate(540.486391, 193.784528) rotate(60.000000) translate(-540.486391, -193.784528) "
                            points="536.293272 189.581462 544.696738 189.564234 544.679511 197.987593 536.276045 198.004821"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="458"
                            id="a"
                            fill="#84898B"
                            transform="translate(546.806594, 205.369977) rotate(63.000000) translate(-546.806594, -205.369977) "
                            points="542.613781 201.165471 551.0155 201.149377 550.999407 209.574482 542.597687 209.590576"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="424"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(529.756058, 150.664413) rotate(50.820000) translate(-529.756058, -150.664413) "
                            points="525.561101 146.465442 533.970499 146.445958 533.951016 154.863384 525.541617 154.882868"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="434"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(536.375377, 159.086175) rotate(53.110000) translate(-536.375377, -159.086175) "
                            points="532.180999 154.886241 540.588855 154.86714 540.569754 163.286109 532.161898 163.30521"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="441"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(542.677940, 167.802894) rotate(55.410000) translate(-542.677940, -167.802894) "
                            points="538.484066 163.601949 546.890408 163.583355 546.871814 172.003838 538.465472 172.022432"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="445"
                            id="a"
                            fill="#00c86e"
                            transform="translate(548.598884, 176.724858) rotate(57.700000) translate(-548.598884, -176.724858) "
                            points="544.405429 172.52287 552.810308 172.5049 552.792339 180.926845 544.387459 180.944815"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="453"
                            id="a"
                            fill="#00c86e"
                            transform="translate(554.180372, 185.915603) rotate(60.000000) translate(-554.180372, -185.915603) "
                            points="549.987253 181.712538 558.390719 181.69531 558.373491 190.118669 549.970026 190.135896"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="459"
                            id="a"
                            fill="#84898B"
                            transform="translate(559.364963, 195.280541) rotate(62.290000) translate(-559.364963, -195.280541) "
                            points="555.172091 191.076379 563.574213 191.060001 563.557834 199.484703 555.155712 199.501082"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="425"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(541.510321, 140.109377) rotate(50.660000) translate(-541.510321, -140.109377) "
                            points="537.31532 135.910472 545.724827 135.890966 545.705321 144.308283 537.295814 144.327789"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="435"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(548.693569, 149.204389) rotate(53.000000) translate(-548.693569, -149.204389) "
                            points="544.499165 145.004502 552.907095 144.98538 552.887972 153.404275 544.480043 153.423397"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="442"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(555.469469, 158.543054) rotate(55.330000) translate(-555.469469, -158.543054) "
                            points="551.275579 154.342145 559.681973 154.323532 559.663359 162.743962 551.256965 162.762576"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="446"
                            id="a"
                            fill="#00c86e"
                            transform="translate(561.858305, 168.148173) rotate(57.660000) translate(-561.858305, -168.148173) "
                            points="557.664843 163.946204 566.069748 163.928222 566.051766 172.350142 557.646861 172.368123"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="454"
                            id="a"
                            fill="#00c86e"
                            transform="translate(567.874353, 178.046679) rotate(60.000000) translate(-567.874353, -178.046679) "
                            points="563.681234 173.843613 572.0847 173.826386 572.067472 182.249744 563.664006 182.266972"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="460"
                            id="a"
                            fill="#84898B"
                            transform="translate(573.456255, 188.137614) rotate(62.330000) translate(-573.456255, -188.137614) "
                            points="569.263387 183.933432 577.665486 183.91707 577.649123 192.341795 569.247024 192.358158"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="426"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(553.273575, 129.568315) rotate(50.520000) translate(-553.273575, -129.568315) "
                            points="549.078536 125.369467 557.488139 125.349942 557.468614 133.767163 549.059011 133.786688"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="436"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(559.479393, 137.324951) rotate(52.420000) translate(-559.479393, -137.324951) "
                            points="555.284849 133.125312 563.693167 133.106083 563.673937 141.52459 555.26562 141.54382"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="443"
                            id="a"
                            fill="#00c86e"
                            transform="translate(565.392821, 145.239718) rotate(54.310000) translate(-565.392821, -145.239718) "
                            points="561.198716 141.039262 569.605777 141.02041 569.586925 149.440174 561.179864 149.459026"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="447"
                            id="a"
                            fill="#00c86e"
                            transform="translate(571.069925, 153.387659) rotate(56.210000) translate(-571.069925, -153.387659) "
                            points="566.876207 149.186354 575.282032 149.167965 575.263643 157.588964 566.857817 157.607353"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="455"
                            id="a"
                            fill="#00c86e"
                            transform="translate(576.444775, 161.674148) rotate(58.100000) translate(-576.444775, -161.674148) "
                            points="572.251385 157.471975 580.656015 157.454126 580.638166 165.876321 572.233536 165.89417"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="461"
                            id="a"
                            fill="#84898B"
                            transform="translate(581.568334, 170.177754) rotate(60.000000) translate(-581.568334, -170.177754) "
                            points="577.375215 165.974689 585.778681 165.957461 585.761453 174.38082 577.357987 174.398047"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="463"
                            id="a"
                            fill="#84898B"
                            transform="translate(586.381099, 178.799721) rotate(61.890000) translate(-586.381099, -178.799721) "
                            points="582.18819 174.595752 590.590542 174.579218 590.574007 183.003691 582.171656 183.020225"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="427"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(565.056695, 119.053670) rotate(50.400000) translate(-565.056695, -119.053670) "
                            points="560.861623 114.85487 569.271308 114.83533 569.251767 123.25247 560.842082 123.27201"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="437"
                            id="a"
                            fill="#1eb4ff"
                            transform="translate(571.673795, 127.291860) rotate(52.320000) translate(-571.673795, -127.291860) "
                            points="567.479226 123.092263 575.88761 123.073016 575.868363 131.491456 567.459979 131.510703"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="444"
                            id="a"
                            fill="#00c86e"
                            transform="translate(578.009858, 135.746078) rotate(54.240000) translate(-578.009858, -135.746078) "
                            points="573.815738 131.545653 582.222845 131.526786 582.203978 139.946504 573.796871 139.965371"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="448"
                            id="a"
                            fill="#00c86e"
                            transform="translate(584.057772, 144.406833) rotate(56.160000) translate(-584.057772, -144.406833) "
                            points="579.864044 140.20555 588.269901 140.187148 588.251499 148.608115 579.845642 148.626517"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="456"
                            id="a"
                            fill="#00c86e"
                            transform="translate(589.810744, 153.264398) rotate(58.080000) translate(-589.810744, -153.264398) "
                            points="585.61735 149.062235 594.021992 149.044379 594.004137 157.466562 585.599495 157.484417"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="462"
                            id="a"
                            fill="#84898B"
                            transform="translate(595.262315, 162.308830) rotate(60.000000) translate(-595.262315, -162.308830) "
                            points="591.069196 158.105764 599.472662 158.088537 599.455434 166.511895 591.051968 166.529123"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="464"
                            id="a"
                            fill="#84898B"
                            transform="translate(600.406364, 171.529972) rotate(61.920000) translate(-600.406364, -171.529972) "
                            points="596.213458 167.325988 604.615793 167.309465 604.59927 175.733955 596.196935 175.750478"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="490"
                            id="a"
                            fill="#84898B"
                            transform="translate(490.414004, 278.862918) rotate(76.360000) translate(-490.414004, -278.862918) "
                            points="486.220697 274.651931 494.616429 274.642813 494.607311 283.073906 486.211579 283.083023"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="503"
                            id="a"
                            fill="#84898B"
                            transform="translate(493.386567, 293.949692) rotate(81.450000) translate(-493.386567, -293.949692) "
                            points="489.192293 289.736403 497.586691 289.730554 497.580842 298.16298 489.186443 298.168829"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="491"
                            id="a"
                            fill="#84898B"
                            transform="translate(505.495696, 273.999356) rotate(76.000000) translate(-505.495696, -273.999356) "
                            points="501.302441 269.788537 509.698289 269.779198 509.68895 278.210175 501.293102 278.219514"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="504"
                            id="a"
                            fill="#84898B"
                            transform="translate(508.249343, 286.893134) rotate(80.000000) translate(-508.249343, -286.893134) "
                            points="504.055386 282.680483 512.450105 282.673679 512.443301 291.105784 504.048582 291.112588"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="513"
                            id="a"
                            fill="#84898B"
                            transform="translate(510.092596, 299.946681) rotate(84.000000) translate(-510.092596, -299.946681) "
                            points="505.897687 295.732314 514.291641 295.728178 514.287505 304.161048 505.893551 304.165184"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="492"
                            id="a"
                            fill="#84898B"
                            transform="translate(520.566463, 269.118687) rotate(75.690000) translate(-520.566463, -269.118687) "
                            points="516.373252 264.908014 524.769202 264.898486 524.759673 273.32936 516.363723 273.338889"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="505"
                            id="a"
                            fill="#84898B"
                            transform="translate(523.174603, 280.684371) rotate(79.010000) translate(-523.174603, -280.684371) "
                            points="518.980843 276.472164 527.375808 276.464718 527.368363 284.896578 518.973397 284.904023"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="514"
                            id="a"
                            fill="#84898B"
                            transform="translate(525.105393, 292.380974) rotate(82.330000) translate(-525.105393, -292.380974) "
                            points="520.91091 288.167308 529.305138 288.162045 529.299876 296.594641 520.905648 296.599904"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="469"
                            id="a"
                            fill="#84898B"
                            transform="translate(537.827162, 223.143255) rotate(65.860000) translate(-537.827162, -223.143255) "
                            points="533.634499 218.937354 542.034673 218.922506 542.019825 227.349156 533.619651 227.364005"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="480"
                            id="a"
                            fill="#84898B"
                            transform="translate(542.517509, 234.319426) rotate(68.800000) translate(-542.517509, -234.319426) "
                            points="538.324855 230.112082 546.723577 230.098668 546.710163 238.52677 538.311441 238.540184"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="493"
                            id="a"
                            fill="#84898B"
                            transform="translate(550.700353, 259.384818) rotate(75.200000) translate(-550.700353, -259.384818) "
                            points="546.507208 255.174376 554.903323 255.16455 554.893497 263.595259 546.497382 263.605085"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="506"
                            id="a"
                            fill="#84898B"
                            transform="translate(554.491379, 276.100357) rotate(79.360000) translate(-554.491379, -276.100357) "
                            points="550.297551 271.887993 558.692426 271.880773 558.685207 280.312722 550.290331 280.319941"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="470"
                            id="a"
                            fill="#84898B"
                            transform="translate(552.508925, 217.268762) rotate(66.000000) translate(-552.508925, -217.268762) "
                            points="548.316266 213.062792 556.716367 213.048008 556.701584 221.474731 548.301483 221.489515"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="481"
                            id="a"
                            fill="#84898B"
                            transform="translate(557.577755, 229.448269) rotate(69.000000) translate(-557.577755, -229.448269) "
                            points="553.385096 225.240826 561.783725 225.227515 561.770414 233.655711 553.371785 233.669022"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="494"
                            id="a"
                            fill="#84898B"
                            transform="translate(565.761114, 254.515238) rotate(75.000000) translate(-565.761114, -254.515238) "
                            points="561.567995 250.304892 569.964179 250.294945 569.954233 258.725585 561.558048 258.735532"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="507"
                            id="a"
                            fill="#84898B"
                            transform="translate(570.193502, 274.058696) rotate(79.560000) translate(-570.193502, -274.058696) "
                            points="565.999634 269.846242 574.39446 269.839152 574.38737 278.27115 565.992544 278.27824"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="471"
                            id="a"
                            fill="#84898B"
                            transform="translate(564.169440, 204.844186) rotate(64.580000) translate(-564.169440, -204.844186) "
                            points="559.976727 200.638911 568.377578 200.623486 568.362153 209.049461 559.961303 209.064885"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="482"
                            id="a"
                            fill="#84898B"
                            transform="translate(568.604557, 214.634204) rotate(66.880000) translate(-568.604557, -214.634204) "
                            points="564.411914 210.427803 572.811568 210.413435 572.7972 218.840606 564.397547 218.854974"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="486"
                            id="a"
                            fill="#84898B"
                            transform="translate(572.624668, 224.549841) rotate(69.170000) translate(-572.624668, -224.549841) "
                            points="568.432004 220.342316 576.830555 220.329093 576.817332 228.757367 568.418782 228.77059"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="495"
                            id="a"
                            fill="#84898B"
                            transform="translate(580.814912, 249.630454) rotate(74.820000) translate(-580.814912, -249.630454) "
                            points="576.621816 245.420192 585.018063 245.410138 585.008008 253.840715 576.611761 253.85077"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="499"
                            id="a"
                            fill="#84898B"
                            transform="translate(583.597055, 260.777809) rotate(77.280000) translate(-583.597055, -260.777809) "
                            points="579.403603 256.566394 587.799052 256.557848 587.790506 264.989225 579.395058 264.99777"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="508"
                            id="a"
                            fill="#84898B"
                            transform="translate(585.887539, 271.987795) rotate(79.730000) translate(-585.887539, -271.987795) "
                            points="581.693637 267.775265 590.088421 267.768285 590.081441 276.200326 581.686657 276.207305"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="472"
                            id="a"
                            fill="#84898B"
                            transform="translate(578.621351, 198.446067) rotate(64.660000) translate(-578.621351, -198.446067) "
                            points="574.428642 194.240753 582.829449 194.225364 582.81406 202.651381 574.413253 202.666771"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="483"
                            id="a"
                            fill="#84898B"
                            transform="translate(583.380515, 209.000505) rotate(67.000000) translate(-583.380515, -209.000505) "
                            points="579.187873 204.794044 587.587466 204.779734 587.573157 213.206965 579.173563 213.221275"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="487"
                            id="a"
                            fill="#84898B"
                            transform="translate(587.685205, 219.693277) rotate(69.330000) translate(-587.685205, -219.693277) "
                            points="583.492537 215.485673 591.891013 215.472533 591.877874 223.900881 583.479397 223.914021"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="496"
                            id="a"
                            fill="#84898B"
                            transform="translate(595.866434, 244.746283) rotate(74.660000) translate(-595.866434, -244.746283) "
                            points="591.673357 240.536098 600.069661 240.525948 600.059511 248.956469 591.663207 248.966619"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="500"
                            id="a"
                            fill="#84898B"
                            transform="translate(599.021429, 257.312544) rotate(77.280000) translate(-599.021429, -257.312544) "
                            points="594.827977 253.101128 603.223425 253.092583 603.21488 261.523959 594.819432 261.532505"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="509"
                            id="a"
                            fill="#84898B"
                            transform="translate(601.587261, 269.960533) rotate(79.890000) translate(-601.587261, -269.960533) "
                            points="597.393327 265.747931 605.788072 265.741056 605.781196 274.173135 597.386451 274.180011"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="473"
                            id="a"
                            fill="#84898B"
                            transform="translate(590.905539, 187.574978) rotate(63.780000) translate(-590.905539, -187.574978) "
                            points="586.712781 183.370093 595.114066 183.354324 595.098297 191.779862 586.697011 191.795632"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="475"
                            id="a"
                            fill="#84898B"
                            transform="translate(595.158330, 196.541531) rotate(65.680000) translate(-595.158330, -196.541531) "
                            points="590.965662 192.335718 599.365929 192.320787 599.350998 200.747344 590.950731 200.762275"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="484"
                            id="a"
                            fill="#84898B"
                            transform="translate(599.090083, 205.595250) rotate(67.570000) translate(-599.090083, -205.595250) "
                            points="594.897444 201.388509 603.296755 201.374477 603.282723 209.80199 594.883412 209.816022"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="488"
                            id="a"
                            fill="#84898B"
                            transform="translate(602.738078, 214.821976) rotate(69.470000) translate(-602.738078, -214.821976) "
                            points="598.545404 210.614303 606.943817 210.601237 606.930751 219.029649 598.532338 219.042715"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="497"
                            id="a"
                            fill="#84898B"
                            transform="translate(610.920461, 239.878518) rotate(74.520000) translate(-610.920461, -239.878518) "
                            points="606.727401 235.6684 615.123755 235.658166 615.113521 244.088637 606.717167 244.098871"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="501"
                            id="a"
                            fill="#84898B"
                            transform="translate(614.445803, 253.847279) rotate(77.280000) translate(-614.445803, -253.847279) "
                            points="610.252351 249.635863 618.647799 249.627318 618.639254 258.058694 610.243806 258.067239"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="510"
                            id="a"
                            fill="#84898B"
                            transform="translate(617.282162, 267.917387) rotate(80.030000) translate(-617.282162, -267.917387) "
                            points="613.088198 263.704722 621.48291 263.697938 621.476126 272.130051 613.081414 272.136835"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="474"
                            id="a"
                            fill="#84898B"
                            transform="translate(605.237115, 180.917470) rotate(63.840000) translate(-605.237115, -180.917470) "
                            points="601.044361 176.712556 609.445614 176.696812 609.42987 185.122384 601.028617 185.138128"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="476"
                            id="a"
                            fill="#84898B"
                            transform="translate(609.749144, 190.460784) rotate(65.760000) translate(-609.749144, -190.460784) "
                            points="605.556479 186.254932 613.956704 186.240037 613.94181 194.666636 605.541584 194.681531"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="485"
                            id="a"
                            fill="#84898B"
                            transform="translate(613.937385, 200.149198) rotate(67.680000) translate(-613.937385, -200.149198) "
                            points="609.744745 195.942404 618.144003 195.928426 618.130025 204.355993 609.730767 204.369971"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="489"
                            id="a"
                            fill="#84898B"
                            transform="translate(617.797135, 209.971835) rotate(69.600000) translate(-617.797135, -209.971835) "
                            points="613.604457 205.764098 622.002811 205.7511 621.989812 214.179571 613.591459 214.192569"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="498"
                            id="a"
                            fill="#84898B"
                            transform="translate(625.981840, 235.042929) rotate(74.400000) translate(-625.981840, -235.042929) "
                            points="621.788794 230.832867 630.185191 230.822562 630.174886 239.25299 621.778489 239.263295"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="502"
                            id="a"
                            fill="#84898B"
                            transform="translate(628.660205, 245.247609) rotate(76.320000) translate(-628.660205, -245.247609) "
                            points="624.466903 241.036641 632.862648 241.027498 632.853506 249.458578 624.457761 249.46772"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="511"
                            id="a"
                            fill="#84898B"
                            transform="translate(630.993547, 255.535873) rotate(78.240000) translate(-630.993547, -255.535873) "
                            points="626.79993 251.324016 635.195102 251.316078 635.187164 259.74773 626.791992 259.755669"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="512"
                            id="a"
                            fill="#84898B"
                            transform="translate(632.979247, 265.896169) rotate(80.160000) translate(-632.979247, -265.896169) "
                            points="628.785256 261.683447 637.179937 261.676748 637.173238 270.108891 628.778557 270.11559"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="522"
                            id="a"
                            fill="#84898B"
                            transform="translate(495.002559, 309.239454) rotate(86.540000) translate(-495.002559, -309.239454) "
                            points="490.806925 305.024073 499.20059 305.021676 499.198193 313.454836 490.804528 313.457233"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="531"
                            id="a"
                            fill="#84898B"
                            transform="translate(495.249233, 324.611618) rotate(91.630000) translate(-495.249233, -324.611618) "
                            points="491.051892 320.394416 499.445444 320.395547 499.446575 328.82882 491.053023 328.827689"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="523"
                            id="a"
                            fill="#84898B"
                            transform="translate(511.016472, 313.096403) rotate(88.000000) translate(-511.016472, -313.096403) "
                            points="506.820382 308.880468 515.21395 308.879081 515.212563 317.312337 506.818995 317.313725"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="532"
                            id="a"
                            fill="#84898B"
                            transform="translate(511.016472, 326.278235) rotate(92.000000) translate(-511.016472, -326.278235) "
                            points="506.818995 322.060913 515.212563 322.062301 515.21395 330.495557 506.820382 330.49417"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="515"
                            id="a"
                            fill="#84898B"
                            transform="translate(526.355071, 304.204842) rotate(85.660000) translate(-526.355071, -304.204842) "
                            points="522.159698 299.989805 530.553445 299.986802 530.550443 308.41988 522.156696 308.422882"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="524"
                            id="a"
                            fill="#84898B"
                            transform="translate(526.911937, 316.045291) rotate(88.980000) translate(-526.911937, -316.045291) "
                            points="522.715525 311.828998 531.109057 311.82829 531.108349 320.261583 522.714817 320.262291"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="533"
                            id="a"
                            fill="#84898B"
                            transform="translate(526.778908, 327.897964) rotate(92.300000) translate(-526.778908, -327.897964) "
                            points="522.581319 323.680546 530.974902 323.682141 530.976498 332.115382 522.582914 332.113787"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="516"
                            id="a"
                            fill="#84898B"
                            transform="translate(557.920248, 302.233784) rotate(85.760000) translate(-557.920248, -302.233784) "
                            points="553.724847 298.018707 562.118584 298.015774 562.11565 306.448861 553.721913 306.451795"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="525"
                            id="a"
                            fill="#84898B"
                            transform="translate(558.544517, 316.267706) rotate(89.170000) translate(-558.544517, -316.267706) "
                            points="554.348042 312.051346 562.741569 312.05077 562.740993 320.484067 554.347465 320.484643"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="534"
                            id="a"
                            fill="#84898B"
                            transform="translate(558.328978, 330.313738) rotate(92.580000) translate(-558.328978, -330.313738) "
                            points="554.131283 326.096231 562.524883 326.09802 562.526673 334.531245 554.133072 334.529455"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="517"
                            id="a"
                            fill="#84898B"
                            transform="translate(573.622588, 300.193769) rotate(85.560000) translate(-573.622588, -300.193769) "
                            points="569.427244 295.978771 577.821002 295.9757 577.817931 304.408767 569.424173 304.411837"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="526"
                            id="a"
                            fill="#84898B"
                            transform="translate(574.346339, 315.468473) rotate(89.040000) translate(-574.346339, -315.468473) "
                            points="570.149907 311.25216 578.543437 311.251493 578.542771 319.684787 570.14924 319.685454"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="535"
                            id="a"
                            fill="#84898B"
                            transform="translate(574.137184, 330.758737) rotate(92.520000) translate(-574.137184, -330.758737) "
                            points="569.939512 326.541249 578.333108 326.542996 578.334856 334.976224 569.94126 334.974477"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="518"
                            id="a"
                            fill="#84898B"
                            transform="translate(589.320881, 298.137535) rotate(85.380000) translate(-589.320881, -298.137535) "
                            points="585.12559 293.922609 593.519367 293.919415 593.516173 302.352462 585.122396 302.355656"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="527"
                            id="a"
                            fill="#84898B"
                            transform="translate(590.146544, 314.644543) rotate(88.920000) translate(-590.146544, -314.644543) "
                            points="585.950152 310.428272 594.343686 310.427522 594.342936 318.860813 585.949402 318.861563"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="536"
                            id="a"
                            fill="#84898B"
                            transform="translate(589.946569, 331.170794) rotate(92.460000) translate(-589.946569, -331.170794) "
                            points="585.74892 326.953325 594.142513 326.955031 594.144219 335.388263 585.750626 335.386557"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="519"
                            id="a"
                            fill="#84898B"
                            transform="translate(605.016825, 296.081491) rotate(85.220000) translate(-605.016825, -296.081491) "
                            points="600.821579 291.866628 609.215374 291.863324 609.212071 300.296353 600.818275 300.299657"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="528"
                            id="a"
                            fill="#84898B"
                            transform="translate(605.819213, 309.405660) rotate(87.920000) translate(-605.819213, -309.405660) "
                            points="601.623149 305.189755 610.01672 305.188312 610.015277 313.621565 601.621706 313.623008"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="537"
                            id="a"
                            fill="#84898B"
                            transform="translate(605.990614, 322.703219) rotate(90.610000) translate(-605.990614, -322.703219) "
                            points="601.793641 318.486356 610.187164 318.48678 610.187588 326.920081 601.794064 326.919657"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="540"
                            id="a"
                            fill="#84898B"
                            transform="translate(605.534786, 335.994130) rotate(93.300000) translate(-605.534786, -335.994130) "
                            points="601.336817 331.7764 609.730468 331.778687 609.732755 340.21186 601.339104 340.209574"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="520"
                            id="a"
                            fill="#84898B"
                            transform="translate(620.712210, 294.042031) rotate(85.080000) translate(-620.712210, -294.042031) "
                            points="616.517003 289.827224 624.910815 289.823825 624.907416 298.256837 616.513604 298.260237"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="521"
                            id="a"
                            fill="#84898B"
                            transform="translate(636.524657, 292.992841) rotate(85.080000) translate(-636.524657, -292.992841) "
                            points="632.32945 288.778034 640.723262 288.774635 640.719863 297.207647 632.326051 297.211047"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="529"
                            id="a"
                            fill="#84898B"
                            transform="translate(621.599754, 308.260780) rotate(87.810000) translate(-621.599754, -308.260780) "
                            points="617.403724 304.044916 625.797302 304.043397 625.795783 312.476644 617.402205 312.478163"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="538"
                            id="a"
                            fill="#84898B"
                            transform="translate(621.805849, 322.505466) rotate(90.540000) translate(-621.805849, -322.505466) "
                            points="617.6089 318.288628 626.002423 318.289003 626.002798 326.722304 617.609275 326.721929"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="541"
                            id="a"
                            fill="#84898B"
                            transform="translate(621.330027, 336.743755) rotate(93.270000) translate(-621.330027, -336.743755) "
                            points="617.13207 332.526035 625.525719 332.5283 625.527985 340.961476 617.134336 340.95921"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="530"
                            id="a"
                            fill="#84898B"
                            transform="translate(637.381278, 307.165340) rotate(87.720000) translate(-637.381278, -307.165340) "
                            points="633.185278 302.94951 641.57886 302.947929 641.577279 311.381171 633.183696 311.382752"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="539"
                            id="a"
                            fill="#84898B"
                            transform="translate(637.620541, 322.324190) rotate(90.480000) translate(-637.620541, -322.324190) "
                            points="633.423614 318.107372 641.817136 318.107705 641.817469 326.541008 633.423947 326.540675"
                        ></polygon>
                        <polygon
                            className=""
                            data-index="542"
                            id="a"
                            fill="#DDDDDD"
                            transform="translate(637.126131, 337.476922) rotate(93.240000) translate(-637.126131, -337.476922) "
                            points="632.928185 333.259211 641.321832 333.261456 641.324077 341.694634 632.93043 341.692389"
                        ></polygon>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>
 
            <h2>एनडीए Vs यूपीए 2019</h2>

            <div className={styles.graph}>

            </div>
            
            <div className={styles.accordion}>
                <div className={styles.heading}>
                    <div className={styles.name}>एनडीए</div>
                    <div className={styles.seat}>सीटें</div>
                    <div className={styles.vote}>वोट %</div>
                    <i className={`${styles.navIcon} ${styles.active}`}>-</i>
                </div>

                <ul className={`${styles.list} ${styles.active}`}>
                    <li>
                        <div className={styles.name}>बीजेपी</div>
                        <div className={styles.seat}>282</div>
                        <div className={styles.vote}>31.33%</div>
                    </li>
                    <li>
                        <div className={styles.name}>शिवसेना</div>
                        <div className={styles.seat}>18</div>
                        <div className={styles.vote}>1.82%</div>
                    </li>
                    <li>
                        <div className={styles.name}>टीडीपी</div>
                        <div className={styles.seat}>16</div>
                        <div className={styles.vote}>2.55%</div>
                    </li>
                    <li>
                        <div className={styles.name}>लोजपा</div>
                        <div className={styles.seat}>6</div>
                        <div className={styles.vote}>0.41%</div>
                    </li>
                    <li>
                        <div className={styles.name}>अन्य</div>
                        <div className={styles.seat}>14</div>
                        <div className={styles.vote}>2.39%</div>
                    </li>
                </ul>
            </div>
            
            <div className={styles.accordion}>
                <div className={styles.heading}>
                    <div className={styles.name}>एनडीए</div>
                    <div className={styles.seat}>सीटें</div>
                    <div className={styles.vote}>वोट %</div>
                    <i className={`${styles.navIcon}`}>+</i>
                </div>

                <ul className={styles.list}>
                    <li>
                        <div className={styles.name}>बीजेपी</div>
                        <div className={styles.seat}>282</div>
                        <div className={styles.vote}>31.33%</div>
                    </li>
                    <li>
                        <div className={styles.name}>शिवसेना</div>
                        <div className={styles.seat}>18</div>
                        <div className={styles.vote}>1.82%</div>
                    </li>
                    <li>
                        <div className={styles.name}>टीडीपी</div>
                        <div className={styles.seat}>16</div>
                        <div className={styles.vote}>2.55%</div>
                    </li>
                    <li>
                        <div className={styles.name}>लोजपा</div>
                        <div className={styles.seat}>6</div>
                        <div className={styles.vote}>0.41%</div>
                    </li>
                    <li>
                        <div className={styles.name}>अन्य</div>
                        <div className={styles.seat}>14</div>
                        <div className={styles.vote}>2.39%</div>
                    </li>
                </ul>            
            </div>
            
            <div className={styles.accordion}>
                <div className={styles.heading}>
                    <div className={styles.name}>एनडीए</div>
                    <div className={styles.seat}>सीटें</div>
                    <div className={styles.vote}>वोट %</div>
                    <i className={`${styles.navIcon}`}>+</i>
                </div>

                <ul className={styles.list}>
                    <li>
                        <div className={styles.name}>बीजेपी</div>
                        <div className={styles.seat}>282</div>
                        <div className={styles.vote}>31.33%</div>
                    </li>
                    <li>
                        <div className={styles.name}>शिवसेना</div>
                        <div className={styles.seat}>18</div>
                        <div className={styles.vote}>1.82%</div>
                    </li>
                    <li>
                        <div className={styles.name}>टीडीपी</div>
                        <div className={styles.seat}>16</div>
                        <div className={styles.vote}>2.55%</div>
                    </li>
                    <li>
                        <div className={styles.name}>लोजपा</div>
                        <div className={styles.seat}>6</div>
                        <div className={styles.vote}>0.41%</div>
                    </li>
                    <li>
                        <div className={styles.name}>अन्य</div>
                        <div className={styles.seat}>14</div>
                        <div className={styles.vote}>2.39%</div>
                    </li>
                </ul>
            </div>
        </div>
    </>
  )
}