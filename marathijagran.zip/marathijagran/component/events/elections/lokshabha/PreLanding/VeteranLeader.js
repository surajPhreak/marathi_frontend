import React, { useState } from 'react'
import Image from 'next/image'
//import styles from '../../../../../public/css/VeteranLeader.module.css'
import styles from'../../../../../public/css/VeteranLeader.module.css'
export default function VeteranLeader(props) {
  const { data, payload1 } = props
  const [politician, Setpolitician] = useState(data);

  const [selectedOption, setSelectedOption] = useState(''); // State to track the selected option

  const [isOpen, setOpen] = useState(true);

  // Define a function to handle the select input change event
  const handleSelectChange = async (event) => { // Make the function async
    const selectedValue = event.target.value;
    let res = [];
    try {
      
     if(selectedValue=='all'){   
      res = await fetch(`https://stg-api.jagran.com/api/jagran/election/ls/mh/allstarcandidates/2019`, payload1
      );
    
     }
     if(selectedValue=='bjp'){   
        res = await fetch(`https://stg-api.jagran.com/api/jagran/election/ls/mh/starcandidates/bjp/2019`, payload1
        
        
        );
      
       }

       if(selectedValue=='congress'){   
        res = await fetch(`https://stg-api.jagran.com/api/jagran/election/ls/mh/starcandidates/congress/2019`, payload1
        
        
        );
      
       }  
       if(selectedValue=='othor'){
        res = await fetch(`https://stg-api.jagran.com/api/jagran/election/ls/mh/starcandidates/others/2019`, payload1
        
        
        );
       }

      if (!res.ok) {
        throw new Error('Failed to fetch posts');
      }
      const newPosts = await res.json();

      // Update the selected option and displayed data based on the selection
      setSelectedOption(selectedValue);
      Setpolitician(newPosts);

      setOpen(true)

    } catch (error) {
      console.error('Error fetching posts:', error);
      setSelectedOption(selectedValue);
      setOpen(!isOpen)
    }
  };

  return (
    <>
      <div className={`${styles.VeteranLeader} mb30`}>
        <div className={styles.top}>
            <h3>मोठे नेते 2019</h3>

            <div className={styles.choose}>
                <div className={styles.select}>
                    <select value={selectedOption} onChange={handleSelectChange}>
                        <option value='all'>सर्व</option>
                        <option value='bjp'>भाजप</option>
                        <option value='congress'>काँग्रेस</option>
                        <option value='othor'>इतर</option>
                    </select>
                </div>
            </div>  
        </div>

        <div className={styles.block}>
            <ul className={styles.partyDetail}>
                <li>
                    <div className={styles.name}>उमेदवाराचे नाव</div>
                    <div className={styles.party}>संघ</div>
                   
                </li>
                {politician.map((item, index)=>{
                   if (item.candidateNameMH && item.candidateNameMH !== 'null'){
                    return(
                <li key={index} className={styles.bjp}>
                    <div className={styles.name}>
                        <Image unoptimized width={38} height={38} src={`https://www.jagranimages.com/images/electionImages/${item.candidateNameEN.toLowerCase().replaceAll(' ','-')}.jpg`} onError={(e) => {e.target.src = 'https://www.jagranimages.com/images/electionImages/default-election-images.jpg';  }} />
                        {item.candidateNameMH}
                    </div>
                    <div className={styles.party}>
                        {item.party}
                    </div>
                    
                </li>
                )}
                })}
               
            </ul>
        </div>
      </div>
    </>
  )
}