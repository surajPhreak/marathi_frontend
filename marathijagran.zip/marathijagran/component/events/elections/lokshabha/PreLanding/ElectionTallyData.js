import React from 'react'
import Image from 'next/image'
import styles from'../../../../../public/css/ElectionTallyData.module.css'
import { useState, useEffect } from 'react';
import { useRef } from 'react';

export default function ElectionTallyData(props) {
  const findRef = useRef(null);

  const { data, payload } = props;
  const [pmdata, setPm] = useState([]);
  const [firstPartyColor, setFirstPartyColor] = useState('defaultColor1');
  const [secondPartyColor, setSecondPartyColor] = useState('defaultColor2');

  const [selectedYear, setSelectedYear] = useState('2019');


  const handleYearChange = (event) => {
    setSelectedYear(event.target.value);

  };

  const updateGraph = () => {
    const selectedYearData = data.loksabha_year.find(
      (year) => year.loksabha_year.toString() === selectedYear
    );

    
  const fetchPosts = async () => {
    try {
      const res = await fetch(`https://api.jagran.com/api/jagran/election/ls/mh/gov/answers/${selectedYear}`, payload);
      if (!res.ok) {
        throw new Error('Failed to fetch posts');
      }
      const newPosts = await res.json();
   
      setPm(newPosts);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };
  fetchPosts()

    const otherData = selectedYearData.total_count_parliament - (selectedYearData.party_count_1 + selectedYearData.party_count_2);

    const partyColors = {
      BJP: '#f35717',
      INC: '#25bb5a',
      JD: '#10783b',
      TDP: '#dada52',
      JNPS: '#f35717',
      BLD: '#f58320',
      CPM: '#de0000',
      SWA: '#22409a',
      CPI: '#de0000',
      // Add more party names and colors as needed
    };



    var secondPartyColor = partyColors[selectedYearData.short_party_name_en_2] || 'defaultColor1';
    var firstPartyColor = partyColors[selectedYearData.short_party_name_en_1] || 'defaultColor2';
  
    setFirstPartyColor(partyColors[selectedYearData.short_party_name_en_1] || 'defaultColor1');
    setSecondPartyColor(partyColors[selectedYearData.short_party_name_en_2] || 'defaultColor2');


    // Create the div elements with the provided styles
    const otherElement = document.createElement('div');
    otherElement.className = styles.other;
    otherElement.style.setProperty('--percentage', `${(otherData * 100) / selectedYearData.total_count_parliament}`);
    otherElement.style.setProperty('--fill', '#848b8e');

    const secondPartyElement = document.createElement('div');
    secondPartyElement.className = `${styles.other} ${styles.baspaGraph}`;
    secondPartyElement.style.setProperty('--percentage', `${(selectedYearData.party_count_2 * 100) / selectedYearData.total_count_parliament}`);
    secondPartyElement.style.setProperty('--fill', `${secondPartyColor}`);

    const firstPartyElement = document.createElement('div');
    firstPartyElement.className = `${styles.other} ${styles.congressGraph}`;
    firstPartyElement.style.setProperty('--percentage', `${(selectedYearData.party_count_1 * 100) / selectedYearData.total_count_parliament}`);
    firstPartyElement.style.setProperty('--fill', `${firstPartyColor}`);

    // Append the div elements to the graphAdd element
    const graphAdd = findRef.current;
    if (graphAdd) {
      graphAdd.innerHTML = ''; // Clear any existing content
      graphAdd.appendChild(otherElement);
      graphAdd.appendChild(secondPartyElement);
      graphAdd.appendChild(firstPartyElement);
    }
  };

  useEffect(() => {
    // Call the updateGraph function whenever the selected year changes
    updateGraph();
  }, [selectedYear]);

  const selectedYearData = data.loksabha_year.find(
    (year) => year.loksabha_year.toString() === selectedYear
  );

 
  return (
    <>
      <div className={`${styles.ElectionTallyData} mb30`}>
        <div className={styles.top}>
        <h1>लोकसभा निवडणुकीचा निकाल {selectedYearData.loksabha_year}</h1>

        <div className={styles.select}>
              <select onChange={handleYearChange} value={selectedYear}>
            {data.loksabha_year.map((yearData) => (
              <option key={yearData.loksabha_year} value={yearData.loksabha_year.toString()}>
                {yearData.loksabha_year}
              </option>
            ))}
          </select>
              </div>
          
          {/* <ul className={styles.link}>
            <li><span className={styles.live}></span>Live अपडेट</li>
            
          </ul> */}
        </div>

        <div className={styles.block}>
          <div className={styles.left}>
            <div className={styles.graph}>
              <div id='graphAdd' ref={findRef}>
              
              </div>

              <div className={styles.mark}>
                बहुमत  
                <div className={styles.arrowline}>
                  <div className={styles.arrow}></div>
                </div>
              </div>

              <div className={styles.total}>
                <strong>542</strong>
                543
              </div>
            </div>
            <div className={styles.totalSheet}>
              <div className={styles.seat}>एकूण जागा {selectedYearData.total_count_parliament}</div>
              <div className={styles.majority}>बहुमत 272</div>
            </div>

            <ul className={styles.partydetail}>
              <li style={{'background': firstPartyColor}}>
                <div className={styles.name}>{selectedYearData.short_party_name_mh_1}</div>
                <div className={styles.number}>{selectedYearData.party_count_1}</div>
              </li>
              <li style={{'background': secondPartyColor}}>
                <div className={styles.name}>{selectedYearData.short_party_name_mh_2}</div>
                <div className={styles.number}>{selectedYearData.party_count_2}</div>
              </li>
             
              <li>
                <div className={styles.name}>इतर</div>
                <div className={styles.number}>{selectedYearData.total_count_parliament-(selectedYearData.party_count_1+selectedYearData.party_count_2)}</div>
              </li>
            </ul>
          </div>

          <div className={styles.right}>
            {/* <div className={styles.choose}>
              <div className={styles.select}>
              <select onChange={handleYearChange} value={selectedYear}>
            {data.loksabha_year.map((yearData) => (
              <option key={yearData.loksabha_year} value={yearData.loksabha_year.toString()}>
                {yearData.loksabha_year}
              </option>
            ))}
          </select>
              </div>
            </div> */}

            <div className={styles.tallySelect}>
            <div className={styles.image}>
              <img width={80} height={80} src={`https://www.jagranimages.com/images/electionImages/pmelection/${pmdata.pmNameEN?pmdata.pmNameEN.replaceAll(' ','-'):null}.jpg`} onError={(e) => {e.target.src = 'https://www.jagranimages.com/images/electionImages/default-election-images.jpg';  }} />
              </div>
              <div className={styles.text}>
                <div className={styles.pm}>पंतप्रधान</div>
                <ul className={styles.listDetail}>
                  <li>{pmdata.pmNameMH}</li>
                  <li> 
                 {pmdata.pmPartyMH}</li>
                </ul>
              </div>
            
              
            </div>
            {selectedYearData && (
            <ul className={styles.list}>
              <li>
                <div className={styles.listname}>एकूण मतदानाची टक्केवारी</div>
                <div className={styles.detail}>{pmdata.totalVotesPercentage}</div>
              </li>
              <li>
                <div className={styles.listname}>विजयी सरकारला मिळालेली मतांची टक्केवारी</div>
                <div className={styles.detail}>{pmdata.votePercentageGovt}</div>
              </li>
              <li>
                <div className={styles.listname}>एकूण खासदार</div>
                <div className={styles.detail}>{pmdata.mpGovt}</div>
              </li>
              <li>
                <div className={styles.listname}>पुरुष खासदार</div>
                <div className={styles.detail}>{pmdata.maleMpGovt}</div>
              </li>
              <li>
                <div className={styles.listname}>महिला खासदार</div>
                <div className={styles.detail}>{pmdata.femaleMpGovt}</div>
              </li>

            </ul>
                        )}
          </div>
        </div>
      </div>
    </>
  )
}