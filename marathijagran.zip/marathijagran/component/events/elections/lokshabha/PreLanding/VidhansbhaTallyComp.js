import  { useState } from 'react'
import styles from '../../../../../public/css/VidhansbhaTally.module.css'
import { useEffect, useRef } from 'react';
import React from 'react';
export default function ElectionTallyVidhan(props){
  const { data, urlLink } =props
  
  const [animationDone, setAnimationDone] = useState(false);

  useEffect(() => {
    setAnimationDone(false)
    // setAnimationDone(true);
   let time= setTimeout(()=>{
      // setAnimationDone(item.party_total_seat)
       updatePie()
    }, 100)
    return ()=>{clearInterval(time)}
  }, [data]); // Trigger animation when data changes
 
  
  const updatePie=()=>{
    setAnimationDone(true)
  }


  return (
    <>      
        <div className={`${styles.ElectionTallyData}`}>
          <div className={styles.top}><h2><a href={urlLink}><span>{data?.state?.state_name||''}</span> <svg><use href="/sprite.svg#rightarrow"></use></svg></a></h2></div>
          <div className={styles.block}>
            <div className={styles.left}>
              <div className={styles.graph}>
                <div id='dataUpdated'>
                  
                  {data.state.party_list.map((item, index)=>{
                    return (
                      <>
                     {animationDone? <div
                      key={index+'1'}
                      className={`${styles['other_' + index]} ${styles.other}`}
                      style={{
                        '--percentage':  `${item.party_total_seat * 100 / data?.state?.total_seats}` ,
                        '--fill': `${item.party_color}`,
                        
                      }}
                        ></div>:<div
                        key={index+'2'}
                        className={`${styles['other_' + index]} ${styles.other}`}
                        style={{
                          '--percentage':  `${item.party_total_seat * 100 / data?.state?.total_seats}` ,
                          '--fill': `${item.party_color}`,
                          
                        }}
                          ></div>}
                        </>
                    )
                  })}
                </div>

                <div className={styles.mark}>
                  बहुमत  {data.state.majority_seat_no}
                  <div className={styles.arrowline}>
                    <div className={styles.arrow}></div>
                  </div>
                </div>

                <div className={styles.total}>
                  <strong>{data.state.total_declared_seat}</strong> / {data.state.total_seats}
                </div>
              </div>
              {/* <div className={styles.totalSheet}>
                <div className={styles.seat}>कुल सीटें {data.state.total_seats}</div>
                <div className={styles.majority}>बहुमत {data.state.majority_seat_no}</div>
              </div> */}

              <ul className={styles.partydetail} id="dataUpdated2">
                {data.state.party_list.map((item, index)=>{
                  return(
                 <React.Fragment key={index}>
                <li style={{'background':`${item.party_color}`}}>
                  <div className={styles.name}>{item.party_name}</div>
                  <div className={styles.number}>{item.party_total_seat}</div>
                </li>
                </React.Fragment>
                )
                })}
              </ul>
            </div>
          </div>
        </div>      
    </>
  )
}