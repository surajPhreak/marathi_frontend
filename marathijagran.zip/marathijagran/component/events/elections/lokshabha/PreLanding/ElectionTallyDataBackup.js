import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/ElectionTallyData.module.css'
import { useState, useEffect } from 'react';
import { useRef } from 'react';

export default function ElectiofnTallyData(props) {
  const findRef = useRef(null);

  const { data, payload } = props;
  const [pmdata, setPm] = useState(data);
  const partyColors = {
    BJP: '#f35717',
    INC: '#25bb5a',
    JD: '#10783b',
    TDP: '#dada52',
    JNPS: '#f35717',
    BLD: '#f58320',
    CPM: '#de0000',
    SWA: '#22409a',
    CPI: '#de0000',
    // Add more party names and colors as needed
  };

  const [firstPartyColor, setFirstPartyColor] = useState(partyColors[pmdata.partyShortNameEN]);
  const [secondPartyColor, setSecondPartyColor] = useState(partyColors[pmdata.oppositionPartyShortNameEn]);

  const [selectedYear, setSelectedYear] = useState('2014');


  const handleYearChange = (event) => {
    setSelectedYear(event.target.value);

  };

  const updateGraph = () => {
    // const selectedYearData = data.loksabha_year.find(
    //   (year) => year.loksabha_year.toString() === selectedYear
    // );

    
  const fetchPosts = async () => {
    try {
      const res = await fetch(`https://stg-api.jagran.com/api/jagran/election/ls/gov/answers/${selectedYear}`, payload);
      if (!res.ok) {
        throw new Error('Failed to fetch posts');
      }
      const newPosts = await res.json();
   
      setPm(newPosts);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };
  fetchPosts()

    const otherData = 543-(parseInt(pmdata.mpGovt)+parseInt(pmdata.totalMpOpposition));

    const partyColors = {
      BJP: '#f35717',
      INC: '#25bb5a',
      JD: '#10783b',
      TDP: '#dada52',
      JNPS: '#f35717',
      BLD: '#f58320',
      CPM: '#de0000',
      SWA: '#22409a',
      CPI: '#de0000',
      // Add more party names and colors as needed
    };

    setFirstPartyColor(partyColors[pmdata.partyShortNameEN] || 'defaultColor1');
    setSecondPartyColor(partyColors[pmdata.oppositionPartyShortNameEn] || 'defaultColor2');


    // Create the div elements with the provided styles
    const otherElement = document.createElement('div');
    otherElement.className = styles.other;
    otherElement.style.setProperty('--percentage', `${(otherData * 100) / 543}`);
    otherElement.style.setProperty('--fill', '#848b8e');

    const secondPartyElement = document.createElement('div');
    secondPartyElement.className = `${styles.other} ${styles.baspaGraph}`;
    secondPartyElement.style.setProperty('--percentage', `${(parseInt(pmdata.totalMpOpposition) * 100) / 543}`);
    secondPartyElement.style.setProperty('--fill', `${secondPartyColor}`);

    const firstPartyElement = document.createElement('div');
    firstPartyElement.className = `${styles.other} ${styles.congressGraph}`;
    firstPartyElement.style.setProperty('--percentage', `${(parseInt(pmdata.mpGovt) * 100) / 543}`);
    firstPartyElement.style.setProperty('--fill', `${firstPartyColor}`);

    // Append the div elements to the graphAdd element
    const graphAdd = findRef.current;
    if (graphAdd) {
      graphAdd.innerHTML = ''; // Clear any existing content
      graphAdd.appendChild(otherElement);
      graphAdd.appendChild(secondPartyElement);
      graphAdd.appendChild(firstPartyElement);
    }
  };

  useEffect(() => {
    // Call the updateGraph function whenever the selected year changes
    updateGraph();

  }, [selectedYear]);

  // const selectedYearData = data.loksabha_year.find(
  //   (year) => year.loksabha_year.toString() === selectedYear
  // );

 
  return (
    <>
      <div className={`${styles.ElectionTallyData} mb30`}>
        <div className={styles.top}>
        <h1>लोकसभा इलेक्शन रिजल्ट {selectedYear}</h1>

        <div className={styles.select}>
              <select onChange={handleYearChange}>
              <option value="2019">2019</option>
              <option value="2014">2014</option>
              <option value="2009">2009</option>
              <option value="2004">2004</option>
              <option value="1999">1999</option>
              <option value="1998">1998</option>
              <option value="1996">1996</option>
              <option value="1991">1991</option>
              <option value="1989">1989</option>
              <option value="1984">1984</option>
              <option value="1980">1980</option>
              <option value="1977">1977</option>
              <option value="1971">1971</option>
              <option value="1967">1967</option>
              <option value="1962">1962</option>
              <option value="1957">1957</option>
              <option value="1952">1952</option>
          </select>
              </div>
          
          {/* <ul className={styles.link}>
            <li><span className={styles.live}></span>Live अपडेट</li>
            
          </ul> */}
        </div>

        <div className={styles.block}>
          <div className={styles.left}>
            <div className={styles.graph}>
              <div id='graphAdd' ref={findRef}>
              
              </div>

              <div className={styles.mark}>
                बहुमत  
                <div className={styles.arrowline}>
                  <div className={styles.arrow}></div>
                </div>
              </div>

              <div className={styles.total}>
                <strong>542</strong>
                543
              </div>
            </div>
            <div className={styles.totalSheet}>
              <div className={styles.seat}>कुल सीटें 543</div>
              <div className={styles.majority}>बहुमत 272</div>
            </div>

            <ul className={styles.partydetail}>
              <li style={{'background': firstPartyColor}}>
                <div className={styles.name}>{pmdata.pmParty}</div>
                <div className={styles.number}>{pmdata.mpGovt}</div>
              </li>
              <li style={{'background': secondPartyColor}}>
                <div className={styles.name}>{pmdata.oppositionParty}</div>
                <div className={styles.number}>{pmdata.totalMpOpposition}</div>
              </li>
             
              <li>
                <div className={styles.name}>अन्य</div>
                <div className={styles.number}>{543-(parseInt(pmdata.mpGovt)+parseInt(pmdata.totalMpOpposition))}</div>
              </li>
            </ul>
          </div>

          <div className={styles.right}>
            {/* <div className={styles.choose}>
              <div className={styles.select}>
              <select onChange={handleYearChange} value={selectedYear}>
            {data.loksabha_year.map((yearData) => (
              <option key={yearData.loksabha_year} value={yearData.loksabha_year.toString()}>
                {yearData.loksabha_year}
              </option>
            ))}
          </select>
              </div>
            </div> */}

            <div className={styles.tallySelect}>
            <div className={styles.image}>
              <img width={80} height={80} src={`https://www.jagranimages.com/images/electionImages/pmelection/${pmdata.pmNameEN?pmdata.pmNameEN.replaceAll(' ','-'):null}.jpg`} onError={(e) => {e.target.src = 'https://www.jagranimages.com/images/electionImages/default-election-images.jpg';  }} />
              </div>
              <div className={styles.text}>
                <div className={styles.pm}>प्रधानमंत्री</div>
                <ul className={styles.listDetail}>
                  <li>{pmdata.pmNameHN}</li>
                  <li> 
                 {pmdata.pmParty}</li>
                </ul>
              </div>
            
              
            </div>
            {pmdata && (
            <ul className={styles.list}>
              <li>
                <div className={styles.listname}>कुल मतदान प्रतिशत</div>
                <div className={styles.detail}>{pmdata.totalVotesPercentage}</div>
              </li>
              <li>
                <div className={styles.listname}>विजयी सरकार को प्राप्त वोट प्रतिशत </div>
                <div className={styles.detail}>{pmdata.votePercentageGovt}</div>
              </li>
              <li>
                <div className={styles.listname}>कुल सांसद</div>
                <div className={styles.detail}>{pmdata.mpGovt}</div>
              </li>
              <li>
                <div className={styles.listname}>पुरुष सांसद</div>
                <div className={styles.detail}>{pmdata.maleMpGovt}</div>
              </li>
              <li>
                <div className={styles.listname}>महिला सांसद</div>
                <div className={styles.detail}>{pmdata.femaleMpGovt}</div>
              </li>

            </ul>
                        )}
          </div>
        </div>
      </div>
    </>
  )
}