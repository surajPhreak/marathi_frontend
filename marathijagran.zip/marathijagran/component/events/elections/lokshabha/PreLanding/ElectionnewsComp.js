//import { DomainPrefixes } from "../../../component/utils/ejConfig";
import { DomainPrefixes } from '@/component/utils/ejConfig';
import Image from 'next/image';
const categoryBaseColComp = (props) => {
    const {categoryData, compHeadTxt} = props;
    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    return(
            <div className="yearender list-article">
                <div className="master-div">
                <div className="allhead"><h2><a href='/tag/lok-sabha-election-2024'>
                {(compHeadTxt!=null && compHeadTxt!=undefined) ? compHeadTxt : categoryData[0].category}
                </a></h2></div>

                <ul className="list">
                    {
                        categoryData.map( (data, index) => { 
                            //const ImpPath = data.imagePath.split(',');
                            
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.split(' ').join('-')+'/':'';
                            return(              
                            <li className="article" key={index}>                            
                                <figure><a href={'/'+data.categoryUrl+'/'+ subcatt +removeLastId(data.webTitleUrl)+'-'+data.id} title={data.headline}>
                                    <Image width={100} height={100} unoptimized src={DomainPrefixes.ImagePath+data.imagePath} alt={data.headline} /></a></figure>
                                <div className="summary">
                                    {/* <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.subcategory?data.subcategory:data.category}</span>{data.pubDate}</span></div> */}
                                    <p><a href={'/'+data.categoryUrl+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id} title={data.headline}>{data.headline}{(data.webTitleUrl.match('-lb-'))?(<b className="liveBlink"></b>):""}</a></p>
                                </div>
                            </li>)                
                        })
                    }
                </ul>
                </div>
                <style>
        {`
        .yearender.list-article .list li{width:23%;}
        .yearender.list-article .list li:nth-child(2n + 2){margin-right:20px;}
        .yearender.list-article .list li:nth-last-child(2), .yearender.list-article .list li:last-child{margin-bottom: 15px;padding-bottom: 15px;border-bottom:1px solid var(--light-grey);}
        @media only screen and (max-width: 1024px){.yearender.list-article .list li{width:100%}}
        `}
    </style>
            </div>
    )
}
export default categoryBaseColComp;