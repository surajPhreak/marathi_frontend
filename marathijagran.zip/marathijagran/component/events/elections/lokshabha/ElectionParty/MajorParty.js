import React from 'react'
import Image from 'next/image'
import styles from '../../../../../public/css/MajorParty.module.css'


export default function MajorParty(props) {
    const {data} = props
    return (
        <>
            <div className={styles.MajorParty}>
               
                <h2>देशातील प्रमुख पक्ष</h2>

                <ul className={styles.partys}>
                    {data.map((item, index)=>{
                        return(
                    <li key={index}>
                        <a href={`/elections/${item.shortPartyNameEN?item.shortPartyNameEN.toLowerCase(): ''}/party.html`}>
                        <div className={styles.partyDetail}>
                        
                        <span><svg><use href={`/electionsprite.svg#${item.shortPartyNameEN?item.shortPartyNameEN.toLowerCase() : ''}`}></use></svg> </span>
                        
                            {item.shortPartyNameMH}
                            
                        </div>
                        </a>
                    </li>
                    )
                    })}
                </ul>
            </div>
        </>
    )
}