
// import React, { useEffect, useState } from 'react';

function ExitPollLoksabha ({exitdata, stateNameHn, urlLink}){

    const data= exitdata.Result.Docs.Doc[0].Party
    return(
        <>
 
            <div className="exitShowDiv" id="exit-himachal">
                <div className="electionSection">
                    <div className="electionTable">
                        <ul className="tableData exitpoll">
                            <li className="row">
                                <span>
                                 {urlLink ?  <a href={urlLink}>{stateNameHn}</a> : stateNameHn}
                                 </span>
                                {                                   
                                   data.map((item, index)=>{
                                        return(
                                            
                                             <>
                                              <span key={index} className={item['Party-Name-En']}>
                                                 <i><img src={item['Image-Name']} width="22" height="22" /></i>
                                                 {item['Party-Name-Hn']}
                                             </span> 
                                             </>
                                        )
                                    })
                                
                               
                                }
                               
                            </li>
                            {
                                exitdata.Result.Docs.Doc.map((itemMap,index)=>{
                                    return(
                            <li key={index} className="row">
                              
                              
                            <span>{itemMap['Agency-Name']}</span>
                         
                            { 
                            itemMap.Party.map((item, index)=>{
                                return(
                                <span key={index} className={`partyLightColor ${item['Party-Name-En']}`}>{item.Prediction}</span>
                             
                                )
                            })
                        }
                        </li>
)
})
                        }
                           
                        </ul>
                    </div>
                </div>
            </div>
            
           


<style>
    {`
        .exitShowDiv {width: 100%; margin-bottom: 20px;}

        .electionContainer { margin-top:20px;padding-bottom: 30px;border-bottom:0px;}  
        .electionNav {margin-bottom: 20px; box-sizing: border-box; display: flex; flex-wrap: nowrap; border-radius: 0px; align-items: center; justify-content: space-between; min-height: 66px; border-bottom: 4px solid #929191;}
        .electionNav li {display: inline-block; font-size: 14px; border-right: 1px solid #cccccc; padding-right: 14px;}
        .electionNav li a {display: inline-flex; cursor:pointer; margin-left: 20px; color: #000; font-weight: bold; -webkit-transition: all 0.5s ease; -moz-transition: all 0.5s ease; -o-transition: all 0.5s ease; transition: all 0.5s ease;}
        .electionNav li a.active{color:#da251d;}
        .electionNav li:last-child {padding-right: 0px; border-right: 0px;}
        .electionCtn{padding-top: 0px; display: flex; justify-content: space-between;}
        
       
        .exitpoll{ display:flex; flex-wrap: wrap; margin-bottom: 0;}
        .electionNav .exitptabBox{width: 96%;  text-align: right;}
        .tableData .row{ display:flex;}
        .tableData li {line-height: 22px; flex: 0 100%; font-weight: 600; border-bottom: 1px solid #bababa; margin-bottom: 0px;}
        .tableData.exitpoll li:first-child span{ font-weight:600; color:#fff;}
        .tableData.exitpoll li:first-child span:first-child{ background-color:#000; color:#fff;}
        .tableData.exitpoll li:first-child span:first-child a{color:#fff;}
        .tableData.exitpoll li span{flex:1; display:flex; justify-content: center; align-items: center; font-weight: normal; padding: 10px 0px; }
        .tableData.exitpoll li span:first-child{justify-content: left; padding-left: 15px; font-weight:800;}
        
        .tableData.exitpoll li span i {display: flex; align-items: center; justify-content: center; margin-right: 10px; width: 30px; height: 30px; background: #fff; border-radius: 50px;}
        .tableData.exitpoll li span img{ margin-bottom: 0px; border-radius: 20px;}
        .electionNav .imgTex { width: 456px box-sizing: border-box; display: flex; flex-wrap: wrap; min-height: 56px;}
        .electionCtn .webAds{width:320px;}
        // .tableData li:last-child{display:none;}
        
        .exitpoll .partyLightColor{font-size:14px;}
        .exitpoll .NDA{background-color:#eb7215;}
        .exitpoll .partyLightColor.NDA{background-color:#fff5ee;}

        .exitpoll .INDI{background-color:#0e813c;}
        .exitpoll .partyLightColor.INDI{background-color:#f0fff9;}

        .exitpoll .Others{background-color:#4d4e4e;}
        .exitpoll .partyLightColor.Others{background-color:#f0f0f0;}

        .exitpoll .MNF{background-color:#2caaff;}
        .exitpoll .partyLightColor.MNF{background-color:#b4d8ed;}

        .exitpoll .BRS{background-color:#ed038b;}
        .exitpoll .partyLightColor.BRS{background-color:#f5c4e1;}

        @media only screen and (max-width:850px){
            .electionSection{margin-bottom:20px;}                   
            .electionNav{flex-wrap: wrap;}
            .electionNav .exitptabBox{ text-align: left;}
            .electionNav .toptabBox{width: 100%; text-align: left; padding-bottom: 10px;     white-space: nowrap;
                overflow-x: auto;}
            .tableData.exitpoll li span{flex-wrap:wrap; justify-content: center; align-items: center; flex-direction: column;}
            .tableData.exitpoll li span:first-child{flex-direction: inherit;}
           
            .tableData.exitpoll li span i{margin-right: 0px;}
            .electionCtn{flex-wrap:wrap;}
            .electionCtn .mobileAds{width: 100%;}
        }

        @media only screen and (max-width:480px){
            .electionNav{margin-bottom:0px; border-bottom:0px;}
            .electionNav .imgTex{width: 100%; justify-content: center;}                
            .electionNav .imgTex .h1, .electionNav .imgTex h1{font-size: 20px;}                
            .electionNav li a{margin-left: 0px;}                
            .electionNav li{font-size: 13px; border:0px;}                
            .electionNav .toptabBox{display: flex; align-items: center; justify-content: space-between;}
  
        }
    `}
</style>
        </>
    )
}
export default ExitPollLoksabha;