import Header from "../global/ampHeader.js"
import Footer from "../global/ampFooter.js"
export const config = { amp:true };
function Layout({children}){
return (
<>
   <Header />
    <div className="container">{children}</div>
   <Footer />
   <style jsx global>{`
      /*common Header footer*/
      *{margin:0; padding:0; outline:none;}
      body{font-family:'Noto Sans', sans-serif; color:#000000; font-size:16px; line-height:22px; background:#fff; vertical-align:baseline; -webkit-text-size-adjust:none;}
      a{color:#000; text-decoration:none; }
      ul,li{list-style:none;}
      h1{font-size:1.2rem; line-height:28px; font-weight:600; margin-bottom:16px;}
      h2{font-size:21px; line-height:35px;}
      .h3{font-size:15px; line-height:20px; font-weight:600;}
      .container{width:100%; max-width:900px; padding:0 20px; clear:both; overflow:hidden; box-sizing:border-box; margin:0 auto;}
      ::-webkit-scrollbar {width:5px; height:1px;}
      ::-webkit-scrollbar-track {background: #f9f9f9;}
      ::-webkit-scrollbar-thumb {background:#ccc;}
      ::-webkit-scrollbar-thumb:hover {background:#ab1111;}
      .amp-container{clear:both; display:block; width:100%; margin:0 auto;}
      .amp-container:after{content:''; overflow:hidden; clear:both; display:block;}
      header{position:sticky; position:-webkit-sticky; clear:both; overflow:hidden; top:0; left:0; z-index:9;  background-color:#ffffff; box-shadow:0 8px 32px #f1f1f1; margin-bottom:8px;}
      header .logo{position:relative; background:#fff; margin-top:4px;}
      header .logo a{background:url('data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%202872.79%20729.69%22%20shape-rendering%3D%22geometricPrecision%22%20text-rendering%3D%22geometricPrecision%22%20image-rendering%3D%22optimizeQuality%22%20fill-rule%3D%22evenodd%22%20clip-rule%3D%22evenodd%22%20width%3D%2232%22%20height%3D%2232%22%3E%3Cdefs%3E%3Cstyle%3E.fil0%7Bfill%3A%23ed7f36%3Bfill-rule%3Anonzero%7D%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22jagran_english-Layer_x0020_1%22%3E%3Cg%20id%3D%22jagran_english-_1579875842320%22%3E%3Cpath%20class%3D%22fil0%22%20d%3D%22M1115.72%20367.25L607.29%20607.64h575.02c-4.52-86.53-28.1-168.03-66.59-240.39z%22%2F%3E%3Cpath%20d%3D%22M347.79%2058.41C128.52%20162.14.15%20380.19%200%20607.67h72.61c-.73-126.83%2043.04-254.31%20134.04-356.54C401.93%2031.67%20738.2%2012.19%20957.58%20207.52l-356.2%20400.15h5.9l549.31-259.71C1013.26%2044.65%20651.05-84.97%20347.79%2058.44l-.01-.03z%22%20fill%3D%22%23e13338%22%20fill-rule%3D%22nonzero%22%2F%3E%3Cpath%20class%3D%22fil0%22%20d%3D%22M240.93%20477.36c60.67-204.43%20275.61-321.04%20479.96-260.32L606.82%20601.56%20957.6%20207.51C738.23%2012.17%20401.93%2031.68%20206.67%20251.14c-91%20102.21-134.77%20229.69-134.06%20356.54h153.24c-2.31-42.87%202.17-86.79%2015.07-130.31v-.01z%22%2F%3E%3Cpath%20d%3D%22M607.53%20332.2c-152.17%200-275.52%20122.4-276.26%20276.04H882.1c.74-153.6-122.5-276.04-274.58-276.04z%22%20fill%3D%22%23fbee1d%22%20fill-rule%3D%22nonzero%22%2F%3E%3Cpath%20d%3D%22M607.53%20332.2c26.4%200%2051.87%203.75%2076.05%2010.65l37.31-125.81c-204.35-60.72-419.3%2055.89-479.95%20260.32-12.91%2043.49-17.37%2087.44-15.08%20130.28h105.43c1.04-153.35%20124.26-275.47%20276.22-275.47l.02.03z%22%20fill%3D%22%23f7ba2f%22%20fill-rule%3D%22nonzero%22%2F%3E%3Cpath%20d%3D%22M1459.64%20157.49V132.9h-42.65V90.25h37.23V66.33h-37.23V26.85h42.65V2.26h-79.43V157.5h79.43zm145.42%200V2.25h-30.91v78.97c0%208.12.9%2015.57.9%2015.57h-.45s-3.16-6.99-7.9-14.89l-47.61-79.65h-32.27v155.24h30.69V71.07c0-8.57-.91-16.92-.91-16.92h.45s3.39%208.12%208.12%2016.24l51.67%2087.09h28.2zm141.81-6.77V66.33h-52.8v21.89h18.5v44c-2.03%201.13-5.64%202.26-11.51%202.26-18.95%200-31.36-18.05-31.36-54.38%200-37.68%2013.99-54.15%2038.81-54.15%2013.31%200%2021.21%202.7%2026.17%205.64l10.61-22.56c-9.93-5.64-22.79-9.02-41.07-9.02-44.67%200-71.52%2032.04-71.52%2079.2%200%2049.64%2023.24%2080.55%2070.4%2080.55%2021.21%200%2033.62-3.16%2043.77-9.02zm107.74%206.77V132.9h-39.49V2.26h-36.55V157.5h76.04zm61.48%200V2.25h-36.55v155.24h36.55zm117.89-46.48c0-15.8-4.28-32.27-34.3-45.8-13.09-5.87-20.98-11.51-20.98-22.79%200-11.06%206.54-17.82%2018.73-17.82%209.48%200%2017.83%203.38%2023.24%206.77l7.67-22.34c-7.45-4.96-19.63-9.02-36.33-9.02-30.24%200-49.19%2021.66-49.19%2047.83%200%2015.12%206.77%2032.04%2030.91%2042.87%2015.8%207%2021.66%2013.09%2021.66%2023.02%200%2011.06-7.9%2018.5-20.76%2018.5-10.83%200-20.08-3.83-25.05-7.22l-8.35%2025.5c8.8%205.87%2021.43%209.25%2040.61%209.25%2030.69%200%2052.12-20.76%2052.12-48.74zm140.01%2046.48V2.25h-36.78v64.08h-39.26V2.25h-36.78v155.24h36.78V90.25h39.26v67.24h36.78z%22%20fill%3D%22%23373435%22%20fill-rule%3D%22nonzero%22%2F%3E%3Cpath%20d%3D%22M2735.43%20315.4c-56.84%200-101.84%208.52-133.81%2021.32v271.52h92.35V373.01c10.67-3.21%2020.73-5.87%2039.09-5.87%2037.29%200%2047.36%2019.74%2047.36%2040.01v201.1h92.37V406.62c0-52.28-36.12-91.2-137.36-91.2zm-612.02%2021.32v271.52h92.35V373.53c15.4-6.4%2039.08-6.93%2061.6%201.61l17.18-58.68c-85.87-3.73-135.61%204.8-171.13%2020.27zm-478.23-21.32c-56.25%200-97.69%2013.32-120.2%2021.86l20.14%2047.47c20.72-8.54%2052.11-17.6%2082.89-17.6%2033.74%200%2056.26%208.53%2056.26%2038.4v13.33c-95.93%208.01-178.24%2029.88-178.24%20104.02%200%2059.75%2047.37%2090.68%20139.75%2090.68%2055.06%200%2098.28-8.53%20124.93-21.33V420.47c0-77.88-53.29-105.07-125.53-105.07zm39.09%20246.43c-8.3%203.74-20.15%205.87-33.76%205.87-36.71%200-58.04-14.4-58.04-48%200-45.88%2036.12-57.61%2091.8-62.42v104.55zm747.59-246.43c-56.24%200-97.69%2013.32-120.2%2021.86l20.15%2047.47c20.71-8.54%2052.1-17.6%2082.89-17.6%2033.75%200%2056.25%208.53%2056.25%2038.4v13.33c-95.92%208.01-178.22%2029.88-178.22%20104.02%200%2059.75%2047.37%2090.68%20139.74%2090.68%2055.06%200%2098.29-8.53%20124.93-21.33V420.47c0-77.88-53.3-105.07-125.53-105.07zm39.09%20246.43c-8.3%203.74-20.14%205.87-33.75%205.87-36.72%200-58.03-14.4-58.03-48%200-45.88%2036.11-57.61%2091.78-62.42v104.55zm-670.27-90.14c0%2085.87%2055.06%20138.69%20131.44%20138.69%2026.66%200%2045-3.74%2055.66-9.07v16c0%2033.07-17.76%2053.87-66.31%2053.87-30.2%200-59.21-7.46-78.75-17.07l-23.68%2053.88c25.45%2012.8%2069.87%2021.33%20119.01%2021.33%2081.71%200%20139.73-37.34%20139.73-118.95V336.72c-22.49-12.27-63.95-21.32-113.08-21.32-109.54%200-164.01%2060.26-164.01%20156.28zm187.1%2084.27c-7.69%204.28-18.36%206.93-30.79%206.93-46.18%200-65.13-30.94-65.13-96.01%200-68.81%2019.54-103.48%2066.91-103.48%2012.43%200%2021.91%201.6%2029%204.8v187.75zm-607.54%2061.71c0%2033.07-17.76%2053.87-66.31%2053.87-12.84%200-25.41-1.41-37.19-3.69l-18.32%2055.25c21.29%204.17%2046%206.59%2072.08%206.59%2081.72%200%20143.37-38.35%20143.37-122.59V252.13h-93.63v365.54z%22%20fill%3D%22%23373435%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E') center no-repeat; width:128px; height:41px; background-size:100%; float:left; position:relative;}.topRight a{color:#fff; font-size:16px; line-height:44px; float:right; font-weight:600;}
      .nav{margin:0; padding:0; width:256px; background:#fff; clear:both; position:relative;}
      .topClose{overflow:hidden; clear:both; display:block;}
      .hDtopright{margin-top:15px; position:relative;}
      .hDtopright svg{display:inline-block;}
      .hDtopright span{display:inline-block; vertical-align:top; margin-top:-1px; margin-left:5px; font-size:14px; color:#000; font-weight:bold;}
      /* .HDtopright .choose-state{font-weight:700;}
      .HDtopright .election{float:left; margin:3px 10px 0px 5px; line-height:18px;}
      .HDtopright .election span{color:#b50505;} 
      .currentTopic{font-size:14px; color:#810909;}*/
      .topNav{display:block; margin: 0 -15px;}
      .scroll{width:100%; float:left; background:#fff; white-space:nowrap; overflow-x:auto; overflow-y:hidden; height:auto}
      .scroll ul li:last-child a{margin-right:27px;}
      .scroll ul{width:97%; float:left;}
      .scroll li{padding:0; display:inline-block; font-weight:700}
      .scroll li a{padding:6px 9px 4px; font-size:14px; line-height:28px; display:block;}
      .scroll li.mobileVishvasLogo a{color:#165f17;}
      .scroll li.photolink a{color:#b30f18;}
      .scroll li .burger{display:inline-block; margin:-9px 0; height:30px}
      /*.scroll ul li:first-child{position:relative; width:24px; height:20px; margin-left:5px;}
      .scroll ul li:first-child a{padding:0; position:absolute; top:4px; left:7px;}*/
      .scroll ul li:first-child i{background:url(https://imgeng.jagran.com/images/micon-home.png?v1) no-repeat; width:19px; height:20px; display:inline-block; background-size:100%; background-position:center;}
      
      .footer{color:#555; text-align:center; margin-bottom:48px; padding-top:13px; clear:both; overflow:hidden;}
      .copyRight{padding:10px 0; display:block; font-size:12px;}
      .copyRight span{display:block;}
      
      /*.android-ios-box{line-height:0; display:inline-block; vertical-align:top; padding:5px;}
      .android-ios-box a{display:inline-block; background-image:url(https://imgeng.jagran.com/images/newimg/articleimage/footerappicon-englishjagran-15062020.jpg); background-repeat:no-repeat; height:37px; width:112px; background-size:212%;}
      .android-ios-box a.android-dwn{background-position:0 0;}
      .android-ios-box a.ios-dwn{background-position:right 0; margin-left:9px;}*/

      .comlink{clear:both; overflow:hidden; padding-bottom:5px; text-align:center;}
      .comlink a{display:inline-block; font-size:12px; color:#555;}
  
      .flexbox{display:flex; justify-content:space-between;}
    
      .ads{clear:both; padding:10px 0; margin:0 auto 20px ; transform:scale(0.90); display:flex; justify-content:center; align-items:center;}
      .tabolabad{transform: scale(1.0);}
      
      .breadcrum{margin-bottom:15px; clear: both; overflow: hidden;}
      .breadcrum li{float:left; color:#000; font-size:12px;}
      .breadcrum li a{color:#000;}
      .breadcrum li:before{content:'/'; float:right; margin:0 4px 0 5px; color:#707070;}
      .breadcrum li:last-child:before{display:none;}.breadcrum li:last-child a, .breadcrum li:last-child{color:#ab1a4f;}
      .MainHd{padding:5px 4% 4px; border-bottom:1px solid #f3f3f3; background:#f8f8f8; width:92%; float:left;}
  
      /*social floating icon*/
        
      .tabs-sec{display:flex; justify-content:center; align-items:center; width:100%; position:fixed; left:0; bottom:75px; z-index:9; height:1px;margin-bottom:10px;}
      .tabs-sec .tab-cell{display: flex;align-items:center;background:#000;box-shadow:0 0 20px rgb(0 0 0 / 20%);border-radius: 40px;}
      .tabs-sec amp-social-share{display:flex;align-items: center;color: var(--colr-dark);white-space: nowrap;padding:4px;}
      .tabs-sec .amp-social-share-system{background-color:var(--colr-primary);padding: 10px 10px 10px 30px;background-size: 25px;border-radius: 30px 0 0 15px;}
      .tabs-sec a span {display:block}
      .amp-next-page-links{display:flex;padding:0 2px 0 10px;position:relative}
      .amp-next-page-links a{position: relative;font-size:0.75rem;text-transform:uppercase;line-height:1;font-weight: 600;}
      .amp-next-page-links a svg{transform: rotate(180deg);margin-bottom:-11px;fill: rgba(var(--primary), 1);position:absolute;right: -20px;top: 8px;width: 20px;height: 20px;}  
      /*bottom User notification, gdpr*/
      amp-user-notification > div{padding:0.5rem; align-items:center; justify-content:center;  background:#ededed;color:#1c1c1c;font-size:13px; }
      amp-user-notification > div a{ text-decoration:none; font-weight:bold; color:#000;}  
      amp-user-notification > div > button{background:#484647;padding:5px 15px;color:#fff;border:0px;margin:0 auto;display:block;}
      /*common Header footer end*/

      
      .related-box{margin-bottom:20px; clear:both; overflow:hidden;}
		.related-box h3{clear:both; font-size:19px; line-height:30px; font-weight:700; text-transform:capitalize; margin-bottom:16px;}
		.related-box ul li{padding:0 0 20px; display:flex; justify-content:space-between; flex-wrap:wrap; border-bottom:1px solid #f1f1f1; margin-bottom:20px;}
		.related-box ul li .thumb{width:100px; height:auto;}
		.related-box ul li .thumb img{height:100%; }
		.related-box ul li .h3{font-weight:normal; font-size:15px; line-height:22px; width:65%;}

      .appBtn{padding: 0 10px; margin-top: 1px; float: right; font-size: 11px; text-transform: uppercase; background: #eae6e694; border-radius: 10px;}
      .appBtn a{text-decoration:none; color:#000; font-weight:500;}
      .sideBarLogo{margin-bottom:19px; width:84%; float:left; background:#fff; padding:14px 6% 7px 10%;  box-shadow:0 4px 12px 0 rgba(0, 0, 0, 0.05);}
      .sideBarLogo .close { float: right; font-size: 14px; font-weight: 100;color: #a29696; position: relative; z-index:999999; }
      
      .topAds { padding-top: 55px; }
      .article-content{ float:left; width:100%;}
      .top-heading{padding:10px 0 0; float:left; width:100%; border-bottom:solid 2px #eee; margin-bottom:5px;}
      .article-content h1 a{font-weight:bold; font-size:22px; line-height:22px; text-decoration:none; color:#333;}
      .article-content .authorBox{font-size:12px; padding:10px 0 0; color:#333; display:flex; justify-content: space-between; border-top:1px solid #f1f1f1; margin-bottom:10px;}
     
      .article-img{ float:left; width:100%; margin-bottom:15px;}.article-img img{width:100%; height: auto;}
      .article-content p{ margin:10px 0; clear:both; line-height:25px; font-size:16px;}
      .article-content iframe{width:100%;}

      .liveBlog{display:inline-block; font-size:19px; color:#000; padding:0 0 0 19px; position:relative; font-weight:700; text-transform:uppercase; margin:15px 0 10px;}
      .MainHd {clear:both; font-size:22px; margin:0 0; padding:4px 8% 5px; line-height:30px; font-weight:600; border-bottom:1px solid #f3f3f3; background: #f8f8f8; width:84%; float:left;}

      .liveBlink{background-color:#dd4b39; height:9px; width:9px; border-radius:50%; display:inline-block; line-height:0px; position:absolute; left:0; top:6px;}
      .liveBlink:before{position:absolute; content:""; height:9px; width:9px; left:0; top:0; background-color:transparent; border-radius:50%; box-shadow:0px 0px 2px 2px #dd4b39; -webkit-animation:active 2s infinite linear; animation:active 2s infinite linear;}
      .list li.article .summary{position:relative;}
      .liveBlink i{color:#dd4b39; margin-left:15px; font-style:inherit;}
      @-webkit-keyframes active{   0%{-webkit-transform:scale(.1);  opacity:1;} 70%{-webkit-transform:scale(2.5); opacity:0;}  100%{opacity:0;}  }
      @keyframes active{  0%{transform:scale(.1); opacity:1;} 70%{transform:scale(2.5);  opacity:0;}  100%{opacity:0;}  }


      .blogArticle{background-color:#f1f1f1; clear:both; overflow:hidden; margin-bottom:30px;}
      
      .blogArticle h2{background-color:#ec1d25; color:#fff; font-size:20px; padding:7px 10px 7px 15px; font-weight:normal; clear:both; margin-bottom:10px; display:block;}

      .blogArticle h2 a{color:#fff;}
      
      .blogListing{padding:0 25px; counter-reset:section; list-style-type:none;}
      .blogListing li{padding: 10px 0px 9px; border-bottom: 1px solid #e5e5e5; padding-left: 18px; position: relative; font-size:14px;}
      .blogListing li::before {counter-increment:section; content:counters(section," ") "."; position:absolute; left:0;}
      .verdictBox{display: block;clear: both;overflow: hidden;}
      .dateStrip {background-color: #232323;font-size: 14px;line-height: 18px;color: #ffffff; font-weight: bold; padding: 9px 15px; display: inline-block; margin: 5px 0 20px;}
      .ipl-social{display:block; clear:both; margin-bottom:5px;}
      .ipl-social > a{width:28px; height:28px; display:inline-block; background-repeat:no-repeat; background-position:center; background-size:14px; border-radius:50%;}
      .ipl-social .fb{background-color:#3b5a9b; background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAQAAAC0NkA6AAAAAnNCSVQICFXsRgQAAAAJcEhZcwAACxMAAAsTAQCanBgAAAD9SURBVFjD7dQxagJBFMbx0UWwELvUNnqDIAh7ALtAUoRUniFHkIRgp6A5QpqQFIG0S/rYBlKG1NZB0P3el2ZhVxiDk52x0Pd/7ez+eM0zxjlG0scM71hgzUJYyZnxESsywBe3hBsPhDTxyj/CbfktGpiTgRE8k4ERuSCDI/gIjkiPDI7gbidkWA5Jtvz2Ey94yuZBOuWQbwsAOTc+w48FSYzfNq9Uhtz7RlILMlFkvwhrrOdjRabFF6wzcj0jVwAdw0JO3PYY8R/JqSKKHBMi1+4EUmm5bVKVLuN8bGeFj8UXjKWtp14RRRRRRBFFDgIZ+0besEa6MUu53PXrXzLKIB9T1bWIAAAAAElFTkSuQmCC');}
      .ipl-social .gplus{background-color:#dd4b39; background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAQAAABu4E3oAAAACXBIWXMAAAsTAAALEwEAmpwYAAABiklEQVQ4y43ST4iMcRzH8e+ssU3sAYnLqhVHF+1BUmQPijhtyUH5c5LLHrnIYQ+EUQ62uDmoUauNEok9Oawiu2yI/DlNItkL0c54OXjm8czMM08+39Pn0+/dr++fiERKtrngoZm0pq2J3rLTGzS1dNmIFUXAPosajipZ6yJYsKEIWOYLJlJfA1eKkCNgd+qHwdMipAq2ZJIFvM/4vQ7ak0WugwOZ5CXmMn4es1nkEriZ+iW+o1aEjIKGHW1+VxHSbx58tV/FiDqqERE2JfUWr1vuL7TeXLLC32BKOUJZrrL7P2cywVZH/AcSEWFlkh6LiFByMqlPqLdc545mQNOhtrSz/SQecthpD5J/mm176ppY2Zh34JVbnvkFFm3vgai4B24YTJJBU+Bx+ua8mrP/kBPdd6vfE7Aq/yhfoGF5RzoGhvORH/jQlR4H6/KRj2CoLSu5j7q+fOQamG01H2HABDgV+bLRt2Sod1SNm/QZTFsavWSz5x1n9NMZlSiSPluNu+2Ru64aNVD0+g/ywftOW4KqdAAAAABJRU5ErkJggg=='); margin:0 3px;}
      .ipl-social .tw{background-color:#4aafe5; background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAQAAAC0NkA6AAAAAnNCSVQICFXsRgQAAAAJcEhZcwAACxMAAAsTAQCanBgAAAJoSURBVFgJ7cFdaM1xHAbw7zhbU3tLI6blJdRkZheYK3VqsfJ+QVqKwjIXlCU30i68LMTKhTUrL7uhFhrFbtRIQq2Ql7gi2wyRsrez53nspc3Ozjk7v//O/0r7fGzS/4c5DHILS7hYSeY/ZvAI3moE2nCOuRaG6Vpuw7jQPOImtCsCulihJBukWTyObyywIcrSL24wD1ihmFDPpTyA+whJuGHDWCahi0FzxN1yglbOtGFoUD90ssQccD465QDfWWCmAFfaALzXIIS0z+JCvRyghcXcjlq0MWgD8FUjUMtpNg5lo1cO0KNBPGhD8Emj4B1XW0wslQc4YcPQrDAgLnO2RYWzcgTqqP2j04qAPzjPXIuAa3KCLm220VioqNCHW9yqVBsF1+UEn20sNCkm/EEjK7hGWdYPVXKCzzYW89CpuPADL/FRTvDGInEHKB/hqYXDI5Yqk6Xoln9uWjh8kQB8wBf5BqcsHO7Jd9xp4bhf/ltg4ZSpX/IVWi0SD8tXqLVImoIm+YjrLBqmo1k+QYeSLTqloBqQD3DCxsNluoLfSghCnGOxMB9neAxVaESfEoAai02paFfC0MkcGw/LlDBU2viUhLtKCF4pxeJRGh5rwtDLFeZCqajRBLHc3LEIt9Erj1BnXjGDxTiJPjlCgwLmnXbhpxzhjpLNKwbxRM5wUVPNC2WzTC/kDN0st3iYz2XMYyGLuQcX8AyQB3jOJRYfZ+ASQpoAfOMhBcwVF6EO3fIAHahkhnnFGaxAi+JCDx5wm1Js4jSPe3EVrxHSGGjHQ1RzvdLMLwpwLou4lhtZzFXM43Sb9F/5C7BV6oQzLQ0hAAAAAElFTkSuQmCC');}  
      .timeLine{display:block; margin-left:5px;}
      .timeLine .amp-live-list-item .adsBox{transform: scale(.9); margin-left:-23px;}
      .timeLine .amp-live-list-item{display:block; border-left:1px solid #cbcbcb; position:relative; padding-left:12px; padding-bottom:10px;}
      .timeLine .amp-live-list-item h3{font-weight: 600;}
      .timeLine .amp-live-list-item:after{content:' '; position:absolute; top:6px; left:-5px; width:9px; height:9px; background-color:#ec1d25; border-radius:50%;}
      .timeLine .amp-live-list-item:first-child:before{content:' '; position:absolute; top:0px; left:-5px; width:9px; height:9px; background-color:#ffffff; border-radius:50%;}
      .timeLine .amp-live-list-item:last-child{padding-bottom:0; border-left:none;}
      .timeLine .amp-live-list-item:last-child:before{content:' '; position:absolute; top:0; left:0; width:1px; height:10px; background-color:#cbcbcb;}
      .timeLineTime{background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAQAAAAngNWGAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA/0lEQVQoU33SPW7CQBCG4YcCt75HBFVyCmgikKzcIRwEUoJzBLhAmpwiPUgkZRpT+QCTAuM/rLzT7ErvajTfDg2JzMFJqXRykEkMsHQWvTpbdqWRNyEUtmYmJma2LkLYGDXiRgi5FDx7BKlcCOumaQiv9bNfH/V5JYQFJL6FXEPhs3XLhbMxmVBUTYfEVCFkHIStNl2RnbDnJMz+FefCkVKY9MQvz1VNMRXKIfGnFfmlEe9bP3ip60nd+n6YPtUw9/F0SV2u8STOvcC71IHfvnA1qLW+kP5S3Ei96ywFo0ot7MxNTc3tqjVbt9cMFoOLuzDAWGbvqFQ62suuI1z5A7kwiyDAOLZsAAAAAElFTkSuQmCC'); background-repeat:no-repeat; background-position:3px center; background-size:12px 12px; padding-left:22px; font-size:15px; line-height:19px; color:#010101; display:block; margin-bottom:10px; font-weight:bold;}
      .timeLine .amp-live-list-item img{margin-bottom:8px; width:99%;}
      .timeLine .amp-live-list-item p{font-size:15px; line-height:24px; color:#393838; margin-bottom:15px; clear:both;}
      .timeLine .amp-live-list-item h2{display:block; clear: both; overflow:hidden; font-size:17px;}
      .tagList {display: -webkit-box;  -webkit-box-orient: vertical;   overflow: hidden;  }
      .commonList, .protxt{margin: 0 8%; width:84%;float:left;}
      .commonList li{padding:14px 0; float:left; border-bottom:1px solid #f3f3f3; list-style:none;}
      .commonList.size1 li{width: 100%; margin:0 0 15px;}
      .commonList.size1 li figure, .commonList.size1 li figure img {height: 85px;}
      .commonList li figure {width: 100px;float: right; margin-left: 15px;}
      .newsBox ul li span{color:#810909; font-size:11px; text-transform: uppercase; line-height:13px; font-weight:bold; padding:0 0 5px; display:block;}
      .newsBox small{margin-left:10px; color:#555; display:inline-block; text-transform:capitalize;}
      .newsBox .h3{font-size:14px; line-height:22px; font-weight:400;}
      .commonList li:last-child {border-bottom:0;}
      .realatedSreachtag h3{font-weight:600; float:left; font-size:15px; color:#000; box-sizing:border-box;}
      .realatedSreachtag .tagList{padding:0 0 5px; overflow:hidden;  display:inline-block;  margin-left:5px; line-height:inherit;}
      .realatedSreachtag .tagList li{list-style:none; margin-bottom:5px; color:#000; float:left;}
      .realatedSreachtag .tagList li a{color:#555; font-size:14px; padding:0 6px; border:1px solid #ccc; border-radius:20px; display:inline-block;}
      .realatedSreachtag{margin:0 0 22px; border:1px solid #f1f1f1; box-sizing:border-box; position:relative; clear:both; overflow:hidden; padding:8px;}
      .realatedSreachtag .content{max-height:60px; overflow:hidden; transition:max-height 0.5s ease;}
      .realatedSreachtag .label-container #read-more-label{float:right; font-size:15px; color:#810909;}
      .realatedSreachtag .label-container #read-more-label:before{content:'+View All';}
      .realatedSreachtag #read-more-trigger {display:none;}
      .realatedSreachtag #read-more-trigger:checked ~ .label-container #read-more-label:before {content: '-View Less';}
      .realatedSreachtag #read-more-trigger:checked ~ .content { max-height: 100em;}
   `}</style>
</>
)
}
export default Layout;