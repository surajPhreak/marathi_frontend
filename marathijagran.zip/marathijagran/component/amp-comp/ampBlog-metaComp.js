import { DomainPrefixes } from "../utils/ejConfig";
import moment from 'moment';
const Meta = (props) => {
    const {articledetaildata, urlRoughter} = props;
    //const authorUrl = articledetaildata.authorEng.toLowerCase().split(' ').join('-');
    const authorUrl = (articledetaildata.authorUrl == undefined) || (articledetaildata.authorUrl == null) ? " " : articledetaildata.authorUrl;
    const bigImage = articledetaildata.imagePath.split(',');
    
    const subcatt = articledetaildata.subcategory ? (articledetaildata.subcategory.toLowerCase() + '/') : '';
    
    const ampBodyWithoutHtml=articledetaildata.summary.replace(/(<([^>]+)>)/ig, '');
    const ampBodyWithoutHtml1=ampBodyWithoutHtml.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
    //const topDealUrl = 'https://english.jagran.com/top-deals/'+ articledetaildata.category.toLowerCase().split(' ').join('-') ;
    const catlUrl = ( (articledetaildata.subcategory==null) || (articledetaildata.subcategory==undefined) ) ? "" : ('https://english.jagran.com/'+ articledetaildata.category.toLowerCase().split(' ').join('-') + '/' + articledetaildata.subcategory.toLowerCase().split(' ').join('-')) ;

    let seodata = [];
    Object.keys(articledetaildata.blogs).map((index, key) => {
        let updatedTime = articledetaildata.blogs[index].commentTime.split(':');

        var refine1 = articledetaildata.blogs[index].comment;
        var refine2 = refine1.replace(/(<([^>]+)>)/gi, '');
        var refine3 = refine2.replace(/"/g, "");

        return(  
            
            

          seodata.push(

            `{
              "@type": "BlogPosting",
              "headline": "${articledetaildata.blogs[index].commentTitle}",
              "url": "${'https://english.jagran.com/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.url+'-'+articledetaildata.id}",
              "datePublished": "${moment(articledetaildata.pubDate).format()}",
              "dateModified": "${moment(articledetaildata.pubDate).set({h: updatedTime[0], m: updatedTime[1]}).format()}",
              "mainEntityOfPage":"${'https://english.jagran.com/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.url+'-'+articledetaildata.id}",
              "author": {
                "@type": "Person",
                "name": "${articledetaildata.authorEng}",
                "url": "${(articledetaildata.authorUrl) ? ('https://english.jagran.com/authors/'+articledetaildata.authorUrl) : 'https://english.jagran.com/authors/'}"
              },
              "articleBody": "${refine3}",
              "publisher": {
                "@type": "Organization",
                "name": "Jagran English",
                "logo": {
                    "@type": "ImageObject",
                    "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png",
                    "width": 600,
                    "height": 60
                }
              },
              "image": {
                "@type": "ImageObject",
                "url": "${DomainPrefixes.ImagePath+articledetaildata.imagePath}",
                "width": 1200,
                "height": 675
              }
            }`

          )
            
          )
    });
    
    const schemaAarray_1=[];
    schemaAarray_1.push({
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "url": `${ 'https://english.jagran.com/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.url+'-'+articledetaildata.id }`,
        "mainEntityOfPage":{ '@type':"WebPage", "@id":`${ 'https://english.jagran.com/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.url+'-'+articledetaildata.id }` },
        "headline": `${ articledetaildata.headline.slice(0, 108) }`,
        "datePublished": `${moment(articledetaildata.pubDate).format()}`,
        "dateModified": `${moment(articledetaildata.modDate).format()}`,
        "description": `${articledetaildata.metaDesc}`,
        "articleBody": `${ampBodyWithoutHtml1}`,
        "articleSection": `${articledetaildata.category}`,
        "author": { "@type": "Person", "name": `${articledetaildata.authorEng}`, "url":`${DomainPrefixes.UrlPrifix +'/authors/'+ authorUrl}` },
        "publisher": { "@type": "Organization", "name": "Jagran English", "logo": { "@type": "ImageObject", "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png", "width": 600, "height": 60 } },
        "image": { "@type": "ImageObject", "url": `${DomainPrefixes.ImagePath+bigImage[0]}`, "height":675, "width":1200 }
});
const schemaAarray_2 = { 
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "item": {"@id": "https://english.jagran.com","name": "News"}
        },
        {
        "@type": "ListItem",
        "position": 2,
        "item": {"@id": `${  DomainPrefixes.UrlPrifix +'/'+ articledetaildata.category.toLowerCase() }`,
        "name":`${articledetaildata.category}`}
        }
    ]
};
(articledetaildata.subcategory==null)||(articledetaildata.subcategory==undefined) ? '' : schemaAarray_2.itemListElement.push({
      "@type": "ListItem",
          "position": 3,
          "item": {"@id": `${catlUrl}`,
         "name":`${articledetaildata.subcategory}`}
 }) ;
// const schemaAarray_3=[];
// schemaAarray_3.push({ 
//     "@context": "https://schema.org",
//     "@type": "BreadcrumbList",
//     "itemListElement": [{
//         "@type": "ListItem",
//         "position": 1,
//         "item": {"@id": "https://english.jagran.com","name": "News"}
//         },
//         {
//         "@type": "ListItem",
//         "position": 2,
//         "item": {"@id": "https://english.jagran.com/top-deals",
//         "name":"Top Deals"}
//         },
//         {
//             "@type": "ListItem",
//             "position": 3,
//             "item": {"@id": `${  topDealUrl  }`,
//             "name":`${articledetaildata.category}`}
//         },
//         {
//             "@type": "ListItem",
//             "position": 4,
//             "item": {"@id": `${  ( urlRoughter.match('top-deals') ) ? ( DomainPrefixes.UrlPrifix +'/top-deals/' + articledetaildata.category.toLowerCase().split(' ').join('-') + "/" + articledetaildata.subcategory.toLowerCase().split(' ').join('-') ) : '' }`,
//             "name":`${ (articledetaildata.subcategory==null)||(articledetaildata.subcategory==undefined) ? '' : articledetaildata.subcategory }`}
//         }
//     ]
// });
const schemaAarray_13=[];
    schemaAarray_13.push(`

        {
            "@context": "https://schema.org",
            "@type": "LiveBlogPosting",
            "url": "${'https://english.jagran.com/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.url+'-'+articledetaildata.id}",
            "datePublished": "${moment(articledetaildata.pubDate).format()}",
            "dateModified":"${moment(articledetaildata.modDate).format()}",
            "publisher": {
            "@type": "Organization",
            "name": "Jagran English",
            "logo": {
                "@type": "ImageObject",
                "url": "https://imgeng.jagran.com/images/jagranenglish-logo-new.png",
                "width": 600,
                "height": 60
            }
            },
            "author": {
            "@type": "Person",
            "name": "${articledetaildata.authorEng}",
            "url": "${(articledetaildata.authorUrl) ? ('https://english.jagran.com/authors/'+articledetaildata.authorUrl) : 'https://english.jagran.com/authors/'}"
            },
            "about":{
                    "@type":"Thing",
                    "name":"event"
                },
            "image": {
            "@type": "ImageObject",
            "url": "${DomainPrefixes.ImagePath+articledetaildata.imagePath}",
            "width": 1200,
            "height": 675
            },
            "coverageStartTime":"${moment(articledetaildata.pubDate).format()}",
            "coverageEndTime":"${moment(articledetaildata.pubDate).add(3, 'days').format()}",
            "headline":"${articledetaildata.headline}",
            "description":"${(articledetaildata.metaDesc)?articledetaildata.metaDesc:''}",
            "liveBlogUpdate": [ ${seodata} ]
        }

    `);
return(
    <>
    <title>{( (articledetaildata.metaTitle==undefined)||(articledetaildata.metaTitle==null) ) ? articledetaildata.headline : articledetaildata.metaTitle}</title>
    <meta name="description" content={( (articledetaildata.metaDesc==undefined)||(articledetaildata.metaDesc==null) )?' ':articledetaildata.metaDesc} />
    <meta name="keywords" content={( (articledetaildata.keywords==undefined)||(articledetaildata.keywords==null) )?' ':articledetaildata.keywords} />    
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_1)}}  />
    <script type="application/ld+json"  dangerouslySetInnerHTML={{__html: schemaAarray_13 }} ></script>
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  />
    <meta name="theme-color" content="#dc0228" />
    <meta property="og:title" content={articledetaildata.headline} />
    <meta property="og:description" content={articledetaildata.metaDesc} />
    <meta property="og:url" content={'https://english.jagran.com/'+articledetaildata.category.toLowerCase()+'/'+subcatt+articledetaildata.url+'-'+articledetaildata.id} />
    <meta property="og:image" content={DomainPrefixes.ImagePath+bigImage[0]} />
    <meta property="og:site_name" content="English Jagran" />
    <meta property="og:type" content="Article" />
    
    {/* {        
        ( urlRoughter.match('top-deals') ) ? 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_3)}}  />) : 
        (<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaAarray_2)}}  />)
    } */}
    </>
)
}
export default Meta;