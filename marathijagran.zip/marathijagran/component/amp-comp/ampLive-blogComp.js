import { DomainPrefixes } from "../utils/ejConfig";
import moment from "moment";
export const config = { amp: true };
export default function articleBody(props){
const {articledetaildata, urlRoughter} = props;
var injectAds = " ";
var injectAds = articledetaildata.summary;
  return (
    <>      
          <br />
           <div className="article-content">
              <div className="liveBlog"><b className="liveBlink"></b>Live Blog</div>
              <h1 className="articleHd">{articledetaildata.headline}</h1>
              <div className="authorBox">
                <div className="authorName"><span className="authorTXt">Author: {(articledetaildata.authorUrl != null || articledetaildata.authorUrl != undefined) ? (<a href={'/authors/'+articledetaildata.authorUrl} title={articledetaildata.authorEng}>{articledetaildata.authorEng}</a>) : articledetaildata.authorEng}</span></div>
                <span className="date">{moment(articledetaildata.modDate).format('llll')}</span>
              </div>
              <div className="figure">
                  <div className="article-img">
                      <amp-img src={DomainPrefixes.ImagePath+articledetaildata.imagePath} layout="responsive" width="1200" height="675" alt={articledetaildata.headline}>
                      </amp-img>
                  </div>
              </div>
              <div dangerouslySetInnerHTML={{ __html: injectAds }} />
          </div>         
          <div className="ads">
              <amp-ad width="336" height="280" type="doubleclick" data-slot={'/13276288/Eng_Jagran/AMP/'+articledetaildata.category+'/liveblog/top_300x250'} data-multi-size="300x250"></amp-ad>
          </div>
          <amp-fx-flying-carpet height="300px"><amp-ad width="300" height="600" layout="fixed" type="doubleclick" data-slot={'/13276288/Eng_Jagran/AMP/'+articledetaildata.category+'/liveblog/FC_300x600'}></amp-ad></amp-fx-flying-carpet>         
          <article className="verdictBox">            
          <br/>            
            {   
                           
                (articledetaildata.isHighlights != "N")
                ?
                (<div className="blogArticle">
                    <h2>HighLights</h2>
                    <ol className="blogListing">
                        {
                            Object.keys(articledetaildata.highlights).map((index) => {
                                return(  <li key={index}>{articledetaildata.highlights[index]}</li>  )
                            })
                        }                               
                    </ol>
                </div>)
                :""
            }
            <div className="verdicttext"><div className="dateStrip">{articledetaildata.formatedDate}</div></div>
            <div className="timeLine">
                {                                           
                    Object.keys(articledetaildata.blogs).map((index, key) => {
                        function blogBlogData(blogBlogDatall, bb){
                            let MyData1 = "commentTime";
                            let MyData2 = "commentTitle";
                            let MyData3 = "comment";
                            let MyData4 = "embeddCode";
                            return(
                                (bb == 1) ?
                                (<div className="amp-live-list-item" key={bb}>
                                    <div className="timeLineTime">{blogBlogDatall[MyData1]}</div>
                                    <h2 className="blogheading">{blogBlogDatall[MyData2]}</h2>
                                    <div className='blogDataHTML' dangerouslySetInnerHTML={ {__html : blogBlogDatall[MyData3] } }></div>
                                    { (blogBlogDatall[MyData4] != "") ?
                                    (<div className='blogDataHTML' dangerouslySetInnerHTML={ {__html : blogBlogDatall[MyData4] } }></div>) : "" }
                                    <div className="ads"><amp-ad width="336" height="280" type="doubleclick" data-slot={"/13276288/Eng_Jagran/AMP/"+articledetaildata.category+"/liveblog/medium_300x250"} data-multi-size="300x250"></amp-ad></div>
                                </div>):
                                 (<div className="amp-live-list-item" key={bb}>
                                 <div className="timeLineTime">{blogBlogDatall[MyData1]}</div>
                                 <h2 className="blogheading">{blogBlogDatall[MyData2]}</h2>
                                 <div className='blogDataHTML' dangerouslySetInnerHTML={ {__html : blogBlogDatall[MyData3] } }></div>
                                 { (blogBlogDatall[MyData4] != "") ?
                                 (<div className='blogDataHTML' dangerouslySetInnerHTML={ {__html : blogBlogDatall[MyData4] } }></div>) : "" }
                             </div>)
                            )
                            
                        }
                        return( blogBlogData(articledetaildata.blogs[index], key) )
                    })
                }  
              </div>
          </article>

         <div className="ads"><amp-ad width="336" height="280" type="doubleclick" data-slot={"/13276288/Eng_Jagran/AMP/"+articledetaildata.category+"/liveblog/bottom_300x250"} data-multi-size="300x250"></amp-ad></div>
      
          <div className="tabolabad"><amp-embed width='100' height='100' type='taboola' layout='responsive'
                  data-publisher='jagrannewmedia-jagranenglish' data-mode='thumbs-feed-01'
                  data-placement='Below Article Thumbnails AMP' data-target_type='mix' data-article='auto'
                  data-feed-container-num="1"
                  data-url='https://english.jagran.com/india/after-delhi-chaos-and-long-queues-meet-fliers-at-mumbai-airport-10058227'></amp-embed>
          </div>
          
          <div className="tabolabad"><amp-embed width='100' height='100' type='taboola' layout='responsive'
                  data-publisher='jagrannewmedia-jagranenglish' data-mode='thumbs-feed-01'
                  data-placement='Below Article Thumbnails AMP' data-target_type='mix' data-article='auto'
                  data-feed-container-num="2"
                  data-url='https://english.jagran.com/india/after-delhi-chaos-and-long-queues-meet-fliers-at-mumbai-airport-10058227'></amp-embed>
          </div>
    </>
  )
}