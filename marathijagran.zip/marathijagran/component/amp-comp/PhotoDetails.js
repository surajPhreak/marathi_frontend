import React from 'react';

function PhotoDetails(props) {
    const {articledetaildata}= props
    return (
        <>
                    <div className='photo-content'>
                        <h1 className="articleHd">{articledetaildata.headline}</h1>
                        <p>{articledetaildata.summary}</p>

                        <span className="date"><strong>{articledetaildata.photoDetails.length} Photos | </strong><small>{articledetaildata.pubDate}</small></span>

                      
                        <div className="mainPhoto">
					        <div className="photoSlidert">
                                <ul>
                                    
                                {articledetaildata.photoDetails.map((item, index)=>{
                                    return(
                                    <li key={index}>
                                         <amp-img src={`https://imgeng.jagran.com/images/${item.imagePath}`} width="400" height="300" layout="responsive" alt={item.headline}></amp-img>
                                        <span className="photoCount"><small>{index+1}</small>/ {articledetaildata.photoDetails.length}</span>
                                        <p><strong>{item.headline} : </strong>{item.description}</p>
                                    </li>
                                    )        
                                })}
                                </ul>
                            </div>
                        </div> 
                        <div className="adBox tabolabad"><amp-embed width="100" height="100" type="taboola" layout="responsive" data-publisher='jagrannewmedia-jagranenglish' data-mode='thumbs-feed-01' data-placement='Below Article Thumbnails AMP' data-target_type='mix' data-article='auto' data-feed-container-num="1" data-url=''></amp-embed></div>

	 <div className="adBox tabolabad"><amp-embed width="100" height="100" type="taboola" layout="responsive" data-publisher='jagrannewmedia-jagranenglish' data-mode='thumbs-feed-01' data-placement='Below Article Thumbnails AMP' data-target_type='mix' data-article='auto' data-feed-container-num="2" data-url=''></amp-embed></div>
     	
                    </div>
               

        </>
    );
}

export default PhotoDetails;