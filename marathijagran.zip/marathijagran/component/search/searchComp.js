import { useState } from "react";
import { DomainPrefixes, PageAPI } from "../utils/ejConfig";
import LazyLoad from "react-lazy-load";
import axios from "axios";
//import Image from "next/image";
function ListingNews(props){
    const{ListingData, topicname, pageNumberRevised, totalCount} = props;    
    const PreRenderd = ListingData.posts;
    const [posts, setPosts] = useState(PreRenderd); 
    //const [isLoading, setIsLoading] = useState(false);
    const [post, setPost] = useState(2);
    const getMorePost = async () => {   
        const res = await axios('/api/ajaxCalls' ,{params:{url:`${PageAPI.KeywordBase_API}${topicname}/${post}/10`}});
        const newPosts = await res.data;
        const dataPost = newPosts.posts;
        //setIsLoading(false);
        // console.log(post)
        if (dataPost && dataPost.length > 0) {
            setPosts((el) =>{
                return [...el, ...dataPost]}); 
            setPost((el)=>el+1);
        }
       

           
      };

    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(totalCount / 10); i++) {
      pageNumbers.push(i);
    }

    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
    }
    return(
        <>
        <div className="allhead listing-dyhead"><h1>{topicname.split('-').join(' ')} </h1></div>
        <div className="main-story">
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index <= 1){ 
                        const ImpPath = data.imagePath.split(',');
                        const subcatt = data.subcategory?data.subcategoryUrl.toLowerCase().split(' ').join('-')+'/':'';
                        return(
                            <div className="article secart" key={index}>
                                <div className="h3">
                                    <h2>
                                    <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                    {/* <a title={data.headline} href={(data.isLiveBlog == "Y")?('/'+data.category.toLowerCase()+'/'+data.webTitleUrl+'-lb-'+data.id):('/'+data.category.toLowerCase()+'/'+data.webTitleUrl+'-'+data.id)}>{data.headline}</a> */}
                                    <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                    </div>
                                    </h2>
                                    <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}><LazyLoad threshold={0.95}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></LazyLoad></a></figure>
                                </div>                            
                            </div>
                        ) }
                      } 
                      )
                  }
                  <div className="article secart emobile"><div className="ads top-300x250"><div id="target-2"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 1 && index <= 3){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.toLowerCase().split(' ').join('-')+'/':'';
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}><LazyLoad threshold={0.95}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></LazyLoad></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }           
                  <div className="article secart emobile"><div className="ads medium-300x250"><div id="target-3"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 3 && index <= 5){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.toLowerCase().split(' ').join('-')+'/':'';
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}><LazyLoad threshold={0.95}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></LazyLoad></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }
<div id="videoplayer"></div>
                  <div className="article secart emobile"><div className="ads bottom-300x250"><div id="target-11"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 5 && index <= 7){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.toLowerCase().split(' ').join('-')+'/':'';
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}><LazyLoad threshold={0.95}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></LazyLoad></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }

                  <div className="article secart emobile"><div className="ads bottom-300x250"><div id="target-4"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 7){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatt = data.subcategoryUrl?data.subcategoryUrl.toLowerCase().split(' ').join('-')+'/':'';
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatt+removeLastId(data.webTitleUrl)+'-'+data.id}><LazyLoad threshold={0.95}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></LazyLoad></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }
                
           
        </div>
{ totalCount> posts.length &&    <div className="load-more"><button id="pagination-btn" className="btn btn-primary" onClick={getMorePost}>Load More</button></div>}       
<div className="eweb ads interstitial-1x1"><div id="target-10"></div></div>
 {/* <div className="pagination border0">
            <div className="floatright">
                <ul>
                    {
                        ( pageNumberRevised==1 )?'':
                        (<li className="first"><a href={'/search/'+topicname+'/page'+ (pageNumberRevised-1)} title="Pagination First"></a></li>)
                    }
                    {
                        pageNumbers.map( (data, index) => {
                            return(
                                (pageNumberRevised == pageNumberRevised+index)?(<li key={index}><strong>{pageNumberRevised+index}</strong></li>):
                                (pageNumbers.length>=pageNumberRevised+index?<li key={index}><a href={'/search/'+topicname+'/page'+ (pageNumberRevised+index)} title="Pagination">{pageNumberRevised+index}</a></li>:'')
                            )                            
                        } )
                        
                    }
                    {
                    ( pageNumbers.length<=pageNumberRevised+1 )?'':
                     <li className="last"><a href={'/search/'+topicname+'/page'+ (pageNumberRevised+1)} title="Pagination Last"></a></li>
}
                </ul>
            </div>
        </div>   */}

        </>
    )
}
export default ListingNews;