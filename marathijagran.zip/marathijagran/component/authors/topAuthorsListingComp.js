import { DomainPrefixes } from "../utils/ejConfig";
//import Image from "next/image";
function TopListingNews(props){
    const{ListingData, authorName, pageNumberRevised} = props;
    let nuberOfpaginationPerPage = ['1','2','3','4','5','6','7','8','9','10'];

    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    
    return(
        <>
        <div className="allhead listing-dyhead"><h1>{authorName.split("-").join(" ")} News</h1></div>
        <div className="main-story">
                  {
                    ListingData.map( 
                      (data, index) => { 
                        if(index <= 1){ 
                        const ImpPath = data.imagePath.split(',');
                        return(
                            <div className="article secart" key={index}>
                                <div className="h3">
                                    <h2>
                                    <a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                    <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                    </div>
                                    </h2>
                                    <figure><a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                </div>                            
                            </div>
                        ) }
                      } 
                      )
                  }
                  <div className="article secart emobile"><div className="ads top-300x250"><div id="al_top_300x250_m"></div></div></div>
                  {
                    ListingData.map( 
                      (data, index) => { 
                        if(index > 1 && index <= 3){ 
                            const ImpPath = data.imagePath.split(',');
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }           
                  <div className="article secart emobile"><div className="ads medium-300x250"><div id="target-4"></div></div></div>
                  {
                    ListingData.map( 
                      (data, index) => { 
                        if(index > 3 && index <= 5){ 
                            const ImpPath = data.imagePath.split(',');
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }
                  <div className="article secart emobile"><div className="ads bottom-300x250"><div id="target-5"></div></div></div>
                  {
                    ListingData.map( 
                      (data, index) => { 
                        if(index > 5){ 
                            const ImpPath = data.imagePath.split(',');
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/top-deals/'+data.categoryUrl+'/'+data.subCategoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }
                  <div className="ads interstitial-1x1"><div id="target-20"></div></div>
           
        </div>
        <div className="pagination border0">
            <div className="floatright">
                <ul>
                    {
                        ( pageNumberRevised==1 )?'':
                        (<li className="first"><a href={'/authors/'+authorName+'-page'+ (pageNumberRevised-1)} title="Pagination First"></a></li>)
                    }
                    {
                        nuberOfpaginationPerPage.map( (data, index) => {
                            return(
                                (pageNumberRevised == pageNumberRevised+index)?(<li key={index}><strong>{pageNumberRevised+index}</strong></li>):
                                (<li key={index}><a href={'/authors/'+authorName+'-page'+ (pageNumberRevised+index)} title="Pagination">{pageNumberRevised+index}</a></li>)
                            )                            
                        } )
                        
                    }                    
                    <li className="last"><a href={'/authors/'+authorName+'-page'+ (pageNumberRevised+1)} title="Pagination Last"></a></li>
                    
                </ul>
            </div>
        </div>  
        <div className="ads interstitial-1x1"><div id="target-20"></div></div>
        </>
    )
}
export default TopListingNews;