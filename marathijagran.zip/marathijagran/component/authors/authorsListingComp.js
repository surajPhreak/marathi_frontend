import { useState } from "react";
import { DomainPrefixes, PageAPI } from "../../component/utils/ejConfig";
import axios from "axios";

//import Image from "next/image";
function ListingNews(props){
    const{ListingData, authorName, pageNumberRevised, totalCount, authorNameSpace} = props;
    const PreRenderd = ListingData.posts;
    const [posts, setPosts] = useState(PreRenderd); 
    //const [isLoading, setIsLoading] = useState(false);
    const [post, setPost] = useState(2);
    const getMorePost = async () => {  
        const res = await axios('/api/ajaxCalls' ,{params:{url:`${PageAPI.AuthorListing_API1}${authorName}/${post}/10`}});

        const newPosts = await res.data;
        
        const dataPost = newPosts.posts;
  
        //setIsLoading(false);
         setTimeout(() => { 
              setPosts((post) => [...post, ...dataPost]); 
              //setIsLoading(false);
              setPost(post + 1);
          }, 10);     
      };
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(totalCount / 10); i++) {
      pageNumbers.push(i);
    }

    function removeLastId(str) {
        const reLast = /-\d+$/;
        return str.replace(reLast, "");
      }
    return(
        <>
         <div className="allhead listing-dyhead"><h1> Articles By {authorNameSpace}</h1></div>
        <div className="main-story">
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index <= 1){ 
                        const ImpPath = data.imagePath.split(',');
                        return(
                            <div className="article secart" key={index}>
                                <div className="h3">
                                    <h2>
                                    <a title={data.headline} href={'/'+data.categoryUrl +'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                    <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.categoryUrl}</span></span>
                                      
                                    </div>
                                    </h2>
                                    <figure><a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                </div>                            
                            </div>
                        ) }
                      } 
                      )
                  }
                  <div className="article secart emobile"><div className="ads top-300x250"><div id="target-2"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 1 && index <= 3){ 
                            const ImpPath = data.imagePath.split(',');
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.categoryUrl}</span></span>
                                            {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }           
                  <div className="article secart emobile"><div className="ads medium-300x250"><div id="target-4"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 3 && index <= 5){ 
                            const ImpPath = data.imagePath.split(',');
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.categoryUrl}</span></span>
                                            {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }
                  <div className="article secart emobile"><div className="ads bottom-300x250"><div id="target-5"></div></div></div>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 5){ 
                            const ImpPath = data.imagePath.split(',');
                            return(
                                <div className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.categoryUrl}</span></span>
                                            {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><img src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </div>
                        ) }
                      } 
                      )
                  }
                  
                  <div className="ads interstitial-1x1"><div id="target-20"></div></div>
           
        </div>
        <div className="load-more"><button id="pagination-btn" className="btn btn-primary" onClick={getMorePost}>Load More</button></div>
        
        {/* <div className="pagination border0">
            <div className="floatright">
                <ul>
                    {
                        ( pageNumberRevised==1 )?'':
                        (<li className="first"><a href={'/authors/'+authorName+'-page'+ (pageNumberRevised-1)} title="Pagination First"></a></li>)
                    }
                    {
                        pageNumbers.map( (data, index) => {
                            return(
                                (pageNumberRevised == pageNumberRevised+index)?(<li key={index}><strong>{pageNumberRevised+index}</strong></li>):
                                (pageNumbers.length>=pageNumberRevised+index?<li key={index}><a href={'/authors/'+authorName+'-page'+ (pageNumberRevised+index)} title="Pagination">{pageNumberRevised+index}</a></li>:'')
                            )                            
                        } )
                        
                    }    
                    {
                    ( pageNumbers.length<=pageNumberRevised+1 )?'':                
                    <li className="last"><a href={'/authors/'+authorName+'-page'+ (pageNumberRevised+1)} title="Pagination Last"></a></li>
                }
                </ul>
            </div>
        </div>   */}
        <div className="ads interstitial-1x1"><div id="target-20"></div></div>
        </>
    )
}
export default ListingNews;