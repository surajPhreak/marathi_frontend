import SVGImagesSymbol from './SVGImages';
import { useRouter } from 'next/router';
import { useState } from 'react';

const TopDealsHeader = (props) => {
    const {headerDataMenu, subHeader}= props;
    const router = useRouter()
    const [clicked, setClicked] = useState('');
    const [mobileHeader, setmobileHeader] = useState('');
    //const [closeMobileHeader, setcloseMobileHeader] = useState('');

    const handleClick = () => {  clicked ? setClicked('') : setClicked('dropdown active');  };
    const handleMobileClick = () => { mobileHeader ? setmobileHeader('') : setmobileHeader('sidebar-hamburger opn'); };

    const list = [];
    const mobileList = [];
    const sublist = [];
    if(headerDataMenu){
        list.push(<li key="121"><a href={'/top-deals/'} className="top-deals"  title="Top Deals">Top Deals</a></li>)
        headerDataMenu.forEach( (p,index) => {
            if(index <= 6){
                list.push(<li key={index}><a href={'/top-deals/'+p.categoryUrl} className="top-deals"  title={p.categoryName}>{p.categoryName}</a></li>)
            }
            if(index > 6){
                sublist.push(
                    <li key={index}>
                    <a href={'/top-deals/'+p.categoryUrl} title={p.categoryName}>{p.categoryName}</a>
                    </li>
                )
            }
            mobileList.push( <li> <a title={p.categoryName} href={'/top-deals/'+p.categoryUrl}>{p.categoryName}</a> </li> );
        } )
        list.push(<li className={clicked || 'dropdown' }  id="dropdown" key="9">
        <a title="More Category" href="#" onClick={handleClick}>MORE +</a>
        <ul className="dropdown-menu menu" id="dropdown-menu">  {sublist}  </ul>
        </li>)
    }
    const subHead = [];
    if(router.query.category && subHeader.length > 0){
        subHeader.forEach( (p) => { subHead.push(<li> <a href={'/top-deals/'+router.query.category+'/'+p.categoryUrl}>{p.categoryName}</a></li>) } )
    }else{ }
    // const notificationdata = [];
    // if(notificationData){
    //     notificationData.forEach( (data) => {
    //         notificationdata.push(
    //             <li className="article" key={data.id}>
    //             <figure><a href={'/'+data.category+'/'+data.webTitleUrl+'-'+data.id} title={data.headline}><img src={DomainPrefixes.imagePath+data.imagePath} alt={data.headline} /></a></figure>
    //             <div className="summary">
    //                 <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.category}</span></span></div>
    //                 <a href={'/'+data.category+'/'+data.webTitleUrl+'-'+data.id} title={data.headline}>{data.headline}</a>
    //             </div>
    //         </li>
    //         )
    //     })
    // }
    return(
        <>
         <SVGImagesSymbol />
        <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@900&amp;family=Poppins&amp;display=swap" rel="stylesheet" />
            <header>
                <div id="header">
                    <div className="container">
                        <div className="header">
                            <ul className="h-left">
                                <li className="logo">
                                    <a title="Home" href="/">
                                        <svg className="icon"><use href="#dssdDocument"></use></svg>
                                        <span className="text-hidden">Jagran Logo</span>
                                    </a>
                                </li>
                                {list}
                            </ul>
                            <div className="topmenu">
                                <a title="Hamburger Menu" className="hamburger" href="#" onClick={handleMobileClick}>
                                    <svg><use href="#menu"></use></svg></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container">


{!router.query.subcategory ? (
       <div className="inTheNews">
       <h2>{router.query.category}</h2>
       <div className="sub-menu" id="inTheNews">
         <ul>
         {subHead}
         </ul>
       </div>
     </div>
      ) : (
        <div></div>
      )}


                </div>
            </header>
            <div className="header-space"></div>
            <div className={mobileHeader || 'sidebar-hamburger' }>
            <div className="sidebar-container">
            <span className="sidebar-close" onClick={handleMobileClick}>
            <svg>
            <use href="#close"></use>
            </svg>
            </span>
            <ul className="sidebar-item">
            {mobileList}
            </ul>
            </div>
            </div>
            {/* <div className="search_popup" id='search_popup'>
                <div className="search_col">
                    <div className="search_form">
                        <span className="close_search" id='close_search'><svg><use href="#close"></use></svg></span>
                        <div className="input_group">
                            <form id="searchForm" action=''>
                                <input className="input_search" placeholder='Type Your search' aria-label="searchText" name="searchText" type="text" id="searchText" />
                                <input id="clickSearchValue1" className="btnsrch" value="" type="submit" />
                            </form>
                        </div>
                    </div>
                </div>
            </div> */}
            <div className="sidebar-hamburger" id='sidebar-hamburger'>
                <div className="sidebar-container">
                    <span className="sidebar-close" id='sidebar-close'><svg><use href="#close"></use></svg></span>
                    <ul className="sidebar-item">{list}</ul>
                </div>
            </div>
            {/* <div className="notification-popup" id="notification-popup">
                <a title="Close" className="close-notification" id="close-notification" href="#"><svg><use href="#close"></use></svg></a>
                <div className="notification-conent">
                    <div className="allhead"><h2>Latest News</h2></div>
                    <ul className="list">{notificationdata}</ul>
                </div>
            </div> */}
            {/* <Script src="../../../js/topDealsCommon.js"></Script> */}
        </>
    )
}
export default TopDealsHeader;