//import React from "react";

import Head from "next/head";
import Link from "next/link";
import { useState } from "react";

//import { useState, useEffect } from 'react';
const FooterHTML = (FooterDataMenu) => {
    //const list = [];
    const [update, setUpdate] = useState(false)
   
    // if(FooterDataMenu.FooterDataMenu.others){
    //   FooterDataMenu.FooterDataMenu.others.forEach( (p, index) => { list.push(<li key={index}><a href={p.url} title={p.menu_name} aria-label={p.menu_name} rel="nofollow noopener" target="_blank">{p.menu_name}</a></li>) } )
    // }
    const listPolicy = [];
    if(FooterDataMenu.FooterDataMenu){
      FooterDataMenu.FooterDataMenu.forEach( (p, index) => { listPolicy.push(<li key={index}><a href={p.url} title={p.title} aria-label={p.title} rel={p.menu_class}>{p.title}</a> </li>) } )
    }
    const schemaAarray_3 = [];
   
    schemaAarray_3.push(`
    var _comscore = _comscore || [];
    _comscore.push({
        c1: "2",
        c2: "13184768",
        cs_ucfr: 1 ,
        options:{
          enableFirstPartyCookie:true
        }
    });
    (function() {
        var s = document.createElement("script"),
            el = document.getElementsByTagName("script")[0];
        s.async = true;
        s.src = "https://sb.scorecardresearch.com/cs/13184768/beacon.js";
        el.parentNode.insertBefore(s, el);
    })();
    `);
    const updateComscore = () => {
     
        setUpdate(true)
        const script = document.getElementById('comscoreScript');
        if (script) {
            script.parentNode.removeChild(script);
        }
    }
    return(
        <>
            <Head>
{         update&&   <script type="text/javascript" dangerouslySetInnerHTML={{ __html: schemaAarray_3 }}></script>
}
            </Head>
          <footer>
                <div className="container">
                <div className="footerStickyads mobileAds">
              <div id="target-51" className="adsView"></div>
            </div>
                <div className="footer">
                    {/* <div className="col-left"><ul className="footer-main-link">{list}</ul></div>
                    <div className="col-right">
                        <ul className="social">
                            <li><a target="_blank" href="https://www.facebook.com/MarathiJagran/" rel="nofollow noopener" title="Facebook" aria-label="Facebook"><svg><use href="#facebook"></use></svg></a></li>
                            <li><a href="https://twitter.com/Marathijagran" rel="nofollow noopener" target="_blank" title="Twitter" aria-label="Twitter"><svg><use href="#twitter"></use></svg></a></li>
                            <li><a href="https://www.instagram.com/Marathijagran/" rel="nofollow noopener" target="_blank" aria-label="Instagram"><svg className="icon"><use href="#instagram"></use></svg></a></li>
                        </ul>
                    </div> */}
                    {/* <ul className="social">
                            <li><a target="_blank" href="https://www.facebook.com/MarathiJagran/" rel="nofollow noopener" title="Facebook" aria-label="Facebook"><svg><use href="/sprite.svg#facebook"></use></svg></a></li>
                            <li><a href="https://twitter.com/marathijagran" rel="nofollow noopener" target="_blank" title="Twitter" aria-label="Twitter"><svg><use href="/sprite.svg#twitter"></use></svg></a></li>
                            <li><a href="https://www.instagram.com/marathijagran/" rel="nofollow noopener" target="_blank" aria-label="Instagram"><svg className="icon"><use href="/sprite.svg#instagram"></use></svg></a></li>
                        </ul> */}
                </div>
                {/* <div className="footer-subscribe">
                    <p>Jagran English brings you all the latest and breaking news from India and around the world. Get live English news from India, World, Politics, Entertainment, Lifestyle, Business, Education, Sports, Technology, and much more. Follow <strong>english.jagran.com</strong> to stay updated with the latest English news.</p>
                </div> */}
                <div className="footer-row">
                    <p className="copyright">Copyright &copy; 2024 Jagran Prakashan Limited.</p>
                    {/* <img src="https://imgeng.jagran.com/images/digital-cert.jpg" height="23" width="115" className="digitalimg" alt="ABC Digital CERTIFIED" /> */}
                </div>
                <div className="link">
                    <ul>{listPolicy}</ul>
                    {/* <ul>
                    <li><a href="/about-us">About Us</a></li>
                    <li><a href="/contact-us">Contact Us</a></li>
                    <li><a href="/actionable-feedback">Actionable Feedback</a></li>
                    <li><a href="/disclaimer">Disclaimer&nbsp;</a></li>
                    <li><a href="/privacy-policy">Privacy Policy</a></li>
                    <li><a href="/this-website-follows-the-dnpas-code-of-conduct">This website follows the DNPA's code of conduct&nbsp;</a></li>
                    <li><a href="mailto:compliant_gro@jagrannewmedia.com">compliant_gro@jagrannewmedia.com</a></li>
                  </ul> */}
                </div>
            </div>
        </footer>
        <div id="gdprbx">
            <div className="container">
                <div className="cookiebox">This website uses cookie or similar technologies, to enhance your browsing experience and provide personalised recommendations. By continuing to use our website, you agree to our <a href="/privacy-policy" rel="noopener" target="_blank">Privacy Policy</a> and <a href="/cookie-policy" rel="noopener" target="_blank">Cookie Policy</a>.<button onClick={updateComscore} className="close" id="close-btn">OK</button>
                </div>
            </div>
        </div>
        </>
    )
}
export default FooterHTML;