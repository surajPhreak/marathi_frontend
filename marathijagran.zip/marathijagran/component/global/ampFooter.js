import { DomainPrefixes } from "../utils/ejConfig";
const Footer = () => {
    return(
        <>
			<div className="tabs-sec"><div className="soical-hz tab-cell"><amp-social-share type="system" aria-label="Share" width="25" height="25"></amp-social-share></div></div>
			<div className="footer">
				<div className="container">
				{/* <div className="android-ios-box">
					<a href="https://bit.ly/2zqTTjH " className="android-dwn" title="Download Android App" target="_blank" rel="nofollow noopener"></a>
					<a href="https://apple.co/35QqUC9" className="ios-dwn" title="Download IOS App" target="_blank" rel="nofollow noopener"></a>
				</div> */}
				<div className="copyRight">Copyright © 2024 Jagran Prakashan Limited.<span>All rights reserved.</span></div>
				<div className="comlink"><a rel="nofollow" href="mailto:compliant_gro&#64;jagrannewmedia.com" title="English Jagran">For any feedback or complaint, <br/> email to compliant_gro&#64;jagrannewmedia.com</a></div>
				</div>
			</div>
			<amp-user-notification id="my-notification"  layout="nodisplay">
				<div className="gdprx">This website uses cookie or similar technologies, to enhance your browsing experience and provide personalised recommendations. By continuing to use our website, you agree to our<a href={DomainPrefixes.UrlPrifix+'/privacy-policy'}> Privacy Policy</a> and <a href={DomainPrefixes.UrlPrifix+'/cookie-policy'}>Cookie Policy</a>.
				<button on="tap:my-notification.dismiss" className="ampstart-btn caps ml1">OK</button>
				</div>
			</amp-user-notification>
        </>
    )
}
export default Footer;