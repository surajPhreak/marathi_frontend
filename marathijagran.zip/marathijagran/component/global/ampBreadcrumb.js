//import React from "react";
//import { DomainPrefixes } from "../utils/ejConfig";
const Breadcrum = (props) => {

    const { articledetaildata, urlRoughter } = props;
  return (
    <section className="breadcrum">
      <ul>
        <li>
          <a href="/" title="Marathi Jagran">
            News
          </a>
        </li>
        {urlRoughter.match("top-deals") ? (
          <li>
            <a href="/top-deals" title="Top Deals">
              Top Deals
            </a>
          </li>
        ) : (
          ""
        )}

        {urlRoughter.match("top-deals") ? (
          <li>
            <a
              href={
                "/top-deals/" +
                articledetaildata.category.toLowerCase().split(" ").join("-")
              }
              title="Marathi Jagran"
            >
              {articledetaildata.category}
            </a>
          </li>
              ) : (
                      
          <li>
            <a
              href={
                "/" +
                articledetaildata.categoryUrl.toLowerCase().split(" ").join("-")
              }
              title="Marathi Jagran"
            >
              {articledetaildata.categoryUrl}
            </a>
          </li>
        )}

        {articledetaildata.subcategoryUrl && urlRoughter.match("top-deals") ? (
          <li>
            <a
              href={
                "/top-deals/" +
                articledetaildata.category.toLowerCase().split(" ").join("-") +
                "/" +
                articledetaildata.subcategory.toLowerCase().split(" ").join("-")
              }
              title="Marathi Jagran"
            >
              {articledetaildata.subcategory}
            </a>
          </li>
        ) : articledetaildata.subcategoryUrl != "NA" ||
          articledetaildata.subcategoryUrl != undefined ? (
          <li>
            <a
              href={
                "/" +
                articledetaildata.categoryUrl.toLowerCase().split(" ").join("-") +
                "/" +
                articledetaildata.subcategoryUrl.toLowerCase().split(" ").join("-")
              }
              title="Marathi Jagran"
            >
              {articledetaildata.subcategoryUrl}
            </a>
          </li>
        ) : (
          ""
        )}

        {/* {(articledetaildata.subcategory == undefined) || (articledetaildata.subcategory == null) ? `` : <li>{articledetaildata.subcategory}</li>} */}
      </ul>
    </section>
  );
};
export default Breadcrum;
