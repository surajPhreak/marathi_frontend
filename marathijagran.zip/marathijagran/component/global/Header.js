
//import { DomainPrefixes } from "../utils/ejConfig";
import SVGImagesSymbol from '../global/SVGImages';
import { useState,useEffect } from 'react';
import Script from 'next/script';
import Link from 'next/link';
import { useSearchParams,usePathname  } from 'next/navigation'
import { useRouter } from "next/router";
import { v4 as uuidv4 } from 'uuid';
import { SHA256, enc } from 'crypto-js';
import { PageAPI, getCookie, setCookie, removeCookie, DMP_AUTH_TOKEN } from "../../component/utils/ejConfig";
import axios from 'axios';

const Header = (props) => {
    const {headerDataMenu, navtrendingg, sidebar, fixUrlCanonical, newfull}= props;
    const [openTab, setOpenTab] = useState('');
    const [sideBar, setSideBar] = useState(false);
    const [userDetail,setUserDetail]=useState({})
    const router = useRouter();
    const searchParams = useSearchParams()
    const pathname = usePathname()

    const urlFullPath = (fixUrlCanonical) ? `https://www.marathijagran.com/${fixUrlCanonical}` : (newfull === '/') ? 'https://www.marathijagran.com' : `https://www.marathijagran.com${newfull}`;


    // const list = [];
    // if(headerDataMenu){
    //     headerDataMenu.forEach( (p) => { 
    //         list.push(<li key={p.url}><a href={p.url} target={p.target} rel={p.target?'rel=noopener noreferrer':''} title={p.title}>{p.title}</a>{ p.child_items?subNav:''}</li>) 
    //     } )
    // }


    // const notificationdata = [];
    // if(notificationData){
    //     notificationData.forEach( (data) => { 
    //         notificationdata.push(
    //             <li className="article" key={data.id}>
    //             <figure><a href={'/'+data.category.toLowerCase()+'/'+data.webTitleUrl+'-'+data.id} title={data.headline}><img src={DomainPrefixes.ImagePath+data.imagePath} alt={data.headline} /></a></figure>
    //             <div className="summary">
    //                 <div className="timestemp text-uppercase"><span className="label"><span className="red">{data.category}</span></span></div>
    //                 <a href={'/'+data.category.toLowerCase()+'/'+data.webTitleUrl+'-'+data.id} title={data.headline}>{data.headline}</a>
    //             </div>
    //         </li>
    //         )        
    //     })
    // }
    const toogeSideBar = () => {
        setSideBar((prev) => !prev)
        document.querySelector("body").classList.toggle('stopScroll'); 

    }

    const trackAnonymousUser = async () => {
        try {
          let anonymousUserCookie = getCookie('ppid');
          if(anonymousUserCookie && anonymousUserCookie !== undefined && anonymousUserCookie !== null && anonymousUserCookie !== '') {
            setCookie('ppid', anonymousUserCookie, 365);
          }else{
            const agent = navigator.userAgent;
            const agentPlatform = navigator.userAgentData.platform || navigator.userAgent; 
            const uuid = uuidv4();
            const anonymousUser = `${agentPlatform}-${agent}-${uuid}`;
            const hash = SHA256(anonymousUser).toString(enc.Hex);
            anonymousUserCookie = hash;
            setCookie('ppid', anonymousUserCookie, 365)
          }
    
          let visitedUrl = getCookie('vu');
          if(visitedUrl && visitedUrl !== undefined && visitedUrl !== null && visitedUrl !== '') {
            let urlList = JSON.parse(atob(visitedUrl));
            urlList.push(urlFullPath);
            const visitedUrlCookieDate = getCookie('vud');
            const visitedUrlDate = new Date(visitedUrlCookieDate);
            const todaysDate = new Date();
            const differenceInTime = todaysDate.getTime() - visitedUrlDate.getTime();
            const differenceInDays = Math.round(differenceInTime / (1000 * 3600 * 24));
            if(differenceInDays >= 0){
              removeCookie('vu');
              removeCookie('vud');
              const anonymousUserData = {
                ppid: anonymousUserCookie,
                reqDomain: "marathijagran.com",
                url: urlList,
                browserUserAgent: navigator.userAgent
              }
              await axios.post(PageAPI.ANONYMOUSUSERTRACKING_API, anonymousUserData, {
                headers: {
                    'Authorization': 'Bearer '+ DMP_AUTH_TOKEN,
                    'Content-Type': 'application/json'
                }
              });
            }else{
              visitedUrl = btoa(JSON.stringify(urlList));
              setCookie('vu', visitedUrl, 365);
            }
          }else{
            let urlList = [];
            urlList.push(urlFullPath);
            visitedUrl = btoa(JSON.stringify(urlList));
            setCookie('vu', visitedUrl, 365);
            setCookie('vud', new Date(), 365);
          }
        } catch (error) {
          console.log("error", error)
        }
    }
    
      useEffect(() => {
        trackAnonymousUser();
      }, []);


    // useEffect(() => {
    //     const token = searchParams.get('token')
    //     if (token) {
    //         try {

    //         const decode = atob(token)
    //             let val = JSON.parse(decode)
    //             console.log('val1',val)
    //         setUserDetail({
    //           first_name:val?.userData?.first_name,
    //           last_name:val.userData.last_name,
    //             profile_picture: val.userData.profile_picture,
    //             mobile_no:val?.userData?.mobile_no
    //         })
    //         localStorage.setItem('uid', token)
    //         router.replace(pathname, undefined, { shallow: true });
    
    //       }
    //       catch (err) {
    //         console.log('invalid token')
    //       }
     
    //     } else if (localStorage.getItem('uid')) {
    //       try {
            
    //           const decode = atob(localStorage.getItem('uid'))
    //           let val=JSON.parse(decode)
    //           console.log('val2',val)

    //         setUserDetail({
    //             first_name:val?.userData?.first_name,
    //             last_name: val?.userData?.last_name,
    //             profile_picture: val.userData.profile_picture,
    //                  mobile_no:val?.userData?.mobile_no

    //         })
    //       }
    //       catch (err) {
    //         console.log('invalid token')
    //       }
    //     }
    //   },[])
    // const logoutUser = () => {
    //     setUserDetail({})
    //     localStorage.removeItem('uid')
    // }
    
    return(
        <>        
        <SVGImagesSymbol />
        {/* <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin /> */}
        {/* <link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="true"/>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;700&display=swap" rel="stylesheet"/> */}

            <Script src="../../../js/common.js?v=2"></Script>
            <Script src="../../js/notifications.js?v=1"></Script>
            <header>
                <div id="header">
                    <div className="container">
                        <div className="header">
                            <a title="Marathi Jagran" href="/" className='logoM'>
                                <svg className="icon"><use href="/sprite.svg#logomarathi"></use></svg>
                            </a>
                            {/* <ul className="h-left">
                                <li className="logo">                                    
                                    <a title="Home" href="/">
                                        <svg className="icon"><use href="/sprite.svg#logomarathi"></use></svg>
                                        <span className="text-hidden">Marathi Jagran Logo</span>
                                    </a>                               
                                </li>
                            </ul>    */}
                            <div className="h-right">
                                <ul className="websmenu">
                                </ul>
                                <ul className="mobsticky">
                                    {/* <li className="web-stories">                                        
                                        <a  href="https://www.marathijagran.com/web-stories?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints" title="Web Stories">
                                            <svg><use href="#web-stories"></use></svg>
                                            <div className="txtmenu">Web Stories</div>
                                        </a>                                       
                                    </li> */}
                                    {/* <li className="noti">
                                        <a className="notification" href="/stort-videos" title="Notification" id="notification"><span className="count"><b className="liveBlink"></b></span>
                                            <svg><use href="#bell"></use></svg>
                                            <div className="txtmenu">Short Video</div>
                                        </a>
                                    </li> */}
                                    <li className="appIcon">                                       
                                        <a href="https://jagranapp.page.link/k7YU" title="Android">
                                        <svg className="icon"><use href="/sprite.svg#android-icon"></use></svg>
                                            <div className="txtmenu">Android</div>
                                        </a>                                        
                                    </li>


                                    <li className="googleNews"><a href="https://news.google.com/publications/CAAqBwgKMPOSqgwwhZO3BA?hl=en-IN&gl=IN&ceid=IN:en" target="_blank" rel="noreferrer" title="Google News"><svg><use href="/sprite.svg#googleNews"></use></svg><div className="txtmenu">Google News</div></a></li>

                                    <li className="search">                                        
                                        <a title="Search" className="searchPopup" id='searchPopup' href="#">
                                            <svg><use href="/sprite.svg#search"></use></svg>
                                            
                                        </a>
                                    </li>
                                    <li className="menu">
                                        <button aria-label="button" className="hamburger"  onClick={toogeSideBar}>                                            
                                            <span className="txtmenu" id='txtmenu'><svg><use href="/sprite.svg#menu"></use></svg></span>
                                        </button>
                                    </li>
                                  

                                    {/* {Object.keys(userDetail).length > 0 ? <li className="dropdownlogin">
                                        
                                        <a> <span className='userCircle'>{userDetail?.first_name?.substring(0, 1) || "A"}</span> <span> {userDetail.first_name?userDetail.first_name:userDetail.mobile_no} </span></a>  
                                        <div className="dropdown-contentlog">
                                        <span onClick={logoutUser}>logout</span>
                                        </div>
                  </li> : <li className='login'>
                  <a  href="https://stg-auth.jagran.com/login.php?domain=marathijagran.com">
          login
        </a>
                  </li>} */}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container">
                    <nav>
                        <ul>
                         {headerDataMenu && headerDataMenu.map( (p,ins) => { 
                            // var xl = ""
                            // if(p.child_items){
                            //     xl = "active";
                            // }
                            return(
                            <> 

                            <li key={ins+'ab'} className={p.child_items ? "active" : ''}><a href={p.url ? p.url:''} target={p.target} rel={p.target?'rel=noopener noreferrer':''} title={p.title}>{p.title}</a>
                            {p.child_items ?                            
                            <ul className='sub-menu'>
                                {p.child_items.map((q,ins2)=>{
                                      return(  
                                        <> 
                                     <li key={ins2}><a href={q.url} target={q.target} rel={q.target?'rel=noopener noreferrer':''} title={q.title}>{q.title}</a></li>
                                     </>
                                     )
                                     
                                })}
                            </ul>                            
                        :
                        ''}
                            </li>
                            </>
                        )
                        } 
                        )}
                        
                        </ul>
                    </nav>
                    {/* <nav><ul>{list}</ul></nav> */}
                    {/* <ul className="secnav">
                        <li><a title="FIFA World Cup 2022" href="/fifa-world-cup-2022?utm_source=web&amp;utm_medium=subnavigation&amp;utm_campaign=fifaworldcup2022">FIFA World Cup 2022</a></li>
                        <li><a title="Fixtures" href="/fifa-world-cup-2022/match-schedule-fixture-result?utm_source=web&amp;utm_medium=subnavigation&amp;utm_campaign=fifa2022fixtures">Fixtures</a></li>
                        <li><a title="Points Tally" href="/fifa-world-cup-2022/points-table?utm_source=web&amp;utm_medium=subnavigation&amp;utm_campaign=fifa2022pointstable">Points Tally</a></li>
                    </ul> */}
                </div>

                <div className="container">
        <div className="inTheNews">
           <h2> <svg><use href="/sprite.svg#trending"></use></svg>ट्रेंडिंग</h2>
            <div className="sub-menu">

            <ul>
                         {navtrendingg && navtrendingg.map( (p,ins) => { 
                            
                            return(
                            <> 

                            <li key={ins+'ac'} className={p.child_items ? "active" : ''}><Link href={p.url} target={p.target} rel={p.target?'rel=noopener noreferrer':''} title={p.title}>{p.title}</Link>
                            {p.child_items ?                            
                            <ul className='sub-menu'>
                                {p.child_items.map((q,ins2)=>{
                                      return(  
                                        <> 
                                     <li key={ins2}><Link href={q.url} target={q.target} rel={q.target?'rel=noopener noreferrer':''} title={q.title}>{q.title}</Link></li>
                                     </>
                                     )
                                     
                                })}
                            </ul>                            
                        :
                        ''}
                            </li>
                            </>
                        )
                        } 
                        )}
                        
                        </ul>
            </div>
        </div>
    </div>

            </header>
            <div className="header-space"></div>
            <div className="search_popup" id='search_popup'>
                <div className="search_col">
                    <div className="search_form">
                        <span className="close_search" id='close_search'><svg><use href="/sprite.svg#close"></use></svg></span>
                        <div className="input_group">
                            <form id="searchForm" action=''>
                                <input className="input_search" placeholder='Type Your search' aria-label="searchText" name="searchText" type="text" id="searchText" />
                                <input id="clickSearchValue1" className="btnsrch" value="" type="submit" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className={`sidebar-hamburger  ${sideBar?'opn':""}`} id='sidebar-hamburger' >
                <div className="sidebar-container">
                    <span onClick={toogeSideBar} className="sidebar-close" id='sidebar-close'><svg><use href="/sprite.svg#close"></use></svg></span>
                    {/* <ul className="sidebar-item">{list}</ul> */}
                    <ul className="sidebar-item">
                         {sidebar && sidebar.map((p, index)  => { 
                            return(
                            <> 
                            {/* <li key={p.url}><a href={p.url} target={p.target} rel={p.target?'rel=noopener noreferrer':''} title={p.title}>{p.title}</a></li> */}
                            <li key={index+'ad'} className={p.child_items ? "accordion" : '' }><a href={p.url} target={p.target} rel={p.target?'rel=noopener noreferrer':''} title={p.title}>{p.title}</a> 
                            {p.child_items ?<span className={"" + (openTab === index ? "active" : "")}  onClick={e => {e.preventDefault(); setOpenTab(openTab === index?"":index)}}></span>:''}
                            {p.child_items ? <ul className={'sub-menu ' + (openTab === index ? "showdiv" : "hidediv")}>
                                {p.child_items.map((q,ins3)=>{
                                      return(  
                                        <> 
                                     <li key={ins3}><a href={q.url} target={q.target} rel={q.target?'rel=noopener noreferrer':''} title={q.title}>{q.title}</a></li>
                                     </>
                                     )
                                     
                                })}
                            </ul>                            
                        :
                        ''}
                            </li>
                            </>
                        )
                        } 
                        )}
                         
                        </ul>


                </div>
            </div>
            {/* <div className="notification-popup" id="notification-popup">
                <a title="Close" className="close-notification" id="close-notification" href="#"><svg><use href="#close"></use></svg></a>
                <div className="notification-conent">
                    <div className="allhead"><h2>Latest News</h2></div>
                    <ul className="list">{notificationdata?notificationdata:''}</ul>
                </div>
            </div> */}
        </>
    )
}
export default Header;