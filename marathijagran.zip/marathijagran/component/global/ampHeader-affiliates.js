import React from "react";
import { DomainPrefixes } from "../utils/ejConfig";

const Header = () => {

return(

<header>	
	<div className="container">
		<div className="flexbox">
				<div className="logo"><a href='/' title="English Jagran" ></a></div>
				{/* <div className="HDtopright"><a href={DomainPrefixes.UrlPrifix} className="currentTopic">#Covid-19</a></div>  */}
		</div>
		<div className="topNav">
			<div className="scroll">
				<ul id="mainNav">
					{/* <li className="home"><a href={DomainPrefixes.UrlPrifix} title="English Jagran Home"><i></i></a></li> */}
					<li><a href='/' title="Home">Home</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals'} title="Top Deals">Top Deals</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/electronics'} title="Electronics">Electronics</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/kitchen-dining'} title="Kitchen & Dining">Kitchen & Dining</a></li>	
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/fashion'} title="Fashion">Fashion</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/health-fitness'} title="Health & Fitness">Health & Fitness</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/today-deals'} title="Today's Deals">Today's Deals</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/automotive'} title="Automotive">Automotive</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/travel'} title="Travel">Travel</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/household-items'} title="Household Items">Household Items</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/beauty-products'} title="Beauty Products">Beauty Products</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/sport-equipment'} title="Sport Equipment">Sport Equipment</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/pregnancy-and-parenting'} title="Pregnancy Parenting">Pregnancy & Parenting</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/food-and-beverages'} title="Food & Beverages">Food & Beverages</a></li>
					<li><a href={DomainPrefixes.UrlPrifix+'/top-deals/musical-instruments'} title="Musical Instruments">Musical Instruments</a></li>

				</ul>
			</div>
		</div>
	</div>
</header>

)

}
export default Header