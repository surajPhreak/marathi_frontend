import React from "react";
import { DomainPrefixes } from "../utils/ejConfig";
import Link from "next/link";
import Head from "next/head";

const Header = ({ navtrendingg }) => {
  return (
    <>
      <Head>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossOrigin="true"
      />
      <link
        href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@700&family=Poppins&display=swap"
        rel="stylesheet"
      />
      </Head>
    <header>
    
      <div className="container">
        <div className="flexbox">
          <div className="logo">
            <a href="/" title="Marathi Jagran"></a>
          </div>
          {/* <div className="HDtopright"><a href={DomainPrefixes.UrlPrifix} className="currentTopic">#Covid-19</a></div>  */}
        </div>
        <div className="topNav">
          <div className="scroll">
            <ul id="mainNav">
              {/* <li className="home"><a href={DomainPrefixes.UrlPrifix} title="Marathi Jagran Home"><i></i></a></li> */}
              <li>
                <a href="/" title="Home">
                  होम
                </a>
              </li>
              <li>
                <a
                  href={
                    "/latest-news?itm_source=amp&itm_medium=latestnews&itm_campaign=navigation"
                  }
                  title="Latest News"
                >
                  ताज्या बातम्या
                </a>
              </li>
              <li>
                <a
                  href={
                    "/maharashtra?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints"
                  }
                  title="maharashtra"
                >
                  महाराष्ट्र
                </a>
              </li>

              {/* <li><a href={'/maharashtra/mumbai//?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints'} title="mumbai">मुंबई</a></li>
					

					<li><a href={'/maharashtra/pune//?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints'} title="pune">पुणे</a></li>

					<li><a href={'/maharashtra/nagpur/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints'} title="nagpur">नागपूर</a></li>

					<li><a href={'/maharashtra/nashik/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints'} title="nashik">नाशिक</a></li> */}

              {/* <li><a href={'/tag/holi-2023/?utm_source=Homepage&amp;utm_medium=NavBar&amp;utm_campaign=holi_2023'} title="holi-2023">હોળી 2023</a></li> */}

              <li>
                <a
                  href={
                    "/entertainment/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints"
                  }
                  title="entertainment"
                >
                  मनोरंजन
                </a>
              </li>
              <li>
                <a href={"/religion/"} title="religion">
                  धर्म
                </a>
              </li>
              <li>
                <a
                  href={
                    "/business/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints"
                  }
                  title="business"
                >
                  बिझनेस
                </a>
              </li>

              {/* <li><a href={'/sports/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints'} title="sports">સ્પોર્ટ્સ</a></li> */}

              <li>
                <a
                  href={
                    "/sports/cricket/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints"
                  }
                  title="cricket"
                >
                  क्रिकेट
                </a>
              </li>

              <li>
                <a
                  href={
                    "/lifestyle/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints"
                  }
                  title="lifestyle"
                >
                  लाईफस्टाईल
                </a>
              </li>

              <li>
                <a href={"/lifestyle/health/"} title="health">
                  आरोग्य
                </a>
              </li>

              {/* <li><a href={'/lifestyle/food/'} title="food">फूड</a></li>

					<li><a href={'/lifestyle/fashion/'} title="fashion">फॅशन</a></li>

					<li><a href={'/lifestyle/tourism/'} title="tourism">पर्यटन</a></li>

					<li><a href={'/lifestyle/relation/'} title="relation">संबंध</a></li>

					<li><a href={'/lifestyle/parenting/'} title="parenting">पालकत्व</a></li> */}
              <li>
                <a
                  href={
                    "/technology?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints"
                  }
                  title="टेक्नालॉजी"
                >
                  टेक्नालॉजी
                </a>
              </li>
              <li>
                <a
                  href={
                    "https://www.marathijagran.com/web-stories/?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints"
                  }
                  title="वेब स्टोरीज"
                >
                  वेब स्टोरीज
                </a>
              </li>

              <li>
                <a
                  href={
                    "/jagran-special?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints"
                  }
                  title="जागरण विशेष"
                >
                  जागरण विशेष
                </a>
              </li>
              <li>
                <a
                  href={
                    "/opinion?utm_source=website&utm_medium=NavBar&utm_campaign=menutouchpoints"
                  }
                  title="मत"
                >
                  मत
                </a>
              </li>

              {/* <li><a href={'/web-stories/?utm_source=website&amp;utm_medium=NavBar&amp;utm_campaign=menutouchpoints'} title="parenting">વેબ સ્ટોરી</a></li> */}
            </ul>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="inTheNews">
          <h2>ट्रेंडिंग</h2>
          <div className="sub-menu" id="inTheNews">
            <ul>
              {navtrendingg &&
                navtrendingg.map((p, index) => {
                  const targetVar = p.target ? (target = p.target) : "";
                  const reltVar = p.target
                    ? (rel = "rel=noopener noreferrer")
                    : "";

                  return (
                    <>
                      <li key={index} className={p.child_items ? "active" : ""}>
                        <Link href={p.url} targetVar reltVar title={p.title}>
                          {p.title}
                        </Link>
                        {p.child_items ? (
                          <ul className="sub-menu">
                            {p.child_items.map((q, ins) => {
                              return (
                                <>
                                  <li key={ins}>
                                    <Link
                                      href={q.url}
                                      target={q.target}
                                      rel={
                                        q.target
                                          ? "rel=noopener noreferrer"
                                          : ""
                                      }
                                      title={q.title}
                                    >
                                      {q.title}
                                    </Link>
                                  </li>
                                </>
                              );
                            })}
                          </ul>
                        ) : (
                          ""
                        )}
                      </li>
                    </>
                  );
                })}
            </ul>
          </div>
        </div>
      </div>

      {/* <div className="container">
        <div className="inTheNews">
           <h2>Trending</h2>
            <div className="sub-menu" id="inTheNews">
                <ul>
                    <li> <a href="https://www.marathijagran.com/tag/karnataka-election?utm_source=header&utm_medium=trendingbar&utm_campaign=event">કર્ણાટક ચૂંટણી</a></li>
                    <li> <a href="https://www.marathijagran.com/tag/ipl-2023?utm_source=header&utm_medium=trendingbar&utm_campaign=event">આઈપીએલ 2023</a></li>
                    <li> <a href="https://www.marathijagran.com/omg/video?utm_source=header&utm_medium=trendingbar&utm_campaign=event">વાઈરલ વીડિયો</a></li>
                   
                </ul>
            </div>
        </div>
    </div> */}
      </header>
      </>
  );
};
export default Header;
