import { useRouter } from 'next/router';
const Breadcrum = (props) => {
    const {articledata, category} = props;
    const router = useRouter();
    return(
        <section className="breadcrum">
            <ul>
                <li><a href='/' title="English Jagran Home">News</a></li>
                <li><a href='/top-deals' title="Top Deals">Top Deals</a></li>
               
                    {(router.query.category)?  (<li><a href={`/top-deals/${router.query.category}`} title={router.query.category.split("-").join(" ").replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()})}>{router.query.category.split("-").join(" ").replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()})}</a> </li>): ("")}                    
                
               
                    {(router.query.subcategory)? (<li><a href={`/top-deals/${router.query.category}/${router.query.subcategory}`} title={router.query.subcategory.split("-").join(" ").replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()})}>{router.query.subcategory.split("-").join(" ").replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()})} </a></li>) : ("")}                    
            
         
                    {/* {(router.query.tittle)? (<li>Details </li>) : ("")}                     */}
           
            </ul>
        </section>
    )
}
export default Breadcrum;