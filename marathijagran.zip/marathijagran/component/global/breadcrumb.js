const Breadcrum = (props) => {
  const { articledata, category, subcategory } = props;
  return (
    <section className="breadcrum">
      <ul>
        <li>
          <a href="/" title="Marathi Jagran Home">
            News
          </a>
        </li>
       {category&& <li>
        {category}
         
        </li>}
       {subcategory&& <li>
        {subcategory}
        </li>}
    
      </ul>
    </section>
  );
};
export default Breadcrum;
