function moreNews(props) {
    const {MoreNewsData} = props;
    return(
        <div className="master-div">
            <div className="allhead"><h2>More In News</h2></div>
                <ul className="list onlytxt">
                    {
                      MoreNewsData.map( (data, index) => { return (              
                        <li className="article" key={index}>
                          <div className="summary"><a href={'/'+data.titleUrl} title={data.english_headline_t}>{data.english_headline_t}{(data.titleUrl.match('-lb'))?(<b className="liveBlink"></b>):""}</a></div>
                          <div className="timestemp text-uppercase">
                            <span className="label"><span className="red">{data.categoryName}</span></span>
                          </div>
                        </li>    
                      )                
                    })
                    }
                </ul>
        </div>
    )
}
export default moreNews;