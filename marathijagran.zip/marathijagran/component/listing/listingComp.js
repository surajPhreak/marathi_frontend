import { DomainPrefixes } from "../../component/utils/ejConfig";
import { useState } from "react";
import { PageAPI } from "../../component/utils/ejConfig";
//import Image from 'next/legacy/image'
import Image from "next/image";
import axios from "axios";

function ListingNews(props){
    const{ListingData, category,head} = props;

    const PreRenderd = ListingData.posts
  
    const [posts, setPosts] = useState(PreRenderd); 
    const [isLoading, setIsLoading] = useState(false);
    const [post, setPost] = useState(2)
    const getMorePost = async () => {   
        
        const res = await axios('/api/ajaxCalls', { params: { url: `${PageAPI.HomeCategory_API}${category}/${post}/10` } });

        const newPosts = await res.data;
        const dataPost = newPosts.posts;
        setIsLoading(false);
        // console.log(post)
        if(dataPost)
         setTimeout(() => { 
              setPosts((post) => [...post, ...dataPost]); 
              setIsLoading(false);
              setPost(post + 1);
          }, 10);     
      };


    // var pageNumberRevised  = (pageNum == null && pageNum == undefined && isNaN(pageNum) ) ? '1' : Math.abs(pageNum) ;
   // let nuberOfpaginationPerPage = pageNumbers;
    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    return posts ? (
        <>
        <div className="allhead listing-dyhead"><h1>{head} बातम्या</h1></div>
        <ul className="main-story">
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index < 1){ 
                        const ImpPath = data.imagePath.split(',');
                        const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                        return(
                            <li className="article secart" key={index + 'd6w'}>
                                <div className="h3">
                                    <h2>
                                    <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                    <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        {/* {(data.webTitleUrl.match('-lb'))?(<b className="liveBlink"></b>):""} */}
                                    </div>
                                    </h2>
                                    <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                </div>                            
                            </li>
                        ) }
                      } 
                      )
                  }
                   <li className="article secart"><div id="videoplayer"></div></li>
                  <li className="article secart emobile"><div className="ads top-300x250"><div id="target-2"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 0 && index < 3){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }           
                  <li className="article secart emobile"><div className="ads medium-300x250"><div id="target-3"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 2 && index < 6){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }
                  <li className="article secart emobile"><div className="ads bottom-300x250"><div id="target-11"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 5 && index < 8){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }

                  <li className="article secart emobile"><div className="ads bottom-300x250"><div id="target-4"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 7){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }
                  
           
            </ul>
{   ListingData.sitemeta && ListingData.sitemeta.count > posts.length &&     <div className="load-more"><button id="pagination-btn" className="btn btn-primary" onClick={getMorePost}>Load More</button></div>
}        {/* <div className="pagination border0">
            <div className="floatright">
                <ul>
                    {
                        ( pageNumberRevised==1 )?'':
                        (<li className="first"><a href={'/'+category+'-page'+ (pageNumberRevised-1)} title="Pagination First"></a></li>)
                    }
                    {
                        pageNumbers.map( (data, index) => {
                            return(
                                (pageNumberRevised == pageNumberRevised+index)?(<li key={index}><strong>{pageNumberRevised+index}</strong></li>):
                                (pageNumbers.length>=pageNumberRevised+index?<li key={index}><a href={'/'+category+'-page'+ (pageNumberRevised+index)} title="Pagination">{pageNumberRevised+index}</a></li>:'')
                            )                            
                        } )

                     
                        
                    }
                    {
                    ( pageNumbers.length<=pageNumberRevised+1 )?'':
                     <li className="last"><a href={'/'+category+'-page'+ (pageNumberRevised+1)} title="Pagination Last"></a></li>}
                    
                </ul>
            </div>
        </div>   */}
        
        </>
    ):""
}
export default ListingNews;