import { DomainPrefixes } from "../../component/utils/ejConfig";
//import Image from "next/image";
import { PageAPI } from "../../component/utils/ejConfig";
import { useState } from "react";
import Image from "next/image";
import axios from "axios";

function ListingNews(props){
    const{ListingData, category} = props;
    // var pageNumberRevised  = (pageNum == null && pageNum == undefined && isNaN(pageNum) ) ? '1' : Math.abs(pageNum) ;

    const PreRenderd = ListingData.posts
  
    const [posts, setPosts] = useState(PreRenderd); 
    const [isLoading, setIsLoading] = useState(false);
    const [post, setPost] = useState(2)
    const getMorePost = async () => {   
        const res = await axios('/api/ajaxCalls', { params: { url: `${PageAPI.Latestarticles_API}${post}/10` } });

            const newPosts = await res.data
        const dataPost = newPosts.posts;
  
        setIsLoading(false);
        // console.log(post)
         setTimeout(() => { 
              setPosts((post) => [...post, ...dataPost]); 
              setIsLoading(false);
              setPost(post + 1);
          }, 10);     
      };


   
   
    function removeLastId(str) {
        const reLast = /-\d+$/;
      
        //console.log(str.replace(reLast, ""));
        //console.log(str.replace(reLast, ""));
        return str.replace(reLast, "");
      }
    return(
        <>
        <div className="allhead listing-dyhead"><h1>ताज्या बातम्या</h1></div>
        <ul className="main-story">
                  {
                    posts.map( 
                      (data, index) => { 
                            if (index <= 1) { 
                        const ImpPath = data.imagePath.split(',');
                        const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                        return(
                            <li className="article secart" key={index}>
                                <div className="h3">
                                    <h2>
                                    <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                    <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                    </div>
                                    </h2>
                                    <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                </div>                            
                            </li>
                        ) }
                      } 
                      )
                  }
                  <li className="article secart"><div id="videoplayer"></div></li>
                  <li className="article secart emobile"><div className="ads top-300x250"><div id="target-2"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 1 && index <= 3){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }           
                  <li className="article secart emobile"><div className="ads medium-300x250"><div id="target-3"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 3 && index <= 5){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                        <span className="label"><span className="red">{data.category}</span></span>
                                        {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+subcatUrl+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }
                  <li className="article secart emobile"><div className="ads bottom-300x250"><div id="target-11"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 5 && index <= 7){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }

                  <li className="article secart emobile"><div className="ads bottom-300x250"><div id="target-4"></div></div></li>
                  {
                    posts.map( 
                      (data, index) => { 
                        if(index > 7){ 
                            const ImpPath = data.imagePath.split(',');
                            const subcatUrl = data.subcategoryUrl? (data.subcategoryUrl.toLowerCase()+'/'):'';
                            return(
                                <li className="article secart" key={index}>
                                    <div className="h3">
                                        <h2>
                                        <a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}>{data.headline}</a>
                                        <div className="timestemp text-uppercase">
                                            <span className="label"><span className="red">{data.category}</span></span>
                                            {(data.isLiveBlog)?(<b className="liveBlink"></b>):""}
                                        </div>
                                        </h2>
                                        <figure><a title={data.headline} href={'/'+data.categoryUrl.toLowerCase()+'/'+removeLastId(data.webTitleUrl)+'-'+data.id}><Image width={200} height={115} style={{maxWidth: '100%', height: 'auto', }} src={DomainPrefixes.ImagePath+ImpPath[0]} alt={data.headline} /></a></figure>
                                    </div>                            
                                </li>
                        ) }
                      } 
                      )
                  }
                  
           
        </ul>
{  ListingData && ListingData.count > posts.length &&       <div className="load-more"><button id="pagination-btn" className="btn btn-primary" onClick={getMorePost}>Load More</button></div>
}     
<div className="eweb ads interstitial-1x1"><div id="target-10"></div></div>
        {/* <div className="pagination border0">
            <div className="floatright">
                <ul>
                    {
                        ( pageNumberRevised==1 )?'':
                        (<li className="first"><a href={'/'+category+'-page'+ (pageNumberRevised-1)} title="Pagination First"></a></li>)
                    }
                    {
                        pageNumbers.map( (data, index) => {
                            return(
                                (pageNumberRevised == pageNumberRevised+index)?(<li key={index}><strong>{pageNumberRevised+index}</strong></li>):
                                (pageNumbers.length>=pageNumberRevised+index?<li key={index}><a href={'/'+category+'-page'+ (pageNumberRevised+index)} title="Pagination">{pageNumberRevised+index}</a></li>:'')
                            )                            
                        } )
                        
                    }
                    {
                    ( pageNumbers.length<=pageNumberRevised+1 )?'':
                     <li className="last"><a href={'/'+category+'-page'+ (pageNumberRevised+1)} title="Pagination Last"></a></li>
                    }
                </ul>
            </div>
        </div>   */}
        
        </>
    )
}
export default ListingNews;