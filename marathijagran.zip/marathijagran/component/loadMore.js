const LoadMore = (props) => {
    return  <div className="loadMore"><a id="pagination-btn" className="btn loadMore-btn" >Load More</a></div>

}

export default LoadMore