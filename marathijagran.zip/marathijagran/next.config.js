/* @type {import('next').NextConfig} */

const nextConfig = {
  env: {
    BEARER_TOKEN:'',
    BEARER_STRING: "Bearer ",
    API_TOKEN: 'Bearer 4f02b430f89b2796a222d9f7bfeb3c0d',
    API_URL: "https://stg-web-push-notification.jagran.com/",
    API_TOKEN1:'5088e7346b40a1c0c0dc6e8bfa88c1d4'
  
  },
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "img.marathijagran.com",
        port: "",
        pathname: "/**",
      },
    ],
  },
  //reactStrictMode: true,

  async rewrites() {
    return [
      {source:'/feed/izooto/:category', destination:'/izootofeeds'},
      {source:'/feed/izooto/:category/:subcat', destination:'/izootofeeds'},

      {source:'/feed/jio/:category', destination:'/jiofeeds'},
      {source:'/feed/jio/:category/:subcat', destination:'/jiofeeds'},

      {source:'/feed/dh/:category', destination:'/dhfeeds'},
      {source:'/feed/dh/:category/:subcat', destination:'/dhfeeds'},

      {source:'/feed/msn/:category', destination:'/msnfeeds'},
      {source:'/feed/msn/:category/:subcat', destination:'/msnfeeds'},

      {source:'/feed/googlenewsstandrss/:category', destination:'/googlenewsstandrssfeeds'},
      {source:'/feed/googlenewsstandrss/:category/:subcat', destination:'/googlenewsstandrssfeeds'},
      //  {source:'/lite/:category/:tittle-lb-:id([a-zA-Z0-9]+)', destination:'/amp-pages/ampLive-blog'},
      //  {source:'/lite/entertainment/:subcategory/:tittle-lb-:id([a-zA-Z0-9]+)', destination:'/amp-pages/ampLive-blog?category=entertainment&subcategory=:subcategory'},
      //  {source:'/lite/elections/:subcategory/:tittle-lb-:id([a-zA-Z0-9]+)', destination:'/amp-pages/ampLive-blog?category=elections&subcategory=:subcategory'},
      //  {source:'/lite/business/:subcategory/:tittle-lb-:id([a-zA-Z0-9]+)', destination:'/amp-pages/ampLive-blog?category=business&subcategory=:subcategory'},
      //  {source:'/lite/photos/:category/:tittle-:id([a-zA-Z0-9]+)', destination:'/amp-pages/ampPhotoDetails'},
      //  {source:'/lite/top-deals/:category/:subcategory/:tittle-:id([a-zA-Z0-9]+)', destination:'/detail/ampArticle-detail-affiliatesPage'},

      //  {source:'/lite/:category/:subcategory/:tittle-:id([a-zA-Z0-9]+)', destination:'/detail/ampArticle-detailPage'},
      //  {source:'/lite/:category/:id([a-zA-Z0-9]+)', destination:'/detail/ampArticle-detailPage'},
      //  {source:'/top-deals/:category', destination:'/topDeals/subList'},
      //  {source:'/top-deals/:category/:subcategory', destination:'/topDeals/subCatArticleList'},
      //  {source:'/top-deals/:category/:subcategory/page:pageNum', destination:'/topDeals/subCatArticleList'},
      //  {source:'/top-deals/:category/:subcategory/:tittle-:id([a-zA-Z0-9]+)', destination:'/topDeals/details'},
      //  {source:'/top-deals', destination:'/topDeals/home'},
      //  {source:'/share-market', destination:'/business/share-market'},

      {
        source: "/:category/:subcategory/:tittle-:id([a-zA-Z0-9]+)/amp",
        destination: "/detail/ampArticle-detailPage",
      },
      {
        source: "/:category/:tittle-:id([a-zA-Z0-9]+)/amp",
        destination: "/detail/ampArticle-detailPage",
      },

      //  {source:'/photos', destination:'/listing/photolisting'},
      //  {source:'/photos-page:pageNum', destination:'/listing/photolisting'},
      //  {source:'/specials', destination:'/listing/specials'},
      //  {source:'/specials/page:pageNum', destination:'/listing/specials'},

      { source: "/about-us", destination: "/static/about-us" },
      { source: "/contact-us", destination: "/static/contact-us" },
      {
        source: "/actionable-feedback",
        destination: "/static/actionable-feedback",
      },
      { source: "/disclaimer", destination: "/static/disclaimer" },
      {
        source: "/this-website-follows-the-dnpas-code-of-conduct",
        destination: "/static/this-website-follows-the-dnpas-code-of-conduct",
      },
      { source: "/privacy-policy", destination: "/static/privacy-policy" },
      { source: "/advertise-withus", destination: "/static/advertise-with-us" },
      { source: "/sitemap", destination: "/static/sitemap" },
      { source: "/privacy-policy", destination: "/static/privacy-policy" },
      { source: "/cookie-policy", destination: "/static/cookie-policy" },
      { source: "/terms-conditions", destination: "/static/terms-conditions" },
      {
        source: "/dnpa-code-of-ethics-for-digital-news-websites",
        destination: "/static/dnpas-code",
      },
      {
        source: "/elections/mera-power-vote",
        destination: "/events/mera-power-vote",
      }, 
      {
        source: "/elections/mera-power-vote/first-time-voters-india.html",
        destination: "/events/mera-power-vote/student",
      },
      {
        source: "/elections/mera-power-vote/farmers-voters-india.html",
        destination: "/events/mera-power-vote/farmer",
      },
      {
        source: "/elections/mera-power-vote/general-voters-india.html",
        destination: "/events/mera-power-vote/urban",
      },
      {
        source: "/elections/mera-power-vote/women-voters-india.html",
        destination: "/events/mera-power-vote/women",
      },
      // {
      //   source: "/pfp.html",
      //   destination: "/events/videos/video-detail-test",
      // },
      {source: "/elections/lok-sabha/schedule.html", destination: "/events/elections/lokshabha/ElectionSchedule", },
      {source: "/elections/election-information", destination: "/events/elections/lokshabha/ElectionInformation" },
      // {source: "/elections/lok-sabha/public-opinion-for-lok-sabha-election-manifesto-ghosna-patra",
      //   destination: "/events/elections/lokshabha/ElectionAnnouncement" },
      {source: "/elections/parties.html", destination: "/events/elections/lokshabha/ElectionParty" },
      {source:'/elections/lok-sabha.html', destination:'/events/elections/lokshabha/PreLanding' },
      {source: "/elections/lok-sabha/maharashtra.html", destination: "/events/elections/lokshabha/ElectionState?statename=maharashtra"},
      
      {source: "/elections/lok-sabha/constituency/:constituencyname([a-zA-Z0-9-]+).html", destination: "/events/elections/lokshabha/ElectionConsituency"},
      // {source: "/election/lok-sabha/:statename([a-zA-Z0-9-]+).html", destination: "/events/elections/lokshabha/ElectionState"},  
      {source: '/elections/:partyname/party.html', destination: '/events/elections/lokshabha/PartyDetail' }, 
     
      { source: "/search/:topicname", destination: "/search/search" },
      {
        source: "/search/:topicname/page:pageNum",
        destination: "/search/search",
      },

      { source: "/latest-news", destination: "/listing/TopNews" },
      { source: "/latest-news-page:pageNum", destination: "/listing/TopNews" },

      //  {source:'/about-us', destination:'/static/about-us'},
      //  {source:'/advertise-withus', destination:'/static/advertise-with-us'},
      //  {source:'/sitemap', destination:'/static/sitemap'},
      //  {source:'/privacy-policy', destination:'/static/privacy-policy'},
      //  {source:'/cookie-policy', destination:'/static/cookie-policy'},
      //  {source:'/terms-conditions', destination:'/static/terms-conditions'},
      //  {source:'/dnpa-code-of-ethics-for-digital-news-websites', destination:'/static/dnpas-code'},

      { source: "/tag/:topicname", destination: "/listing/tag-page" },
      {
        source: "/tag/:topicname-page:pageNum",
        destination: "/listing/tag-page",
      },

      { source: "/authors", destination: "/authors/authors" },
      {
        source: "/authors/:authorName",
        destination: "/authors/authors-listing",
      },
      {
        source: "/authors/:authorName-page:pageNum",
        destination: "/authors/authors-listing",
      },

      {
        source: "/:category/:subcategory/:tittle-:id([a-zA-Z0-9]+)",
        destination: "/detail/DetailPage",
      },
      {
        source: "/:category([a-zA-Z-]+)/:subcategory([a-zA-Z-]+)",
        destination: "/listing/SubCatListingPage",
      },
      {
        source: "/:category/:tittle-:id([a-zA-Z0-9]+)",
        destination: "/detail/DetailPage",
      },
  
      {
        source: "/:category/:subcategory/page:pageNum",
        destination: "/listing/SubCatListingPage",
      },

      { source: "/:category", destination: "/listing/listing" },
      { source: "/:category-page:pageNum", destination: "/listing/listing" },
    ];
  },
};
module.exports = nextConfig;
