const path = require("path");
const webpack = require('webpack');

module.exports = {
  mode: "production",
  entry: "./sw.js",
  output: {
    path: path.resolve(__dirname, "public", "js"),
    filename: "sw.bundles.js",
  },
  plugins: [
    new webpack.DefinePlugin({
     // "process.env.API_URL": JSON.stringify("https://stg-web-push-notification.jagran.com/"),
     // "process.env.API_URL": JSON.stringify("https://web-push-notification-api.jagran.com/"),
      "process.env.API_URL": JSON.stringify("https://web-push-notification-api.jagran.com/"),
      "process.env.API_TOKEN": JSON.stringify("Bearer 5088e7346b40a1c0c0dc6e8bfa88c1d4"),
    }),
  ],
};
