import React from "react";
import { PageAPI } from "../component/utils/ejConfig";
import axios from "axios";

const sitemap = () => {
  return null;
};

export const getServerSideProps = async ({ res,query }) => {
  const BASE_URL = "http://localhost:3000";
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  function formatDateToCustomTimeZone(date, offset='+0530') {
    const utcDate = new Date(date.getTime() + (date.getTimezoneOffset() * 60000));
    const offsetHours = parseInt(offset.slice(0, 3), 10);
    const offsetMinutes = parseInt(offset.slice(3), 10);
    const offsetMilliseconds = (offsetHours * 60 + offsetMinutes) * 60 * 1000;
    const customTimeZoneDate = new Date(utcDate.getTime() + offsetMilliseconds);
    const formattedDate = customTimeZoneDate.toUTCString().replace('GMT', offset);
    return formattedDate;
  }
  

  const currentDate = new Date();
  const formattedDate = formatDateToCustomTimeZone(currentDate, '+0530');
  
  if(query.subcat){
    if(query.category == "tag"){
      var apiUrl = PageAPI.feed_TagwordBase_API+"/"+query.subcat+"/1/10";
    }else{
      var apiUrl = PageAPI.feed_SubcategoryListing_API+query.category+"/"+query.subcat+"/1/10";
    }
}else{
  if(query.category == "latest-news"){
    var apiUrl = PageAPI.feed_LatestPosts_API+"1/10";
  }else{
    var apiUrl = PageAPI.feed_Category_API+query.category+"/1/10";
  }

}



const postData = await axios.get(apiUrl, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );
// console.log(postData);
const sitemap = `<rss xmlns:dc="https://purl.org/dc/elements/1.1/" xmlns:media="https://search.yahoo.com/mrss/" xmlns:mi="https://schemas.ingestion.microsoft.com/common/" version="2.0">
<channel>
<title>Marathi News, Breaking News in Marathi, Latest News in Marathi - Marathi Jagran News</title>
<description>Marathi Jagran Marathi News: , Breaking News in Marathi, Top News Headlines, Marathi Latest News , Today Top News, Marathi News Today on Marathi Jagran.</description>
<language>HI</language>
<link>https://www.marathijagran.com</link>
${postData.posts.map(post => `<item>
<link>https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</link>
<title><![CDATA[ ${post.headline} ]]></title>
<pubDate>${formatDateToCustomTimeZone(new Date(post.pubDate))}</pubDate>
<guid isPermaLink="false">https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</guid>
<description><![CDATA[ ${post.summary} ]]></description>
<dc:publisher>Marathi Jagran</dc:publisher>
<dc:modified>${formatDateToCustomTimeZone(new Date(post.pubDate))}</dc:modified>
<dc:creator>${post.author}</dc:creator>
<mi:expirationDate/>
<mi:shortTitle/>
<mi:dateTimeWritten/>
<mi:deepLink>https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</mi:deepLink>
<media:keywords>Breaking News in Marathi, Top News Headlines, Marathi Latest News , Today Top News, Marathi News Today on Marathi Jagran</media:keywords>
</item>
`).join('')}
</channel>
</rss>
`;


  res.setHeader("Content-Type", "text/xml");
  res.write(sitemap);
  res.end();

  return {
    props: {},
  };
};

export default sitemap;