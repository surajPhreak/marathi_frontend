import axios from "axios";
import Head from "next/head";
import Image from "next/image";
import HeadInjection from "../../component/seo/ListingHeadComp";
import SeoCommonScript from "../../component/seo/seoCommonScript";
import Layout from "../../component/layout/layout";
import { PageAPI } from "../../component/utils/ejConfig";
import TopNewsCom from "../../component/home/topNewsComp";
import CategoryBasedNews from "../../component/home/categoryBaseLong";
import SearchListingNews from "../../component/search/searchComp";
import DefineSlotListing from "../../component/ads/defineSlotListing";
//import TaboolaAdsListing from "../../component/ads/taboolaAd-listing";
import { useEffect } from "react";
import LazyLoad from "react-lazy-load";
import Custom404 from "../404";

export default function Home(props) {

  const {StateDate, JagranSpecialData1, ListingData1, topicname, pageNumberRevised,headerdata, footerdata, navtrending,sidebar} = props;

  const topNewsAdata1 = StateDate.posts;  
  const JagranSpecialData = JagranSpecialData1.posts;
  
  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'search listing page ','tvc_listing_page_type':'article listing','tvc_page_cat':'${topicname}','language':'gujarati'})
   `);

  const splitJoin = topicname.split('-');
  var  MetaWord =[];
  splitJoin.map( (data, index) => {
    return( MetaWord.push(data.charAt(0).toUpperCase() + data.slice(1)) )
  })
  MetaWord = MetaWord.join(' ');

  useEffect (() => {
    var widthWindow = window.innerWidth;
    if(widthWindow >= 1024){
      scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
    }

    var scroll=0;
    function showAds(showid, i){
        var para = document.createElement("script");
        var divbx = document.createElement("div");
        divbx.id=showid;
        var a = "googletag.cmd.push(function() { googletag.display('"+divbx.id+"'); });";
        var t = document.createTextNode(a);   
        para.appendChild(t);
        divbx.appendChild(para);
        document.getElementById("target-"+i).appendChild(divbx);
    }
    function scriptG(url,asyncTT){
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = url;
      script.asyncT = "async";
      script.id = asyncTT;
      document.body.appendChild(script);
    }
    
    window.addEventListener("scroll", function(){
        if(scroll==0){

          /*Taboola*/
          window._taboola = window._taboola || [];
          _taboola.push({category:'auto'});
          !function (e, f, u, i) {
            if (!document.getElementById(i)){
              e.async = 1;
              e.src = u;
              e.id = i;
              f.parentNode.insertBefore(e, f);
            }
          }(document.createElement('script'),
          document.getElementsByTagName('script')[0],
          '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
          'tb_loader_script');
          if(window.performance && typeof window.performance.mark == 'function')
       { window.performance.mark('tbl_ic'); }
       window._taboola = window._taboola || [];
       _taboola.push({
         mode: 'thumbnails-a',
         container: 'taboola-below-category-thumbnails',
         placement: 'Below Category Thumbnails',
         target_type: 'mix'
       });
       window._taboola = window._taboola || [];
       _taboola.push({flush: true});
          /*Taboola*/
          // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);

          if(widthWindow >= 1024){
            // if(document.getElementById('target-1')){ showAds('al_medium_300x250', 1)}
            // if(document.getElementById('target-10')){ showAds('al_interstitial_1x1', 10)}
          }else{
            scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true)  
            // if(document.getElementById('target-2')){ showAds('al_medium_300x250_m', 2)}
            if(document.getElementById('target-2')){ showAds('al_top_300x250_m', 2)} 
            // if(document.getElementById('target-3')){ showAds('al_medium_300x250_m', 3)}
            // if(document.getElementById('target-4')){ showAds('al_bottom_300x250_m', 4)}
            // if (document.getElementById('target-11')) { showAds('al_interstitial_1x1_m', 11) }
            // if (document.getElementById("target-9")) { showAds("al_video_interstitial_1x1_m", 9); }
            // if (document.getElementById("target-51")) { showAds("al_sticky_320x50_m", 51); }
            // if (document.getElementById("target-11")) {showAds("al_interstitial_1x1_m", 11);}

          }
          scroll=1;    
        }
    });    
}, []);
  return ListingData1? (
    <>
      <Layout headerdata={headerdata}  sidebar={sidebar} footerdata={footerdata} navtrending={navtrending} Title={MetaWord + ' News: Latest News on ' + MetaWord + ', Photos, Videos & Updates on ' + MetaWord} 
      Keywords={MetaWord +' News, ' + MetaWord + ' Latest News, ' + MetaWord + ' Updates, ' + MetaWord + ' Breaking News, ' + MetaWord + ' Videos'}
      Description={MetaWord + ' News: Read all the Latest News on ' + MetaWord + ', Photos, Videos online only on enMetaWordglish.jagran.com. Stay updated with breaking news and exclusive live coverage of ' + MetaWord + ' only at marathijagran.com'} fixUrlCanonical={topicname}>
        <Head>
          <HeadInjection categoryy={topicname} />
          <SeoCommonScript />
        </Head>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>
        <DefineSlotListing categoryNameURL={'serach'} metaKeywords={MetaWord +' News, ' + MetaWord + ' Latest News, ' + MetaWord + ' Updates, ' + MetaWord + ' Breaking News, ' + MetaWord + ' Videos'} />
        <div className="main-content">
          <div className="left-col">
            <div className="ls-area-body">
                {topNewsAdata1 && <LazyLoad><CategoryBasedNews categoryData={topNewsAdata1} compHeadTxt={"महाराष्ट्र"} /></LazyLoad>}
            </div>
          </div>
          <div className="main-col">
              <div className="ls-area-body">
              {ListingData1 && <LazyLoad><SearchListingNews ListingData={ListingData1} totalCount={ListingData1.count} pageNumberRevised={pageNumberRevised} topicname={topicname} /></LazyLoad>}
              </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">              
                  <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div></div></div>
                  {JagranSpecialData && <LazyLoad><CategoryBasedNews categoryData={JagranSpecialData} compHeadTxt={"जागरण विशेष"} /></LazyLoad>}
                  <div className="eweb"><div className="ads medium-300x250"><div id="target-1"></div></div></div>         
            </div>
          </div>
        </div>
        <div id="hjdg"><div className="ads al_video_interstitial"><div id='target-9'></div></div></div>

        <div className="taboolaads">
          <div id="taboola-below-category-thumbnails"></div>
          {/* <TaboolaAdsListing /> */}
        </div>
      </Layout>
    </>
  
  ) : (
      <Layout headerdata={headerdata} footerdata={footerdata} navtrending={navtrending}>
          <div className="errorSearch">
          <Image width={441} height={200} src="https://img.marathijagran.com/2023/07/404.png" alt="error page" title="Page Not Found" />
        <p>आप जिस पेज़ को देखना चाहते है वो उपलब्ध नहीं है,<br /> कृपया <a href="https://marathijagran.com/"><strong>क्लिक करके, होम पेज</strong></a> पर वापस जाइए!</p>

      </div>
      </Layout>
    
  );
}
export const getServerSideProps = async (context) => {

 const {query} = context;
  const {topicname, pageNum} = query;
  const search = decodeURI(topicname)

  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
 
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  
  const StateDate = await axios.get(CategoryDataa ('maharashtra', 8),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  const JagranSpecialData1 = await axios.get(CategoryDataa ('jagran-special', 4),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  const HomePoneData = await axios.get(PageAPI.HomePone_API,payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  var pageNumber  = (pageNum && pageNum != null && pageNum != undefined && !isNaN(pageNum) ) ? Math.abs(pageNum-1) :'1' ;
  var pageNumberRevised  = (pageNum == null && pageNum == undefined && isNaN(pageNum) ) ? 1 : Math.abs(pageNum) ;

  const ListingPath_API = PageAPI.KeywordBase_API + search + '/' + pageNumber + '/' + 10;
  const ListingData1 = await axios.get(ListingPath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  return { props: {StateDate, JagranSpecialData1, HomePoneData, ListingData1, topicname:search, pageNumberRevised } }
};