//const postcss = require('postcss')
import {DomainPrefixes, PageAPI} from '../../component/utils/ejConfig';
import axios from 'axios';
import Head from 'next/head';
import Meta from '../../component/seo/ampMeta';
import Layout from '../../component/layout/ampLayout';
import Breadcrum from "../../component/global/ampBreadcrumb.js";
import ArticleBody from '../../component/detail/ampArticleDetailComp';
import RelatedReads from '../../component/detail/ampRelatedReadsComp';
import { useRouter } from 'next/router';
import GoogleAnalytics from '../../component/seo/ampGoogleAnalytics';
export const config = { amp: true };

export default function ArticlePage(props){
  const routerUrl = useRouter().asPath;  
  const routerUrlRefine = routerUrl.replace('lite/', '');
  //var newfull = routerUrlRefine.replace(/\?.*$/g,"");
  const { ARTICLE_DETAIL_DATA, ARTICLE_RELATED_APIDATA, ARTICLE_ALSOREAD_APIDATA } = props;
  const subcatt = ARTICLE_DETAIL_DATA.subcategory?ARTICLE_DETAIL_DATA.subcategory.toLowerCase()+'/':'';
  const carvar = ARTICLE_DETAIL_DATA.category.toLowerCase().split(' ').join('-'); 
  return(
    <Layout>
      <Head>
        {ARTICLE_DETAIL_DATA && <Meta articledetaildata={ARTICLE_DETAIL_DATA} urlRoughter={routerUrlRefine} />}
        <link rel="canonical" href={'https://www.marathijagran.com' +'/' + carvar + "/" + subcatt+ ARTICLE_DETAIL_DATA.webTitleUrl.toLowerCase()+'-'+ARTICLE_DETAIL_DATA.id} />
      </Head>
      {ARTICLE_DETAIL_DATA && <GoogleAnalytics articledetaildata={ARTICLE_DETAIL_DATA} />}
      {ARTICLE_DETAIL_DATA && <Breadcrum articledetaildata={ARTICLE_DETAIL_DATA} urlRoughter={routerUrlRefine} />}
      {ARTICLE_DETAIL_DATA && <ArticleBody articledetaildata={ARTICLE_DETAIL_DATA} urlRoughter={routerUrlRefine} articleasloread={ARTICLE_ALSOREAD_APIDATA} />}
      {ARTICLE_RELATED_APIDATA && <RelatedReads relatedreadsdata={ARTICLE_RELATED_APIDATA} />}
      
    </Layout>
  )
}
export const getServerSideProps = async (context) => {
  const {query} = context;
  const {category, id } = query;
  var token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqYWdyYW5uZXdtZWRpYSIsImlhdCI6MTY2MTIzNjg2Mn0.cngV-wseScZG2S7VQH7DPj7i1LPnA1sxpqGzH2kUAolSJ4hEYeAIlifH8dvoqoQ5P_x-5HhL3-wGTjJauhmwyg";
  const payload = {  headers: { Authorization: `Bearer ${token}` }  };
  //console.log(payload);
  let ARTICLE_DETAIL_API = PageAPI.Article_API + id;
  let ARTICLE_RELATED_APIINFO = PageAPI.ARTICLE_RELATED_API + id + "/" + category.toLowerCase() + '/' + 1 + '/' + 3;
  let ARTICLE_ALSOREAD = PageAPI.ARTICLE_ALSOREAD_API + id + "/" + category.toLowerCase() + '/' + 0 + '/' + 2;
  const ARTICLE_DETAIL_DATA = await axios.get(ARTICLE_DETAIL_API, payload).then((resp) => { return resp.data }).catch(() => { return null });
  //console.log(ARTICLE_DETAIL_DATA);
  const ARTICLE_RELATED_APIDATA = await axios.get(ARTICLE_RELATED_APIINFO, payload).then( (resp) => {return resp.data} ).catch( () => {return null} );
  const ARTICLE_ALSOREAD_APIDATA = await axios.get(ARTICLE_ALSOREAD, payload).then( (resp) => {return resp.data} ).catch( () => {return null} );
  return { props: { ARTICLE_DETAIL_DATA, ARTICLE_RELATED_APIDATA, ARTICLE_ALSOREAD_APIDATA } }
}
//module.exports.postcss = true