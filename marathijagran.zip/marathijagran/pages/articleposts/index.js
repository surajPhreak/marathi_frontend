import Head from "next/head";
import Link from "next/link";
import { useEffect } from "react";
import axios from "axios";
function Posts({ posts }) {
  const adId = `listing_top_300x250_${Date.now()}`;
  const initGPT = () => {
    // Load GPT library asynchronously
    const script = document.createElement("script");
    script.async = true;
    script.src = "https://www.googletagservices.com/tag/js/gpt.js";
    document.body.appendChild(script);

    script.onload = () => {
      // Initialize GPT library
      googletag.cmd.push(function () {
        googletag.pubads().enableSingleRequest();
        googletag.enableServices();

        // Define ad slot
        googletag
          .defineSlot(
            "/13276288/jagran/desktop/Prime/Listing/Top_300x250",
            [
              [300, 250],
              [300, 200],
              [250, 250],
            ],
            adId
          )
          .addService(googletag.pubads());

        // Display ad
        googletag.display(adId);
      });
    };
  };

  useEffect(() => {
    if (typeof window.googletag === "undefined") {
      // GPT library not loaded yet, load it
      console.log("GPT library not loaded yet, load it.");

      initGPT();
    } else {
      // GPT library already loaded, initialize it
      console.log("GPT library already loaded, initialize it.");
      initGPT();
    }
  }, []);

  useEffect(() => {
    // Re-initialize GPT library and display ad when component is re-rendered after navigation

    console.log("Re-initialize GPT library");
    initGPT();
  });

  return (
    <div>
      <Head>
        <title>Posts/post</title>
      </Head>

      <h1>Posts</h1>
      <div
        id={adId}
        data-ad-unit="/13276288/jagran/desktop/Prime/Listing/Top_300x250"></div>
      <ul>
        {posts.map((post) => (
          <li key={post.id}>
            <Link href={`/posts/${post.slug}`}>{post.title.rendered}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export async function getServerSideProps() {
  const { data: posts } = await axios.get(
    "https://www.marathijagran.com/wp-json/wp/v2/posts?per_page=10"
  );

  return { props: { posts } };
}

export default Posts;
