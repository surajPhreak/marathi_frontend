import Head from "next/head";
import axios from "axios";
import { useEffect } from "react";
import Link from "next/link";

function PostDetail({ post }) {
  //console.log(post);

  const adId = `listing_medium_300x250_${post.id}_${Date.now()}`;
  const initGPT = () => {
    // Load GPT library asynchronously
    const script = document.createElement("script");
    script.async = true;
    script.src = "https://www.googletagservices.com/tag/js/gpt.js";
    document.body.appendChild(script);

    script.onload = () => {
      // Initialize GPT library
      googletag.cmd.push(function () {
        googletag.pubads().enableSingleRequest();
        googletag.enableServices();

        // Define ad slot

        googletag
          .defineSlot(
            "/13276288/jagran/desktop/Prime/Listing/Medium_300x250",
            [
              [300, 250],
              [300, 200],
              [250, 250],
            ],
            adId
          )
          .addService(googletag.pubads());
        // Display ad
        googletag.display(adId);
      });
    };
  };

  useEffect(() => {
    if (typeof window.googletag === "undefined") {
      // GPT library not loaded yet, load it
      initGPT();
    } else {
      // GPT library already loaded, initialize it
      initGPT();
    }
  }, []);

  useEffect(() => {
    // Re-initialize GPT library and display ad when component is re-rendered after navigation
    initGPT();
  });

  return (
    <div>
      <Head>
        <title>{post.id}</title>
      </Head>
      <Link href={`/posts`}>Back</Link>
      <div
        id={adId}
        data-ad-unit="/13276288/jagran/desktop/Prime/Listing/Medium_300x250"></div>
      <h1>{post.title.rendered}</h1>

      <div dangerouslySetInnerHTML={{ __html: post.content.rendered }} />
    </div>
  );
}

export async function getServerSideProps(context) {
  const { data: post } = await axios.get(
    `https://www.marathijagran.com/wp-json/wp/v2/posts?slug=${context.params.slug}`
  );

  return { props: { post: post[0] } };
}

export default PostDetail;
