import axios from "axios";
import Layout from "../../../../component/layout/layout";
import { PageAPI } from "../../../../component/utils/ejConfig";
import Head from "next/head";
import HeadInjection from "../../../../component/seo/HomeHeadComp";
import dynamic from "next/dynamic";

//import TopDeals from "../component/events/top-deals/topDealsHome";
import DefineSlotHome from "../../../../component/ads/defineSlotHome";
//import TaboolaAdsHome from "../component/ads/taboolaAd-home";
const CategoryBasedNews = dynamic(() =>
  import("../../../../component/home/categoryBaseLong")
);

import SeoCommonScript from "../../../../component/seo/seoCommonScript";
import { useEffect } from "react";
import { useRouter } from "next/router";
//import React from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../../../component/seo/SeoCommonSchema";

import ElectionInfo from '../../../../component/events/elections/lokshabha/ElectionInformation/ElectionInfo';
import ResultGraph from '../../../../component/events/elections/lokshabha/common/ResultGraph';
import ElectionnewsComp from "../../../../component/events/elections/lokshabha/PreLanding/ElectionnewsComp";
import Breadcrumdetails from "../../../../component/events/elections/lokshabha/breadcrumb/Breadcrumdetails";
import BreadcrumSeoSchema from '../../../../component/events/elections/lokshabha/breadcrumb/BreadcrumSeoSchema';
export default function ElectionInformation(props) {
  const {
    StateDate,
    Politics,
    ElectionnewsData,
    headerdata,
    footerdata,
    navtrending,
    sidebar,
    ELECTION_RESULT_RHS, payload1
  } = props;

  //console.log(BusinessData1);

  //console.log(EntertainmentData);
  //const topDealsData1 = TopDealsData.docs;

  const router = useRouter();
  const routPath = router.asPath;

  const schemaAarray_11 = [];
  schemaAarray_11.push(`
      var dataLayer = window.dataLayer || []; dataLayer.push({'event':'pageview','tvc_page_type':'election information landing page','tvc_landing_type':'election information page','language':'marathi'});
   `);
  useEffect(() => {
    var widthWindow = window.innerWidth;
    if (widthWindow >= 1024) {
      scriptG("https://securepubads.g.doubleclick.net/tag/js/gpt.js", true);
    }

    var scroll = 0;
    function showAds(showid, i) {
      var para = document.createElement("script");
      var divbx = document.createElement("div");
      divbx.id = showid;
      var a =
        "googletag.cmd.push(function() { googletag.display('" +
        divbx.id +
        "'); });";
      var t = document.createTextNode(a);
      para.appendChild(t);
      divbx.appendChild(para);
      document.getElementById("target-" + i).appendChild(divbx);
    }
    function scriptG(url, asyncTT) {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = url;
      script.asyncT = "async";
      script.id = asyncTT;
      document.body.appendChild(script);
    }
    window.addEventListener("scroll", function () {
      if (scroll == 0) {
        /*Taboola*/
        window._taboola = window._taboola || [];
        _taboola.push({ homepage: "auto" });
        !(function (e, f, u, i) {
          if (!document.getElementById(i)) {
            e.async = 1;
            e.src = u;
            e.id = i;
            f.parentNode.insertBefore(e, f);
          }
        })(
          document.createElement("script"),
          document.getElementsByTagName("script")[0],
          "//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js",
          "tb_loader_script"
        );
        if (
          window.performance &&
          typeof window.performance.mark == "function"
        ) {
          window.performance.mark("tbl_ic");
        }
        window._taboola = window._taboola || [];
        _taboola.push({
          mode: "thumbnails-a",
          container: "taboola-below-home-thumbnails",
          placement: "Below Home Thumbnails",
          target_type: "mix",
        });
        window._taboola = window._taboola || [];
        _taboola.push({ flush: true });
        /*Taboola*/

        // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);
        if (widthWindow >= 1024) {
          // if (document.getElementById("target-1")) {
          //   showAds("al_medium_300x250", 1);
          // }
          // if (document.getElementById("target-2")) {
          //   showAds("al_bottom_300x250", 2);
          // }
          // if (document.getElementById("target-3")) {
          //   showAds("al_interstitial_1x1", 3);
          // }
          // if (document.getElementById("target-4")) {
          //   showAds("al_medium_728x90", 4);
          // }
          // if (document.getElementById("target-5")) {
          //   showAds("al_bottom_728x90", 5);
          // }
        } else {
          scriptG("https://securepubads.g.doubleclick.net/tag/js/gpt.js", true);
          if (document.getElementById("target-6")) {
            showAds("al_top_300x250_m", 6);
          }
          // if (document.getElementById("target-7")) {
          //   showAds("al_top_300x100_m", 7);
          // }
          // if (document.getElementById("target-6")) {showAds("top_300x250_1_m", 6);}
          // if (document.getElementById("target-5")) {
          //   showAds("al_top_300x250_1_m", 5);
          // }
          // if (document.getElementById("target-14")) {showAds("al_bottom_300x250_m", 14);}
          // if (document.getElementById("target-51")) {
          //   showAds("al_sticky_320x50_m", 51);
          // }
          // if (document.getElementById("target-8")) {
          //   showAds("al_medium_300x250_m", 8);
          // }
          // if (document.getElementById("target-9")) {
          //   showAds("al_bottom_300x250_m", 9);
          // }
          // if (document.getElementById("target-10")) {
          //   showAds("al_interstitial_1x1_m", 10);
          // }
        }

        scroll = 1;
      }
    });
  }, []);

  
  return (
    <>
      <Layout
        headerdata={headerdata}
        footerdata={footerdata}
        navtrending={navtrending}
        sidebar={sidebar}
        Title="लोकसभा निवडणूक 2024 ची माहिती Lok Sabha Election 2024 | All You Need To Know"
        Keywords=" Lok Sabha Election 2024, Election 2024 Awareness Campaign, Online Voter Id Application, Election 2024 Helpline info, भारतातील राजकीय पक्षांची यादी, काँग्रेस पक्ष, भारतीय राजकारण, भारतीय निवडणूक आयोग, लोकसभा निवडणूक 2024, निवडणूक 2024 निकाल, भाजपा, INC काँग्रेस, शिवसेना, राष्ट्रवादी काँग्रेस पार्टी, महाराष्ट्र पॉलिटिक्स,"
        Description="लोकसभा निवडणूक 2024 ची माहिती All Detailed Information about Lok Sabha Election 2024 including Election Awareness, Voter ID Application, Helpline app etc at marathijagran.com"
      >
        <Head>
          {/* <HeadInjection /> */}
          <SeoCommonScript />
          <BreadcrumSeoSchema data="election information" routPath={routPath}></BreadcrumSeoSchema>   
        </Head>
        <SeoCommonSchema></SeoCommonSchema>

        <script dangerouslySetInnerHTML={{ __html: schemaAarray_11 }}></script>

        <DefineSlotHome
          metaKeywords={
            " Lok Sabha Election 2024, Election 2024 Awareness Campaign, Online Voter Id Application, Election 2024 Helpline info, भारतातील राजकीय पक्षांची यादी, काँग्रेस पक्ष, भारतीय राजकारण, भारतीय निवडणूक आयोग, लोकसभा निवडणूक 2024, निवडणूक 2024 निकाल, भाजपा, INC काँग्रेस, शिवसेना, राष्ट्रवादी काँग्रेस पार्टी, महाराष्ट्र पॉलिटिक्स,"
          }
        />
        {/* <div className="eweb" id="hjdg"><div className="ads pagepush-980x50"><div id='al_pagepush_980x50'></div></div></div> */}
        <Breadcrumdetails data="election information"></Breadcrumdetails> 
        <div className="main-content">
          <div className="left-col">
            <div className="ls-area-body">
              {StateDate && StateDate.posts.length > 0 && (
                <>
                  <CategoryBasedNews
                    categoryData={StateDate.posts}
                    compHeadTxt={"महाराष्ट्र"}
                  />
                </>
              )}
              <div className="emobile">
                <div className="ads bottom-300x250">
                  <div id="target-7"></div>
                </div>
              </div>
              <div className="eweb">
                <div className="ads bottom-300x250">
                  <div id="target-2"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="main-col">
            <div className="ls-area-body">
            <ElectionInfo />
              <div className="emobile">
                <div className="ads medium-300x250">
                  <div id="target-6"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">
              <div className="eweb">
                <div className="ads top-300x250 mb50">
                  <div id="al_top_300x250"></div>
                </div>
              </div>
              {Politics && Politics.posts.length > 0 && (
                <>
                  <CategoryBasedNews
                    categoryData={Politics.posts}
                    compHeadTxt={"महाराष्ट्र राजकारण"}
                    type="tag"
                    categoryUrl={
                      Politics.sitemeta && Politics.sitemeta.categoryUrl
                        ? Politics.sitemeta.categoryUrl
                        : ""
                    }
                  />
                  {ELECTION_RESULT_RHS && <ResultGraph data={ELECTION_RESULT_RHS} payload1={payload1} />}
                </>
              )}
              <div className="eweb">
                <div className="ads medium-300x250">
                  <div id="target-1"></div>
                </div>
              </div>

              {/* <LazyLoad><CategoryBasedNews categoryData={TrendingData} /></LazyLoad> */}
            </div>
          </div>
        </div>
        <div className="eweb">
          <div className="ads interstitial-1x1">
            <div id="target-3"></div>
          </div>
        </div>
        {/* <div className="">English Jagran interstitial Ad</div> */}
        <div className="emobile">
          <div className="ads interstitial-1x1">
            <div id="target-10"></div>
          </div>
        </div>



        <div
          className="ads medium-728x90 ewebf"
          style={{ marginBottom: "30px", clear: "both" }}
        >
          <div id="target-4"></div>
        </div>
        <div className="emobile">
          <div className="ads medium-300x250">
            <div id="target-8"></div>
          </div>
        </div>

        <div
          className="ads medium-728x90 ewebf"
          style={{ marginBottom: "30px", clear: "both" }}
        >
          <div id="target-5"></div>
        </div>
        <div className="emobile">
          <div className="ads medium-300x250">
            <div id="target-9"></div>
          </div>
        </div>


        <div className="main-content secdiv">
  
         
            <div className="ls-area-body">
              {ElectionnewsData && ElectionnewsData.posts.length > 0 && (
                <LazyLoad>
                  <ElectionnewsComp
                    categoryData={ElectionnewsData.posts}
                    compHeadTxt={"निवडणूक विशेष"}
                  />
                </LazyLoad>
              )}
            </div>
        
   
        </div>

        <div className="taboolaads">
          <div id="taboola-below-home-thumbnails"></div>
        </div>
      </Layout>
    </>
  );
}
export const getServerSideProps = async (context) => {
  const token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqYWdyYW5uZXdtZWRpYSIsImlhdCI6MTY4MTc0MDk3N30.7nBM4X7b-ausYzFQeRe51rKk0YnZYMjn3SZZGbsKN1S7tV-4UkyvcIK4ABECS_ST4C9-rcU0ObXLLN45Em154g";
  const payload1 = {  headers: { Authorization: `Bearer ${token}` }  };
  //const {urlParameter} = context;
  //const {category, id} = urlParameter;
  const currentDate = new Date();
  const payload = { headers: { Authorization: process.env.API_TOKEN } };

  let timeInMinutes = currentDate.getMinutes() * 60;
  const HomePoneData = await axios
    .get(PageAPI.HomePone_API + "?v" + timeInMinutes, payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  let homeId = HomePoneData?.posts.map((el) => el.id) || [];


  const ELECTION_RESULT_RHS = await axios.get('https://api.jagran.com/api/jagran/election/ls/mh/toptwopartiesbystate/maharashtra/2019', payload1).then((resp) => { return resp.data }).catch((err) => { console.log(err);  return null; })

  function CategoryDataa(category, nuOfStory) {
    return PageAPI.Category_API + category + "/1/" + nuOfStory;
  }
  function CategoryDataExcludeId(category, nuOfStory, ids) {
    return (
      PageAPI.Category_API + category + "/1/" + nuOfStory + "?exclude=" + ids
    );
  }
  function SubCategoryDataa(category, subCategory, nuOfStory) {
    return (
      PageAPI.SubcategoryListing_API +
      category +
      "/" +
      subCategory +
      "/1/" +
      nuOfStory
    );
  }
  let StateDate = await axios
    .get(CategoryDataa("maharashtra", 4, homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error.message);
      return null;
    });
  // StateDate.posts = StateDate?.posts?.filter((el,index) => {
  //   if (HomePoneData?.posts?.some(e => e.id == el.id)) {
  //     return false
  //   } else {
  //     return el
  //   }
  // }).slice(0, 4)
  let stateId = StateDate?.posts?.map((el) => el.id) || [];
  
  // const Politics = await axios.get(CategoryDataa ('maharashtra-politics', 4)).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  const ListingPath_API =
    PageAPI.TagwordBase_API +
    "maharashtra-politics/1/4?exclude=" +
    [...stateId, ...homeId].join(",");
  const Politics = await axios
    .get(ListingPath_API, payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      return null;
    });

  // const HelathData1 = await axios
  //   .get(SubCategoryDataa("lifystyle", "health", 8), payload)
  //   .then((resp) => {
  //     return resp.data;
  //   })
  //   .catch((error) => {
  //     console.log(error);
  //     return null;
  //   });
  
    const ElectionnewsData = await axios.get(PageAPI.TagwordBase_API+'lok-sabha-election-2024/1/8 ', payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
    return {
    props: {
    StateDate,
    Politics,
    ElectionnewsData,
    ELECTION_RESULT_RHS, payload1
    },
  };
};
