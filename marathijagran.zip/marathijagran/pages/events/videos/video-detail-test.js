
import Layout from "../../../component/layout/layout";
import Head from "next/head";
import Script from 'next/script';
import { useEffect } from "react";

export default function VideoDetail(props) {
  const {headerdata, footerdata, navtrending} = props;
    // youtube player
    useEffect(() => {
        
      // function checkAutoplay() {
      //     if (window.performance) {
      //         if (window.performance.navigation.type != 0) {
      //             return false;
      //         }
      //     }
      //     if (document.referrer) {
      //         if (location.host == document.referrer.match(/:\/\/(.[^/]+)/)[1]) return true;
      //     }
      //     return false;
      // }

      // Initialize YouTube player once the API is loaded
      function initYouTubePlayer() {
          console.log(window.YT,'Ensure that YT object is available'); // Ensure that YT object is available
          if (window.YT && window.YT.createPlayerForPublishers) {
              // var autoplay = checkAutoplay();
              // if (autoplay === false) {
              //     autoplay = true;
              // }
              window.YT.createPlayerForPublishers(
                  'pfp-container',
                  makeAdsRequest,
                  {
                      youtubeOptions: {
                          videoId: "4P1o-8isYNU",
                          height: "360px",
                          width: "100%",
                          disablekb: 1,
                          playerVars: { 'Referer':'https://www.marathijagran.com/',widget_referrer:'https://www.marathijagran.com/' },
                          
                      }
                  },
                  onPlayerReady
              );
          } else {
              console.error("YouTube IFrame API or createPlayerForPublishers method is not available.");
          }
      }


      // Load the YouTube IFrame API script
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api?ima=1';
      const firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);


      // const ima_sdk = document.createElement('script');
      // ima_sdk.src = 'https://imasdk.googleapis.com/js/sdkloader/ima3_debug.js';
      // const ima_sdk_tag = document.getElementsByTagName('script')[0];
      // ima_sdk_tag.parentNode.insertBefore(ima_sdk, ima_sdk_tag);

      // Define functions used by YouTube API
      window.onYouTubeIframeAPIReady = initYouTubePlayer;

      // Define your functions
      function makeAdsRequest(adsRequest, adsRenderingSettings) {
          //adsRequest.adTagUrl = 'https://pubads.g.doubleclick.net/gampad/ads?iu=/13276288/external/single_ad_samples&sz=640x480&cust_params=sample_ct%3Dlinear&ciu_szs=300x250%2C728x90&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator=';

          // adsRequest.adTagUrl = 'https://pubads.g.doubleclick.net/gampad/ads?iu=/21775744923/external/single_ad_samples&sz=640x480&cust_params=sample_ct%3Dlinear&ciu_szs=300x250%2C728x90&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator='
          
          adsRequest.adTagUrl = 'https://pubads.g.doubleclick.net/gampad/ads?iu=/21775744923/external/single_preroll_skippable&sz=640x480&ciu_szs=300x250%2C728x90&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator='
          
          
          console.log('new adsRequest');

          adsRenderingSettings.useStyledNonLinearAds = true;
          adsRenderingSettings.uiElements = [
              window.google.ima.UiElements.AD_ATTRIBUTION,
              window.google.ima.UiElements.COUNTDOWN
          ];


          // Set the referrer
          window.google.ima.settings.setVpaidMode({
              vpaidMode: window.google.ima.ImaSdkSettings.VpaidMode.ENABLED,
              Referer: 'https://www.marathijagran.com/'
          });
      }

      var player;
      var imaManager;

      function onPlayerReady(plyr, ima) {
          player = plyr;
          imaManager = ima;
          // if (autoplay) {
          //     event.target.setVolume(100);
          //     event.target.playVideo();
          // }
      }
      
      /*function onPlayerReady(event) {
          var player = event.target;
      
          // Add event listener to prevent right-click
          player.getIframe().addEventListener('contextmenu', function (e) {
              e.preventDefault();
          });
      }*/

      // Clean up
      return () => {
          // Remove the YouTube API script when unmounting
          tag.parentNode.removeChild(tag);
          delete window.onYouTubeIframeAPIReady;
      };
  }, []);
  return (
    <>
      <Layout headerdata={headerdata} footerdata={footerdata} navtrending={navtrending}>
      
      <Head>
                <title>PfP IMA Integration</title>
                <meta name="robots" content="NOINDEX,NOFOLLOW"/>
                <meta name="Referer" content="origin"/>                
            </Head>
            <Script src="https://imasdk.googleapis.com/js/sdkloader/ima3_debug.js"/>
           
            <div className='container'>
                <div className='playerPFP' id='video-player'>
                    <div id='pfp-container'></div>
                </div>
            </div>

      </Layout>
      <style>{`
    .playerPFP{position:relative; padding-bottom:53.75%; padding-top:22px; height:0; line-height:0; margin-bottom:20px; clear:both; width:100%; border-radius:0; overflow:hidden; background-color: #e2dbdb;}
    .playerPFP iframe{position:absolute; top:0; left:0; width:100%; height:100%; border:0;}
    
      `}</style>
    </>
  )
}
