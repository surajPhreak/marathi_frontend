import axios from "axios";
import Head from "next/head";
import Script from 'next/script';
import Image from "next/image";
import SeoCommonScript from "../../../component/seo/seoCommonScript";
import Layout from "../../../component/layout/layout";
import { PageAPI, DomainPrefixes } from "../../../component/utils/ejConfig";
import { useEffect, useState } from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../../component/seo/SeoCommonSchema";
import StorySection from '../../../component/events/mera-power-vote/storySection';
import NewsComp from "@/component/events/mera-power-vote/NewsComp";
import Custom404 from "../../404";


export default function Index(props) {
  const {ListingData1, payload} = props;


  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'farmer landing page','tvc_landing_page_type':'event landing page','language':'marathi'});
   `);  
 const num=Math.random();
  return (
    //ListingData1!=0?
    <>
     <Head>
          <title>शेतकरी मतदार India, मतदार जागृती अभियान 2024 | Mera Power Vote</title>
          <meta name="description" content=" मराठी जागरणच्या 2024 च्या मतदार जागृती मोहिमेद्वारे भारतातील शेतकरी मतदारांना उन्नत करा. 'मेरा पॉवर व्होट' आणि शेतकऱ्यांची महत्त्वाची भूमिकांचा शोधा घ्या. माहितीपूर्ण मतदान निवडीसाठी आमच्यात सामील व्हा!" />
          <meta name="keywords" content="लोकसभा निवडणूक 2024, निवडणूक 2024, लोकसभा निवडणूक 2024, सार्वत्रिक निवडणूक 2024, निवडणूक आयोग, भारतातील शेतकरी मतदार, मतदार जागृती मोहीम, मराठी जागरण मतदार मोहीम," />
          <link rel="canonical" href={"https://www.marathijagran.com/mera-power-vote"} />
          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />
          <meta property="og:title" content="शेतकरी मतदार India, मतदार जागृती अभियान 2024 | Mera Power Vote" />
          <meta property="og:description" content="मराठी जागरणच्या 2024 च्या मतदार जागृती मोहिमेद्वारे भारतातील शेतकरी मतदारांना उन्नत करा. 'मेरा पॉवर व्होट' आणि शेतकऱ्यांची महत्त्वाची भूमिकांचा शोधा घ्या. माहितीपूर्ण मतदान निवडीसाठी आमच्यात सामील व्हा!" />
          <meta property="og:url" content={'https://www.marathijagran.com/mera-power-vote'} />

          <meta property="og:image" content='https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg' />

          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="Marathi Jagran" />
          <meta property="og:type" content="Article" />
          
          <meta name="theme-color" content="#dc0228" />

            <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" href="../../css/vote-power.css?stamptime" />
          <SeoCommonScript />


      </Head>
    
      <Script src='../../js/mera-power-vote.js'></Script>
        <SeoCommonSchema></SeoCommonSchema>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>

        <header>
        <div className="container">
            <div className="row">
                <div className="col-lg-12">
                    <nav className="headerMenu">
                        <div className="logo">
                            <a href={"/elections/mera-power-vote/"}>
                            <Image width={515} height={477} src="https://img.marathijagran.com/2024/03/mera-power-marathi-logo.png" alt="Marathi Jagran" />
                            </a>                            
                        </div>
                        <div className="menuLinks">
                            <ul>
                                {/* <li>
                                    <a href={"/elections/lok-sabha.html"}> लोकसभा चुनाव 2024</a>
                                </li> */}
                                <li>
                                    <a href={"https://www.marathijagran.com/"}> Back to Marathi Jagran</a>
                                </li>
                            </ul>
                        </div>
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>


    <div className="sectionOne">
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="relpos" data-aos="fade-up" data-aos-duration="1800">
                        <div className="sectionTitle">
                            <h2>यावेळी मतदान नाही <br />शक्ती मतदान करेल</h2>
                            <h1>शेतकरी</h1>
                        </div>
                        <div className="handIcon"data-aos="fade-in" data-aos-duration="1500">
                        <Image width={151} unoptimized height={314} quality={1} className="ball" src="https://www.jagranimages.com/images/merapowervote/hand.png" alt="" />
                        </div>
                    </div>
                </div>
                <div className="col-lg-5 col-md-5" data-aos="fade-left" data-aos-duration="1800">
                <Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/farmer.png" alt="शक्ती मतदान करेल" className="img-fluid" />
                </div>                
            </div>
        </div>
    </div>

    <div className="sectionTwo">
        <div className="voteImage" data-aos="flip-right" data-aos-duration="1800">
        <Image width={695} unoptimized height={451} src="https://www.jagranimages.com/images/merapowervote/vote-box.png" alt="" />
        </div>
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="sectionDescription secDesc2" data-aos="fade-up" data-aos-duration="1800">
                        <h2>माय पॉवर व्होट : अन्नदातांचा आवाज</h2>
                        <p>तळपत्या उन्हातल्या शेतापासून ते देशाच्या ताटांपर्यंत, शेतकरी तुम्ही भारताच्या हृदयाचे ठोके आहात. तुम्ही केवळ पिकांचेच नव्हे तर आमच्या भूमीचे जीवनधारेचे पोषण करता. तरीही, तुमची मेहनत अनेकदा पूर्ण परिणामांमध्ये रुपांतरीत होत नाही. पण तुमच्या हातात एक शक्ती आहे, एक शक्ती जी तुमचे नशीब पुन्हा लिहू शकते - तुमचे पॉवर व्होट.</p>
                        <p>हा केवळ अधिकार नाही तर क्रांती आहे. ही उदासीनता दूर करण्याची तुमची संधी आहे. तुमचे मत म्हणजे तुम्ही पेरलेले बी, तुमच्या जीवनाचे पोषण करणाऱ्या धोरणांमध्ये वाढणारे रोप. वाजवी किंमत, सहज क्रेडिट, उत्तम पायाभूत सुविधा – या सर्व तुमच्या गरजा आहेत, मागण्या नाहीत. त्यामुळे तुमचे मत सरकारचा संकल्प होई</p>
                        <p>उन्हात तुमची ऊर्जा जाळू नका. लक्षात ठेवा, एखाद्या राष्ट्राचे आरोग्य तेथील शेतकऱ्यांचे आरोग्य प्रतिबिंबित करते. योग्य नेत्याची निवड करून, तुम्ही केवळ सरकार नाही, तर असे भविष्य निवडता जिथे तुमची शेतं फुलतील, तुमची मुलांची  भरभराट होईल आणि तुमचे गाव सुद्धा समृद्ध होईल.</p>
                        <p>संधींनी परिपूर्ण, आरोग्यसेवा उपलब्ध, शिक्षण हे दिवाबत्ती आणि नद्यांप्रमाणे वाहणारे पर्यायी उत्पन्नाचे स्रोत अशा गावांची कल्पना करा. ही काल्पनिक गोष्ट नाही, हे वास्तव आहे. फक्त स्वत:साठी नाही तर भावी पिढ्यांसाठी तुमचे  पॉवर व्होट करा आणि भारताच्या नशिबाचे निर्माते व्हा.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {/* <StorySection data={newsSection} /> */}
    <div className="container">
          <div className="main-content secdiv">   
          <div className="ls-area-body">     
              {ListingData1 && <NewsComp categoryData={ListingData1.posts} payload={payload} compHeadTxt={"शेतकरी मतदार"} link={'farmer-voters'} />}
              </div>
              </div>
              </div>

              <div className="sectionSeven">
        <div className="container">
            <div className="row">
                <div className="col-lg-12 text-center">
                    
                    <div className="sectionTitle mt-35" data-aos="fade-up" data-aos-duration="1800">
                    <h2 style={{color:'#000'}}>5 वर्षाच्या अर्थसंकल्पातील तरतुदी</h2>
                        
                    </div>
                </div>
            </div>
        </div>
        <div className="container workProgesss">
            <div className="row">
                <div className="col-lg-12">
                    <ul>
                        <li>पीएम किसान संपदा योजनेचा लाभ</li>
                        <li>मत्स्य शेतीवर विशेष भर</li>
                        <li>सी फूडचे दुप्पट उत्पादन</li>
                        <li>डेअरी उद्योग मजबूत करणे</li>
                        <li>पीक विम्याचा लाभ</li>
                        <li>ग्रामीण भागातील घरांचे फायदे</li>
                        <li>नॅनो डीएपी</li>
                        <li>नैसर्गिक शेतीवर भर</li>
                        <li>कृषी स्टार्टअप</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
    <style>{`body{ background: #fff7e3 !important; }`}</style>
    </>
   
  )
}
export const getServerSideProps = async (context) => {
  const { query } = context;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  

  const ListingPath_API = PageAPI.TagwordBase_API + 'farmer-voters/1/4'
  const ListingData1 = await axios.get(ListingPath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );

  return { props: { ListingData1, payload} };
};