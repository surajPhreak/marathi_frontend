import axios from "axios";
import Head from "next/head";
import Script from 'next/script';
import Image from "next/image";
import SeoCommonScript from "../../../component/seo/seoCommonScript";
import Layout from "../../../component/layout/layout";
import { PageAPI, DomainPrefixes } from "../../../component/utils/ejConfig";
import { useEffect, useState } from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../../component/seo/SeoCommonSchema";
//import StorySection from '../../../component/events/mera-power-vote/storySection';
import NewsComp from "@/component/events/mera-power-vote/NewsComp";
import Custom404 from "../../404";


export default function Index(props) {
  const {ListingData1, payload} = props;


  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'student landing page','tvc_landing_page_type':'event landing page','language':'marathi'});
   `);  
 
  return (
    //ListingData1!=0?
    <>
     <Head>
          <title>Voter Awareness Campaign 2024: Mera Power Vote | Marathi Jagran</title>
          <meta name="description" content="आमच्या मतदार जागृती अभियान 2024 - मेरा पॉवर व्होट च्या माध्यमातून तुमच्या नागरी कार्यांमध्ये सहभाग वाढवा. प्रत्येक मत आपल्या देशाचे भविष्य घडवते. सकारात्मक बदल सुरू करण्यासाठी आमच्यात सामील व्हा" />
          <meta name="keywords" content="लोकसभा निवडणूक 2024, निवडणूक 2024, मतदान 2024, सार्वत्रिक निवडणूक 2024, लोकसभा निवडणूक 2024, मराठी जागरण मेरा पॉवर वोट मोहीम" />
          <link rel="canonical" href={"https://www.marathijagran.com/mera-power-vote"} />
          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />
          <meta property="og:title" content="Voter Awareness Campaign 2024: Mera Power Vote | Marathi Jagran" />
          <meta property="og:description" content="आमच्या मतदार जागृती अभियान 2024 - मेरा पॉवर व्होट च्या माध्यमातून तुमच्या नागरी कार्यांमध्ये सहभाग वाढवा. प्रत्येक मत आपल्या देशाचे भविष्य घडवते. सकारात्मक बदल सुरू करण्यासाठी आमच्यात सामील व्हा" />
          <meta property="og:url" content={'https://www.marathijagran.com/mera-power-vote'} />

          <meta property="og:image" content='https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg' />

          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="Marathi Jagran" />
          <meta property="og:type" content="Article" />
          
          <meta name="theme-color" content="#dc0228" />

            <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" href="../../css/vote-power.css?stamptime" />
          <SeoCommonScript />

      </Head>
    
      <Script src='../../js/mera-power-vote.js'></Script>
        <SeoCommonSchema></SeoCommonSchema>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>


        <header>
        <div className="container">
            <div className="row">
                <div className="col-lg-12">
                    <nav className="headerMenu">
                        <div className="logo">
                            <a href={"/elections/mera-power-vote/"}>
                            <Image width={515} height={477} src="https://img.marathijagran.com/2024/03/mera-power-marathi-logo.png" alt="Marathi Jagran" />
                            </a>                            
                        </div>
                        <div className="menuLinks">
                            <ul>
                                {/* <li>
                                    <a href={"/elections/lok-sabha.html"}> लोकसभा चुनाव 2024</a>
                                </li> */}
                                <li>
                                    <a href={"https://www.marathijagran.com/"}> Back to Marathi Jagran</a>
                                </li>
                            </ul>
                        </div>
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div className="sectionOne">
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="relpos" data-aos="fade-up" data-aos-duration="1800">
                        <div className="sectionTitle">
                            <h2>यावेळी मतदान नाही <br /> शक्ती मतदान करेल</h2>
                            <h1>माझे पहिले मत</h1>
                        </div>
                        <div className="handIcon"data-aos="fade-in" data-aos-duration="1500">
                        <Image width={151} unoptimized height={314} quality={1} className="ball" src="https://www.jagranimages.com/images/merapowervote/hand.png" alt="" />
                        </div>
                    </div>
                </div>
                <div className="col-lg-5 col-md-5" data-aos="fade-left" data-aos-duration="1800">
                <Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/students2.png" alt="शक्ती मतदान करेल" className="img-fluid" />
                </div>                
            </div>
        </div>
    </div>

    <div className="sectionTwo">
        <div className="voteImage" data-aos="flip-right" data-aos-duration="1800">
        <Image width={695} unoptimized height={451} quality={1} src="https://www.jagranimages.com/images/merapowervote/vote-box.png" alt="" />
        </div>
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="sectionDescription secDesc2" data-aos="fade-up" data-aos-duration="1800">
                        <h2>माझे &apos;पॉवर&apos;व्होट : युवा जोश</h2>
                        <p>तरुणांच्या चैतन्यशील ऊर्जेवर आपल्या देशाचे भवितव्य अवलंबून आहे. तुमचा, सर्वात मोठा मतदान गट, तुमची स्वप्ने आणि आकांक्षांनी परिपूर्ण भविष्य घडवण्याची ताकद आहे. संपूर्ण जग तुमच्या क्षमता आणि मेहनतीपुढे नतमस्तक आहे.</p>
                        <p>जोशाची मशाल पेटवा! तुमचे मत हे केवळ कर्तव्य नाही, तर ती घोषणा आहे. शिक्षण, रोजगार, पर्यावरण – तुमच्या उद्याला आकार देणारा प्रत्येक मुद्दा तुमच्या मतपत्रिकेवर आपली जागा मिळवतो.</p>
                        <p>परिवर्तक व्हा, उत्प्रेरक व्हा. तुम्ही मत देताना, तुम्ही EVM वर फक्त बटण दाबत नाही, तर तुम्ही एक प्रगतीशील उपक्रमाची पणती पेटवत आहात. तुमचा आवाज लाखोंनी एकत्र येऊन शालीनतेच्या पायाखालच्या जमिनीला हलवून टाकू शकतो. मतदान हे केवळ प्रतिनिधी निवडण्यापुरते नसते, तर ते तुमच्यासाठी पात्र असलेले भविष्य निवडणे असते. असे भविष्य जेथे तुमच्या कल्पना ऐकल्या जातात, तुमच्या गरजा पूर्ण केल्या जातात आणि तुमच्या स्वप्नांचे पालनपोषण केले जाते.</p>
                        <p>तुमच्या देशाच्या भविष्याच्या कहाणीत बघ्याची भूमिका घेऊ नका. उठा, आणि मतदान करा. हा केवळ अधिकार नाही तर ती जबाबदारी, विशेषाधिकार आणि कल्याणासाठी एक शस्त्र आहे. लक्षात ठेवा, भविष्य वारशाने मिळत नाही, ते जिंकले जाते. आपले मत द्या, भारताच्या नशिबाचे निर्माते व्हा.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {/* <StorySection data={newsSection} /> */}
    <div className="container">
          <div className="main-content secdiv">   
          <div className="ls-area-body">     
              {ListingData1 && <NewsComp categoryData={ListingData1.posts} payload={payload} compHeadTxt={"माझे पहिले मत"} link={'first-time-voters'} />}
              </div>
              </div>
              </div>

              <div className="sectionSeven">
        <div className="container">
            <div className="row">
                <div className="col-lg-12 text-center">
                  
                    <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
                    <h2 style={{ marginBottom: '35px', color:'#000', marginTop:'0' }}>5 वर्षाच्या अर्थसंकल्पातील तरतुदी
                    </h2>
                    </div>
                </div>
            </div>
        </div>
        <div className="container workProgesss">
            <div className="row">
                <div className="col-lg-12">
                    <ul>
                        <li>प्रशिक्षण देऊन बनवले सक्षम</li>
                        <li>उच्च शिक्षणासाठी संस्था</li>
                        <li>नॅशनल डिजिटल लायब्ररी</li>
                        <li>एकलव्य मॉडेल निवासी शाळा</li>
                        <li>शिक्षणासाठी टीव्ही चॅनेल</li>
                        <li>रोजगारासाठी पीएलआय योजना</li>
                        <li>अंगणवाडी सेविकांना स्मार्टफोन</li>
                        <li>राष्ट्रीय शैक्षणिक धोरण</li>
                        <li>शाळा आणि उच्च शिक्षणात मोठे बदल</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <style>{`body{ background: #fff7e3 !important; }`}</style>
    </>
   
  )
}
export const getServerSideProps = async (context) => {
  const { query } = context;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  

  const ListingPath_API = PageAPI.TagwordBase_API + 'first-time-voters/1/12'
  const ListingData1 = await axios.get(ListingPath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );

  return { props: { ListingData1, payload} };
};