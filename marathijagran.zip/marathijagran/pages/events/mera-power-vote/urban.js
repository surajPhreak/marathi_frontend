import axios from "axios";
import Head from "next/head";
import Script from 'next/script';
import Image from "next/image";
import SeoCommonScript from "../../../component/seo/seoCommonScript";
import Layout from "../../../component/layout/layout";
import { PageAPI, DomainPrefixes } from "../../../component/utils/ejConfig";
import { useEffect, useState } from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../../component/seo/SeoCommonSchema";
//import StorySection from '../../../component/events/mera-power-vote/storySection';
import NewsComp from "@/component/events/mera-power-vote/NewsComp";
import Custom404 from "../../404";


export default function Index(props) {
  const {ListingData1, payload} = props;

  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'urban landing page','tvc_landing_page_type':'event landing page','language':'marathi'});
   `);  
 
  return (
    //ListingData1!=0?
    <>
     <Head>
          <title>सामान्य आणि शहरी मतदार India, मतदार जागृती अभियान 2024 | मेरा पॉवर वोट</title>
          <meta name="description" content="तुमची शहरी मते वाढवा! 2024 च्या मतदार जागृती मोहिमेत सामील व्हा - माझा पॉवर वोट सूचना सामान्य मतदारांसाठी. Marathi News, Breaking News in Marathi, Latest News in Marathi - Marathi Jagran  वर शोधा." />
          <meta name="keywords" content="लोकसभा निवडणूक 2024, निवडणूक 2024, लोकसभा निवडणूक 2024, सार्वत्रिक निवडणूक 2024, निवडणूक आयोग, भारतातील शहरी मतदार, मतदार जागृती मोहीम, मराठी जागरण मतदार मोहीम, भारतातील सामान्य मतदार," />
          <link rel="canonical" href={"https://www.marathijagran.com/mera-power-vote"} />
          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />
          <meta property="og:title" content="सामान्य आणि शहरी मतदार India, मतदार जागृती अभियान 2024 | मेरा पॉवर वोट" />
          <meta property="og:description" content="तुमची शहरी मते वाढवा! 2024 च्या मतदार जागृती मोहिमेत सामील व्हा - माझा पॉवर वोट सूचना सामान्य मतदारांसाठी. Marathi News, Breaking News in Marathi, Latest News in Marathi - Marathi Jagran  वर शोधा." />
          <meta property="og:url" content={'https://www.marathijagran.com/mera-power-vote'} />

          <meta property="og:image" content='https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg' />

          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="Marathi Jagran" />
          <meta property="og:type" content="Article" />
          
          <meta name="theme-color" content="#dc0228" />

            <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" href="../../css/vote-power.css?stamptime" />
          <SeoCommonScript />

      </Head>
    
      <Script src='../../js/mera-power-vote.js'></Script>
        <SeoCommonSchema></SeoCommonSchema>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>

        <header>
        <div className="container">
            <div className="row">
                <div className="col-lg-12">
                    <nav className="headerMenu">
                        <div className="logo">
                            <a href={"/elections/mera-power-vote/"}>
                            <Image width={515} height={477} src="https://img.marathijagran.com/2024/03/mera-power-marathi-logo.png" alt="Marathi Jagran" />
                            </a>                            
                        </div>
                        <div className="menuLinks">
                            <ul>
                                {/* <li>
                                    <a href={"/elections/lok-sabha.html"}> लोकसभा चुनाव 2024</a>
                                </li> */}
                                <li>
                                    <a href={"https://www.marathijagran.com/"}> Back to Marathi Jagran</a>
                                </li>
                            </ul>
                        </div>
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div className="sectionOne">
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="relpos" data-aos="fade-up" data-aos-duration="1800">
                        <div className="sectionTitle">
                            <h2>यावेळी मतदान नाही <br /> शक्ती मतदान करेल </h2>
                            <h1>शहरी मतदार</h1>
                        </div>
                        <div className="handIcon"data-aos="fade-in" data-aos-duration="1500">
                        <Image width={151} unoptimized height={314} quality={1} className="ball" src="https://www.jagranimages.com/images/merapowervote/hand.png" alt="" />
                        </div>
                    </div>
                </div>
                <div className="col-lg-5 col-md-5" data-aos="fade-left" data-aos-duration="1800">
                <Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/urban-img.png" alt="शक्ती मतदान करेल" className="img-fluid" />
                </div>                
            </div>
        </div>
    </div>

    <div className="sectionTwo">
        <div className="voteImage" data-aos="flip-right" data-aos-duration="1800">
        <Image width={695} unoptimized height={451} quality={1} src="https://www.jagranimages.com/images/merapowervote/vote-box.png" alt="" />
        </div>
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="sectionDescription secDesc2" data-aos="fade-up" data-aos-duration="1800">
                        <h2>माझे पॉवर व्होट : काम तसेच राष्ट्रहित</h2>
                        <p>कर्तव्याच्या पलीकडे, तुमची शक्ती देखील वापरून पहा! तुम्ही, आमच्या राष्ट्राचा कणा आहात, तुमच्या अथक प्रयत्नांनी देशाच्या प्रगतीला चालना द्या. पण तुमचा प्रभाव ऑफिसच्या दारात संपत नाही. तुमच्या देशाचे भविष्य घडवण्याची गुरुकिल्ली तुमच्याकडे आहे ती म्हणजे -  पॉवर व्होट.
                        नुसते प्रवासी बनू नका, वास्तुविशारद बना. तुमचे मत हे तुमचे छिन्नी आहे, जे समृद्ध राष्ट्राचा मार्ग प्रशस्त करते. रोजगाराच्या संधींना प्रोत्साहन देणारे, तुमच्या स्वप्नांचे पालनपोषण करणारे आणि विकासाच्या इंजिनला गती देणारे सरकार निवडा.  अश्या शिक्षण आणि आरोग्य सेवेची मागणी करा जे तुम्हाला आणि तुमच्या प्रियजनांना सक्षम बनवेल.</p>
                        <p>हे फक्त तुमच्या प्रोफेशनबद्दल नाही तर तुमच्या उद्याबद्दल आहे. चांगले वेतन, उत्तम कामाची परिस्थिती आणि तुम्ही पडल्यास तुम्हाला पकडण्यासाठी सामाजिक सुरक्षा जाळ्याची कल्पना करा. तुमच्या गरजा पूर्ण करणाऱ्या सपोर्ट पॉलिसी, तुमचे योगदान मोलाचे आणि पुरस्कृत असेल असे भविष्य सुनिश्चित करते. उठा, संघटित व्हा आणि मतदान करा.</p>
                        <p>लक्षात ठेवा, तुमचे मत हा केवळ अधिकार नसून ते एक प्रभावी साधन आहे. त्याचा हुशारीने वापर करा, कारण तुमच्या आकांक्षा प्रतिबिंबित करणारे, तुमचे भविष्य सुरक्षित करणारे आणि तुमच्या समर्पणाचे प्रतिफळ देणारे राष्ट्र निर्माण करण्याची शक्ती त्यात आहे. तुमच्या शक्तीला मतदान करा, भारताच्या नशिबाचे निर्माता बना</p>

                    </div>
                </div>
            </div>
        </div>
    </div>

    {/* <StorySection data={newsSection} /> */}
    <div className="container">
          <div className="main-content secdiv">   
          <div className="ls-area-body">     
              {ListingData1 && <NewsComp categoryData={ListingData1.posts} payload={payload} compHeadTxt={"शहरी मतदार"} link={'general-voters'} />}
              </div>
              </div>
              </div>
              <div className="sectionSeven">
        <div className="container">
            <div className="row">
                <div className="col-lg-12 text-center">
                    
                    <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
                       
                        <h2 style={{ marginTop: '20px', marginBottom: '40px', color: '#000' }}>5 साल के बजट प्रावधान</h2>
                        
                    </div>
                </div>
            </div>
        </div>
        <div className="container workProgesss">
            <div className="row">
                <div className="col-lg-12">
                    <ul>
                        <li>प्राप्तिकर झाला सोपा आणि सुलभ</li>
                        <li>लोकांना छप्पर मिळाले</li>
                        <li>भविष्याचा मार्ग: सौर ऊर्जा</li>
                        <li>मिशन कर्मयोगी योजना: कर्मचाऱ्यांचे पुनरुज्जीवन</li>
                        <li>इलेक्ट्रिक वाहनांचा प्रचार</li>
                        <li>प्रत्येक घरात शुद्ध पिण्याचे पाणी</li>
                        <li>स्वच्छतेकडे विशेष लक्ष</li>
                        <li>कोरोना लसीने वाचवले जीव</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
 
    <style>{`body{ background: rgb(255, 242, 0, .2); }`}</style>
    </>
   
  )
}
export const getServerSideProps = async (context) => {
  const { query } = context;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  

  const ListingPath_API = PageAPI.TagwordBase_API + 'general-voters/1/4'
  const ListingData1 = await axios.get(ListingPath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );

  return { props: { ListingData1, payload} };
};