import axios from "axios";
import Head from "next/head";
import Script from 'next/script';
import Image from "next/image";
import SeoCommonScript from "../../../component/seo/seoCommonScript";
import Layout from "../../../component/layout/layout";
import { PageAPI, DomainPrefixes } from "../../../component/utils/ejConfig";
import { useEffect, useState } from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../../component/seo/SeoCommonSchema";
//import StorySection from '../../../component/events/mera-power-vote/storySection';
import NewsComp from "@/component/events/mera-power-vote/NewsComp";
import Custom404 from "../../404";


export default function Index(props) {
  const {ListingData1, payload} = props;


  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'mera power vote landing page','tvc_landing_page_type':'event landing page','language':'marathi'});
   `);  
 

  return (
    //ListingData1!=0?
    <>
     <Head>
          <title>Voter Awareness Campaign 2024: Mera Power Vote | Marathi Jagran</title>
          <meta name="description" content="आमच्या मतदार जागृती अभियान 2024 - मेरा पॉवर व्होट च्या माध्यमातून तुमच्या नागरी कार्यांमध्ये सहभाग वाढवा. प्रत्येक मत आपल्या देशाचे भविष्य घडवते. सकारात्मक बदल सुरू करण्यासाठी आमच्यात सामील व्हा" />
          <meta name="keywords" content="लोकसभा निवडणूक 2024, निवडणूक 2024, मतदान 2024, सार्वत्रिक निवडणूक 2024, लोकसभा निवडणूक 2024, मराठी जागरण मेरा पॉवर वोट मोहीम" />
          <link rel="canonical" href={"https://www.marathijagran.com/mera-power-vote"} />
          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />
          <meta property="og:title" content="Voter Awareness Campaign 2024: Mera Power Vote | Marathi Jagran" />
          <meta property="og:description" content="आमच्या मतदार जागृती अभियान 2024 - मेरा पॉवर व्होट च्या माध्यमातून तुमच्या नागरी कार्यांमध्ये सहभाग वाढवा. प्रत्येक मत आपल्या देशाचे भविष्य घडवते. सकारात्मक बदल सुरू करण्यासाठी आमच्यात सामील व्हा" />
          <meta property="og:url" content={'https://www.marathijagran.com/mera-power-vote'} />

          <meta property="og:image" content='https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg' />

          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="Marathi Jagran" />
          <meta property="og:type" content="Article" />
          
          <meta name="theme-color" content="#dc0228" />

            <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" href="../../css/vote-power.css?stamptime" />
          <SeoCommonScript />

      </Head>
    
      <Script src='../../js/mera-power-vote.js?v=1'></Script>
        <SeoCommonSchema></SeoCommonSchema>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>

        <div className="mainHome">
            <div className="meraPowerVoteImg"><h1><Image width={515} height={477} src="https://img.marathijagran.com/2024/03/mera-power-marathi-logo.png" alt="Mera power vote" /></h1></div>
            <nav className="homeSlideMenu">
                <ul className="homeMenuList">
                   <li className="homeMenuItem">
                      <a href={"/elections/mera-power-vote/first-time-voters-india.html"} className="homeMenuLink">
                         <span className="homeMenuLabel">माझे पहिले मत</span> 
                         <h2 className="homeMenuContent"><strong>माझे पहिले मत</strong> <small>क्लिक करा</small></h2>
                         <div className="homeMenuImage"><Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/students2.png" alt="Student" className="homeMenuImg" /></div>
                         </a>
                   </li>
                   <li className="homeMenuItem">
                      <a href={"/elections/mera-power-vote/farmers-voters-india.html"} className="homeMenuLink">
                         <span className="homeMenuLabel">शेतकरी</span> 
                         <h2 className="homeMenuContent"><strong>शेतकरी</strong> <small>क्लिक करा</small></h2>
                         <div className="homeMenuImage"><Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/farmer.png" alt="Farmer" className="homeMenuImg" /></div>
                         </a>
                   </li>
                   <li className="homeMenuItem">
                      <a href={"/elections/mera-power-vote/general-voters-india.html"} className="homeMenuLink">
                         <span className="homeMenuLabel">शहरी मतदार</span> 
                         <h2 className="homeMenuContent"><strong>शहरी मतदार</strong> <small>क्लिक करा</small></h2>
                         <div className="homeMenuImage"><Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/urban-img.png" alt="Urban" className="homeMenuImg" /></div>
                         </a>
                   </li>
                   <li className="homeMenuItem">
                        <a href={"/elections/mera-power-vote/women-voters-india.html"} className="homeMenuLink">
                            <span className="homeMenuLabel">स्त्री</span> 
                            <h2 className="homeMenuContent"><strong>स्त्री</strong> <small>क्लिक करा</small></h2>
                            <div className="homeMenuImage"><Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/women.png" alt="Women" className="homeMenuImg" /></div>
                         </a>
                   </li>
                </ul>
            </nav>            
    </div>
    <div className="aboutUs">
        <div className="container">
            <div className="row">
                <div className="col-lg-12 col-md-12 text-center">
                    <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
                        <h3>माझे शक्ती मत: <br />
                            <span>भारत भाग्य विधाता</span></h3>
                    </div>
                </div>                
                <div className="col-lg-12 mx-auto text-center mt-3 mt-lg-5">
                    <p>ईव्हीएमची टच बटणे विसरून जा, तुमच्या मताची कल्पना रॉकेटचे लॉन्च पॅड म्हणून करा. शाळेचे दार संधीसाठी खुले होत आहे. तुमच्या घराच्या चाव्या, योग्य किंमत, उत्तम आरोग्य सेवा आणि समृद्ध समाज. तुमची ही स्वप्ने मतदानानेच साकार होतील.</p>
                    <p>मत द्या आणि भारताला तिसरी सर्वात मोठी अर्थव्यवस्था म्हणून उदयास येताना पहा. एक स्थिर, निर्णायक सरकार निवडा, अन्यायाविरुद्ध ढालीप्रमाणे उभे करा. तुमच्या एका मताने लाखो स्वप्ने उजळून निघतील. हे मत जागतिक सन्मानासाठीचा हा आपला पासपोर्ट आहे.</p>
                    <p>मतदान करा, भारताचे भाग्य घडवा. मत ही तुमची शक्ती आहे. प्रगती, निवडा आणि भारताचा उदय निवडा. तुमच पॉवर व्होट करा. आपले भविष्य सुनिश्चित करा. भारत भाग्य विधाता बना.</p>
                </div>
            </div>
        </div>
    </div>
    {/* <StorySection data={newsSection} /> */}
    <div className="container">
          <div className="main-content secdiv">   
          <div className="ls-area-body">     
              {ListingData1 && <NewsComp categoryData={ListingData1.posts} payload={payload} compHeadTxt={"लोकसभा निवडणूक 2024"} link={'lok-sabha-elections-2024'} />}
              </div>
              </div>
              </div>

              <div className="sectionFour">
        <div className="container">
            <div className="row">
                <div className="col-lg-12">                    
                </div>
                <div className="col-lg-6 col-md-6 order2">
                    <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
                        <h2>देशाच्या <br /> मतदार</h2>
                    </div>                    
                    <div className="voterByGender" data-aos="fade-left" data-aos-duration="1800">
                        <div className="mailVoter">
                            
                        <ul> 
                            <li><strong>एकूण मतदार </strong>- 96,88,21,926 (97 कोटी)  </li>     
                            <li><strong>महिला मतदार </strong>- 47,15,41,888 (47.1 कोटी)  </li>      
                            <li><strong>पुरुष मतदार</strong> - 49,72,31,994 (49.7 कोटी)  </li>       
                            <li><strong>अपंग मतदार</strong> - 88,35,449    </li>                             
                            <li><strong>तृतीयपंथी मतदार</strong> - 48,044  </li>                              
                            <li><strong>100 वय वर्षांवरील मतदार</strong> - 2,38,791</li>   
                            </ul>
                            {/* <img src="https://www.jagranimages.com/images/merapowervote/maleVoter.png" alt="Male Voter" /> */}
                        </div>
                        {/* <div className="femaleVOter mt-5">
                            <p>महिला मतदाता  - 12 हजार</p>
                            <p> कुल मतदाता - 96,88,21,926 (97 करोड़)  <br />           
                            महिला मतदाता - 47,15,41,888 (47.1 करोड़)  <br />     
                            पुरुष मतदाता - 49,72,31,994 (49.7 करोड़)  <br />        
                            दिव्‍यांग मतदाता - 88,35,449    <br />                           
                            थर्ड जेंडर मतदाता - 48,044  <br />                              
                            100 साल से अधिक उम्र वाले मतदाता - 2,38,791</p>
                             <img src="https://www.jagranimages.com/images/merapowervote/femaleVoter.png" alt="Female Voter" /> 
                        </div> */}
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 order1">
                    
                    
                    <div className="electionDataByCity" data-aos="fade-right" data-aos-duration="1800">
                        
                        <div className="chart">
                        <Image width={512} unoptimized height={528} quality={1} src="https://img.marathijagran.com/2024/03/pai-chart-marathi.png" alt="Pai Chart" />
                        </div>
                        <h3>एकूण मतदार - 97 कोटी <br /> <br /> स्रोत: भारतीय निवडणूक आयोगाचा अहवाल</h3>
                    </div>
                </div>
            </div>
            {/* <div className="row" data-aos="fade-up" data-aos-duration="1800">
            <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
            <h2>मतदाताओं की  बड़होत्री</h2>
                
                    </div>     
                <div className="col-lg-8 col-md-8 mx-auto">
                    <div>
                        <canvas id="myChart"></canvas>
                    </div>                    
                </div>
            </div> */}
        </div>
    </div>

    </>
   
  )
}
export const getServerSideProps = async (context) => {
  const { query } = context;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  

  const ListingPath_API = PageAPI.TagwordBase_API + 'lok-sabha-elections-2024/1/4'
  const ListingData1 = await axios.get(ListingPath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );
  
  return { props: { ListingData1, payload} };
};