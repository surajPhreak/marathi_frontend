import axios from "axios";
import Head from "next/head";
import Script from 'next/script';
import Image from "next/image";
import SeoCommonScript from "../../../component/seo/seoCommonScript";
import Layout from "../../../component/layout/layout";
import { PageAPI, DomainPrefixes } from "../../../component/utils/ejConfig";
import { useEffect, useState } from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../../component/seo/SeoCommonSchema";
//import StorySection from '../../../component/events/mera-power-vote/storySection';
import NewsComp from "@/component/events/mera-power-vote/NewsComp";
import Custom404 from "../../404";


export default function Index(props) {
  const {ListingData1, payload} = props;

  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'woman landing page','tvc_landing_page_type':'event landing page', 'language':'marathi'});
   `);  
 
  return (
    //ListingData1!=0?
    <>
     <Head>
          <title>महिला मतदार India, मतदार जागृती अभियान 2024 | Mera Power Vote</title>
          <meta name="description" content="दैनिक जागरणच्या मतदार जागृती अभियान 2024 - मेरा पॉवर व्होटसह भारतातील महिला मतदारांना सक्षम करा! सकारात्मक बदल घडवून आणण्यासाठी महिला मतदारांच्या सहभागाचे महत्त्व जाणून घ्या. देशाचे भविष्य घडवणाऱ्या महिला मतदारांच्या वाढत्या टक्केवारीबद्दल जाणून घ्या." />
          <meta name="keywords" content="लोकसभा निवडणूक 2024, निवडणूक 2024, लोकसभा निवडणूक 2024, सार्वत्रिक निवडणूक 2024, निवडणूक आयोग, भारतातील महिला मतदार, मतदार जागृती मोहीम, मराठी जागरण मतदार मोहीम," />
          <link rel="canonical" href={"https://www.marathijagran.com/mera-power-vote"} />
          <meta name="google-site-verification" content="JX6UO2MG5wMXoMbwFtLiIEaCfJ5nUmjXpZx_-cYEpdM" />
          <meta property="og:title" content="महिला मतदार India, मतदार जागृती अभियान 2024 | Mera Power Vote" />
          <meta property="og:description" content="दैनिक जागरणच्या मतदार जागृती अभियान 2024 - मेरा पॉवर व्होटसह भारतातील महिला मतदारांना सक्षम करा! सकारात्मक बदल घडवून आणण्यासाठी महिला मतदारांच्या सहभागाचे महत्त्व जाणून घ्या. देशाचे भविष्य घडवणाऱ्या महिला मतदारांच्या वाढत्या टक्केवारीबद्दल जाणून घ्या." />
          <meta property="og:url" content={'https://www.marathijagran.com/mera-power-vote'} />

          <meta property="og:image" content='https://img.marathijagran.com/2023/07/marathi-jagran-logo-1.jpg' />

          <meta property="og:image:type" content="image/jpg"/>
          <meta property="og:site_name" content="Marathi Jagran" />
          <meta property="og:type" content="Article" />
          
          <meta name="theme-color" content="#dc0228" />

            <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" href="../../css/vote-power.css?stamptime" />
          <SeoCommonScript />

      </Head>
    
      <Script src='../../js/mera-power-vote.js'></Script>
        <SeoCommonSchema></SeoCommonSchema>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>

        <header>
        <div className="container">
            <div className="row">
                <div className="col-lg-12">
                    <nav className="headerMenu">
                        <div className="logo">
                            <a href="/elections/mera-power-vote/">
                                <Image width={515} height={477} src="https://img.marathijagran.com/2024/03/mera-power-marathi-logo.png" alt="Marathi Jagran" />
                            </a>                            
                        </div>
                        <div className="menuLinks">
                            <ul>
                                {/* <li>
                                    <a href={"/elections/lok-sabha.html"}> लोकसभा चुनाव 2024</a>
                                </li> */}
                                <li>
                                    <a href={"https://www.marathijagran.com/"}> Back to Marathi Jagran</a>
                                </li>
                            </ul>
                        </div>
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div className="sectionOne">
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="relpos" data-aos="fade-up" data-aos-duration="1800">
                        <div className="sectionTitle">
                            <h2>यावेळी मतदान नाही <br /> शक्ती मतदान करेल</h2>
                            <h1>महिला</h1>
                        </div>
                        <div className="handIcon"data-aos="fade-in" data-aos-duration="1500">
                            <Image width={151} unoptimized height={314} quality={1} className="ball" src="https://www.jagranimages.com/images/merapowervote/hand.png" alt="" />
                        </div>
                    </div>
                </div>
                <div className="col-lg-5 col-md-5" data-aos="fade-left" data-aos-duration="1800">
                    <Image width={605} unoptimized height={934} quality={1} src="https://www.jagranimages.com/images/merapowervote/women.png" alt="शक्ती मतदान करेल" className="img-fluid" />
                </div>                
            </div>
        </div>
    </div>

    <div className="sectionTwo">
        <div className="voteImage" data-aos="flip-right" data-aos-duration="1800">
            <Image width={695} unoptimized height={451} quality={1} src="https://www.jagranimages.com/images/merapowervote/vote-box.png" alt="" />
        </div>
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-7">
                    <div className="sectionDescription secDesc2" data-aos="fade-up" data-aos-duration="1800">
                        <h2>माय पॉवर व्होट: महिला सबलीकरण</h2>
                        <p>प्रत्येक भारतीय स्त्रीला मतदानाचा अधिकार आहे, हा हक्क अमेरिकेत 144 वर्षांनी आणि ब्रिटनमध्ये शतकानंतर मोठ्या कष्टाने मिळवला आहे. तरीही, भारताचा पाया समानतेने जन्माला आला, ज्याने महिलांना त्यांचे नशीब घडवण्यात समान भागीदार घोषित केले. तो केवळ अधिकार नव्हता, तर ती सक्षमीकरणाची गर्जना होती. आता संसदेत 33 टक्के महिलांना प्रतिनिधित्व देण्याची सुविधा होत आहे.</p>
                        <p>ही संख्या नाही तर क्रांती आहे. हे केवळ तुमच्यासाठीच नाही तर येणाऱ्या पिढ्यांसाठी शिक्षण, समानता आणि प्रगतीचे वचन आहे. हे सामाजिक आणि आर्थिक अडथळे दूर करत आहे. यामध्ये तुमचे मत महत्त्वपूर्ण भूमिका बजावेल.</p>
                        
                        <p>सुवर्ण इतिहास विसरू नका, तुमच्या गर्जना शांत होऊ देऊ नका. मताकडे दुर्लक्ष करून प्रगतीची मशाल विझू देऊ नका. तुमचे मत हीच तुमची शक्ती आहे, तुमचा आवाज अन्यायाविरुद्धचे शस्त्र आहे. तुमचे प्रत्येक मत समानतेच्या उभारणीत रचलेली वीट आहे.</p>
                        
                        <p>मातांनो, भगिनींनो उठा जागरूक व्हा! एकमेकांच्या प्रगतीचे शिल्पकार व्हा. तुमचे शक्तिशाली मत, केवळ तुमच्यासाठीच नाही, तर समता आणि समृद्धी हवी असलेल्या असंख्य महिलांसाठी आहे. चला एकत्र येऊन आपल्या मतांनी मार्ग उजळवूया. आपल्या महिलांच्या सामूहिक शक्तीने भारताला सक्षम बनवूया. तुमच्या &apos;पॉवर&apos; मताने भारताच्या नशिबाचे निर्माते बना.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {/* <StorySection data={newsSection} /> */}

    <div className="container">
          <div className="main-content secdiv">   
          <div className="ls-area-body">     
              {ListingData1 && <NewsComp categoryData={ListingData1.posts} payload={payload} compHeadTxt={"महिला मतदार"} link={'women-voters'} />}
              </div>
              </div>
              </div>

              <div className="sectionSeven">
        <div className="container">
            <div className="row">
                <div className="col-lg-12 text-center">
                    
                    <div className="sectionTitle" data-aos="fade-up" data-aos-duration="1800">
                        {/* <h2>सरकार ने किया</h2>
                        <h1>कितना काम</h1> */}
                        <h2 style={{ marginBottom: '30px', color:'#000' }}>5 वर्षाच्या अर्थसंकल्पातील तरतुदी</h2>
                        
                    </div>
                </div>
            </div>
        </div>
        <div className="container workProgesss">
            <div className="row">
                <div className="col-lg-12">
                    <ul>
                        <li>महिला व बालकांच्या पोषणावर विशेष भर</li>
                        <li>अंगणवाडी केंद्रांच्या अद्ययावतीकरणावर भर</li>
                        <li>महिला बनत आहेत लखपती दीदी</li>
                        <li>महिला करत आहेत अधिक बचत</li>
                        <li>उज्ज्वला योजनेमुळे बदलत आहे महिलांची स्थिती</li>
                        <li>मुलींच्या प्रवेशात वाढ</li>
                        <li>सर्वाइकल कैंसर टाळण्यासाठी लस</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <style>{`body{ background: rgb(250, 36, 27, .1); }`}</style>
    </>
   
  )
}
export const getServerSideProps = async (context) => {
  const { query } = context;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  

  const ListingPath_API = PageAPI.TagwordBase_API + 'women-voters/1/4'
  const ListingData1 = await axios.get(ListingPath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );

  return { props: { ListingData1, payload} };
};