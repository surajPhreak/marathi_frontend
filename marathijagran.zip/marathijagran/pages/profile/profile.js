import Head from 'next/head';
import axios from 'axios';
import Image from 'next/image';
import Layout from "../../component/layout/layout";

function Profile(props) {
    return (
        <>
            <Layout>
                <div className="profileSec">
                    <h1>Profile</h1>
                    
                    <form action=''>
                        <div className='profile'>
                            <div className='control_group'>
                                <label>First name</label>
                                <div className='controls'>
                                    <input type='text' className='input' />
                                </div>
                            </div>
                            <div className='control_group'>
                                <label>First name</label>
                                <div className='controls'>
                                    <input type='text' className='input' />
                                </div>
                            </div>
                            <div className='control_group'>
                                <label>First name</label>
                                <div className='controls'>
                                    <input type='text' className='input' />
                                </div>
                            </div>
                            <div className='control_group'>
                                <label>First name</label>
                                <div className='controls'>
                                    <input type='text' className='input' />
                                </div>
                            </div>
                            <div className='control_group'>
                                <label>First name</label>
                                <div className='controls'>
                                    <input type='text' className='input' />
                                </div>
                            </div>
                            <div className='button'>
                                <input type='submit' value="Submit" className='btn btn-primary' />
                            </div>
                        </div>
                    </form>
                </div>
            </Layout>

            <style>{`
                .profileSec { margin-bottom: 50px; width: 100%; }
                .profileSec h1 { margin-bottom: 20px; font-size: 30px; }
                .control_group { margin-bottom: 10px; width: 100%; display: flex; align-items: center; }
                .control_group label { width: 170px; font-size: 15px; }
                .control_group .controls { padding-left: 30px; width: 100%; }
                .input {
                    padding: 6px 8px;
                    border-radius: 4px;
                    border: 1px solid #e4e7eb;
                    width: 100%;
                    font-size: 15px;
                    box-sizing: border-box;
                    box-shadow: none;
                    color: #333333;
                    outline: none;
                    height: 30px;
                    transition: border linear 0.1s, box-shadow linear 0.1s;
                    background-color: #ffffff;
                }
                .button { display: flex; justify-content: flex-end; }
                .btn { cursor: pointer; }
                
                @media screen and (max-width: 768px) {
                    .control_group { flex-wrap: wrap; }
                    .control_group label { width: 100%; }
                    .control_group .controls { padding-left: 0; width: 100%; }
                    }

            `}</style>
        </>
    );
}
export default Profile;