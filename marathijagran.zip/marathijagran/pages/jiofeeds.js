import React from "react";
import { PageAPI } from "../component/utils/ejConfig";
import axios from "axios";

const sitemap = () => {
  return null;
};

export const getServerSideProps = async ({ res,query }) => {
  const BASE_URL = "http://localhost:3000";
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  function formatDateToCustomTimeZone(date, offset='+0530') {
    const utcDate = new Date(date.getTime() + (date.getTimezoneOffset() * 60000));
    const offsetHours = parseInt(offset.slice(0, 3), 10);
    const offsetMinutes = parseInt(offset.slice(3), 10);
    const offsetMilliseconds = (offsetHours * 60 + offsetMinutes) * 60 * 1000;
    const customTimeZoneDate = new Date(utcDate.getTime() + offsetMilliseconds);
    const formattedDate = customTimeZoneDate.toUTCString().replace('GMT', offset);
    return formattedDate;
  }
  

  const currentDate = new Date();
  const formattedDate = formatDateToCustomTimeZone(currentDate, '+0530');
  
  if(query.subcat){
    if(query.category == "tag"){
      var apiUrl = PageAPI.feed_TagwordBase_API+"/"+query.subcat+"/1/10";
    }else{
      var apiUrl = PageAPI.feed_SubcategoryListing_API+query.category+"/"+query.subcat+"/1/10";
    }
}else{
  if(query.category == "latest-news"){
    var apiUrl = PageAPI.feed_LatestPosts_API+"1/10";
  }else{
    var apiUrl = PageAPI.feed_Category_API+query.category+"/1/10";
  }
}



const postData = await axios.get(apiUrl, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );
// console.log(postData);
const sitemap = `<rss xmlns:atom="http://www.w3.org/2005/Atom" version="2.0">
  <channel>
    <title><![CDATA[ Marathi News, Breaking News in Marathi, Latest News in Marathi - Marathi Jagran ]]></title>
    <description><![CDATA[ Marathi Jagran Marathi News: , Breaking News in Marathi, Top News Headlines, Marathi Latest News , Today Top News, Marathi News Today on Marathi Jagran. ]]></description>
    <language>hi</language>
    <copyright>Copyright (c) 2023 marathijagran! Inc. All rights reserved.</copyright>
    <link>https://www.marathijagran.com/latest-news</link>
    <atom:link href="https://rss.jagran.com/marathijagran/latest-news.xml" rel="self" type="application/rss+xml"/>
    <image>
      <url>https://img.marathijagran.com/2023/07/dziHqtsC-marathi-jagran-logo-1.jpg</url>
      <title>Marathi Jagran News - ${query.category}</title>
      <link>https://www.marathijagran.com/${query.category}${query.subcat ? "/" + query.subcat : ''}</link>
    </image>
    <lastBuildDate>${formattedDate}</lastBuildDate>
    ${
        postData?.posts?.map(post => `<item>
          <title><![CDATA[ ${post.headline} ]]></title>
          <link>https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</link>
          <description><![CDATA[ ${post.summary} ]]></description>
          <pubDate>${formatDateToCustomTimeZone(new Date(post.pubDate))}</pubDate>
          <image><![CDATA[ https://img.marathijagran.com/${post.imagePath} ]]></image>
          <guid isPermaLink="true">https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</guid>
        </item>
      `).join('')
    }
  </channel>
</rss>
`;

  res.setHeader("Content-Type", "text/xml");
  res.write(sitemap);
  res.end();

  return {
    props: {},
  };
};

export default sitemap;