import axios from "axios";
import Head from "next/head";
import HeadInjection from "../../component/seo/ListingHeadComp";
import SeoCommonScript from "../../component/seo/seoCommonScript";
import Layout from "../../component/layout/layout";
import { PageAPI } from "../../component/utils/ejConfig";
import TopNewsCom from "../../component/home/topNewsComp";
import CategoryBasedNews from "../../component/home/categoryBaseLong";
import DefineSlotListing from "../../component/ads/defineSlotListing";
import ListingNews from "../../component/authors/authorsListingComp";
import TopListingNews from "../../component/authors/topAuthorsListingComp";
import Custom404 from "../404";
import LazyLoad from "react-lazy-load";
import Image from "next/image";
import { useEffect } from "react";
import { DomainPrefixes } from "../../component/utils/ejConfig";
import GoogleAnalyticsDetailsAuthor from "../../component/seo/GoogleAnalyticsDetailsAuthor";

export default function Home(props) {
  const {StateDate, JagranSpecialData1, AuthorProfile1,footerdata, HomePoneData, authorName, ListingData1,pageNumberRevised, NewCategory, headerdata, navtrending,sidebar } = props;
  const topNewsAdata1 = StateDate.posts;  
  const JagranSpecialData = JagranSpecialData1.posts;

  useEffect(() => {
    var widthWindow = window.innerWidth;
    if(widthWindow >= 1024){
      scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
    }

    var scroll = 0;
    function showAds(showid, i) {
      var para = document.createElement("script");
      var divbx = document.createElement("div");
      divbx.id = showid;
      var a = "googletag.cmd.push(function() { googletag.display('" +  divbx.id + "'); });";
      var t = document.createTextNode(a);
      para.appendChild(t);
      divbx.appendChild(para);
      document.getElementById("target-" + i).appendChild(divbx);
    }
    function scriptG(url,asyncTT){
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = url;
      script.asyncT = "async";
      script.id = asyncTT;
      document.body.appendChild(script);
    }

    window.addEventListener("scroll", function () {
      if (scroll == 0) {

                        /*Taboola*/
                        window._taboola = window._taboola || [];
                        _taboola.push({category:'auto'});
                        !function (e, f, u, i) {
                          if (!document.getElementById(i)){
                            e.async = 1;
                            e.src = u;
                            e.id = i;
                            f.parentNode.insertBefore(e, f);
                          }
                        }(document.createElement('script'),
                        document.getElementsByTagName('script')[0],
                        '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
                        'tb_loader_script');
                        if(window.performance && typeof window.performance.mark == 'function')
                     { window.performance.mark('tbl_ic'); }
                     window._taboola = window._taboola || [];
                     _taboola.push({
                       mode: 'thumbnails-a',
                       container: 'taboola-below-category-thumbnails',
                       placement: 'Below Category Thumbnails',
                       target_type: 'mix'
                     });
                     window._taboola = window._taboola || [];
                     _taboola.push({flush: true});
                  /*Taboola*/
                  // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);

        if (widthWindow >= 1024) {
          // if (document.getElementById("target-1")) {showAds("al_medium_300x250", 1);}
          // if (document.getElementById("target-10")) {showAds("al_interstitial_1x1", 10);}
          // if (document.getElementById("target-8")) {showAds("al_bottom_300x250", 8);}
          // if (document.getElementById("target-9")) {showAds("al_video_interstitial_1x1", 9);}
          } else {
          scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true)  
          if (document.getElementById("target-2")) {showAds("al_top_300x250_m", 2);} 
          // if (document.getElementById("target-3")) {showAds("al_medium_300x250_m", 3);}
          // if (document.getElementById("target-4")) {showAds("al_bottom_300x250_m", 4);}
          // if (document.getElementById("target-11")) {showAds("al_interstitial_1x1_m", 11);}
          // if (document.getElementById("target-9")) {showAds("al_video_interstitial_1x1_m", 9);}
        }
        scroll = 1;
      }
    });
  }, []);

  return (
 AuthorProfile1?
    <>
   
       <Layout headerdata={headerdata} footerdata={footerdata} sidebar={sidebar} navtrending={navtrending} Title={AuthorProfile1.authorName + " Stories, Latest Story List from " + AuthorProfile1.authorName +" - Marathi Jagran"} Keywords="" Description={"Find out the latest story of " + AuthorProfile1.authorName + ". Read the breaking news related to the world, national, sports, entertainment, lifestyle stories in " + AuthorProfile1.authorName + "  style only on marathi.jagran.com"} >
         <Head>
           <HeadInjection categoryy={AuthorProfile1.user_nicename} />
         <SeoCommonScript />
         </Head>   
          <DefineSlotListing categoryNameURL={'authors'} metaKeywords={''} />
          <GoogleAnalyticsDetailsAuthor authorName={AuthorProfile1.authorName} type='Author Landing' />

         <div className="main-content">
           <div className="left-col">
             <div className="ls-area-body">
             {topNewsAdata1 && <LazyLoad><TopNewsCom topNewsAdata={topNewsAdata1} compHeadTxt={"महाराष्ट्र"} /></LazyLoad>}
             </div>
           </div>
           <div className="main-col">
               <div className="ls-area-body">
               <LazyLoad>
             <div className="autor-profile authorProfile">
                    <div className="profile authorbio">
                        <div className="left-col">
                             {/* <figure><img src={AuthorProfile1.user_image} alt={AuthorProfile1.authorName} /></figure> */}
                             <figure>{!AuthorProfile1.authorImageName.includes('no-user.png')&&<Image width={90} unoptimized height={90} src={`${DomainPrefixes.ImagePath}${AuthorProfile1.authorImageName}`} alt={AuthorProfile1.authorName} />}</figure>
                        </div>
                        <div className="right-col">
                            <h2>{AuthorProfile1.authorName}</h2>
                            { AuthorProfile1.designation ?
                            <span>{AuthorProfile1.designation}</span> : ''}
                             { AuthorProfile1.user_emailsss ?
                            <span><a href="mailto:{AuthorProfile1.user_email}">{AuthorProfile1.user_email}</a></span> : ''}
                           
                       </div> 
                   </div>
                   <div className="editorLft authornew">
                    <span>Connect:</span>
                                 <ul className="autor-social">
                                 { AuthorProfile1.authorFBUrl ?
                                     <li className="fb-btn"><a target="_blank" rel="noreferrer" href={AuthorProfile1.authorFBUrl} title={AuthorProfile1.authorName}><svg className="icon"><use href="/sprite.svg#3225194-facebook"></use></svg></a></li> : ''}
                                      { AuthorProfile1.authorTwitterUrl ?
                                     <li className="tw-btn"><a target="_blank" rel="noreferrer" href={AuthorProfile1.authorTwitterUrl} title={AuthorProfile1.authorName}><svg className="icon"><use href="/sprite.svg#3225183-twitter"></use></svg></a></li> : ''}
                                      { AuthorProfile1.authorLnkedinUrl ?
                                     <li className="lin-btn"><a target="_blank" rel="noreferrer" href={AuthorProfile1.authorLnkedinUrl} title={AuthorProfile1.authorName}><svg className="icon"><use href="/sprite.svg#3225190-linkedin"></use></svg></a></li> : ''}
                                 </ul>
                           </div>

                    <div className="authoeDesc"><p>{AuthorProfile1.authorDesc}</p></div>
                    { AuthorProfile1.location ?
                    <div className="editorLft authornew"><strong>Location:</strong> {AuthorProfile1.location}</div> : ''}
                    { AuthorProfile1.area_of_expertise ?
                    <div className="authoeDesc"><strong>Area of Expertise</strong><br />
                    <span className="authurExtended">{AuthorProfile1.area_of_expertise}</span>
                    </div> : ''}
                    { AuthorProfile1.language_spoken ?
                    <div className="authoeDesc"><strong>Language Spoken</strong><br />
                    <span className="authurExtended">{AuthorProfile1.language_spoken}</span>
                    </div> : ''}
                    { AuthorProfile1.honors_and_award ?
                    <div className="authoeDesc"><strong>Honors & Award</strong><br />
                    <span className="authurExtended">{AuthorProfile1.honors_and_award}</span>
                    </div> : ''}
                    { AuthorProfile1.honors_and_award ?
                    <div className="authoeDesc"><strong>Certification</strong><br />
                    <span className="authurExtended">{AuthorProfile1.certification}</span>
                    </div> : ''}
                </div>
                </LazyLoad>
               
                 {ListingData1 && <ListingNews ListingData={ListingData1} totalCount={ListingData1.count} pageNumberRevised={pageNumberRevised} authorName={NewCategory} authorNameSpace={AuthorProfile1.authorName} />}
                 {/* :<LazyLoad>
                  <TopListingNews ListingData={ListingData1} pageNumberRevised={pageNumberRevised} authorName={authorName} /></LazyLoad> */}
               </div>
           </div>
          <div className="right-col">
            <div className="ls-area-body">              
                   <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div></div></div>
                   {JagranSpecialData && <LazyLoad><CategoryBasedNews categoryData={JagranSpecialData} compHeadTxt={"जागरण विशेष"} /></LazyLoad>}
             </div>
           </div>
         </div>
         {/* <div className="ads"><br /><br /></div>
         <div className="main-content secdiv">          
         </div> */}       
      </Layout> </>: <Custom404></Custom404>
  
  )
}
export const getServerSideProps = async (context) => {

  const {query} = context;
  const {authorName='', pageNum} = query;
  
  let categorysplit=''
  let lastIndex = ''
  let str = ''
  let NewCategory ='nil'
  let matches =''
 if (authorName) {
    categorysplit=authorName.split('page');
    lastIndex = categorysplit[0].lastIndexOf('-');
    str = categorysplit[0].substring(0, lastIndex);
    NewCategory = authorName.indexOf("page")==-1?authorName:str;
    matches = authorName.match(/(\d+)/);
  }
   
// if(context.req.headers.referer){
//   var url1 = new URL(context.req.headers.referer);
//   var rl = url1.pathname.split("/");
//   // console.log(rl[1]);
//   if(rl[1] === "top-deals"){
//   var comp = 1;
//   }else{
//     var comp = 0;
//   }
// }else{
//   var comp = 0;
// }

   const matches1=matches==null?'1':categorysplit[1];

  // const newAuthor = NewCategory.split('-'); 
  // const arrayAuthor = [];
  // newAuthor.forEach( element => {
  //   arrayAuthor.push(  element.charAt(0).toUpperCase() + element.slice(1) )
  // });

  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };

  
  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  
  const StateDate = await axios.get(CategoryDataa ('maharashtra', 8),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  const JagranSpecialData1 = await axios.get(CategoryDataa ('jagran-special', 4),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  const HomePoneData = await axios.get(PageAPI.HomePone_API,payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
   var pageNumber  = (matches1 && matches1 != null && matches1 != undefined && !isNaN(matches1) ) ? Math.abs(matches1) :'1' ;
   var pageNumberRevised  = (matches1 == null && matches1 == undefined && isNaN(matches1) ) ? 1 : Math.abs(matches1) ;

   const ListingPath_API = PageAPI.AuthorListing_API1 + NewCategory + '/' + pageNumber  + '/' + 10;
   
   const ListingData1 = await axios.get(ListingPath_API,payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );

    
// console.log(comp);
  // const ProfilePath_API = PageAPI.AuthorProfile_API + NewCategory;
  // const AuthorProfile = await axios.get(ProfilePath_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  // const AuthorProfile_Data = AuthorProfile.author;
  
  const ProfilePath_API1 = PageAPI.AuthorProfile_API1 + NewCategory;
  const AuthorProfile1 = await axios.get(ProfilePath_API1,payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );


  return { props:{StateDate, JagranSpecialData1, AuthorProfile1, HomePoneData, ListingData1, NewCategory, pageNumberRevised, authorName }}
  // return { props: { moreNewsData, HomePoneData, TopDealsData, ListingData1, NewCategory, pageNumberRevised, AuthorProfile_Data } }
};