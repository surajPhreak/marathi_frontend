import axios from "axios";
import Head from "next/head";
import HeadInjection from "../../component/seo/ListingHeadComp";
import SeoCommonScript from "../../component/seo/seoCommonScript";
import Layout from "../../component/layout/layout";
import { PageAPI } from "../../component/utils/ejConfig";
import CategoryBasedNews from "../../component/home/categoryBaseLong";
import DefineSlotListing from "../../component/ads/defineSlotListing";
import LazyLoad from "react-lazy-load";
import Image from "next/image";
import Custom404 from "../404";
import { useEffect } from "react";
import GoogleAnalyticsDetailsAuthor from "../../component/seo/GoogleAnalyticsDetailsAuthor";

export default function Home(props) {
  const {AuthorsData, JagranSpecialData1, headerdata, footerdata, navtrending,sidebar} = props;
  const JagranSpecialData = JagranSpecialData1.posts;
  useEffect(() => {
    var widthWindow = window.innerWidth;
    if(widthWindow >= 1024){
      scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
    }

    var scroll = 0;
    function showAds(showid, i) {
      var para = document.createElement("script");
      var divbx = document.createElement("div");
      divbx.id = showid;
      var a = "googletag.cmd.push(function() { googletag.display('" +  divbx.id + "'); });";
      var t = document.createTextNode(a);
      para.appendChild(t);
      divbx.appendChild(para);
      document.getElementById("target-" + i).appendChild(divbx);
    }
    function scriptG(url,asyncTT){
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = url;
      script.asyncT = "async";
      script.id = asyncTT;
      document.body.appendChild(script);
    }

    window.addEventListener("scroll", function () {
      if (scroll == 0) {

                        /*Taboola*/
                        window._taboola = window._taboola || [];
                        _taboola.push({category:'auto'});
                        !function (e, f, u, i) {
                          if (!document.getElementById(i)){
                            e.async = 1;
                            e.src = u;
                            e.id = i;
                            f.parentNode.insertBefore(e, f);
                          }
                        }(document.createElement('script'),
                        document.getElementsByTagName('script')[0],
                        '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
                        'tb_loader_script');
                        if(window.performance && typeof window.performance.mark == 'function')
                     { window.performance.mark('tbl_ic'); }
                     window._taboola = window._taboola || [];
                     _taboola.push({
                       mode: 'thumbnails-a',
                       container: 'taboola-below-category-thumbnails',
                       placement: 'Below Category Thumbnails',
                       target_type: 'mix'
                     });
                     window._taboola = window._taboola || [];
                     _taboola.push({flush: true});
                  /*Taboola*/
                  // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);

        if (widthWindow >= 1024) {
          // if (document.getElementById("target-1")) {showAds("al_medium_300x250", 1);}
          // if (document.getElementById("target-10")) {showAds("al_interstitial_1x1", 10);}
          // if (document.getElementById("target-8")) {showAds("al_bottom_300x250", 8);}
          // if (document.getElementById("target-9")) {showAds("al_video_interstitial_1x1", 9);}
          } else {
          scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true)   
          // if (document.getElementById("target-3")) {showAds("al_medium_300x250_m", 3);}
          // if (document.getElementById("target-4")) {showAds("al_bottom_300x250_m", 4);}
          // if (document.getElementById("target-11")) {showAds("al_interstitial_1x1_m", 11);}
          // if (document.getElementById("target-9")) {showAds("al_video_interstitial_1x1_m", 9);}
        }
        scroll = 1;
      }
    });
  }, []);

  return AuthorsData!=null? (
    <>
      <Layout headerdata={headerdata} footerdata={footerdata} sidebar={sidebar} navtrending={navtrending} Title="Authors Panel, Complete Bio of Authors - Marathi Jagran" Keywords="Marathi Jagran Authors, Marathi Jagran Writers, Marathi Jagran Content Writers, Marathi Jagran Editorial Desk" Description="Get all the content created by the Marathi Jagran Editorial desk curated under the name of authors related to Entertainment, News, Sports, Lifestyle and crime news of Marathi.jagran.com">
       <Head>
          <HeadInjection categoryy={'authors'} />
          <SeoCommonScript />
        </Head>
        <DefineSlotListing categoryNameURL={'authors'} metaKeywords={'Marathi Jagran Authors, Marathi Jagran Writers, Marathi Jagran Content Writers, Marathi Jagran Editorial Desk'} />
        <GoogleAnalyticsDetailsAuthor type={'Author Listing'} />
        {/* <div className="eweb" id="hjdg"><div className="ads pagepush-980x50"><div id='al_pagepush_980x50'></div></div></div> */}
        <div className="seclayout">
          <div className="leftSection">
            <LazyLoad>
            <div className="stickySidebar author-box">
                <div className="allhead">
                    {/* <h1>જાગરણ અંગ્રેજી લેખકોની યાદી</h1>
                    <span>જાગરણ ગુજરાતી સંપાદકીય ટીમના સભ્યો નીચે સૂચિબદ્ધ છે: </span> */}
                </div>
                {
                AuthorsData.map( (item, key) => {
                    return(
                      
                <div className="autor-profile authorListnew" key={key}>
                    <div className="profile">
                        <div className="left-col">
                            {/* <a href={'/authors/'+item.user_nicename}  title={item.authorName}><figure><img src={`https://img.marathijagran.com/${item.user_image}`} alt={item.authorName} /></figure></a> */}
                            <a href={'/authors/'+item.user_nicename}  title={item.authorName}><figure>{!item.authorImageName.includes('no-user.png')&&<Image width={225} unoptimized height={225} src={`https://img.marathijagran.com/${item.authorImageName}`} alt={item.authorName} />}</figure></a>
                        </div>
                        <div className="right-col">
                            <h2><a href={'/authors/'+item.user_nicename}  title={item.authorName}>{item.authorName}</a></h2>
                            <div className="editorLft">
                                 {/* <span>Editor</span> */}
                                <ul className="autor-social">
                                    <li className="fb-btn"><a target="_blank" rel="noreferrer" href={item.facebook} title={item.authorName}><svg className="icon"><use href="/sprite.svg#3225194-facebook"></use></svg></a></li>
                                    <li className="tw-btn"><a target="_blank" rel="noreferrer" href={item.twitter} title={item.authorName}><svg className="icon"><use href="/sprite.svg#3225183-twitter"></use></svg></a></li>
                                    <li className="lin-btn"><a target="_blank" rel="noreferrer" href={item.linkedin} title={item.authorName}><svg className="icon"><use href="/sprite.svg#3225190-linkedin"></use></svg></a></li>
                                </ul>
                            </div>
                            <p>{item.authorDesc}</p>
                        </div>
                    </div>
                </div>)
                })
            }
            </div>
            </LazyLoad> 
          </div>
          <div className="rightSection">
            <div className="stickySidebar">
                  <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div></div></div>
                  {JagranSpecialData && <LazyLoad><CategoryBasedNews categoryData={JagranSpecialData} compHeadTxt={"जागरण विशेष"} /></LazyLoad>}
            </div>
          </div>
        </div>        
        
        <div className="ads bottom-728x90 ewebf"><div id='al_bottom_728x90'></div></div>

      </Layout>
      
    </>
  )
  : (
    <Custom404></Custom404>
  );
}
export const getServerSideProps = async () => {

  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };

  function CategoryDataa (category, nuOfStory){ return PageAPI.Category_API + category +'/1/' + nuOfStory; }  
  const JagranSpecialData1 = await axios.get(CategoryDataa ('jagran-special', 4),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  
  const AuthorsData = await axios.get(PageAPI.Authors_API, payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  return { props: { JagranSpecialData1, AuthorsData } }
};