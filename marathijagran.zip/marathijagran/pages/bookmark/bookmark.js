import Head from 'next/head';
import axios from 'axios';
import Image from 'next/image';
import Layout from "../../component/layout/layout";

function Bookmark(props) {
    return (
        <>
            <Layout>
                <div className="bookmarkSec">
                    <h1>Bookmark</h1>
                    
                    <div className="listBookmark">
                        <ul className="bookmarkcontainer">
                            <li className="bookmark">
                                <figure><a href="#"><img src="https://images.herzindagi.info/image/2024/Mar/How-dirty-is-period-blood.jpg" width="180" height="150" /></a></figure>

                                <div className="txt-part re-bookmark">
                                    <a href="javascript:void(0)" className="bookmark active"><svg><use href="#bookmarkfill"></use></svg></a>
                                    <h3><a href="#">कितना गंदा होता है ब्लड? पीरियड से जुड़ी इन बातों पर कहीं आप भी तो नहीं करती हैं यकीन?</a></h3>
                                </div>
                            </li>
                            <li className="bookmark">
                                <figure><a href="#"><img src="https://images.herzindagi.info/image/2024/Mar/ways-to-get-rid-of-headache-during-ramadan-fasting.jpg" width="180" height="150" /></a></figure>
                                <div className="txt-part re-bookmark">
                                    <a href="javascript:void(0)" className="bookmark active"><svg><use href="#bookmarkfill"></use></svg></a>
                                    <h3><a href="#">रोजे के दौरान आपको भी होता है सिर दर्द? इन उपायों से पाएं राहत</a></h3>
                                </div>
                            </li>
                            <li className="bookmark">
                                <figure><a href="#"><img src="https://images.herzindagi.info/image/2024/Mar/cold-intolerance-causes.jpg" width="180" height="150" /></a></figure>
                                <div className="txt-part re-bookmark">
                                    <a href="javascript:void(0)" className="bookmark active"><svg><use href="#bookmarkfill"></use></svg></a>
                                    <h3><a href="#">क्या आपको भी गर्मी के मौसम में लगती है ठंड? इन बीमारियों का हो सकता है खतरा</a></h3>
                                </div>
                            </li>
                            <li className="bookmark">
                                <figure><a href="#"><img src="https://images.herzindagi.info/image/2024/Mar/almond-antioxidant-rich-foods-for-health-and-beauty.jpg" width="180" height="150" /></a></figure>
                                <div className="txt-part re-bookmark">
                                    <a href="javascript:void(0)" className="bookmark active"><svg><use href="#bookmarkfill"></use></svg></a>
                                    <h3><a href="#">ये हैं हाई एंटीऑक्सीडेंट फूड, जो सेहत और सौंदर्य दोनों का रखते हैं ख्याल</a></h3>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </Layout>

            <style>{`
                .bookmarkSec { margin-bottom: 50px; width: 100%; }
                .bookmarkSec h1 { margin-bottom: 20px; font-size: 30px; }
                .bookmarkSec .bookmarkcontainer { display: flex; justify-content: space-between; flex-wrap: wrap; align-items: start; gap: 20px; }
                .bookmarkSec .bookmarkcontainer li { display: flex; justify-content: space-between; gap: 20px; position: relative; width: calc(50% - 10px); }
                .bookmarkSec .bookmarkcontainer li h3 { font-size: 16px; }
                .bookmarkSec .bookmarkcontainer li figure { margin-bottom: 10px; }
                .bookmarkSec .bookmarkcontainer li figure,
                .bookmarkSec .bookmarkcontainer li figure img { position: relative; overflow: hidden; width: 180px; height: 120px; }
                .bookmarkSec .bookmarkcontainer li .re-bookmark { padding-right: 30px; width: calc(100% - 200px); }
                .bookmarkSec .bookmarkcontainer li .re-bookmark a:hover { background-size: 100% 1px; }
                .re-bookmark a.bookmark { position: absolute !important; right: 0; }
                a.bookmark.active svg { width: 16px; height: 16px; position: absolute; right: 0; }
                a.bookmark.active { color: #da251d; fill: #da251d !important; }
                
                @media screen and (max-width: 768px) {
                    .bookmarkSec .bookmarkcontainer li { width: 100%; }
                    .bookmarkSec .bookmarkcontainer li h3 { font-size: 13px; }
                    .bookmarkSec .bookmarkcontainer li figure,
                    .bookmarkSec .bookmarkcontainer li figure img { width: 150px; height: 100px; }
                    .bookmarkSec .bookmarkcontainer li .re-bookmark { width: calc(100% - 170px); }
                }

            `}</style>
        </>
    );
}
export default Bookmark;