import '/styles/globals.css'
import App from 'next/app';
import axios from "axios";

import {  Noto_Sans } from 'next/font/google'


const notosans = Noto_Sans({
  subsets: ['latin'],
  weight: ['100','200','300','400','500', '600','700','800'],
  // variable: '--font-anekGujarati',
  display: 'swap',
})

class MyApp extends App {
  static async getInitialProps({ Component, ctx }) {
    // Fetch data from an API
    const payload = {  headers: { Authorization: process.env.API_TOKEN }  };

    const data = await axios.get('https://api.marathijagran.com/header',payload).then((resp) => { return resp.data; }).catch((error) => { console.log(error); return {navtrending:[],footer:[],fluOutMenu:[],header:[]};});
    
    
   


    // Pass the data to the page component as props
    let pageProps = {};
    if (Component.getInitialProps) {
      pageProps = await Component.getInitialProps(ctx);
    }

    return { pageProps, data, };
  }

  render() {
    const { Component, pageProps, data,  } = this.props;

    return (
       <main className={notosans.className}>
      <Component {...pageProps} headerdata={data.header} sidebar={data.fluOutMenu} footerdata={data.footer} navtrending={data.subMenu}/>
      </main>
        );
  }
}

export default MyApp;
