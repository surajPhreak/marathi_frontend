import axios from "axios";
import Head from "next/head";
import HeadInjection from "../../component/seo/ListingHeadComp";
import SeoCommonScript from "../../component/seo/seoCommonScript";
import Layout from "../../component/layout/layout";
import { PageAPI, DomainPrefixes } from "../../component/utils/ejConfig";
import TopNewsCom from "../../component/home/topNewsComp";
import CategoryBasedNews from "../../component/home/categoryBaseLong";
import ListingNews from "../../component/listing/SubCatListingComp";
import Breadcrum from "../../component/global/breadcrumb";
import { useEffect, useState } from "react";
import DefineSlotListing from "../../component/ads/defineSlotListing";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../component/seo/SeoCommonSchema";
import Custom404 from "../404";

export default function Home(props) {
  const {StateDate, JagranSpecialData1, ListingData1, category, subcategory, headerdata, footerdata, navtrending,sidebar} = props;
  const topNewsAdata1 = StateDate&&  StateDate.posts;  
  const JagranSpecialData = JagranSpecialData1.posts;
   const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'${subcategory?subcategory:''} listing page','tvc_listing_page_type':'category listing','tvc_page_cat':'${category.toLowerCase()}','article_subcategory':'${subcategory?subcategory:''}','language':'marathi'});
   `);
   function showAds(showid, i) {
    var para = document.createElement("script");
    var divbx = document.createElement("div");
    divbx.id = showid;
    var a =
      "googletag.cmd.push(function() { googletag.display('" +
      divbx.id +
      "'); });";
    var t = document.createTextNode(a);
    para.appendChild(t);
    divbx.appendChild(para);
    document.getElementById("target-" + i).appendChild(divbx);
  }
  function scriptG(url,asyncTT){
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;
    script.asyncT = "async";
    script.id = asyncTT;
    document.body.appendChild(script);
  }

 

  useEffect(() => {
    var widthWindow = window.innerWidth;
    if(widthWindow >= 1024){
      scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
    }

    var scroll = 0;
    

    window.addEventListener("scroll", function () {
      if (scroll == 0) {
      /*Taboola*/
      window._taboola = window._taboola || [];
      _taboola.push({category:'auto'});
      !function (e, f, u, i) {
        if (!document.getElementById(i)){
          e.async = 1;
          e.src = u;
          e.id = i;
          f.parentNode.insertBefore(e, f);
        }
      }(document.createElement('script'),
      document.getElementsByTagName('script')[0],
      '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
      'tb_loader_script');
      if(window.performance && typeof window.performance.mark == 'function')
   { window.performance.mark('tbl_ic'); }
   window._taboola = window._taboola || [];
   _taboola.push({
     mode: 'thumbnails-a',
     container: 'taboola-below-category-thumbnails',
     placement: 'Below Category Thumbnails',
     target_type: 'mix'
   });
   window._taboola = window._taboola || [];
   _taboola.push({flush: true});
                 
  // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);

        if (widthWindow >= 1024) {
          // if (document.getElementById("target-1")) { showAds("al_medium_300x250", 1);}
          // if (document.getElementById("target-10")) { showAds("al_interstitial_1x1", 10); }
          // if (document.getElementById("target-8")) {showAds("al_bottom_300x250", 8);}
           if (document.getElementById("target-9")) {showAds("al_video_interstitial_1x1", 9);}
        } else {
          scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true)  
          if (document.getElementById("target-2")) { showAds("al_medium_300x250_m", 2);}
          // if (document.getElementById("target-3")) { showAds("al_medium_300x250_m", 3);}
          // if (document.getElementById("target-4")) { showAds("al_bottom_300x250_m", 4);}
          // if (document.getElementById("target-10")) {  showAds("al_interstitial_1x1_m", 10); }
          if (document.getElementById("target-9")) { showAds("al_video_interstitial_1x1_m", 9); }
          // if (document.getElementById("target-51")) {showAds("al_sticky_320x50_m", 51);}

        }
        scroll = 1;
      }
    });
  }, []);


  
  return ListingData1? (
    //ListingData1!=0?
    <>
      <Layout headerdata={headerdata} footerdata={footerdata} navtrending={navtrending} sidebar={sidebar} Title={ListingData1.sitemeta  && ListingData1.sitemeta.metaTitle ? ListingData1.sitemeta.metaTitle : ''} Keywords={' '} Description={ListingData1.sitemeta && ListingData1.sitemeta.metaDesc ? ListingData1.sitemeta.metaDesc : ''} >
      
        <Head>
          <HeadInjection categoryy={category} />
          <SeoCommonScript />
        </Head>
        <SeoCommonSchema></SeoCommonSchema>
        <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>
        <DefineSlotListing categoryNameURL={category}  metaKeywords={ListingData1.sitemeta&& ListingData1.sitemeta.keywords||''} />
        <Breadcrum category={category} />
        <div className="main-content">
          <div className="left-col">
            <div className="ls-area-body">
            {topNewsAdata1 && <LazyLoad><CategoryBasedNews categoryData={topNewsAdata1} compHeadTxt={"महाराष्ट्र"} /></LazyLoad>}
            <div className="eweb"><div className="ads bottom-300x250"><div id="target-8"></div></div></div>
          
            </div>
          </div>
          <div className="main-col">
            <div className="ls-area-body">
              {/* <ListingNews ListingData={ListingData1} totalCount={ListingData1.sitemeta.count} category={category} subcategory={subcategory} /> */}
              {ListingData1 && <ListingNews ListingData={ListingData1} category={category} subcategory={subcategory} head={ListingData1&& ListingData1.sitemeta?ListingData1.sitemeta.category:category} />}
              <div className="ads interstitial-1x1"><div id="target-10"></div></div>
            </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">
              <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div> </div></div>
              <div id="article_container2" className="article_container2"></div>
              {JagranSpecialData && <LazyLoad><CategoryBasedNews categoryData={JagranSpecialData} compHeadTxt={"जागरण विशेष"} /></LazyLoad>}
              <div className="eweb"><div className="ads medium-300x250"><div id="target-1"></div></div></div>
            </div>
          </div>
        </div>
        <div  id="hjdg"><div className="ads al_video_interstitial"><div id='target-9'></div></div></div>
        <div className="taboolaads">
          <div id="taboola-below-category-thumbnails"></div>
          {/* <TaboolaAdsListing /> */}
        </div>
      </Layout>
    </>
    //: <Custom404 />
  ):
  (
    <Custom404></Custom404>
    
  );
}
export const getServerSideProps = async (context) => {
  const { query } = context;
  const { category, pageNum, subcategory } = query;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };

  // const categorysplit = subcategory.split("-");
  // const subcategory = subcategory.indexOf("-") == -1 ? subcategory : categorysplit[0];
  // const matches = subcategory.match(/(\d+)/);
  // const matches1 = matches == null ? "1" : matches[0];
  let categoryTxt=category
  let subcategoryTxt=subcategory
  if (!categoryTxt) {
    categoryTxt=''
  }
  if (!subcategoryTxt) {
    subcategoryTxt=''
  }
  function CategoryDataExcludeId (category, nuOfStory,ids){ return PageAPI.Category_API + category +'/1/' + nuOfStory+'?exclude='+ids.join(','); } 
  const ListingPath_API = PageAPI.SubcategoryListing_API + category + "/" + subcategory + "/1/" + 10;
  // console.log(ListingPath_API);

  const ListingData1 = await axios.get(ListingPath_API,payload).then((resp) => {  return resp.data; }).catch((error) => {  return null;
  });
  let listingId=ListingData1?.posts?.map(el=>el.id)||[]
  //console.log('ll',listingId)
  let StateDate = await axios.get(CategoryDataExcludeId ('maharashtra', 4,listingId),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  const JagranSpecialData1 = await axios.get(CategoryDataExcludeId ('jagran-special', 4,listingId),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  
  const HomePoneData = await axios.get(PageAPI.HomePone_API,payload).then((resp) => { return resp.data; }).catch((error) => { console.log(error); return null;});
  
  // var pageNumber = pageNum && pageNum != null && pageNum != undefined && !isNaN(pageNum) ? Math.abs(pageNum) : "1";
  // var pageNumberRevised = pageNum == null && pageNum == undefined && isNaN(pageNum) ? 1 : Math.abs(pageNum);


 
  // const Meta_Path = PageAPI.MetaCategorySubcat_API + category + "/" + subcategory;
  // const MetaData = await axios.get(Meta_Path, payload).then((resp) => { return resp.data; }).catch((error) => { console.log(error);  return null; });
  return { props: {StateDate, JagranSpecialData1, HomePoneData, ListingData1, category:categoryTxt, subcategory:subcategoryTxt} };
};
