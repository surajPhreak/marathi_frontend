import axios from "axios";
import Head from "next/head";
import HeadInjection from "../../component/seo/ListingHeadComp";
import SeoCommonScript from "../../component/seo/seoCommonScript";
import Layout from "../../component/layout/layout";
import { PageAPI } from "../../component/utils/ejConfig";
import TopNewsCom from "../../component/home/topNewsComp";
import CategoryBasedNews from "../../component/home/categoryBaseLong";
import ListingNews from "../../component/listing/latest-newsComp";
import Breadcrum from "../../component/global/breadcrumb";
import Custom404 from "../404";
import { useEffect } from "react";
import DefineSlotListing from "../../component/ads/defineSlotListing";
//import TaboolaAdsListing from "../../component/ads/taboolaAd-listing";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../../component/seo/SeoCommonSchema";
export default function Home(props) {
  const {StateDate, JagranSpecialData1, ListingData1, category, pageNumberRevised, headerdata, navtrending,sidebar} = props;
  const topNewsAdata1 = StateDate.posts;  
  const JagranSpecialData = JagranSpecialData1.posts;

  const schemaAarray_11=[];
   schemaAarray_11.push(`
   var dataLayer = window.dataLayer || [];dataLayer.push({'event':'pageview','tvc_page_type':'Listing Page','tvc_listing_page_type':'Article Listing','tvc_page_cat':'${category}','article_subcategory':'national','language':'English'})
   `);

  useEffect (() => {
    var widthWindow = window.innerWidth;
    if(widthWindow >= 1024){
      scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
    }

    var scroll=0;
    function showAds(showid, i){
        var para = document.createElement("script");
        var divbx = document.createElement("div");
        divbx.id=showid;
        var a = "googletag.cmd.push(function() { googletag.display('"+divbx.id+"'); });";
        var t = document.createTextNode(a);   
        para.appendChild(t);
        divbx.appendChild(para);
        document.getElementById("target-"+i).appendChild(divbx);
    }
    function scriptG(url,asyncTT){
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = url;
      script.asyncT = "async";
      script.id = asyncTT;
      document.body.appendChild(script);
    }
    
    window.addEventListener("scroll", function(){
        if(scroll==0){

              /*Taboola*/
              window._taboola = window._taboola || [];
              _taboola.push({category:'auto'});
              !function (e, f, u, i) {
                if (!document.getElementById(i)){
                  e.async = 1;
                  e.src = u;
                  e.id = i;
                  f.parentNode.insertBefore(e, f);
                }
              }(document.createElement('script'),
              document.getElementsByTagName('script')[0],
              '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
              'tb_loader_script');
              if(window.performance && typeof window.performance.mark == 'function')
           { window.performance.mark('tbl_ic'); }
           window._taboola = window._taboola || [];
           _taboola.push({
             mode: 'thumbnails-a',
             container: 'taboola-below-category-thumbnails',
             placement: 'Below Category Thumbnails',
             target_type: 'mix'
           });
           window._taboola = window._taboola || [];
           _taboola.push({flush: true});
        /*Taboola*/
        // scriptG('https://cdn.izooto.com/scripts/f3c265e32e010b5080fb2e88ef527d5df2d5353e.js', false);

          if(widthWindow >= 1024){
            if(document.getElementById('target-1')){ showAds('al_medium_300x250', 1)}
            if(document.getElementById('target-10')){ showAds('al_interstitial_1x1', 10)}
          }else{
            scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
            if(document.getElementById('target-2')){ showAds('al_top_300x250_m', 2)}
            if(document.getElementById('target-3')){ showAds('al_medium_300x250_m', 3)}
            if(document.getElementById('target-4')){ showAds('al_bottom_300x250_m', 4)}
            if (document.getElementById('target-11')) { showAds('al_interstitial_1x1_m', 11) }
            if (document.getElementById("target-51")) {showAds("al_sticky_320x50_m", 51);}

          }
          scroll=1;    
        }
    });    
}, []);

  return (
    ListingData1?
   <>
   
      <Layout  headerdata={headerdata} navtrending={navtrending} sidebar={sidebar} Title="Latest News, તાજા સમાચાર: Latest News, Photos and Videos on Latest News - Marathi Jagran" Keywords="Latest News, Latest News Photos, Latest News Videos, Latest News in Marathi, News Headlines, તાજા સમાચાર" Description="Latest News: Get latest news, top stories on Latest News and get latest news updates, photos and videos on Latest News, Get all the Latest News in Marathi on Marathijagran.com.">
      <Head>
        <HeadInjection categoryy={category} fixUrlCanonical={'latest-news'}/>
        <SeoCommonScript />
        <SeoCommonSchema></SeoCommonSchema>
      </Head>
      <script dangerouslySetInnerHTML={{__html: schemaAarray_11 }}  ></script>
      <DefineSlotListing categoryNameURL={'latest-news'} />

        <Breadcrum category={category} />
        <div className="main-content">
          <div className="left-col">
            <div className="ls-area-body">
            {topNewsAdata1 && <LazyLoad><TopNewsCom topNewsAdata={topNewsAdata1} compHeadTxt={"महाराष्ट्र"} /></LazyLoad>}
            </div>
          </div>
          <div className="main-col">
              <div className="ls-area-body">
               {ListingData1 && <LazyLoad><ListingNews ListingData={ListingData1} pageNumberRevised={pageNumberRevised} category={category} /></LazyLoad>}
              </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">              
                  <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div></div></div>
                  {JagranSpecialData && <LazyLoad><CategoryBasedNews categoryData={JagranSpecialData} compHeadTxt={"जागरण विशेष"} /></LazyLoad>}
                  <div className="eweb"><div className="ads medium-300x250"><div id="target-1"></div></div></div>
            </div>
          </div>
        </div>
        <div className="taboolaads">
          <div id="taboola-below-category-thumbnails"></div>
          {/* <TaboolaAdsListing /> */}
        </div>
      </Layout>
     
    </>
     : <Custom404 />
  )
}
export const getServerSideProps = async (context) => {

  const {query} = context;
  const {pageNum} = query;
  const category = "Latest News";
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };

  function CategoryDataExcludeId(category, nuOfStory, ids) { return PageAPI.Category_API + category + '/1/' + nuOfStory + '?exclude='+ids.join(','); } 
  let ListingPath_API = PageAPI.Latestarticles_API + pageNumber  + '/' + 10;

  const ListingData1 = await axios.get(ListingPath_API,payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  let listingId=ListingData1?.posts?.map(el=>el.id)||[]

  const StateDate = await axios.get(CategoryDataExcludeId ('maharashtra', 4,listingId),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  const JagranSpecialData1 = await axios.get(CategoryDataExcludeId ('jagran-special', 4,listingId),payload).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );

  var pageNumber  = (pageNum && pageNum != null && pageNum != undefined && !isNaN(pageNum) ) ? Math.abs(pageNum-1) :'1' ;
  var pageNumberRevised  = (pageNum == null && pageNum == undefined && isNaN(pageNum) ) ? 1 : Math.abs(pageNum) ;



  return { props: {StateDate, JagranSpecialData1, ListingData1, category, pageNumberRevised } }
};