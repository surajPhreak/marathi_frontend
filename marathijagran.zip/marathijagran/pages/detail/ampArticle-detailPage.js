//const postcss = require('postcss')
import {DomainPrefixes, PageAPI} from '../../component/utils/ejConfig';
import axios from 'axios';
import Head from 'next/head';
import Layout from "../../component/layout/ampLayout";
import Meta from '../../component/seo/ampMeta';
import Breadcrum from "../../component/global/ampBreadcrumb.js";
import ArticleBody from '../../component/detail/ampArticleDetailComp';
import RelatedReads from '../../component/detail/ampRelatedReadsComp';
import { useRouter,useLocation  } from 'next/router';
import GoogleAnalytics from '../../component/seo/ampGoogleAnalytics';
import Ga4Amp from '../../component/seo/ga4-amp.js'
import Custom404 from '../404';
export const config = { amp: true };
export default function ArticlePage(props){
  const routerUrl = useRouter().asPath;  
  const router = useRouter();  
  const routerUrlRefine = routerUrl.replace('lite/', '');
  //var newfull = routerUrlRefine.replace(/\?.*$/g,"");
  const { ARTICLE_DETAIL_DATA, navtrending} = props;
  const subcatt = ARTICLE_DETAIL_DATA && ARTICLE_DETAIL_DATA.subcategoryUrl ? ARTICLE_DETAIL_DATA.subcategoryUrl+'/' : '';
  function removeLastId(str) {
    const reLast = /-\d+$/;

    // console.log(str.replace(reLast, ""));
    //console.log(str.replace(reLast, ""));
    return str.replace(reLast, "");
  }
  var elements= ARTICLE_DETAIL_DATA.keywords ? ARTICLE_DETAIL_DATA.keywords.replace(/[&\/\\#+()$~%.'":*?<>{}]/g, '').trim().split(',') : '';
  //console.log(elements)
  var quotedElements = elements ? elements.map( (element) => {return `\"${element.trim()}\"`}) : '';
  // const subcatt = ARTICLE_DETAIL_DATA.subcategory!='NA'?ARTICLE_DETAIL_DATA.subcategory+'/':'';
  
  // const carvar = ARTICLE_DETAIL_DATA.category.toLowerCase().split(' ').join('-'); 
  var jsonObj = `{"targeting":{"Category": ["AMP Article Detail","${ARTICLE_DETAIL_DATA.categoryUrl ? ARTICLE_DETAIL_DATA.categoryUrl : ''}", ${quotedElements}]}}`;
  return ARTICLE_DETAIL_DATA!=null?(
    <Layout navtrendingg={navtrending}>
      <Head>
      <link rel="canonical" href={DomainPrefixes.UrlPrifix+'/'+ARTICLE_DETAIL_DATA.categoryUrl+'/'+subcatt+removeLastId(ARTICLE_DETAIL_DATA.webTitleUrl).toLowerCase()+'-'+ARTICLE_DETAIL_DATA.id} />
        {ARTICLE_DETAIL_DATA && <Meta articledetaildata={ARTICLE_DETAIL_DATA} urlRoughter={routerUrlRefine} />}
      </Head>
      {ARTICLE_DETAIL_DATA && <GoogleAnalytics articledetaildata={ARTICLE_DETAIL_DATA} />}
      {ARTICLE_DETAIL_DATA && <Ga4Amp articledetaildata={ARTICLE_DETAIL_DATA}/>}
      {ARTICLE_DETAIL_DATA && <Breadcrum articledetaildata={ARTICLE_DETAIL_DATA} urlRoughter={routerUrlRefine} />}
      {ARTICLE_DETAIL_DATA && <ArticleBody jsonObj={jsonObj}  articledetaildata={ARTICLE_DETAIL_DATA} urlRoughter={routerUrlRefine}  />}
      <div className="adBox tabolabad">
        <amp-embed
          width="100"
          height="100"
          type="taboola"
          layout="responsive"
          data-publisher="jagrannewmedia-marathijagran"
          data-mode="thumbnails-a"
          data-placement="Below Article Thumbnails AMP"
          data-target_type="mix"
          data-article="auto"
          data-url={`${DomainPrefixes.UrlPrifix}${routerUrl}`}
        ></amp-embed>
      </div>
    </Layout>
    
  ):(<Custom404></Custom404>)
}
export const getServerSideProps = async (context) => {
  const {query} = context;
  const {category, id } = query;
  //console.log(payload);
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };

  let ARTICLE_DETAIL_API = PageAPI.Article_API + id;
  const ARTICLE_DETAIL_DATA = await axios.get(ARTICLE_DETAIL_API,payload).then((resp) => { return resp.data }).catch(() => { return null });

 return { props: { ARTICLE_DETAIL_DATA} }
}
//module.exports.postcss = true