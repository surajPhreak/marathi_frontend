import axios from "axios";
import Head from "next/head";
import { DomainPrefixes } from "../../component/utils/ejConfig";
import { useRouter } from "next/router";
import HeadInjection from "../../component/seo/DetailHeadComp";
import GoogleAnalyticsDetails from "../../component/seo/GoogleAnalyticsDetails";
import Layout from "../../component/layout/layout";
import { PageAPI } from "../../component/utils/ejConfig";
import Breadcrum from "../../component/global/breadcrumb";
import DefineSlotDetail from "../../component/ads/defineSlotDetail";
import Medium300x250 from "../../component/ads/medium300x250";
import { useEffect } from "react";
import LazyLoad from "react-lazy-load";
import DetailsSchema from "../../component/seo/DetailsSchema";
import SeoCommonSchema from "../../component/seo/SeoDetailSchema";
import dynamic from 'next/dynamic';

import SeoCommonScript from "../../component/seo/seoCommonScript";

const ArticleRecommendation = dynamic(() => import("../../component/detail/ArticleRecommendation"));
const ArticleTag = dynamic(() => import('../../component/detail/ArticleTag'), {
  loading: () => <p>Loading...</p>,
})
const DeatailPage = dynamic(() => import('../../component/detail/DetailComp'), {
  loading: () => <p>Loading...</p>,
})
const RelatedTag = dynamic(() => import('../../component/detail/RelatedTag'), {
  loading: () => <p>Loading...</p>,
})
const CategoryBasedNews = dynamic(() => import('../../component/home/categoryBaseLong'), {
  loading: () => <p>Loading...</p>,
})
const Custom404 = dynamic(() => import('../404'), {
  loading: () => <p>Loading...</p>,
})
export default function Home(props) {
  const {StateDate, JagranSpecialData1, articleData1, relatedArticleData, category, headerdata, footerdata, navtrending,sidebar,subcategory} = props;
   const topNewsAdata1 = StateDate?StateDate.posts : '';  
  const JagranSpecialData = JagranSpecialData1 ? JagranSpecialData1.posts : '';
  const subcatt = articleData1 && articleData1.subcategoryUrl?articleData1.subcategoryUrl+'/':'';

  const routerUrl = useRouter().asPath;

  function removeLastId(str) {
    const reLast = /-\d+$/;
  
    //console.log(str.replace(reLast, ""));
    //console.log(str.replace(reLast, ""));
    return str.replace(reLast, "");
  }

  const routerUrlRefine = routerUrl.replace('lite/', '');
  // console.log(LifeStyleData);

  useEffect (() => {

    const shareBtn = document.querySelector('.share-btn1');
    //const shareMsg = document.querySelector('.share-btn-msg');
if(shareBtn){
    const ogBtnContent = shareBtn.textContent;
    const title = document.querySelector('h1').textContent;
    const url = document.querySelector('link[rel=canonical]') &&
        document.querySelector('link[rel=canonical]').href ||
        window.location.href;
    shareBtn.addEventListener('click', () => {
        if (navigator.share) {
            navigator.share({
                title,
                url
            }).then(() => {
                //showMessage(shareBtn, 'Thanks!');
                console.log("Thanks")
            })
                .catch(err => {
                    // showMessage(shareBtn, `Couldn't share`);
                    console.log("Couldn't share")
                });
        } else {
            //showMessage(shareMsg, 'Not supported');
            console.log("Not supported")
        }
    });


      var widthWindow = window.innerWidth;
      if(widthWindow >= 1024){
        scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true) 
      }
      var scroll=0;
      function showAds(showid, i){
          var para = document.createElement("script");
          var divbx = document.createElement("div");
          divbx.id=showid;
          var a = "googletag.cmd.push(function() { googletag.display('"+divbx.id+"'); });";
          var t = document.createTextNode(a);   
          para.appendChild(t);
          divbx.appendChild(para);
          document.getElementById("target-"+i).appendChild(divbx);
      }
      function scriptG(url,asyncTT){
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = url;
        script.asyncT = "async";
        script.id = asyncTT;
        document.body.appendChild(script);
      }
      var articleRecomended= document.getElementById('articleRecomended')?document.getElementById('articleRecomended').innerHTML:''
      if(document.getElementById('articleRecomended'))
      document.getElementById('articleRecomended').innerHTML=''

      window.addEventListener("scroll", function(){
  
          if(scroll==0){      
          if(document.getElementById('recomdedArticle')){document.getElementById('recomdedArticle').innerHTML=articleRecomended}
            /*Taboola*/
            window._taboola = window._taboola || [];
            _taboola.push({article:'auto'});
            !function (e, f, u, i) {
              if (!document.getElementById(i)){
                e.async = 1;
                e.src = u;
                e.id = i;
                f.parentNode.insertBefore(e, f);
              }
            }(document.createElement('script'),
            document.getElementsByTagName('script')[0],
            '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
            'tb_loader_script');
            if(window.performance && typeof window.performance.mark == 'function')
            { window.performance.mark('tbl_ic'); }
            window._taboola = window._taboola || [];
            _taboola.push({
              mode: 'thumbnails-a',
              container: 'taboola-below-article-thumbnails',
              placement: 'Below Article Thumbnails',
              target_type: 'mix'
            });
            window._taboola = window._taboola || [];
            _taboola.push({flush: true});
            /*Taboola*/

            // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);

            if(widthWindow >= 1024){
              // if(document.getElementById('target-1')){ showAds('al_medium_300x250', 1)}
              // if(document.getElementById('target-9')){ showAds('al_bottom_300x250', 9)}              
              // if(document.getElementById('target-3')){ showAds('midarticle_480x320', 3)}
              // if(document.getElementById('target-10')){ showAds('al_interstitial_1x1', 10)}     
              if(document.getElementById('target-15')){ showAds('al_video_interstitial_1x1', 15)}           
              // if(document.getElementById('target-19')){ showAds('innovation_1x1', 19)}           
              // if(document.getElementById('target-20')){ showAds('inimage_1x1', 20)}           
            }else{  
              scriptG('https://securepubads.g.doubleclick.net/tag/js/gpt.js', true)   
              if(document.getElementById('target-4')){ showAds('al_top_300x250_m', 4)}         
              // if(document.getElementById('target-5')){ showAds('al_medium_300x250_m', 5)}
              // if(document.getElementById('target-17')){ showAds('al_bottom_300x250_m', 17)}
              // if(document.getElementById('target-12')){ showAds('al_interstitial_1x1_m', 12)}
              // if(document.getElementById('target-13')){ showAds('al_medium_300x50_m', 13)}
              if(document.getElementById('target-15')){ showAds('al_video_interstitial_1x1', 15)}
              // if(document.getElementById('target-16')){ showAds('anchor_ads_sticky', 16)}
              // if (document.getElementById("target-51")) {showAds("al_sticky_320x50_m", 51);}
              // if (document.getElementById("target-52")) {showAds("innovation_mobile1x1", 52);}
              // if (document.getElementById("target-53")) {showAds("inimage_mobile1x1", 53);}

            }
            scriptG('https://www.instagram.com/embed.js', false)
            scriptG('https://platform.twitter.com/widgets.js', false);
          
            function imageOpt(tagpass){
              var imgEl = document.getElementsByTagName(tagpass);
                    for (var m=0; m<imgEl.length; m++) {
                  if(imgEl[m].getAttribute('data-src')) {
                    imgEl[m].setAttribute('src',imgEl[m].getAttribute('data-src'));
                    imgEl[m].removeAttribute('data-src');
                  }
                }
              }
  
             imageOpt('img');
             //imageOpt('script');
             imageOpt('iframe');   
             
            scroll=1;    
          }
      });
    }
      //////
  }, []);
  return articleData1 !=null ? (
    <>
      <Layout headerdata={headerdata} footerdata={footerdata} sidebar={sidebar} navtrending={navtrending} Title={(articleData1.metaTitle) ? articleData1.metaTitle  : articleData1.webTitle} Keywords={(articleData1.metaKeywords) ? articleData1.metaKeywords : ''} Description={(articleData1.metaDescription) ? articleData1.metaDescription :''} articleImgPath={(articleData1.bigImage == null || articleData1.bigImage == undefined)? '': articleData1.bigImage} fixUrlCanonical={category.toLowerCase()+'/'+subcatt.toLowerCase()+removeLastId(articleData1.webTitleUrl).toLowerCase()+'-'+articleData1.id}>
      
          
        <Head>
        {articleData1.postType=='post'?<link rel="amphtml" href={'https://www.marathijagran.com/' + category.toLowerCase()+'/'+subcatt.toLowerCase()+removeLastId(articleData1.webTitleUrl).toLowerCase()+'-'+articleData1.id+"/amp"} />:''}
        
          <HeadInjection articledata={articleData1}  />
          <SeoCommonScript></SeoCommonScript>
          <link rel="preload" as="image" href={DomainPrefixes.ImagePath+articleData1.largeImage}></link>
        </Head>
        
        <SeoCommonSchema articledata={articleData1}></SeoCommonSchema>
        
        <GoogleAnalyticsDetails  articledetaildata={articleData1}  />
        <DetailsSchema articledata={articleData1}></DetailsSchema>
        <DefineSlotDetail categoryNameURL={category} metaKeywords={(articleData1.metaKeywords) ? articleData1.metaKeywords : ''} tagData={articleData1.tags ? articleData1.tags : ''}/>

        <Breadcrum category={category} subcategory={subcategory} />
        <div className="main-content spacing">
          <div className="left-col">
            <div className="ls-area-body hidelisting">
            {topNewsAdata1 && <LazyLoad><CategoryBasedNews categoryData={topNewsAdata1} compHeadTxt={"महाराष्ट्र"} /></LazyLoad> }
            <div className="eweb"><div className="ads bottom-300x250"><div id="target-9"></div></div></div>
          
            </div>
          </div>
          <div className="main-col">
            <div className="ls-area-body">
              {/* <Top300x250/> */}
              {articleData1 && <DeatailPage articledata={articleData1} recommendation={relatedArticleData} />}
      
              {articleData1.tags && <ArticleTag articledata={articleData1.tags} routerUrl={routerUrl}></ArticleTag>}
              {category=='latest-news' ? '' : 
              (relatedArticleData && <RelatedTag articledata={articleData1} relatedData={relatedArticleData}></RelatedTag>)
              }
              {category=='latest-news' ? '' : 
              relatedArticleData &&  <div id="articleRecomended" style={{'display':'none'}}><ArticleRecommendation articledata={articleData1} recommendation={relatedArticleData} /></div>
            }  
            </div>
          </div>
          <div className="right-col hidelisting">
            <div className="ls-area-body">
                  <div className="eweb"><div className="ads top-300x250"><div id="al_top_300x250"></div></div></div>
                  {JagranSpecialData &&   <LazyLoad><CategoryBasedNews categoryData={JagranSpecialData} compHeadTxt={"जागरण विशेष"} /></LazyLoad>}
                  <Medium300x250 /> 
            </div>
          </div>
        </div> 


        <div id="hjdg"><div className="ads al_video_interstitial"><div id='target-15'></div></div></div> 
        <div className="stickyads"><div className="ads emobilef"><div id='target-16'></div></div></div> 
        <div className="eweb"><div className="ads"><div id="target-19"></div></div></div>
        <div className="eweb"><div className="ads"><div id="target-20"></div></div></div>
        <div className="ads emobilef"><div id='target-52'></div></div>
        <div className="ads emobilef"><div id='target-53'></div></div>
        <div className="taboolaads">
          <div id="taboola-below-article-thumbnails"></div>
        </div>
        {/* <script type="text/javascript" dangerouslySetInnerHTML={{__html:` window._taboola = window._taboola || [];
  _taboola.push({homepage:'auto'});
  !function (e, f, u, i) {
    if (!document.getElementById(i)){
      e.async = 1;
      e.src = u;
      e.id = i;
      f.parentNode.insertBefore(e, f);
    }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js',
  'tb_loader_script');
  if(window.performance && typeof window.performance.mark == 'function')
    {window.performance.mark('tbl_ic');}`}}>
 
        </script>
        <div id="taboola-below-home-thumbnails"></div>
<script type="text/javascript" dangerouslySetInnerHTML={{__html:`  window._taboola = window._taboola || [];
_taboola.push({
  mode: 'thumbnails-a',
  container: 'taboola-below-home-thumbnails',
  placement: 'Below Home Thumbnails',
  target_type: 'mix'
});`}}>

      </script>
      <script type="text/javascript" dangerouslySetInnerHTML={{__html:`  window._taboola = window._taboola || [];
  _taboola.push({flush: true});`}}>

</script> */}
        <a href="#" aria-label="Read more" className="share-btn1" style={{display:'none'}}><svg><use href="#share-icon"></use></svg></a>
      </Layout>
    </>
   ) : (
    <Custom404 />
    
  );
}
export const getServerSideProps = async (context) => {
  const {query} = context;

  const {category, tittle, id,subcategory=''} = query;
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };


  
  function CategoryDataa(category, nuOfStory) { return PageAPI.Category_API + category + '/1/' + nuOfStory; }  
  function CategoryDataExcludeId (category, nuOfStory,ids){ return PageAPI.Category_API + category +'/1/' + nuOfStory+'?exclude='+ids; } 
  const a1 =  axios.get(CategoryDataExcludeId('maharashtra', 4,id),payload).then((resp) => {
    return resp.data
  }).catch((error) => {  return null; });
  const a2 =  axios.get(CategoryDataExcludeId ('jagran-special', 4,id),payload).then( (resp) => {return resp.data} ).catch( (error) => { return null} );

  const articlePath = PageAPI.NonAMPArticle_API+id  ;

  const a3 =  axios.get(articlePath,payload).then( (resp) => {return resp.data} ).catch( (error) => { return null} );
  const a4 =  axios.get(CategoryDataExcludeId(category, 6,id),payload).then((resp) => {
    if (resp.data && resp.data.posts) { 
      resp.data.posts = resp.data.posts.map((el) => {
       return {...el,isHide:false}
      })
   }
    return resp.data
  }).catch((error) => { return null });
  const [StateDate,JagranSpecialData1,articleData1,relatedArticleData]=await Promise.all([a1,a2,a3,a4])

  

  return { props: { StateDate, JagranSpecialData1, articleData1, relatedArticleData, category,subcategory } }
};