import React from "react";
import { PageAPI } from "../component/utils/ejConfig";
import axios from "axios";

const sitemap = () => {
  return null;
};
export const getServerSideProps = async ({ res,query }) => {
  const BASE_URL = "http://localhost:3000";
  const payload = {  headers: { Authorization: process.env.API_TOKEN }  };
  function formatDateToCustomTimeZone(date, offset='+0530') {
    const utcDate = new Date(date.getTime() + (date.getTimezoneOffset() * 60000));
    const offsetHours = parseInt(offset.slice(0, 3), 10);
    const offsetMinutes = parseInt(offset.slice(3), 10);
    const offsetMilliseconds = (offsetHours * 60 + offsetMinutes) * 60 * 1000;
    const customTimeZoneDate = new Date(utcDate.getTime() + offsetMilliseconds);
    const formattedDate = customTimeZoneDate.toUTCString().replace('GMT', offset);
    return formattedDate;
  }
  

  const currentDate = new Date();
  const formattedDate = formatDateToCustomTimeZone(currentDate, '+0530');

  
  
      if(query.subcat){
            if(query.category == "tag"){
              var apiUrl = PageAPI.feed_TagwordBase_API+"/"+query.subcat+"/1/10";
            }else{
              var apiUrl = PageAPI.feed_SubcategoryListing_API+query.category+"/"+query.subcat+"/1/10";
            }
      }else{
        if(query.category == "latest-news"){
          var apiUrl = PageAPI.feed_LatestPosts_API+"1/10";
        }else{
          var apiUrl = PageAPI.feed_Category_API+query.category+"/1/10";
        }
      }
      function escapeXml(unsafe) {
        return unsafe.replace(/[<>&'"]/g, function (c) {
            switch (c) {
                case '<': return '&lt;';
                case '>': return '&gt;';
                case '&': return '&amp;';
                case '\'': return '&apos;';
                case '"': return '&quot;';
            }
        });
      }

const postData = await axios.get(apiUrl, payload).then( (resp) => {return resp.data} ).catch( (error) => {return null} );
const sitemap = `<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:media="http://search.yahoo.com/mrss/">
  <channel>
    <lastBuildDate>${formattedDate}</lastBuildDate>
    <title>Marathi News, Breaking News in Marathi, Latest News in Marathi - Marathi Jagran</title>
    <description>Marathi Jagran Marathi News: , Breaking News in Marathi, Top News Headlines, Marathi Latest News , Today Top News, Marathi News Today on Marathi Jagran.</description>
    <link>https://marathijagran.com/</link>
    ${postData?.posts?.map(post => `<item>
      <guid isPermaLink="true">https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</guid>
      <pubDate>${formatDateToCustomTimeZone(new Date(post.pubDate))}</pubDate>
      <title><![CDATA[ ${post.headline} ]]></title>
      <description><![CDATA[ ${post.summary} ]]></description>
      <content:encoded>${escapeXml(post.content)}</content:encoded>
      <link>https://www.marathijagran.com/${post.categoryUrl}/${post.subcategoryUrl?post.subcategoryUrl+'/':''}${post.webTitleUrl}-${post.id}</link>
      <author><![CDATA[ ${post.author} ]]></author>
    </item>`).join('\n')}
  </channel>
</rss>`;



  res.setHeader("Content-Type", "text/xml");
  res.write(sitemap);
  res.end();

  return {
    props: {},
  };
};

export default sitemap;