import Layout from "../../component/layout/layout";
import Head from "next/head";
import Link from 'next/link'
import SeoCommonScript from "../../component/seo/seoCommonScript";
export default function aboutus(props){
    const{headerdata, footerdata, navtrending}=props
    return(        
        <>
          <Layout headerdata={headerdata} footerdata={footerdata} navtrending={navtrending} Title="Sitemap - Jagran English Sitemap: Latest News India, World News, Business News, Cricket News" Keywords="English Jagran News, English Jagran News Headlines, Latest English Jagran News, English Jagran News Today, English Jagran News Online, English Jagran News India" Description="Read the latest English Jagran news article, health tips, fashion trends along with beauty tips, photos, videos and follow the latest celebrities fashion many more at jagran english">
          <Head><SeoCommonScript /></Head>
          <div className="siteMapN">
                <div className="allhead"><h1>Sitemap</h1></div>
                <div className="sitemap_con">
                    <ul>
                         <li><h2><Link href="/">Home</Link></h2></li>
                        <li><h2><a href="/india">India</a></h2></li>
                        <li><h2><a href="/world">World</a></h2></li>
                        <li><h2><a href="/politics">Politics</a></h2></li>
                        <li><h2><a href="/entertainment">Entertainment</a></h2>               
                            <ul className="catlistParallel">
                                <li><h2><a href="/entertainment/news">News</a></h2></li>
                                <li><h2><a href="/entertainment/movie-reviews">Movie Reviews</a></h2></li>
                                <li><h2><a href="/entertainment/bollywood">Bollywood</a></h2></li>
                            </ul>
                        </li>
                        <li><h2><a href="/tv">TV</a></h2></li>
                        <li><h2><a href="/sports">Sports</a></h2></li>
                        <li><h2><a href="/business">Business</a></h2></li>
                        <li><h2><a href="/technology">Technology</a></h2></li>
                        <li><h2><a href="/lifestyle">Lifestyle</a></h2></li>
                        <li><h2><a href="/education">Education</a></h2></li>
                        <li><h2><a href="/auto">Auto</a></h2></li>
                        <li><h2><a href="/elections">Elections</a></h2></li>
                    </ul>
                </div>
            </div>
          </Layout>               
        </>
    )
}