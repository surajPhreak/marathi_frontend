import Layout from "../../component/layout/layout";
import Head from "next/head";
import Script from "next/script";
//import Image from 'next/image';
import DisclaimerComp from "../../component/static/DisclaimerComp";
import SeoCommonScript from "../../component/seo/seoCommonScript";
export default function disclm(props){
  const{headerdata, footerdata, navtrending} =props
    return(
        
        <>
          <Layout headerdata={headerdata} footerdata={footerdata} navtrending={navtrending} Title="Contact Jagran English: News, News Headlines, Latest News Today, Online News, Current News, Top News – english.jagran.com" Keywords="English Jagran News, English Jagran News Headlines, Latest English Jagran News, English Jagran News Today, English Jagran News Online, English Jagran News India" Description="Read the latest English Jagran news article, health tips, fashion trends along with beauty tips, photos, videos and follow the latest celebrities fashion many more at jagran english">
          <Head><SeoCommonScript /></Head>
          <DisclaimerComp />                
        </Layout>
        
                
        </>
    )
}