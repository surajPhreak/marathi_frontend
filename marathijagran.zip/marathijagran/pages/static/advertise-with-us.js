import Layout from "../../component/layout/layout";
import Head from "next/head";
import SeoCommonScript from "../../component/seo/seoCommonScript";
export default function aboutus(props){
    const{headerdata, footerdata} =props
    return(
        
        <>
          <Layout headerdata={headerdata} footerdata={footerdata} Title="Advertise with Jagran English - Business News, Breaking News, Latest News Topics" Keywords="English Jagran News, English Jagran News Headlines, Latest English Jagran News, English Jagran News Today, English Jagran News Online, English Jagran News India" Description="Read the latest English Jagran news article, health tips, fashion trends along with beauty tips, photos, videos and follow the latest celebrities fashion many more at jagran english">
          <Head><SeoCommonScript /></Head>
          <div className="container_adv">
                <div className="allhead"><h2>Advertise with us</h2></div>
                <div className="advbody">
                    <div className="box1 inquiries">
                        <div className="allhead"><h2>Ad inquiries for Web</h2></div>
                        <h3>JAGRAN PRAKASHAN LTD </h3>
                        <p>20TH FLOOR, C-1 TOWER-B,<br />
                        World Trade Tower, SECTOR-16,<br />
                        Noida, Gautam Buddha Nagar,<br />
                        Uttar Pradesh, 201301. <br/>
                        Phone: +91-0120-4716000 <br />  
                            E-mail: <a href="mailto:advt@mmionline.in">advt@mmionline.in</a>
                        </p>
                    </div>
                    <div className="box2 tie-ups">
                        <div className="allhead"><h2>Jagran.com Content Tie-ups</h2></div>
                        <p>Looking ahead for increased visibility? Jagran.com gives you the right platform to showcase your exclusive content.</p>
                        <p>Contact us at:</p>
                        <h3>JAGRAN PRAKASHAN LTD </h3>
                        <p>20TH FLOOR, C-1 TOWER-B,<br />
                        World Trade Tower, SECTOR-16,<br />
                        Noida, Gautam Buddha Nagar,<br />
                        Uttar Pradesh, 201301. <br/>
                        Phone: +91-0120-4716000 <br />  
                            E-mail: <a href="mailto:partnership@mmionline.in">partnership@mmionline.in</a>
                        </p>
                    </div>
                    <div className="box3 inquiries-print">
                        <div className="allhead"><h2>Ad inquiries for Print</h2></div>
                        <p className="click"><a target="_blank" rel="noreferrer" href="http://jplcorp.in/JPLWeb/JPL_AdWithUs.aspx">Click Here</a> &raquo;</p>
                    </div>
                    <div className="box2 gallery-box">
                        <div className="allhead"><h2>Showcase Gallery For Rich Media Ads - Desktop</h2></div>
                        <ul className="list-adver">
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/roadblock-with-standard-Ad.html">Roadblock Standard</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/roadblock-with-expando-Ad.html"> Roadblock Expandable</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/Roadblock_pagepusher.html">Roadblock Pagepusher</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/roadblock-with-overlay-base-Ad.html">Roadblock Overlay</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/billboard.html">Billboard Fixed</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/Billboard_with_BaseAd.html">Billboard with BaseAd </a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/page-tear.html">Page Tear</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/Jagran_Wallpaper.html">Wallpaper - 300x600</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/Jagran_Data_Selfie.html">Data Selfie</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/Jagran_Synchronized_Ad_Takeover.html">Synchronized Ad Takeover</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/ad/Jagran_Interactive_Flipflop.html">Interactive Flipflop</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/sitesync.html">Site Sync</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/jagran/sitetakeover.html">Site Takeover</a></li>
                        </ul>
                    </div>
                    <div className="box2 gallery-box">
                        <div className="allhead"><h2>Showcase Gallery For Rich Media Ads - Mobile</h2></div>
                        <ul className="list-adver">
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/demo_event/Full-Page-Flex-Mobile.html">Full Page Flex Mobile</a></li>
                            <li><a target="_blank" rel="noreferrer" href="http://events.jagran.com/demo_event/Expandable-Mobile.html">Expandable Mobile</a></li>
                        </ul>
                    </div>
                </div>
            </div>   
          </Layout>
        </>
    )
}