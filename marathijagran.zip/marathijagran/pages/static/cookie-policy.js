import Layout from "../../component/layout/layout";
import Head from "next/head";
import SeoCommonScript from "../../component/seo/seoCommonScript";
export default function aboutus(props){
    const{headerdata, footerdata, navtrending} =props
    return(
        
        <>
          <Layout headerdata={headerdata} footerdata={footerdata} navtrending={navtrending} Title="Jagran English Cookie Policy" Keywords="" Description="Cookie Policy - MMI is committed to respecting user’s online privacy">
          <Head><SeoCommonScript /></Head>
          <article className="newsBox cookie-policy">
                <br />
                <h1>Cookie Policy</h1>
                <p>Jagran Prakashan Limited Group (&ldquo;we&rdquo;, &ldquo;us&rdquo;, &ldquo;JPL&rdquo;) is committed to respecting your ((&ldquo;you&rdquo;, &ldquo;data subject&rdquo;, &ldquo;user&rdquo;, &ldquo;subscriber) online privacy &rdquo;)  This Cookie Policy explains how and why cookies and other similar technologies may be stored on and accessed from your device when you use or visit jagran or application that posts a link to this Policy (collectively, &ldquo;the Sites&rdquo;). This Cookie Policy should be read together with our Privacy Policy and Terms of Use. jagran uses cookies, tags and other technologies when you use any of the services on theJPL websites, mobile sites or mobile apps (collectively &ldquo;the services&rdquo;). Cookies are used to ensure everyone has their best possible experience. Cookies also help us keep your account safe. By continuing to visit or use our services, you are agreeing to the use of cookies and similar technologies for the purposes we describe in this policy. If you prefer not to receive cookies or web beacons, then you should stop using our website/ mobile application, or consult your browsing and third party cookie settings as described below.</p>
                <p><strong>What are Cookies and Other Tracking Technologies?</strong></p>
                <p>Cookies are small pieces of text stored by a website/ mobile application you visit in your browser and subsequently sent by your web browser in every request to the website/ mobile application. A cookie file is stored in your web browser and allows the Site or a third-party to recognize you and make your next visit easier and the Site more useful to you. Essentially, cookies are a user&rsquo;s identification card for the jagran servers. Cookies allow jagran to serve you better and more efficiently, and to personalize your experience on our Site. Web beacons, tags and scripts may be used in the Websites or in emails to help us to deliver cookies, count visits, understand usage and campaign effectiveness and determine whether an email has been opened and acted upon. We may analyse or perform analysis based on the use of these technologies and generate reports on an individual and aggregated basis.</p>
                <p>Cookies can be &quot;persistent&quot; or &quot;session&quot; cookies. A persistent cookie helps us recognize you as an existing user, so it&rsquo;s easier to return to jagran or interact with our services without signing in again. After you sign in, a persistent cookie stays in your browser and will be read by jagran when you return to one of our sites/ applications or a partner site that uses our services. Session cookies only last for as long as the session (usually the current visit to a website/ application or a browser session).</p>
                <p>The other tracking technologies work similarly to cookies and place small data files on your devices or monitor your website/ mobile application activity to enable us to collect information about how you use our websites/ applications. This allows our websites/ applications to recognize your device from those of other users of the Sites. The information provided below about cookies also applies to these other tracking technologies.</p>
                <p><strong>How do our websites/ mobile applications use cookies and other tracking technologies?</strong></p>
                <p>jagran uses cookies and other tracking technologies to identify you and your interests, to remember your preferences, and to track your use of our website/ mobile application. We also use cookies and other tracking technologies to control access to certain content on our website/ mobile application, protect the websites/ mobile applications, and show you advertisements and to process any requests that you make to us.</p>
                <p>To administer our website/ mobile application and for research purposes, jagran also has contracted with third-party service providers to track and analyse statistical usage and volume information from our site users. These third-party service providers use persistent cookies to help us to improve the user experience, manage our site content, and analyse how users navigate and utilize the website/ mobile application.</p>
                <p><strong>We categorize cookies as follows</strong></p>
                <p>Each cookie falls within one of the four following categories:</p>
                <div className="scorTableData1">
                    <table border="1" cellPadding="0" cellSpacing="0" width="100%">
                        <tbody>
                            <tr>
                                <td>Category</td>
                                <td>Description</td>
                            </tr>
                            <tr>
                                <td>1. Essential Cookies</td>
                                <td>Essential cookies (First Party Cookies) are sometimes called &ldquo;strictly necessary&rdquo; as without
                                    them we cannot provide many services that you need on the website/ mobile application. For example,
                                    essential cookies help remember your preferences as you move around the website/ mobile application.
                                </td>
                            </tr>
                            <tr>
                                <td>2. Analytics Cookies</td>
                                <td>These cookies track information about visits to the jagran so that we can make improvements and report
                                    our performance. For example: analyse visitor and user behaviour so as to provide more relevant content
                                    or suggest certain activities. They collect information about how visitors use the Websites/ mobile
                                    application, which site the user came from, the number of each user&rsquo;s visits and how long a user
                                    stays on the Website/ mobile application. We might also use analytics cookies to test new ads, pages, or
                                    features to see how users react to them.</td>
                            </tr>
                            <tr>
                                <td>3. Functionality or Preference Cookies</td>
                                <td>During your visit to the website/ mobile application, cookies are used to remember information you have
                                    entered or choices you make (such as your username, language or your region) on the website/ mobile
                                    application. They also store your preferences when personalizing the website/ mobile application to
                                    optimize your use of jagran. These preferences are remembered, through the use of the persistent
                                    cookies, and the next time you visit the website/ mobile application you will not have to set them
                                    again.</td>
                            </tr>
                            <tr>
                                <td>4. Targeting or Advertising Cookies</td>
                                <td>These Third Party Cookies are placed by third party advertising platforms or networks in order to,
                                    deliver ads and track ad performance, enable advertising networks to deliver ads that may be relevant to
                                    you based upon your activities (this is sometimes called &ldquo;behavioural&rdquo;&ldquo;tracking&rdquo;
                                    or &ldquo;targeted&rdquo; advertising) on the website/ mobile application. They may subsequently use
                                    information about your visit to target you with advertising that you may be interested in, on the jagran
                                    and other websites. For example, these cookies remember which browsers have visited the Website/ mobile
                                    application. Most types of these cookies track consumers via their Device ID or IP address therefore
                                    they may collect personal data.</td>
                            </tr>
                            <tr>
                                <td>5. Third party Cookies</td>
                                <td>We use a number of partners that may also set cookies on your device on our behalf when you visit our
                                    website/ mobile application to allow them to deliver tailored advertising within their domains, for
                                    example Google Analytics. We endeavour to identify these cookies before they are used so that you can
                                    decide whether you wish to accept them or not. Based on the type of cookies used by the relevant
                                    third-party, the information these cookies collect may include personal data but they would not be able
                                    to directly identify you as an individual or have any of your personal information such as Name, E-mail
                                    id or mobile number.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p><strong>When does jagran place cookies?</strong></p>
                <p>We use cookies on our websites, mobile sites and mobile applications. Any browser visiting these sites will receive cookies from us which helps us identify you more quickly when you return. We will not use &quot;cookies&quot; or other technologies to follow your click stream on the Internet generally, but will use them, and other devices, to determine which pages or information you find most useful or interesting at our own website/ mobile application.</p>
                <p><strong>How cookies are used for online analytics purposes?</strong></p>
                <p>We may use web analytics services on our Services, such as, but not limited to those of Google Analytics. These services help us analyse how users use the services, including by noting the third-party site from which you arrive. The information collected by the technology will be disclosed to or collected directly by these service providers, who use the information to evaluate your use of the Services. We also use Google Analytics for certain purposes related to online marketing, as described in the following section.</p>
                <p><strong>How are cookies used for advertising purposes?</strong></p>
                <p>Cookies and other ad technology such as beacons, pixels, and tags help us serve relevant ads to you more effectively. They also help us provide aggregated auditing, research, and reporting for advertisers, understand and improve our service, and know when content has been shown to you. We work with website/ mobile application analytics and advertising partners, including Lotame, Facebook, etc. to deliver jagran advertisements on third party publisher sites - these partners may set cookies on your device&rsquo;s web browser. These cookies allow our partners to recognize your device so that the ad server can show you jagran advertisements elsewhere on the Internet, and so that our analytics software can measure your engagement and interactions while using jagran services. In this way, ad servers may compile anonymous, de-identified information about where you, or others who are using your device, saw our advertisements, whether or not you interacted with our advertisements, and actions performed on subsequent visits to jagran and its applications. This information allows an ad network to deliver targeted advertisements that they believe will be of most interest to you, and it allows jagran to optimize the performance of our advertising campaigns and the usability of our website/ mobile application. In other words, we use analytics data in concert with data about our online ads that have been shown using the Google Display Network, Facebook for Advertisers, or other online advertising networks. By doing so, we can understand how anonymous users interacted with our website/ mobile application after seeing our ads. </p>
                <p><strong>What third-party cookies does jagran use?</strong></p>
                <p>Please note that the third parties (advertising networks and providers of external services like web traffic analysis services) may also use cookies on our Services. Also, note that the names of cookies, pixels and other technologies may change over time. </p>
                <p>We use trusted partners to help us service advertising, who may place cookies on your device. We also pull through content from social networks into our own pages, such as embedded Facebook feeds. The social networks, such as Facebook, Google, etc. may themselves also put cookies on your machine. If a user logs into Facebook, Twitter or Google+ via our website/ mobile application, they will leave a cookie on the users&apos; device. This is the same process as if the user logs into these social networks directly.</p>
                <p>We also use Google Analytics on our Services to help us analyse how our Services are used.  Google Analytics uses performance cookies to track customer&rsquo;s interactions. For example, by using cookies, Google can tell us which pages our users view, which are most popular, what time of day our website/ mobile application is visited, whether visitors have been to our website/ mobile application before, what website referred the visitor to our website/ mobile application, and other similar information.  All of this information is anonymized. </p>
                <p>We have limited control over these &apos;third party&apos; cookies, so we suggest that you check the respective privacy policies for these external services to help you understand what data these organisations hold about you ,what they do with it and how you can opt-out of the same.</p>
                <p>Facebook : <a rel="noreferrer" target="_blank" href="https://www.facebook.com/policy.php">https://www.facebook.com/policy.php</a>
                <br />
                        Google AdWords: <a rel="noreferrer" target="_blank" href="https://support.google.com/adwords/answer/2549116?hl=en">https://support.google.com/adwords/answer/2549116?hl=en</a>
                <br />
                        Google Analytics: <a rel="noreferrer" target="_blank" href="http://www.google.com/analytics/learn/privacy.html">http://www.google.com/analytics/learn/privacy.html</a>.<br />
                        Google Tag Manager: <a rel="noreferrer" target="_blank" href="https://www.google.com/analytics/tag-manager/faq/">https://www.google.com/analytics/tag-manager/faq/</a>
                <br />
                        Google+: <a rel="noreferrer" target="_blank" href="https://www.google.com/policies/privacy/">https://www.google.com/policies/privacy/</a>
                <br />
                        Twitter: <a rel="noreferrer" target="_blank" href="https://twitter.com/en/privacy">https://twitter.com/en/privacy</a>
                <br />
                        Lotame: <a rel="noreferrer" target="_blank" href="https://www.lotame.com/about-lotame/privacy/lotame-and-gdpr/">https://www.lotame.com/about-lotame/privacy/lotame-and-gdpr/</a>
                <br />
                        Datability: <a rel="noreferrer" target="_blank" href="https://www.izooto.com/privacy-policy">https://www.izooto.com/privacy-policy</a>
                </p>
                <p><strong>What are Web Beacons?</strong></p>
                <p>jagran occasionally advertises on third party web sites. As part of our effort to track the success of our advertising campaigns, we may at times use a visitor identification technology such as &quot;web beacons,&quot; or &quot;action tags,&quot; which count visitors who have come to Our Site after being exposed to jagran banner ad on a third party site. We do not use this technology to access your personal information and it is only used to compile aggregated statistics about visitors who come to Our Site to gauge the effectiveness of our ads.</p>
                <p>By navigating on Our Site, you agree that we can place cookie and web beacons on your computer or device. If you prefer not to receive web beacons, then you should stop using Our Site, or consult your browsing settings.</p>
                <p><strong>How to control cookies?</strong></p>
                <p>Most browsers allow you to control cookies through their settings preferences. However, if you choose to turn off these cookies you will still see advertising on the internet but it may not be tailored to your interests. It does not mean that you won&apos;t be served any advertisements whilst you are online.  Whilst we have mentioned most of the third parties involved in using targeting or advertising cookies in the preceding section (What third-party cookies does jagranuse), the list is not exhaustive and is subject to change. Therefore, even if you choose to turn off all the third party cookies listed in section (What third-party cookies does jagran use), you may still receive some tailored advertisements and recommendations.</p>
                <p>There are a number of ways you can manage what cookies are set on your devices. Essential cookies, however, cannot be disabled. If you do not allow certain cookies to be installed, the website/ mobile application may not be accessible to you and/or the performance, features, or services of the website may be compromised. </p>
                <p>You can also manage this type of cookie in the privacy settings on the web browser you are using. Please note that if you use your browser settings to block all cookies you may not be able to access parts of our or others&apos; websites/ mobile applications. Please see below for more information.</p>
                <p>The browser settings for changing your cookies settings are usually found in the &apos;options&apos; or &apos;preferences&apos; menu of your internet browser. In order to understand these settings, the following links may be helpful. Otherwise you should use the &apos;Help&apos; option in your internet browser for more details.</p>
                <ol>
                    <li><a href="https://support.microsoft.com/en-us/help/17442/windows-internet-explorer-delete-manage-cookies" rel="noreferrer" target="_blank">Cookie settings in Internet Explorer</a></li>
                    <li><a href="https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences" rel="noreferrer"  target="_blank">Cookie settings in Firefox</a></li>
                    <li><a href="https://support.google.com/chrome/answer/95647" rel="noreferrer" target="_blank">Cookie settings in Chrome</a></li>
                    <li><a href="https://support.apple.com/kb/ph21411?locale=en_US" rel="noreferrer" target="_blank">Cookie settings in Safari</a></li>
                </ol>
                <p>More information:  To find out more about cookies, including how to see what cookies have been set and how to manage and delete them, visit <a rel="noreferrer" target="_blank" href="https://www.allaboutcookies.org">www.allaboutcookies.org</a>. You can learn more about opting out of receiving interest-based ads from other companies at <a rel="noreferrer" target="_blank" href="https://optout.aboutads.info">optout.aboutads.info </a>and <a rel="noreferrer" target="_blank" href="https://www.networkadvertising.org/choices">www.networkadvertising.org/choices</a>. In addition, certain third party advertising networks, like Facebook (pixels) and Google, permit users to opt out of or customize preferences associated with your internet browsing. To learn more about this feature from Google, click <a rel="noreferrer" target="_blank" href="https://myaccount.google.com/not-supported">here</a>. For further information about the Facebook Pixel, click <a rel="noreferrer" target="_blank" href="https://www.facebook.com/business/help/651294705016616">here</a>.</p>
                <p>If you have any queries regarding this Cookie Policy please contact us at <br />
                <a href="mailto:contactus@jagrannewmedia.com">contactus@jagrannewmedia.com</a>
                </p>
                <p><strong>Postal Address</strong> <br /> Jagran Prakashan Limited, 20th Floor, Plot No 1, Delhi Noida Direct Flyway, Central Auto Market Block B, C Block, Sector 16, Noida, Uttar Pradesh 201301</p>
                </article>
                <br />
          </Layout>
        </>
    )
}