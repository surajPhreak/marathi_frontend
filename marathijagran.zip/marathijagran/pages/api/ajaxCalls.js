import axios from "axios";

export default async function ajax(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*'); 
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST'); 
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');  
  const query = req.query;
  const { url } = query;
  try {
    const response = await axios(url,{headers:{Authorization:process.env.API_TOKEN}});  
    const data = await response.data;


      res.status(200).json(data);
  } catch (error) {

    // console.log(error)

      res.status(404).json({ error: 'Something went wrong' }); //pass our own error 
    }
}