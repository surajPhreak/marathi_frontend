
import Link from 'next/link';
import Image from 'next/image';


export default function Custom404(props) {  
  //const { headerdata, footerdata } = props
    return  (
       
        <div className="errorPage">
        <Image width={441} unoptimized height={200} src="https://img.marathijagran.com/2023/07/404.png" alt="error page" title="Page Not Found" />
        <p>आप जिस पेज़ को देखना चाहते है वो उपलब्ध नहीं है,<br /> कृपया <a href="https://marathijagran.com/"><strong>क्लिक करके, होम पेज</strong></a> पर वापस जाइए!</p>

      </div>
      
    )  
  }