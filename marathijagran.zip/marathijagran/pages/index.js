import axios from "axios";
import Layout from "../component/layout/layout";
import { PageAPI } from "../component/utils/ejConfig";
import Head from "next/head";
import HeadInjection from "../component/seo/HomeHeadComp";
import dynamic from "next/dynamic";

import PoneNews from "../component/home/pone";
//import TopDeals from "../component/events/top-deals/topDealsHome";
import DefineSlotHome from "../component/ads/defineSlotHome";
//import TaboolaAdsHome from "../component/ads/taboolaAd-home";
const CategoryBasedNews = dynamic(() =>
  import("../component/home/categoryBaseLong")
);
const CategoryBaseColComp = dynamic(() =>
  import("../component/home/categoryBaseColComp")
);
import WebStories from "../component/home/webStories";
import SeoCommonScript from "../component/seo/seoCommonScript";
import { useEffect } from "react";
//import React from "react";
import LazyLoad from "react-lazy-load";
import SeoCommonSchema from "../component/seo/SeoCommonSchema";

export default function Home(props) {
  const {
    StateDate,
    JagranSpecialData1,
    EntertainmentData1,
    SportsData1,
    Politics,
    ReligiontData1,
    HelathData1,
    FoodData1,
    BusinessData1,
    WorldData1,
    NationaltData1,
    HomePoneData,
    webStoriesData1,
    headerdata,
    footerdata,
    navtrending,
    sidebar,
  } = props;

  const homePoneData1 =
    HomePoneData && HomePoneData.posts ? HomePoneData.posts : "";

  //console.log(BusinessData1);

  //console.log(EntertainmentData);
  //const topDealsData1 = TopDealsData.docs;
   const schemaAarray_11=[];
   schemaAarray_11.push(`var dataLayer = window.dataLayer || []; dataLayer.push({'event':'pageview','tvc_page_type':'homepage','tvc_homepage_type':'homepage','language':'marathi'});
   `);
  useEffect(() => {
 
    var widthWindow = window.innerWidth;
    if (widthWindow >= 1024) {
      scriptG("https://securepubads.g.doubleclick.net/tag/js/gpt.js", true);
    }

    var scroll = 0;
    function showAds(showid, i) {
      var para = document.createElement("script");
      var divbx = document.createElement("div");
      divbx.id = showid;
      var a =
        "googletag.cmd.push(function() { googletag.display('" +
        divbx.id +
        "'); });";
      var t = document.createTextNode(a);
      para.appendChild(t);
      divbx.appendChild(para);
      document.getElementById("target-" + i).appendChild(divbx);
    }
    function scriptG(url, asyncTT) {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = url;
      script.asyncT = "async";
      script.id = asyncTT;
      document.body.appendChild(script);
    }
    window.addEventListener("scroll", function () {
      if (scroll == 0) {
        /*Taboola*/
        window._taboola = window._taboola || [];
        _taboola.push({ homepage: "auto" });
        !(function (e, f, u, i) {
          if (!document.getElementById(i)) {
            e.async = 1;
            e.src = u;
            e.id = i;
            f.parentNode.insertBefore(e, f);
          }
        })(
          document.createElement("script"),
          document.getElementsByTagName("script")[0],
          "//cdn.taboola.com/libtrc/jagrannewmedia-marathijagran/loader.js",
          "tb_loader_script"
        );
        if (
          window.performance &&
          typeof window.performance.mark == "function"
        ) {
          window.performance.mark("tbl_ic");
        }
        window._taboola = window._taboola || [];
        _taboola.push({
          mode: "thumbnails-a",
          container: "taboola-below-home-thumbnails",
          placement: "Below Home Thumbnails",
          target_type: "mix",
        });
        window._taboola = window._taboola || [];
        _taboola.push({ flush: true });
        /*Taboola*/

        // scriptG('https://cdn.izooto.com/scripts/a374bed090ff73104f619afa779310ea1884526f.js', false);
        if (widthWindow >= 1024) {
          // if (document.getElementById("target-1")) {
          //   showAds("al_medium_300x250", 1);
          // }
          // if (document.getElementById("target-2")) {
          //   showAds("al_bottom_300x250", 2);
          // }
          // if (document.getElementById("target-3")) {
          //   showAds("al_interstitial_1x1", 3);
          // }
          // if (document.getElementById("target-4")) {
          //   showAds("al_medium_728x90", 4);
          // }
          // if (document.getElementById("target-5")) {
          //   showAds("al_bottom_728x90", 5);
          // }
        } else {
          scriptG("https://securepubads.g.doubleclick.net/tag/js/gpt.js", true);
          if (document.getElementById("target-6")) {
            showAds("al_top_300x250_m", 6);
          }
          //if (document.getElementById("target-7")) {showAds("al_top_300x100_m", 7);}
          // if (document.getElementById("target-6")) {showAds("top_300x250_1_m", 6);}
          //if (document.getElementById("target-5")) {showAds("al_top_300x250_1_m", 5);}
          // if (document.getElementById("target-14")) {showAds("al_bottom_300x250_m", 14);}
          //if (document.getElementById("target-51")) {showAds("al_sticky_320x50_m", 51);}
          //if (document.getElementById("target-8")) {showAds("al_medium_300x250_m", 8);}
          //if (document.getElementById("target-9")) {showAds("al_bottom_300x250_m", 9);}
          //if (document.getElementById("target-10")) {showAds("al_interstitial_1x1_m", 10);}
        }

        scroll = 1;
      }
    });
  }, []);

  
  

  return (
    <>
      <Layout
        headerdata={headerdata}
        footerdata={footerdata}
        navtrending={navtrending}
        sidebar={sidebar}
        Title="Marathi News, Breaking News in Marathi, Latest News in Marathi - Marathi Jagran"
        Keywords="Marathi news, Marathi news, news in Marathi, Marathi Samachar, Marathi Samachar, latest news Marathi, breaking news in Marathi"
        Description="Marathi Jagran Marathi News: , Breaking News in Marathi, Top News Headlines, Marathi Latest News , Today Top News, Marathi News Today on Marathi Jagran. "
      >
        <Head>
          <HeadInjection />
          <SeoCommonScript />
        </Head>
        <SeoCommonSchema></SeoCommonSchema>

        <script dangerouslySetInnerHTML={{ __html: schemaAarray_11 }}></script>

        <DefineSlotHome
          metaKeywords={
            "Marathi Jagran Marathi News: , Breaking News in Marathi, Top News Headlines, Marathi Latest News , Today Top News, Marathi News Today on Marathi Jagran."
          }
        />
        {/* <div className="eweb" id="hjdg"><div className="ads pagepush-980x50"><div id='al_pagepush_980x50'></div></div></div> */}
        <div className="main-content">
          <h1 className="mvp-logo-title">Marathi News | मराठी बातम्या</h1>
        
          
          <div className="left-col">
            <div className="ls-area-body">
              {StateDate && StateDate.posts.length > 0 && (
                <>
                  <CategoryBasedNews
                    categoryData={StateDate.posts}
                    compHeadTxt={"महाराष्ट्र"}
                  />
                </>
              )}
              <div className="emobile">
                <div className="ads bottom-300x250">
                  <div id="target-7"></div>
                </div>
              </div>
              <div className="eweb">
                <div className="ads bottom-300x250">
                  <div id="target-2"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="main-col">
            <div className="ls-area-body">
              {homePoneData1 && homePoneData1.length > 0 && (
                <PoneNews homePoneData={homePoneData1} />
              )}
              <div className="emobile">
                <div className="ads medium-300x250">
                  <div id="target-6"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">
              <div className="eweb">
                <div className="ads top-300x250 mb50">
                  <div id="al_top_300x250"></div>
                </div>
              </div>
              {Politics && Politics.posts.length > 0 && (
                <>
                  <CategoryBasedNews
                    categoryData={Politics.posts}
                    compHeadTxt={"महाराष्ट्र राजकारण"}
                    type="tag"
                    categoryUrl={
                      Politics.sitemeta && Politics.sitemeta.categoryUrl
                        ? Politics.sitemeta.categoryUrl
                        : ""
                    }
                  />
                </>
              )}
              <div className="eweb">
                <div className="ads medium-300x250">
                  <div id="target-1"></div>
                </div>
              </div>

              {/* <LazyLoad><CategoryBasedNews categoryData={TrendingData} /></LazyLoad> */}
            </div>
          </div>
        </div>
        <div className="eweb">
          <div className="ads interstitial-1x1">
            <div id="target-3"></div>
          </div>
        </div>
        {/* <div className="">English Jagran interstitial Ad</div> */}
        <div className="emobile">
          <div className="ads interstitial-1x1">
            <div id="target-10"></div>
          </div>
        </div>

        <div className="web-story-main">
          {webStoriesData1 && <WebStories webStoriesData={webStoriesData1} />}
        </div>

        <div
          className="ads medium-728x90 ewebf"
          style={{ marginBottom: "30px", clear: "both" }}
        >
          <div id="target-4"></div>
        </div>
        <div className="emobile">
          <div className="ads medium-300x250">
            <div id="target-8"></div>
          </div>
        </div>
        <div className="main-content secdiv">
          <div className="left-col">
            <div className="ls-area-body">
              {WorldData1 && WorldData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBasedNews
                    categoryData={WorldData1.posts}
                    compHeadTxt={"विदेश"}
                  />
                </LazyLoad>
              )}
            </div>
            {/* <div className="emobile">
                  <div id="target-14"></div>
              </div> */}
          </div>

          <div className="main-col">
            <div className="ls-area-body">
              {NationaltData1 && NationaltData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBaseColComp
                    categoryData={NationaltData1.posts}
                    compHeadTxt={"देश"}
                  />
                </LazyLoad>
              )}
            </div>
            <div className="emobile">
              <div id="target-14"></div>
            </div>
          </div>

          <div className="right-col">
            <div className="ls-area-body">
              {JagranSpecialData1 && JagranSpecialData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBasedNews
                    categoryData={JagranSpecialData1.posts}
                    compHeadTxt={"जागरण विशेष"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
        </div>
        <div
          className="ads medium-728x90 ewebf"
          style={{ marginBottom: "30px", clear: "both" }}
        >
          <div id="target-5"></div>
        </div>
        <div className="emobile">
          <div className="ads medium-300x250">
            <div id="target-9"></div>
          </div>
        </div>
        <div className="main-content secdiv">
          <div className="left-col">
            <div className="ls-area-body">
              {BusinessData1 && BusinessData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBasedNews
                    categoryData={BusinessData1.posts}
                    compHeadTxt={"बिझनेस"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
          <div className="main-col">
            <div className="ls-area-body">
              {EntertainmentData1 && EntertainmentData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBaseColComp
                    categoryData={EntertainmentData1.posts}
                    compHeadTxt={"मनोरंजन"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">
              {SportsData1 && SportsData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBasedNews
                    categoryData={SportsData1.posts}
                    compHeadTxt={"क्रिकेट"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
        </div>

        <div className="main-content secdiv">
          <div className="left-col">
            <div className="ls-area-body">
              {FoodData1 && FoodData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBasedNews
                    categoryData={FoodData1.posts}
                    compHeadTxt={"फूड"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
          <div className="main-col">
            <div className="ls-area-body">
              {HelathData1 && HelathData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBaseColComp
                    categoryData={HelathData1.posts}
                    compHeadTxt={"आरोग्य"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
          <div className="right-col">
            <div className="ls-area-body">
              {ReligiontData1 && ReligiontData1.posts.length > 0 && (
                <LazyLoad>
                  <CategoryBasedNews
                    categoryData={ReligiontData1.posts}
                    compHeadTxt={"धर्म"}
                  />
                </LazyLoad>
              )}
            </div>
          </div>
        </div>

        <div className="taboolaads">
          <div id="taboola-below-home-thumbnails"></div>
        </div>
      </Layout>
    </>
  );
}
export const getServerSideProps = async (context) => {
  //const {urlParameter} = context;
  //const {category, id} = urlParameter;
  const currentDate = new Date();
  const payload = { headers: { Authorization: process.env.API_TOKEN } };

  let timeInMinutes = currentDate.getMinutes() * 60;
  const HomePoneData = await axios
    .get(PageAPI.HomePone_API + "?v" + timeInMinutes, payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  let homeId = HomePoneData?.posts.map((el) => el.id) || [];

  const webStoriesData1 = await axios
    .get(PageAPI.webStories_API)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log("webStoriesData1 err");
      return null;
    });
  function CategoryDataa(category, nuOfStory) {
    return PageAPI.Category_API + category + "/1/" + nuOfStory;
  }
  function CategoryDataExcludeId(category, nuOfStory, ids) {
    return (
      PageAPI.Category_API + category + "/1/" + nuOfStory + "?exclude=" + ids
    );
  }
  function SubCategoryDataa(category, subCategory, nuOfStory) {
    return (
      PageAPI.SubcategoryListing_API +
      category +
      "/" +
      subCategory +
      "/1/" +
      nuOfStory
    );
  }
  let StateDate = await axios
    .get(CategoryDataExcludeId("maharashtra", 4, homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error.message);
      return null;
    });
  // StateDate.posts = StateDate?.posts?.filter((el,index) => {
  //   if (HomePoneData?.posts?.some(e => e.id == el.id)) {
  //     return false
  //   } else {
  //     return el
  //   }
  // }).slice(0, 4)
  let stateId = StateDate?.posts?.map((el) => el.id) || [];
  const JagranSpecialData1 = await axios
    .get(CategoryDataExcludeId("jagran-special", 4, homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const EntertainmentData1 = await axios
    .get(CategoryDataExcludeId("entertainment", 8, homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const SportsData1 = await axios
    .get(CategoryDataExcludeId("sports", 4, homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  // const Politics = await axios.get(CategoryDataa ('maharashtra-politics', 4)).then( (resp) => {return resp.data} ).catch( (error) => {console.log(error); return null} );
  const ReligiontData1 = await axios
    .get(CategoryDataExcludeId("religion", 4,homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const NationaltData1 = await axios
    .get(CategoryDataExcludeId("national", 8,homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const FoodData1 = await axios
    .get(SubCategoryDataa("lifystyle", "food", 4), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const ListingPath_API =
    PageAPI.TagwordBase_API +
    "maharashtra-politics/1/4?exclude=" +
    [...stateId, ...homeId].join(",");
  const Politics = await axios
    .get(ListingPath_API, payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      return null;
    });

  const HelathData1 = await axios
    .get(SubCategoryDataa("lifystyle", "health", 8), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const BusinessData1 = await axios
    .get(CategoryDataExcludeId("business", 4,homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  const WorldData1 = await axios
    .get(CategoryDataExcludeId("international", 4,homeId?.join(",")), payload)
    .then((resp) => {
      return resp.data;
    })
    .catch((error) => {
      console.log(error);
      return null;
    });
  return {
    props: {
      StateDate,
      JagranSpecialData1,
      EntertainmentData1,
      SportsData1,
      Politics,
      ReligiontData1,
      HelathData1,
      FoodData1,
      BusinessData1,
      WorldData1,
      NationaltData1,
      HomePoneData,
      webStoriesData1,
    },
  };
};
