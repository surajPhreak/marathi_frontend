// document.getElementById('txtmenu').addEventListener('click', function(event){
//   event.preventDefault();
//   document.getElementById('sidebar-hamburger').classList.toggle('opn');
// });
// document.getElementById('sidebar-close').addEventListener('click', function(){
//   document.getElementById('sidebar-hamburger').classList.toggle('opn');  
// });

document.getElementById('searchPopup').addEventListener('click', function(event){
  event.preventDefault();
  document.getElementById('search_popup').classList.toggle('opn');
});
document.getElementById('close_search').addEventListener('click', function(){
  document.getElementById('search_popup').classList.toggle('opn');  
});
// document.getElementById('notification').addEventListener('click', function(event){
//   event.preventDefault();
//   document.getElementById('notification-popup').classList.toggle('show');
// });
// document.getElementById('close-notification').addEventListener('click', function(event){
//   event.preventDefault();
//   document.getElementById('notification-popup').classList.toggle('show');
// });

/*GDPR JS*/
function readCookie(name){
  var nameEQ = name + "=";
  var ca = document.cookie.split(';');
  for(var i=0;i < ca.length;i++) {
      var c = ca[i];
      while (c.charAt(0)==' ') c = c.substring(1,c.length);
      if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
  }
  return null;
}
function createCookie(name,value,days) {
  if(days){
      var date = new Date();
      date.setTime(date.getTime()+(days*24*60*60*1000));
      var expires = "; expires="+date.toGMTString();
  }
  else var expires = "";
  document.cookie = name+"="+value+expires+"; path=/";
}
if ( !readCookie('hide') ) {  document.getElementById('gdprbx').style.display='block'; }
document.getElementById('close-btn').addEventListener('click', function(){
    document.getElementById('gdprbx').style.display='none';
    createCookie('hide', true, 60);
    return false;
});
/*GDPR JS*/

/*Search*/
function searchTxt(event){
  event.preventDefault();
  if(document.getElementById('searchText').value != 'Type Your search' && document.getElementById('searchText').value != ''){
    var myStr =  document.getElementById('searchText').value;
    myStr=myStr.replace(/(^\s+|[^a-zA-Z0-9\u0900-\u097F ]+|\s+$)/g,"").toLowerCase();
    myStr=myStr.replace(/\s+/g, "-");
    window.location.href = '/search/'+myStr;
    return false;
  }
}
//document.getElementById('clickSearchValue1').addEventListener('click', searchTxt);
//document.getElementById('searchText').addEventListener('onblur', searchTxt);
document.getElementById("searchForm").addEventListener("submit", searchTxt);
/*Search*/
/*eweb and emobile responsive js*/
var widthWindow = window.innerWidth;
const elementsWeb = document.getElementsByClassName("eweb");
const elementsMob = document.getElementsByClassName("emobile");
if(widthWindow >= 1024){ while(elementsMob.length > 0){ elementsMob[0].parentNode.removeChild(elementsMob[0]); }  }
else{ while(elementsWeb.length > 0){ elementsWeb[0].parentNode.removeChild(elementsWeb[0]); } }
/*eweb and emobile ad remove js*/

/*Image height width*/
document.addEventListener("DOMContentLoaded", function(){
var imgE2 = document.getElementsByTagName('img');
for (var n=0; n < imgE2.length; n++) {
imgE2[n].setAttribute('width',imgE2[n].offsetWidth);
imgE2[n].setAttribute('height','100%');  
}
});

let val=readCookie('hide')

var _comscore = _comscore || [];
_comscore.push({
    c1: "2",
    c2: "13184768",
    cs_ucfr:val?"1":"",
    options:{
      enableFirstPartyCookie:true
    }
});
(function() {
    var s = document.createElement("script"),
        el = document.getElementsByTagName("script")[0];
    s.async = true;
    s.src = "https://sb.scorecardresearch.com/cs/13184768/beacon.js";
    s.id="comscoreScript"
    el.parentNode.insertBefore(s, el);
})();