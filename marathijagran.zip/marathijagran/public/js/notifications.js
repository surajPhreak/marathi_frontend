console.log("script");
const checkPermission = () => {
  if (!("serviceWorker" in navigator)) {
    throw new Error("No support for service worker!");
  }

  if (!("Notification" in window)) {
    throw new Error("No support for notification API");
  }

  if (!("PushManager" in window)) {
    throw new Error("No support for Push API");
  }
};

function getBrowserType() {
  if (
    (navigator.userAgent.indexOf("Opera") ||
      navigator.userAgent.indexOf("OPR")) != -1
  ) {
    return "Opera";
  } else if (navigator.userAgent.indexOf("Chrome") != -1) {
    return "Chrome";
  } else if (navigator.userAgent.indexOf("Safari") != -1) {
    return "Safari";
  } else if (navigator.userAgent.indexOf("Firefox") != -1) {
    return "Firefox";
  } else if (
    navigator.userAgent.indexOf("MSIE") != -1 ||
    !!document.documentMode == true
  ) {
    return "IE";
  } else {
    return "Unknown";
  }
}


function getDeviceType() {
  const userAgent = navigator.userAgent;
  if (/Mobi|Android/i.test(userAgent)) {
    if (/iPad|Android(?!.*Mobile)|Tablet/i.test(userAgent)) {
      // return 'Tablet';
      return "mobile";
    } else {
      return "mobile";
    }
  } else {
    return "desktop";
  }
}
const getCategory = () => {
  let url = window?.location?.pathname?.split("/");
  console.log('url',window?.location?.pathname)
  if (url && url[1]) {
    return url[1];
  } else if (window?.location?.pathname == '/') {
    return 'home'
   }
  else {
    return "";
  }
};
const registerSw = async () => {
  if ("serviceWorker" in navigator) {
    const domain = window.location.hostname;
    try {
      const registration = await navigator.serviceWorker.register(
        "/js/sw.bundles.js?v=1"
      );
      registration.active;
      if (localStorage.getItem("wp")) {
        if (registration?.active) {
          registration?.active?.postMessage({
            userData: JSON.parse(localStorage.getItem("wp")),
            type: "active user",
          });
        }
        
        else if (registration?.installing)
          registration?.installing?.postMessage({
            userData: JSON.parse(localStorage.getItem("wp")),
            type: "install user",
          });

        // self.dispatchEvent(new ExtendableEvent("pushsubscriptionchange"));
      } else {

        registration?.installing?.postMessage({
          data: {
            browser: getBrowserType(),
            device: getDeviceType(),
            domain: 'marathijagran.com',
            type: "install",
            lang: ["mr"],
            category:getCategory()
          },
        });
        // registration?.active?.postMessage({ data: { browser: getBrowserType(), device: getDeviceType(), domain: domain ,type:'active',lang:['mr']} });
      }
    } catch (err) {
      console.error("Service worker registration failed:", err);
    }
  }
};
//   function showPosition(position) {}
const requestNotificationPermission = async () => {
  const permission = await Notification.requestPermission();
  if (navigator.geolocation)
    if (permission !== "granted") {
      // navigator.geolocation.getCurrentPosition(showPosition);
      //throw new Error("Notification permission not granted")
    }
};
navigator.serviceWorker.addEventListener("message", (event) => {
  if (event.data && event.data.response) {
    const receivedData = event.data.response;

    handleResponseData(receivedData);
  }
});
const main = async () => {
  //checkPermission
  checkPermission();

  //request

  await requestNotificationPermission();
//register
  await registerSw();
  //saved1
};

const channel = new BroadcastChannel("myChannel");

channel.addEventListener("message", (event) => {
  if (event.data.type === "saveData") {
    if (event?.data?.response?.id)
      localStorage.setItem(
        "wp",
        JSON.stringify({ id: event.data.response.id, t: Date.now(),lang:event.data.response.lang })
      );
  }
});
main();
